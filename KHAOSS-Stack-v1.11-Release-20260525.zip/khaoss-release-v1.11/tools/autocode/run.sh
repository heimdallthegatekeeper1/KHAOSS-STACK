#!/usr/bin/env bash
# BW_R80P79_STANDALONE_PKG — Beewid Autocode Standalone launcher (Linux/Mac)
# First run: creates .venv + installs requirements. Subsequent runs: just boots.
set -e
cd "$(dirname "$0")"

# BW_STANDALONE_DIST=1 tells the server to inject ?dist=1 into its /popout
# redirect, which the instance.html then reads to mark "BEEWID ONLY" features.
export BW_STANDALONE_DIST=1

if [ ! -d ".venv" ]; then
  echo "First run — setting up Python virtual environment (one-time, ~30s)…"
  python3 -m venv .venv
  ./.venv/bin/pip install --quiet --upgrade pip
  ./.venv/bin/pip install --quiet -r requirements.txt
  echo "Setup complete."
fi

PORT="${BEEWID_STANDALONE_AUTOCODE_PORT:-8508}"
echo ""
echo "════════════════════════════════════════════════════════════════"
echo "  Beewid Autocode Standalone"
echo "  → http://127.0.0.1:${PORT}"
echo "  Ctrl+C to stop"
echo "════════════════════════════════════════════════════════════════"
echo ""
./.venv/bin/python beewid_autocode_standalone_server.py --port "$PORT"
