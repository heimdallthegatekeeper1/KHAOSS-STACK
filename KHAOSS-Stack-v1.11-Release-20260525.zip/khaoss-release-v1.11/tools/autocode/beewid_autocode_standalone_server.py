"""
beewid_autocode_standalone_server.py — BW_R80P72B
Standalone autocode server. Spawned by main API on demand via
POST /autocode/spawn-popout. Runs on its own port (8508-8520).

Serves the canonical autocode sub-tab manager + instance UI. Reuses
beewid_autocode_engine directly so it remains functional even when
the main API (:8506) is down — true lifeboat behavior.

Run standalone:  python3 beewid_autocode_standalone_server.py --port 8508
"""
import os, sys, json, asyncio, time, argparse
from pathlib import Path

# BW_R80P79_PHASEE — Process start time + configurable port.
# Port default :8508 (what Phase A/E logs confirm); overridable via env var.
_STANDALONE_START_TIME = time.time()
STANDALONE_PORT = int(os.environ.get('BEEWID_STANDALONE_AUTOCODE_PORT', 8508))
from starlette.applications import Starlette
from starlette.responses import HTMLResponse, JSONResponse, FileResponse, RedirectResponse, StreamingResponse, PlainTextResponse
from starlette.routing import Route, Mount
from starlette.staticfiles import StaticFiles
from starlette.requests import Request
import uvicorn

# BW_R80P72B — Paths
COCKPIT_DIR = Path(__file__).resolve().parent
LOG_DIR     = COCKPIT_DIR.parent / 'logs'
LOG_DIR.mkdir(parents=True, exist_ok=True)
CREDS_FILE  = Path.home() / '.claude' / '.credentials.json'

# BW_R80P72B — Clear API key env so claude-code uses OAuth (Max Plan) not API billing.
os.environ.pop('ANTHROPIC_API_KEY', None)
os.environ.pop('ANTHROPIC_TOKEN',   None)

# BW_R80P72B — sys.path so we can import beewid_autocode_engine
if str(COCKPIT_DIR) not in sys.path:
    sys.path.insert(0, str(COCKPIT_DIR))

# Try canonical engine import. If it fails, we fall back to proxying to main API.
_ENGINE_AVAILABLE = False
_ENGINE_IMPORT_ERROR = ''
try:
    from beewid_autocode_engine import (  # type: ignore
        run_autocode_stream as _engine_stream,
        export_autocode_report as _engine_export,
    )
    _ENGINE_AVAILABLE = True
except Exception as _eimp:
    _ENGINE_IMPORT_ERROR = repr(_eimp)


def _make_log(port: int):
    path = LOG_DIR / f'standalone_{port}.log'
    def _log(msg: str) -> None:
        ts = time.strftime('%H:%M:%S')
        try:
            with path.open('a') as f:
                f.write(f'[{ts}] [STANDALONE:{port}] {msg}\n')
        except Exception:
            pass
    return _log


async def _proxy_to_main_run_stream(request, _log):
    """BW_R80P72B — Fallback when engine import failed. Proxies the SSE stream
    from the main API at :8506. Lifeboat is degraded to "works when main IS up"."""
    import httpx as _hxp
    try:
        body = await request.json()
    except Exception:
        body = {}

    async def gen():
        try:
            async with _hxp.AsyncClient(timeout=None) as c:
                async with c.stream(
                    'POST', 'http://127.0.0.1:8506/autocode/run-stream',
                    json=body,
                    headers={'Content-Type': 'application/json'},
                ) as r:
                    async for chunk in r.aiter_raw():
                        if chunk:
                            yield chunk
        except Exception as e:
            _log(f'proxy fallback failed: {e}')
            yield (f"data: {json.dumps({'type':'error','message':f'proxy fallback: {e}'})}\n\n").encode()
            yield (f"data: {json.dumps({'type':'done','ok':False})}\n\n").encode()

    return StreamingResponse(gen(), media_type='text/event-stream',
                             headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'})


def build_app(port: int) -> Starlette:
    _log = _make_log(port)
    _log(f'init — engine_available={_ENGINE_AVAILABLE} import_err={_ENGINE_IMPORT_ERROR!r}')

    async def health(_: Request) -> JSONResponse:
        return JSONResponse({
            'ok': True,
            'service': 'beewid_autocode_standalone',
            'version': 'r80p79-phasee',          # BW_R80P79_PHASEE
            'uptime_s': round(time.time() - _STANDALONE_START_TIME, 1),  # BW_R80P79_PHASEE
            'leg': 'c',                          # BW_R80P79_PHASEE — triple-redundancy leg C
            'port': port,
            'oauth_creds_present': CREDS_FILE.exists(),
            'engine_available': _ENGINE_AVAILABLE,
            'engine_import_error': _ENGINE_IMPORT_ERROR if not _ENGINE_AVAILABLE else '',
            'marker': 'BW_R80P72B',
        })

    async def popout_page(_: Request):
        """Serve the canonical sub-tab manager with ?popout=1 marker.

        BW_R80P79_STANDALONE_PKG — when launched via the packaged distribution
        (run.sh / run.bat sets BW_STANDALONE_DIST=1), also append &dist=1 so the
        instance UI knows to mark Beewid-only features. Live-cockpit launches
        don't set the env var, so dist=1 isn't injected and no marking happens.
        """
        mgr = COCKPIT_DIR / 'beewid_autocode.html'
        if not mgr.exists():
            return HTMLResponse(
                f'<h1>autocode manager missing</h1><p>{mgr}</p>', status_code=500)
        _dist_suffix = '&dist=1' if os.environ.get('BW_STANDALONE_DIST') == '1' else ''
        return RedirectResponse(url=f'/beewid_autocode.html?popout=1{_dist_suffix}',
                                status_code=302)

    async def root(_: Request):
        return RedirectResponse(url='/popout', status_code=302)

    # ─────────────────────────────────────────────────────────────
    # Autocode endpoints — mirror the main API's shape so the canonical
    # instance UI works against this server unchanged.
    # ─────────────────────────────────────────────────────────────
    async def autocode_status(_: Request):
        import shutil
        cc = shutil.which('claude')
        return JSONResponse({'available': cc is not None, 'path': cc or ''})

    # BW_STANDALONE_SYNC — native escape hatches. The engine is imported in-process,
    # so the A1 raw buffer and the PT1C ring are ALREADY in this server's memory for
    # any run it spawned. Expose both natively so the lifeboat works when :8506 is DOWN
    # (the whole point). Mirrors api.py /autocode/ring-dump + /autocode/raw-stream.
    async def autocode_ring_dump_native(request: Request):
        run_id = request.path_params.get('run_id', '')
        if not _ENGINE_AVAILABLE:
            return PlainTextResponse('engine not available on this leg; use main :8506',
                                     status_code=503)
        from beewid_autocode_engine import (
            _bw_r80p79pt1c_p1_get_ring_events_since as _evs,
            _bw_r80p79pt1c_p1_get_ring_info as _info,
        )
        events = _evs(run_id, since_seq=-1)
        info = _info(run_id)
        out = [f'=== STANDALONE RING DUMP (leg C) — run_id: {run_id} ===',
               f'events: {len(events)}  ring_info: {info}', '=' * 60]
        for ev in events:
            if isinstance(ev, dict):
                t = ev.get('type', '?')
                if t == 'output':
                    out.append(ev.get('text', ''))
                else:
                    out.append(f'[{t}] ' + json.dumps({k: v for k, v in ev.items()
                                                       if k != '_event_seq'})[:400])
            else:
                out.append(str(ev)[:400])
        return PlainTextResponse('\n'.join(out))

    async def autocode_raw_stream_native(request: Request):  # BW_STANDALONE_SYNC
        run_id = request.path_params.get('run_id', '')
        if not _ENGINE_AVAILABLE:
            return PlainTextResponse('engine not available on this leg; use main :8506',
                                     status_code=503)
        import asyncio as _aio
        from beewid_autocode_engine import (
            _bw_trio_a1_get_raw_tail as _tail,
            _bw_trio_a1_subscribe as _sub,
            _bw_trio_a1_unsubscribe as _unsub,
            _ACTIVE_RUNS as _ar,
        )

        async def _gen():
            yield (f'=== STANDALONE RAW STREAM (leg C) — run_id: {run_id} ===\n'
                   f'(ring-INDEPENDENT escape hatch; native on :{port})\n'
                   f'{"=" * 60}\n').encode('utf-8', 'replace')
            try:
                for ln in _tail(run_id):
                    yield (ln + '\n').encode('utf-8', 'replace')
            except Exception:
                pass
            q = None
            try:
                q = _sub(run_id)
            except Exception:
                q = None
            if q is not None:
                try:
                    while True:
                        try:
                            if await request.is_disconnected():
                                break
                        except Exception:
                            pass
                        try:
                            ln = await _aio.wait_for(q.get(), timeout=1.0)
                        except _aio.TimeoutError:
                            # mirror api.py: break if run is no longer active
                            if _ar.get(run_id, {}).get('terminal_state') != 'running':
                                break
                            continue
                        if ln is None:
                            break
                        yield (ln + '\n').encode('utf-8', 'replace')
                finally:
                    try:
                        _unsub(run_id, q)
                    except Exception:
                        pass
            yield b'\n=== stream ended ===\n'

        return StreamingResponse(_gen(), media_type='text/plain')

    async def autocode_run_stream(request: Request):
        if not _ENGINE_AVAILABLE:
            # BW_R80P72B — engine missing; proxy to main API as last resort
            return await _proxy_to_main_run_stream(request, _log)

        try:
            body = await request.json()
        except Exception:
            body = {}
        prompt        = (body.get('prompt') or '').strip()
        if not prompt:
            return JSONResponse({'ok': False, 'error': 'empty prompt'}, status_code=400)
        mode          = (body.get('mode') or 'standard').strip().lower()
        # BW_R80P74E — Pin to direct (OAuth). Standalone server was defaulting to
        # cloud-anthropic-proxy when no backend field specified; popout windows
        # inherited this default and hit the proxy 401 loop after r80p74c fixed
        # the main API but not this file. Same sledgehammer as r80p74c.
        requested_backend = (body.get('backend') or '').strip().lower()  # informational
        backend = 'cloud-anthropic-direct'
        instance_id   = body.get('instance_id') or 'main'
        model         = body.get('model') or 'claude-sonnet-4-6'
        # BW_R80P74K — None/null budget from panel's ∞ toggle → high ceiling
        _bw_r80p74k_b = body.get('budget')
        budget        = 10_000_000 if _bw_r80p74k_b is None else int(_bw_r80p74k_b or 50000)
        api_key       = body.get('api_key') or ''
        tui           = body.get('tui') or 'claude-code'
        intrusion     = int(body.get('intrusion_level') or 1)
        custom_flags  = body.get('custom_flags') or None
        auto_approve  = body.get('auto_approve_tools') or []
        structured    = bool(body.get('structured_report', True))

        _log(f'run start instance={instance_id} mode={mode} model={model} '
             f'prompt_chars={len(prompt)}')

        async def event_gen():
            collected = []
            outcome = {'mode': mode}
            try:
                async for event in _engine_stream(
                    prompt             = prompt,
                    tui                = tui,
                    backend            = backend,
                    model              = model,
                    budget             = budget,
                    api_key_override   = api_key,
                    timeout_seconds    = 600,
                    instance_id        = instance_id,
                    intrusion_level    = intrusion,
                    mode               = mode,
                    custom_flags       = custom_flags,
                    auto_approve_tools = auto_approve,
                    structured_report  = structured,
                ):
                    collected.append(event)
                    et = event.get('type')
                    if et == 'done':
                        outcome['ok'] = event.get('ok', event.get('success', False))
                        outcome['returncode'] = event.get(
                            'returncode', -1 if not outcome.get('ok') else 0)
                    yield f"data: {json.dumps(event)}\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'type':'error','message':f'engine exception: {e}'})}\n\n"
                yield f"data: {json.dumps({'type':'done','ok':False,'success':False})}\n\n"

            # Post-stream report write
            try:
                report = _engine_export(instance_id, prompt, collected, outcome)
                if report.get('ok'):
                    ev = {'type': 'report_saved', 'path': report['path']}
                else:
                    ev = {'type': 'error', 'message': f"report save failed: {report.get('error')}"}
                yield f"data: {json.dumps(ev)}\n\n"
            except Exception as e:
                yield f"data: {json.dumps({'type':'error','message':f'report exception: {e}'})}\n\n"

            _log(f'run end instance={instance_id} ok={outcome.get("ok")}')

        return StreamingResponse(
            event_gen(),
            media_type='text/event-stream',
            headers={'Cache-Control': 'no-cache', 'X-Accel-Buffering': 'no'},
        )

    # BW_R80P74K — Approval response forwarder mirror. Standalone runs its
    # own engine (when import succeeded), so it needs its own route into the
    # in-memory queue. Identical contract to main API's /autocode/approval-response.
    async def autocode_approval_response(request: Request):
        if not _ENGINE_AVAILABLE:
            return JSONResponse(
                {'ok': False, 'error': 'engine not available in standalone'},
                status_code=503,
            )
        try:
            body = await request.json()
        except Exception:
            body = {}
        instance_id = (body.get('instance_id') or '').strip()
        approval_id = (body.get('approval_id') or '').strip()
        decision    = (body.get('decision') or '').strip()
        if decision not in ('allow', 'deny', 'always_allow'):
            return JSONResponse(
                {'ok': False, 'error': f'invalid decision: {decision!r}'},
                status_code=400,
            )
        try:
            from beewid_autocode_engine import _bw_r80p74j_post_response as _post
        except Exception as e:
            return JSONResponse(
                {'ok': False, 'error': f'engine import: {e!r}'},
                status_code=500,
            )
        ok = _post(instance_id, approval_id, decision)
        return JSONResponse({'ok': bool(ok), 'instance_id': instance_id,
                             'approval_id': approval_id, 'decision': decision})

    # BW_R80P79_POPOUT_UNIFY — Generic /autocode/* proxy to main API (:8506).
    # WHY: standalone natively implements only 3 endpoints (status, run-stream,
    # approval-response) — the "lifeboat" set. The canonical instance UI loaded
    # in popout iframes makes 22+ other autocode fetches (runs/active, runs/{id}/
    # resources, capture-diag, stage-file, kill-run, etc.) using bare relative
    # paths, which resolved to this server and 404'd. This catch-all forwards
    # everything not matched by the native routes above to :8506.
    #
    # Listed AFTER the specific autocode routes so they win (Starlette uses
    # first-match), and BEFORE the static mounts so it intercepts before they
    # try to serve a non-existent file.
    #
    # Lifeboat semantics preserved: run-stream stays native and keeps streaming
    # even when :8506 is down. Only secondary endpoints depend on :8506.
    async def autocode_proxy_to_main(request: Request):
        import httpx as _hxp_pr
        _log = _make_log(port)
        rest = request.path_params.get('rest', '')
        # Forward to main api preserving query string + method + body + headers.
        upstream = f'http://127.0.0.1:8506/autocode/{rest}'
        qs = request.url.query
        if qs:
            upstream = upstream + '?' + qs
        # Forward all headers except host/content-length (httpx sets these).
        fwd_headers = {}
        for k, v in request.headers.items():
            lk = k.lower()
            if lk in ('host', 'content-length', 'connection'):
                continue
            fwd_headers[k] = v
        # Read body bytes (works for JSON, multipart, empty — any content-type).
        try:
            body_bytes = await request.body()
        except Exception as e:
            return JSONResponse({'ok': False, 'error': f'body read failed: {e!r}'},
                                status_code=400)
        # BW_R80P79_STANDALONE_PKG — fail-fast proxy timeout (was 30s).
        # Protects the lifeboat: when :8506 is down, secondary endpoint proxies
        # must fail fast (2.5s) rather than hang the standalone. Native
        # run-stream is unaffected (it doesn't go through this proxy and has
        # its own no-timeout AsyncClient for SSE streaming).
        try:
            async with _hxp_pr.AsyncClient(timeout=2.5) as client:
                resp = await client.request(
                    request.method, upstream,
                    content=body_bytes, headers=fwd_headers,
                )
            # Filter hop-by-hop headers from upstream response.
            out_headers = {}
            for k, v in resp.headers.items():
                lk = k.lower()
                if lk in ('transfer-encoding', 'content-encoding', 'content-length',
                          'connection', 'keep-alive'):
                    continue
                out_headers[k] = v
            from starlette.responses import Response as _StResp
            return _StResp(content=resp.content, status_code=resp.status_code,
                           headers=out_headers,
                           media_type=resp.headers.get('content-type'))
        except _hxp_pr.ConnectError as e:
            _log(f'proxy {request.method} /autocode/{rest} → main :8506 unreachable: {e}')
            return JSONResponse(
                {'ok': False, 'error': f'main api :8506 unreachable: {e!r}',
                 'proxied_path': f'/autocode/{rest}'},
                status_code=503,
            )
        except Exception as e:
            _log(f'proxy {request.method} /autocode/{rest} failed: {e!r}')
            return JSONResponse(
                {'ok': False, 'error': f'proxy failed: {e!r}',
                 'proxied_path': f'/autocode/{rest}'},
                status_code=502,
            )

    # Routes
    routes = [
        Route('/health',                health,             methods=['GET']),
        Route('/popout',                popout_page,        methods=['GET']),
        Route('/',                      root,               methods=['GET']),
        Route('/autocode/status',       autocode_status,    methods=['GET']),
        Route('/autocode/run-stream',   autocode_run_stream, methods=['POST']),
        Route('/autocode/approval-response', autocode_approval_response, methods=['POST']),
        # BW_STANDALONE_SYNC — native escape hatches BEFORE the catch-all proxy.
        Route('/autocode/ring-dump/{run_id}',  autocode_ring_dump_native, methods=['GET']),
        Route('/autocode/raw-stream/{run_id}', autocode_raw_stream_native, methods=['GET']),
        # BW_R80P79_POPOUT_UNIFY — catch-all /autocode/* proxy (see autocode_proxy_to_main).
        # Must come AFTER the three specific autocode routes above so they win first-match.
        Route('/autocode/{rest:path}',  autocode_proxy_to_main,
              methods=['GET', 'POST', 'PUT', 'DELETE', 'PATCH']),
        # BW_R80P72C — serve /static/* from cockpit dir so the canonical
        # instance HTML's <link href="/static/beewid_theme.css"> resolves.
        # Mirrors api.py:826 in the main app. MUST be listed BEFORE the
        # catch-all '/' mount because Starlette matches the first hit.
        Mount('/static', app=StaticFiles(directory=str(COCKPIT_DIR), html=False)),
        # BW_R80P72B — static mount for cockpit dir last (catch-all)
        Mount('/', app=StaticFiles(directory=str(COCKPIT_DIR), html=False)),
    ]
    return Starlette(debug=False, routes=routes)


def main():
    parser = argparse.ArgumentParser()
    # BW_R80P79_PHASEE — default from env var (BEEWID_STANDALONE_AUTOCODE_PORT), then :8508
    parser.add_argument('--port', type=int, default=STANDALONE_PORT)
    parser.add_argument('--host', default='127.0.0.1')
    args = parser.parse_args()
    app = build_app(args.port)
    uvicorn.run(app, host=args.host, port=args.port, log_level='warning')


if __name__ == '__main__':
    main()
