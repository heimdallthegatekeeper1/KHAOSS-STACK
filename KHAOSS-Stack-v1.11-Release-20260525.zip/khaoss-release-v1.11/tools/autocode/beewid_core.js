/**
 * BEEWID CORE v1.2
 * Sidebar nav, topbar, API client, SSE, model status,
 * notifications, session helpers, kill switch, log panel.
 *
 * v1.2 additions:
 *   - Topbar: permission dropdown (L0–L3), ☢ NUKE, ↺ OLLAMA restart
 *   - Kill switch body fixed: { enabled: false/true }
 *   - Export button visual feedback (flash ✓)
 *   - BW_nukeOllama / BW_restartOllama / BW_setPolicy globals
 *
 * Every page needs:
 *   <link rel="stylesheet" href="/static/beewid_theme.css">
 *   <div id="bw-nav"></div>   ← before page content
 *   <script src="/static/beewid_core.js"></script>
 */

// BW_R80P62 — Diagnostics instrumentation, installed at core.js load.
// Captures console output, network errors, JS errors, and unhandled rejections
// into a ring buffer that BeewidDiagnostics.capture() reads later.
// MUST run before any other beewid code so it sees everything from page load.
(function () {
  if (window.__bwDiagInstalled) return;
  window.__bwDiagInstalled = true;

  var MAX_CONSOLE  = 500;
  var MAX_NETWORK  = 200;
  var MAX_ERRORS   = 100;

  var _buffers = {
    console: [],
    network: [],
    errors:  [],
    startedAt: new Date().toISOString()
  };
  window.__bwDiagBuffers = _buffers;

  function _push(arr, entry, cap) {
    arr.push(entry);
    if (arr.length > cap) arr.shift();
  }
  function _now() { return new Date().toISOString(); }

  // --- Console proxy (info/log/warn/error/debug) ---
  ['log', 'info', 'warn', 'error', 'debug'].forEach(function (level) {
    var orig = console[level];
    console[level] = function () {
      try {
        var args = Array.prototype.slice.call(arguments).map(function (a) {
          if (a instanceof Error) return a.stack || (a.name + ': ' + a.message);
          if (typeof a === 'object') {
            try { return JSON.stringify(a); } catch (e) { return String(a); }
          }
          return String(a);
        });
        _push(_buffers.console, { t: _now(), level: level, msg: args.join(' ') }, MAX_CONSOLE);
      } catch (e) { /* never break console */ }
      return orig.apply(console, arguments);
    };
  });

  // --- Network tap (failed fetches, non-2xx responses) ---
  if (window.fetch) {
    var origFetch = window.fetch;
    window.fetch = function (resource, options) {
      var url    = (typeof resource === 'string') ? resource : (resource && resource.url) || String(resource);
      var method = (options && options.method) || 'GET';
      var t0 = performance.now();
      return origFetch.apply(window, arguments)
        .then(function (resp) {
          var dt = Math.round(performance.now() - t0);
          if (!resp.ok) {
            _push(_buffers.network, {
              t: _now(), method: method, url: url, status: resp.status,
              statusText: resp.statusText, durationMs: dt
            }, MAX_NETWORK);
          }
          return resp;
        })
        .catch(function (err) {
          var dt = Math.round(performance.now() - t0);
          _push(_buffers.network, {
            t: _now(), method: method, url: url, status: 0,
            statusText: 'fetch failed: ' + (err.message || err),
            durationMs: dt
          }, MAX_NETWORK);
          throw err;
        });
    };
  }

  // --- Global error capture ---
  window.addEventListener('error', function (ev) {
    _push(_buffers.errors, {
      t: _now(), kind: 'error',
      msg: ev.message || String(ev.error),
      src: ev.filename || '',
      line: ev.lineno, col: ev.colno,
      stack: (ev.error && ev.error.stack) || ''
    }, MAX_ERRORS);
  });
  window.addEventListener('unhandledrejection', function (ev) {
    var r = ev.reason;
    _push(_buffers.errors, {
      t: _now(), kind: 'unhandledrejection',
      msg: (r && (r.message || r.toString())) || 'unknown rejection',
      stack: (r && r.stack) || ''
    }, MAX_ERRORS);
  });

  console.info('[BW_R80P62] Diagnostics instrumentation installed at', _buffers.startedAt);
})();

(function (W) {
  'use strict';
  /* BW_PANEL_BAIL — skip bar injection in copilot iframe */
  if (typeof location !== 'undefined' && location.search.indexOf('panel=1') > -1) return;

  const API_BASE = 'http://127.0.0.1:8506';

  /* ── Tab registry ─────────────────────────────────────────── */
  // BW_R80P79_GUI_HARDEN — Canonical NAV order per 8th Opus spec (May 2026).
  // Two regions: "Main work" (tabs 1-6) and "Settings region" (tabs 7-9).
  // Governance absorbed into Settings (beewid_governance.html file preserved).
  // null entry renders as .bw-nav-divider between regions.
  const TABS = [
    // ─── Main work ───
    { id: 'chat',          label: 'Chat',          icon: '◈', file: 'beewid_chat.html'          },
    { id: 'agents',        label: 'Agents',        icon: '◉', file: 'beewid_agents.html'         },
    { id: 'knowledge',     label: 'Knowledge',     icon: '◈', file: 'beewid_knowledge.html'      },
    { id: 'orchestration', label: 'Orchestration', icon: '⬡', file: 'beewid_orchestration.html'  },
    { id: 'trading',       label: 'Trading',       icon: '◆', file: 'beewid_trading.html',       badge: 'IN DEV' },
    { id: 'voice',         label: 'Secretary',     icon: '◎', file: 'beewid_voice.html',         disabled: true, badge: 'SOON' },
    null,
    // ─── Settings region ───
    { id: 'autocode',      label: 'Autocode',      icon: '⬟', file: 'beewid_autocode.html'       },
    { id: 'diagnostics',   label: 'Diagnostics',   icon: '⚕', file: 'beewid_diagnostics.html'    },
    { id: 'settings',      label: 'Settings',      icon: '◇', file: 'beewid_settings.html'       },
  ];

  function getActiveTab() {
    const f = W.location.pathname.split('/').pop() || '';
    for (const t of TABS) { if (t && t.file === f) return t.id; }
    return null;
  }

  /* ── Sidebar ──────────────────────────────────────────────── */
  const HEX = '<svg viewBox="0 0 24 24" xmlns="http://www.w3.org/2000/svg" fill="none" stroke="currentColor" stroke-width="1.5"><path d="M12 2L21.5 7.5V16.5L12 22L2.5 16.5V7.5L12 2Z"/><path d="M12 6.5L18 10.25V17.75L12 21L6 17.75V10.25L12 6.5Z" fill="currentColor" opacity="0.25" stroke="none"/></svg>';

  function injectSidebar() {
    const placeholder = document.getElementById('bw-nav');
    if (!placeholder) return;
    const active = getActiveTab();
    const tabs = TABS.map(t => {
      if (t === null) return '<div class="bw-nav-divider"></div>';
      const cls  = ['bw-nav-item', t.id === active ? 'active' : '', t.disabled ? 'disabled' : ''].filter(Boolean).join(' ');
      const href = t.disabled ? '#' : '/static/' + t.file;
      return '<a class="' + cls + '" href="' + href + '" title="' + t.label + '">'
           + '<span class="bw-nav-icon">' + t.icon + '</span>'
           + '<span class="bw-nav-label">' + t.label + '</span>'
           + (t.badge || t.disabled ? '<span class="bw-nav-tag">' + (t.badge || 'soon') + '</span>' : '') /* BW_R80P79_GUI_HARDEN — badge prop */
           + '</a>';
    }).join('');

    const aside = document.createElement('aside');
    aside.id = 'bw-sidebar';
    aside.innerHTML = '<div class="bw-sidebar-logo">' + HEX + '<span class="bw-sidebar-wordmark">BEEWID</span></div>'
      + '<nav class="bw-nav-list">' + tabs + '</nav>'
      + '<div class="bw-sidebar-footer">'
      /* BW_R119: agent status section */
      + '<div class="bw-agent-status">'
      + '<div class="bw-agent-box" data-agent="w5" onclick="window._bwAgentJump(\'w5\')" title="W5 · open agent hub">'
      + '<div class="bw-dot cold" id="bw-w5-dot"></div>'
      + '<span class="bw-model-name" id="bw-w5-label">W5 · cold</span>'
      + '<button class="bw-agent-popout-btn" onclick="event.stopPropagation();window._bwAgentPopout(\'w5\')" title="W5 controls">⧉</button>'
      + '</div>'
      + '<div class="bw-agent-box" data-agent="w6" onclick="window._bwAgentJump(\'w6\')" title="W6 · open agent hub">'
      + '<div class="bw-dot cold" id="bw-w6-dot"></div>'
      + '<span class="bw-model-name" id="bw-w6-label">W6 · cold</span>'
      + '<button class="bw-agent-popout-btn" onclick="event.stopPropagation();window._bwAgentPopout(\'w6\')" title="W6 controls">⧉</button>'
      + '</div>'
      + '<div class="bw-agent-box" data-agent="w7" onclick="window._bwAgentJump(\'w7\')" title="W7 · open agent hub">'
      + '<div class="bw-dot" id="bw-w7-dot"></div>'
      + '<span class="bw-model-name" id="bw-w7-label">W7 · not configured</span>'
      + '<button class="bw-agent-popout-btn" onclick="event.stopPropagation();window._bwAgentPopout(\'w7\')" title="W7 controls">⧉</button>'
      + '</div>'
      + '<div class="bw-agent-divider"></div>'
      + '<div id="bw-nav-agents-dynamic"></div>'
      + '</div>'
      + '</div>';
    placeholder.replaceWith(aside);
  }

  /* ── Topbar ───────────────────────────────────────────────── */
  function injectTopbar() {
    if (document.getElementById('bw-topbar')) return;

    /* 4 bars × 32px = 128px */
    // BW_R80P79_DELAYER — Layout switching ELIMINATED (2026-05-22).
    // The bw_topbar_layout toggle (legacy ↔ r80p78pt2a) and its "Restore Layout"
    // button were broken and made the UI undiagnosable — operator couldn't tell
    // real placement bugs from legacy-mode artifacts. Pinned to the single
    // feature-complete layout (PT2A, with legacy-only features merged in:
    // AI toggle clickability, Under the hood, Popout Chat, SYS/BW refresh ↺,
    // PROFILE selector + auto-detect, PERM selector). Layout-switching will be
    // re-added later as a proper, tested feature; recovery for broken layouts
    // will come via the planned Nav/Topbar Resurrection button (Hermes-skill).
    //
    // Was: var _bwR80p78pt2aLayout = localStorage.getItem('bw_topbar_layout') || 'r80p78pt2a';
    // Was: window.bwSetTopbarLayout = function(name) { ... } (the operator flipper)
    // Now: deterministic single layout — no reads, no writes, no flipper.
    function _bwR80p79_getActiveLayout() { return 'pinned'; }
    // One-time migration: clear the obsolete localStorage key so nothing lingers.
    try { localStorage.removeItem('bw_topbar_layout'); } catch (e) {}
    // Topbar height: 4 bars × 32px = 128px (was conditional on layout).
    document.documentElement.style.setProperty('--bw-topbar-h', '96px'); /* BW_TOPBAR_CONSOLIDATE: 3 bars × 32px — ResizeObserver overrides dynamically */
    // BW_R80P78PT2A — Shared style constants. Hoisted ABOVE the legacy-vs-new
    // branch so both code paths can reference them (the new builder uses
    // BSR/BSA/BS/PS in the Controls dropdown and IND in Bar 1).
    var BS  = 'background:var(--bw-bg3);border:1px solid rgba(255,255,255,0.15);color:var(--bw-text2);border-radius:4px;padding:4px 11px;cursor:pointer;font-size:12px;font-family:var(--bw-mono);font-weight:500;transition:all .15s;white-space:nowrap';
    var BSR = BS + ';color:var(--bw-red);border-color:rgba(252,80,80,0.45);background:rgba(252,80,80,0.08)';
    var BSA = BS + ';color:var(--bw-amber);border-color:rgba(237,137,54,0.45);background:rgba(237,137,54,0.08)';
    var PS  = 'background:var(--bw-bg3);border:1px solid rgba(255,255,255,0.15);color:var(--bw-text2);border-radius:4px;padding:3px 6px;font-size:11px;font-family:var(--bw-mono);cursor:pointer;outline:none;margin-left:4px;font-weight:500';
    var IND = 'display:inline-flex;align-items:center;gap:4px;font-family:var(--bw-mono);font-size:10px;padding:1px 7px;border-radius:10px;border:1px solid var(--bw-border2);background:var(--bw-bg3);white-space:nowrap';
    // BW_R80P79_DELAYER — Legacy 5-bar block DELETED (was 175 lines wrapped
    // in `if (_bwR80p78pt2aLayout !== 'r80p78pt2a') { ... } else { _bwR80p78pt2aBuildTopbars(...) }`).
    // All legacy-only features were merged into PT2A before deletion:
    //   - AI toggle clickability   → bar1 #bw-ai-toggle (was #bw-ind-enabled span)
    //   - Under the hood button    → bar2 #bw-r80p79-uth-btn
    //   - Popout Chat button       → bar3 #bw-bar1-popout-btn
    //   - SYS refresh ↺ button     → bar2 #bw-r80p79-sys-refresh-btn
    //   - BW refresh ↺ button      → bar2 #bw-r80p79-bw-refresh-btn
    //   - PROFILE selector + auto-detect → controls dropdown
    //   - PERM L0-L3 selector      → controls dropdown
    // (Verified 2026-05-22: the PT2A comment claim "PERM is duplicated in Perms
    // panel" was FALSE; _createQPPanel had no L0-L3 controls. PERM merged.)
    // BASE removed: unused inside _bwR80p78pt2aBuildTopbars (verified via grep).
    _bwR80p78pt2aBuildTopbars(W, document, IND, BSR, BSA, BS, PS);

    /* BW_R61: Universal Controls button — wires onclick for bw-bar1-engine-btn.
       BW_R133: button is now static in #bw-tb-utilities; we just set its onclick. */
    (function _injectUniversalControls() {
      var isChat = (W.location.pathname.split('/').pop() || '').replace(/\?.*$/,'') === 'beewid_chat.html'
                || W.location.pathname === '/' || W.location.pathname === '';
      /* BW_R133: wire the static engine button instead of creating a new one */
      var engineBtn = document.getElementById('bw-bar1-engine-btn');
      if (!engineBtn) return;

      if (isChat) {
        engineBtn.onclick = function() {
          if (W.bwToggleControls) W.bwToggleControls();
        };
      } else if ((W.location.pathname.split('/').pop()||'').replace(/\?.*$/,'') === 'beewid_trading.html') {
        /* BW_R110: Trading bar1 Engine btn -> shared panel */
        engineBtn.onclick = function() { BW_toggleSharedEngine(); };
      } else {
        /* All non-chat tabs incl. Trading: shared engine panel */ /* BW_R106 */
        engineBtn.onclick = function() { BW_toggleSharedEngine(); };
      } /* BW_R104 BW_R106 */
    })(); /* end _injectUniversalControls BW_R133 */


    // ──────────────────────────────────────────────────────────────────────
    // BW_R80P78PT2A — New 4-bar topbar builder. Activated when localStorage
    // bw_topbar_layout === 'r80p78pt2a'. Builds:
    //   #bw-topbar          (T1: status — ENABLED/time/W5/W6/L3/Agentic/Cloud/api) BW_TOPBAR_CONSOLIDATE
    //   #bw-topbar2-new     (T2: Controls▾ LEFT · CHAT+Popout RIGHT) BW_TOPBAR_CONSOLIDATE
    //   #bw-topbar3-new     (T3: History LEFT · Controls+Terminals+UTH+FullComs+stats+refresh+hotload+log▾ RIGHT) BW_TOPBAR_CONSOLIDATE
    //   #bw-r80p78pt2a-controls-drop (Hidden dropdown: SYSTEM CONTROLS + rate selectors) BW_TOPBAR_CONSOLIDATE
    function _bwR80p78pt2aBuildTopbars(W, doc, IND, BSR, BSA, BS, PS) {  // BW_R80P79_DELAYER — BASE param removed (was unused)
      // BW_R80P78PT2B — Single fixed-position wrapper holds all 4 bars as
      // flex-column siblings. Each bar wraps internally when narrow. A
      // ResizeObserver on the wrapper updates --bw-topbar-h dynamically.
      var wrap = doc.createElement('div');
      wrap.id = 'bw-topbar-wrapper-r80p78pt2a';
      wrap.style.cssText = 'position:fixed;top:0;left:var(--bw-sidebar-w);right:0;z-index:1001;display:flex;flex-direction:column;background:var(--bw-bg3);transition:left .18s cubic-bezier(.4,0,.2,1)';

      // BW_R80P78PT2B — Common per-bar style: no fixed positioning, wraps internally.
      var BAR_BASE = 'display:flex;align-items:center;padding:0 12px;gap:8px;font-size:12px;min-height:32px;background:var(--bw-bg3);border-bottom:1px solid var(--bw-border2);flex-wrap:wrap';

      // BW_R80P78PT2B — Bar 1 (status indicators) + Beewid version pinned left.
      var bar1 = doc.createElement('div');
      bar1.id = 'bw-topbar';
      bar1.style.cssText = BAR_BASE + ';justify-content:flex-start';
      bar1.innerHTML = ''
        + '<span id="bw-r80p78pt2b-version" style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-gold);letter-spacing:.08em;padding:2px 6px;background:rgba(245,200,66,0.06);border:1px solid rgba(245,200,66,0.25);border-radius:3px;flex-shrink:0">BEEWID v0.81 &middot; ALPHA</span>'
        + '<div class="bw-topbar-divider"></div>'
        // BW_R80P79_DELAYER — Was a static #bw-ind-enabled indicator; merged in
        // legacy's clickable AI toggle (BW_toggleAI). IDs match legacy
        // (bw-ai-toggle / bw-ai-dot-tb / bw-ai-label-tb) so the existing state
        // sync at ~line 2659 finds and updates this element.
        + '<span id="bw-ai-toggle" class="bw-ai-status enabled" onclick="BW_toggleAI && BW_toggleAI()" title="Toggle AI on/off" style="' + IND + ';color:var(--bw-green);cursor:pointer"><span id="bw-ai-dot-tb" style="width:6px;height:6px;border-radius:50%;background:currentColor;flex-shrink:0;margin-right:2px"></span><span id="bw-ai-label-tb">AI ENABLED</span></span>'
        + '<div class="bw-topbar-divider"></div>'
        + '<span id="bw-clock" style="font-family:var(--bw-mono);font-size:11px;color:var(--bw-text2);letter-spacing:.05em;flex-shrink:0"></span>'
        + '<div class="bw-topbar-divider"></div>'
        + '<span id="bw-ind-w5" title="W5 model — right-click to lock OFF" oncontextmenu="if(window._bwBringToChat){event.preventDefault();if(window.bwToggleLockout)bwToggleLockout(\'w5\',event);}" style="' + IND + ';cursor:context-menu;color:var(--bw-amber)"><span style="width:6px;height:6px;border-radius:50%;background:currentColor;flex-shrink:0;margin-right:2px"></span>W5 cold</span>'
        + '<span id="bw-ind-w6" title="W6 model — right-click to lock OFF" oncontextmenu="if(window._bwBringToChat){event.preventDefault();if(window.bwToggleLockout)bwToggleLockout(\'w6\',event);}" style="' + IND + ';cursor:context-menu;color:var(--bw-amber)"><span style="width:6px;height:6px;border-radius:50%;background:currentColor;flex-shrink:0;margin-right:2px"></span>W6 cold</span>'
        + '<span id="bw-ind-policy"  style="' + IND + ';color:var(--bw-text3)">L1</span>'
        + '<span id="bw-ind-agentic" style="' + IND + ';color:var(--bw-text3)">&#128274; Agentic OFF</span>'
        + '<span id="bw-ind-cloud"   style="' + IND + ';color:var(--bw-text3)">&#9729; Cloud OFF</span>'
        + '<span id="bw-ind-api"     style="' + IND + ';color:var(--bw-text3)">api &#8212;</span>'
        + '<span id="bw-topbar-alert" style="font-size:11px;color:var(--bw-amber);white-space:nowrap"></span>';

      // BW_TOPBAR_CONSOLIDATE — Rate saved values (hoisted; used by T3 and Controls dropdown).
      var savedSysR2 = '8000', savedBwR2 = '8000';
      try { savedSysR2 = localStorage.getItem('bw_sys_rate') || '8000'; } catch (e) {}
      try { savedBwR2  = localStorage.getItem('bw_bw_rate')  || '8000'; } catch (e) {}
      // BW_TRIO_FIX Fix1 — T2: Controls▾ · CHAT · Popout all right-snapped together.
      // Was space-between which spread 3 buttons across a 1200px bar — CHAT invisible.
      var btnStyle = 'flex-shrink:0;font-family:var(--bw-mono);font-size:10px;padding:2px 9px;background:var(--bw-bg3);border:1px solid var(--bw-border2);color:var(--bw-text3);border-radius:3px;cursor:pointer;white-space:nowrap';
      var bar2 = doc.createElement('div');
      bar2.id = 'bw-topbar2-new';
      bar2.style.cssText = BAR_BASE + ';justify-content:flex-end;gap:8px;padding:0 14px';
      bar2.innerHTML = ''
        + '<button id="bw-t2-controls-btn" onclick="window._bwR80p78pt2aToggleControlsDrop && window._bwR80p78pt2aToggleControlsDrop()" title="Show admin controls" style="flex-shrink:0;font-family:var(--bw-mono);font-size:10px;padding:2px 9px;background:var(--bw-bg3);border:1px solid var(--bw-border2);color:var(--bw-gold);border-radius:3px;cursor:pointer;white-space:nowrap;line-height:1">&#8998; Controls &#9662;</button>'
        + '<button id="bw-bar1-chat-btn" onclick="BW_toggleCopilot && BW_toggleCopilot()" title="Toggle Beewid Chat" style="flex-shrink:0;font-family:var(--bw-mono);font-size:11px;padding:3px 14px;background:rgba(245,200,66,0.12);color:var(--bw-gold);border:2px solid rgba(245,200,66,0.5);border-radius:5px;cursor:pointer;font-weight:700;letter-spacing:.06em;white-space:nowrap">&#9670; CHAT</button>'
        + '<button id="bw-bar1-popout-btn" onclick="window.open(\'/static/beewid_chat.html?standalone=1\',\'_blank\',\'width=500,height=800\')" style="' + btnStyle + '" title="Open standalone chat popout">&#11041; Popout Chat</button>';

      // BW_TOPBAR_CONSOLIDATE — T3: History LEFT · operational right cluster.
      // Engine/Tools/Perms removed (deferred to Beewid Bar dispatch).
      // Full Coms BIGGER per roadmap spec. Log▾ absorbs Handoff + Problems.
      var bar3 = doc.createElement('div');
      bar3.id = 'bw-topbar3-new';
      bar3.style.cssText = BAR_BASE + ';justify-content:space-between;gap:6px;padding:0 14px';
      bar3.innerHTML = ''
        // LEFT: History snapped-left
        + '<div style="display:flex;align-items:center">'
        +   '<button id="bw-bar1-history-btn" onclick="bwOpenHistory && bwOpenHistory()" title="Chat History" style="' + btnStyle + '">&#128218; History</button>'
        + '</div>'
        // RIGHT: operational cluster (wraps on narrow viewport)
        + '<div style="display:flex;align-items:center;gap:6px;flex-wrap:wrap">'
        // Controls▾ (T3 copy; canonical toggle same as T2)
        +   '<button id="bw-r80p78pt2a-controls-btn" onclick="window._bwR80p78pt2aToggleControlsDrop && window._bwR80p78pt2aToggleControlsDrop()" title="Show admin controls" style="flex-shrink:0;font-family:var(--bw-mono);font-size:10px;padding:2px 9px;background:var(--bw-bg3);border:1px solid var(--bw-border2);color:var(--bw-gold);border-radius:3px;cursor:pointer;white-space:nowrap;line-height:1">&#8998; Controls &#9662;</button>'
        // Terminals▾
        +   '<div id="bw-res-terminal-wrap" style="position:relative;flex-shrink:0">'
        +     '<button onclick="BW_toggleTermMenu&&BW_toggleTermMenu()" style="' + btnStyle + '">&#9881; Terminals &#9662;</button>'
        +     '<div id="bw-term-menu" style="display:none;position:absolute;top:calc(100% + 4px);right:0;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:6px;min-width:215px;z-index:9999;box-shadow:0 4px 16px rgba(0,0,0,.4);overflow:hidden">'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'beewid\')">Beewid cockpit terminal</div>'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'root\')">Root terminal</div>'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'ollama\')">Ollama logs (live)</div>'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'session\')">Session log (tail)</div>'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'n8n\')">n8n UI :5679</div>'
        +       '<div class="bw-term-item" onclick="BW_openTerminal&&BW_openTerminal(\'az\')">Agent Zero UI :5000</div>'
        +     '</div>'
        +   '</div>'
        // Under the hood
        +   '<button id="bw-r80p79-uth-btn" onclick="BW_popOutResources && BW_popOutResources()" style="' + btnStyle + '" title="Open resources in popout window">&#8599; Under the hood</button>'
        // Full Coms — BIGGER than neighbours per roadmap spec
        +   '<button id="bw-bar1-fullcoms-btn" onclick="BW_openFullComs && BW_openFullComs()" title="Full Coms — Engine + Controls + Perms in standalone window" style="flex-shrink:0;font-family:var(--bw-mono);font-size:11px;padding:4px 14px;background:rgba(245,200,66,0.1);border:1.5px solid rgba(245,200,66,0.45);color:var(--bw-gold);border-radius:4px;cursor:pointer;white-space:nowrap;font-weight:600">&#8862; Full Coms</button>'
        + '<div style="width:1px;height:14px;background:var(--bw-border2);flex-shrink:0"></div>'
        // Compact stats (visible: cpu/ram/disk/net; hidden bar-divs preserve polling)
        +   '<span id="bw-res-cpu"  title="System CPU"  style="font-family:var(--bw-mono);font-size:10px;color:var(--bw-text2);flex-shrink:0;white-space:nowrap">&#8212;</span>'
        +   '<span id="bw-res-ram"  title="System RAM"  style="font-family:var(--bw-mono);font-size:10px;color:var(--bw-text2);flex-shrink:0;white-space:nowrap">&#8212;</span>'
        +   '<span id="bw-res-disk" title="Disk I/O"    style="font-family:var(--bw-mono);font-size:10px;color:var(--bw-text2);flex-shrink:0;white-space:nowrap">&#8212;</span>'
        +   '<span id="bw-res-net"  title="Network I/O" style="font-family:var(--bw-mono);font-size:10px;color:var(--bw-text2);flex-shrink:0;white-space:nowrap">&#8595;&#8212; &#8593;&#8212;</span>'
        +   '<span id="bw-bar-cpu"     style="display:none"></span>'
        +   '<span id="bw-bar-ram"     style="display:none"></span>'
        +   '<span id="bw-bar-bw-cpu"  style="display:none"></span>'
        +   '<span id="bw-res-bw-cpu"  style="display:none"></span>'
        +   '<span id="bw-res-bw-ram"  style="display:none"></span>'
        +   '<span id="bw-res-bw-disk" style="display:none"></span>'
        +   '<span id="bw-res-bw-net"  style="display:none"></span>'
        + '<div style="width:1px;height:14px;background:var(--bw-border2);flex-shrink:0"></div>'
        // Utility: refresh + hotload
        +   '<button id="bw-r80p78pt2b-refresh-btn" onclick="BW_hardRefresh && BW_hardRefresh()" style="' + btnStyle + '" title="Hard refresh">&#8634; refresh</button>'
        +   '<button id="bw-r80p78pt2a-hotload-btn" onclick="bwHotload && bwHotload()" style="' + btnStyle + '" title="Hot-load newly absorbed skills">&#10227; hotload</button>'
        // Log▾ — absorbs Handoff + Problems per roadmap BW_TOPBAR_CONSOLIDATE
        +   '<div style="position:relative" id="bw-r80p78pt2b-log-wrap">'
        +     '<button id="bw-r80p78pt2b-log-btn" onclick="_bwR80p78pt2bToggleLogMenu && _bwR80p78pt2bToggleLogMenu()" style="' + btnStyle + '" title="Log · Handoff · Problems">&#128220; log &#9662;</button>'
        +     '<div id="bw-r80p78pt2b-log-menu" style="display:none;position:fixed;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:6px;min-width:190px;z-index:1200;box-shadow:0 4px 16px rgba(0,0,0,.5);overflow:hidden;font-family:var(--bw-mono);font-size:11px">'
        +       '<div style="padding:5px 10px;border-bottom:1px solid var(--bw-border2);color:var(--bw-text3);font-size:9px">LOG &amp; HANDOFF</div>'
        +       '<div class="hdr-hoff-row" style="padding:6px 10px;cursor:pointer;color:var(--bw-text2)" onclick="BW_toggleLog && BW_toggleLog();_bwR80p78pt2bCloseLogMenu && _bwR80p78pt2bCloseLogMenu()">&#128220; Session log</div>'
        +       '<div class="hdr-hoff-row" style="padding:6px 10px;cursor:pointer;color:var(--bw-text2);border-top:1px solid var(--bw-border2)" onclick="bwDownloadHandoff && bwDownloadHandoff(false);_bwR80p78pt2bCloseLogMenu && _bwR80p78pt2bCloseLogMenu()">&#11015; Download handoff</div>'
        +       '<div class="hdr-hoff-row" style="padding:6px 10px;cursor:pointer;color:var(--bw-text2);border-top:1px solid var(--bw-border2)" onclick="bwDownloadHandoff && bwDownloadHandoff(true);_bwR80p78pt2bCloseLogMenu && _bwR80p78pt2bCloseLogMenu()">&#128204; Stamp handoff</div>'
        +       '<div class="hdr-hoff-row" style="padding:6px 10px;cursor:pointer;color:#f97316;border-top:1px solid var(--bw-border2)" onclick="BW_toggleProblems && BW_toggleProblems();_bwR80p78pt2bCloseLogMenu && _bwR80p78pt2bCloseLogMenu()">&#9888; Problems</div>'
        +     '</div>'
        +   '</div>'
        + '</div>';

      // BW_TOPBAR_CONSOLIDATE — Bar 4 deleted. Refresh+hotload+log▾ → T3; CHAT+Popout → T2.
      // HARD RULE preserved: topbars = global controls only (TABPLACE_FIX still in effect).

      // BW_TOPBAR_CONSOLIDATE — Append 3 bars (T1/T2/T3) into wrapper.
      wrap.appendChild(bar1);
      wrap.appendChild(bar2);
      wrap.appendChild(bar3);

      // BW_R80P78PT2B — Insert wrapper into body at top.
      doc.body.insertBefore(wrap, doc.body.firstChild);

      // BW_R80P78PT2B — Controls dropdown. PERM and PROFILE removed: PERM
      // is duplicated in Perms panel.
      var ctrlDrop = doc.createElement('div');
      ctrlDrop.id = 'bw-r80p78pt2a-controls-drop';
      ctrlDrop.style.cssText = 'display:none;position:fixed;top:128px;left:var(--bw-sidebar-w);right:0;padding:8px 14px;background:rgba(20,10,10,0.96);border-bottom:1px solid rgba(252,80,80,0.2);z-index:997;flex-wrap:wrap;align-items:center;gap:8px;font-size:12px;transition:left .18s cubic-bezier(.4,0,.2,1)';
      ctrlDrop.innerHTML = ''
        + '<span style="font-family:var(--bw-mono);font-size:9px;color:rgba(252,80,80,0.55);letter-spacing:.12em;margin-right:8px">SYSTEM CONTROLS</span>'
        + '<div class="bw-topbar-divider"></div>'
        + '<div class="bw-topbar-item" style="gap:4px">'
        +   '<span class="bw-topbar-label">RAM</span>'
        +   '<span id="bw-ram-val" style="font-family:var(--bw-mono);font-size:10px;color:var(--bw-text2)">&#8230;</span>'
        +   '<button id="bw-freeram-btn" onclick="BW_freeRam && BW_freeRam()" style="' + BSR + ';padding:1px 5px;font-size:9px" title="Unload models from RAM">free</button>'
        + '</div>'
        + '<div class="bw-topbar-divider"></div>'
        + '<button id="bw-nuke-btn"    onclick="BW_nukeOllama && BW_nukeOllama()"    style="' + BSR + '" title="Nuclear stop — all Ollama processes">&#9762; NUKE</button>'
        + '<button id="bw-restart-btn" onclick="BW_restartOllama && BW_restartOllama()" style="' + BSA + ';margin-left:4px" title="Restart Ollama">&#8634; OLLAMA</button>'
        + '<div class="bw-topbar-divider" style="margin:0 6px"></div>'
        + '<button id="bw-hotload-btn" onclick="BW_hotloadSkills && BW_hotloadSkills()" style="' + BSA + ';font-size:9px;padding:1px 7px" title="Hot-load newly absorbed skills">&#8635; Hotload skills</button>'
        // BW_R80P79_DELAYER — Merged from legacy bar3: PROFILE selector + auto-detect.
        // Verified 2026-05-22: PROFILE was NOT duplicated anywhere else; the only
        // BW_applyProfile UI element was the legacy topbar selector. Merged here
        // to preserve the feature.
        + '<div class="bw-topbar-divider" style="margin:0 6px"></div>'
        + '<div class="bw-topbar-item" style="gap:4px">'
        +   '<span class="bw-topbar-label" style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-text3);letter-spacing:.06em">PROFILE</span>'
        +   '<select id="bw-res-profile" style="' + PS + '" onchange="BW_applyProfile && BW_applyProfile(this.value)"><option value="">&#8212; profile &#8212;</option><option value="ultra_low">ultra-low</option><option value="low">low</option><option value="mid">mid</option><option value="high">high</option><option value="god">god tier</option></select>'
        +   '<button id="bw-detect-btn" onclick="BW_autodetectHardware && BW_autodetectHardware()" style="' + BS + ';padding:1px 5px" title="Auto-detect">&#128269;</button>'
        + '</div>'
        // BW_R80P79_DELAYER — Merged from legacy bar3: PERM selector.
        // Verified 2026-05-22: PT2A code comment claimed "duplicated in Perms panel"
        // — FALSE. The Perms panel (_createQPPanel, line ~1145) does NOT contain
        // L0/L1/L2/L3 controls. The function BW_setPolicy was reachable only via
        // legacy topbar. Merged here to preserve.
        + '<div class="bw-topbar-divider" style="margin:0 6px"></div>'
        + '<div class="bw-topbar-item" style="gap:4px">'
        +   '<span class="bw-topbar-label" style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-text3);letter-spacing:.06em">PERM</span>'
        +   '<select id="bw-policy-select" style="' + PS + '" onchange="BW_setPolicy && BW_setPolicy(this.value)"><option value="0">L0 Read</option><option value="1">L1 Upload</option><option value="2" selected>L2 Write</option><option value="3">L3 Full</option></select>'
        + '</div>'
        // BW_TOPBAR_CONSOLIDATE — Rate selectors moved from old Bar 2 to Controls dropdown.
        + '<div class="bw-topbar-divider" style="margin:0 6px"></div>'
        + '<div class="bw-topbar-item" style="gap:4px">'
        +   '<span class="bw-topbar-label" style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-text3);letter-spacing:.06em">SYS</span>'
        +   '<select id="bw-sys-rate" onchange="BW_setSysRate&&BW_setSysRate(this.value)" style="font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg4);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text3);padding:1px 2px">'
        +     '<option value="0">Off</option><option value="30000">30s</option><option value="8000"' + (savedSysR2==='8000'?' selected':'') + '>8s</option><option value="3000">3s</option>'
        +   '</select>'
        +   '<button id="bw-r80p79-sys-refresh-btn" onclick="BW_refreshSysBar && BW_refreshSysBar()" style="flex-shrink:0;font-family:var(--bw-mono);font-size:11px;padding:0 4px;background:transparent;border:none;color:var(--bw-text3);cursor:pointer" title="Refresh SYS stats">&#8634;</button>'
        + '</div>'
        + '<div class="bw-topbar-item" style="gap:4px">'
        +   '<span class="bw-topbar-label" style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-gold);letter-spacing:.06em">&#9670; BW</span>'
        +   '<select id="bw-bw-rate" onchange="BW_setBwRate&&BW_setBwRate(this.value)" style="font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg4);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text3);padding:1px 2px">'
        +     '<option value="0">Off</option><option value="30000">30s</option><option value="8000"' + (savedBwR2==='8000'?' selected':'') + '>8s</option><option value="3000">3s</option>'
        +   '</select>'
        +   '<button id="bw-r80p79-bw-refresh-btn" onclick="BW_refreshBwBar && BW_refreshBwBar()" style="flex-shrink:0;font-family:var(--bw-mono);font-size:11px;padding:0 4px;background:transparent;border:none;color:var(--bw-text3);cursor:pointer" title="Refresh Beewid stats">&#8634;</button>'
        + '</div>'
        + '<div style="flex:1"></div>';
        // BW_R80P79_DELAYER — "Revert to legacy layout" button REMOVED.
        // The bw_topbar_layout toggle is gone; this layout is now the only one.
        // A future Nav/Topbar Resurrection button (Hermes-skill-triggered) will
        // be the recovery path if the layout ever breaks again.

      doc.body.appendChild(ctrlDrop);

      // BW_R80P78PT2B — Controls dropdown toggle helper (idempotent).
      window._bwR80p78pt2aToggleControlsDrop = function() {
        var d = document.getElementById('bw-r80p78pt2a-controls-drop');
        if (!d) return;
        d.style.display = (d.style.display === 'flex' || d.style.display === 'block') ? 'none' : 'flex';
      };

      // BW_TOPBAR_CONSOLIDATE — Log menu toggle/close. Log▾ now absorbs Handoff + Problems.
      // Legacy aliases kept (_bwR80p78pt2bToggleHandoffMenu, _bwR80p78pt2bCloseHandoffMenu).
      window._bwR80p78pt2bToggleLogMenu = function() {
        var m = document.getElementById('bw-r80p78pt2b-log-menu');
        if (!m) return;
        if (m.style.display === 'none' || !m.style.display) {
          m.style.display = 'block';
          setTimeout(function() {
            document.addEventListener('click', function _lc(e) {
              var w = document.getElementById('bw-r80p78pt2b-log-wrap');
              if (w && !w.contains(e.target)) {
                m.style.display = 'none';
                document.removeEventListener('click', _lc);
              }
            });
          }, 10);
        } else {
          m.style.display = 'none';
        }
      };
      window._bwR80p78pt2bCloseLogMenu = function() {
        var m = document.getElementById('bw-r80p78pt2b-log-menu');
        if (m) m.style.display = 'none';
      };
      // Legacy aliases — safe; old handoff menu no longer in DOM BW_TOPBAR_CONSOLIDATE
      window._bwR80p78pt2bToggleHandoffMenu = window._bwR80p78pt2bToggleLogMenu;
      window._bwR80p78pt2bCloseHandoffMenu  = window._bwR80p78pt2bCloseLogMenu;

      // BW_R80P78PT2B — More-precise CSS hide rule. :not([id="..."])
      // excludes new Bar 4 buttons by id so they stay visible; legacy
      // buttons (with their own legacy IDs or none) still match the
      // attribute selector. Only hide BUTTON inside #hdr-handoff-wrap,
      // not the wrap itself.
      var hideCSS = doc.createElement('style');
      hideCSS.id = 'bw-r80p78pt2a-hide-legacy';
      hideCSS.textContent = ''
        + 'body.bw-r80p78pt2a-active button[onclick^="BW_hardRefresh"]:not([id="bw-r80p78pt2b-refresh-btn"]),'
        + 'body.bw-r80p78pt2a-active button[onclick^="bwHotload"]:not([id="bw-r80p78pt2a-hotload-btn"]),'
        + 'body.bw-r80p78pt2a-active button[onclick^="BW_toggleLog"]:not([id="bw-r80p78pt2b-log-btn"]),'
        + 'body.bw-r80p78pt2a-active #hdr-handoff-wrap > button,'
        + 'body.bw-r80p78pt2a-active button#hdr-problems-btn,'
        + 'body.bw-r80p78pt2a-active body > #bw-tab-bar {'
        + '  display: none !important;'
        + '}';
      doc.head.appendChild(hideCSS);
      doc.body.classList.add('bw-r80p78pt2a-active');

      // BW_R80P78PT2B — ResizeObserver on the wrapper updates --bw-topbar-h
      // dynamically. When bars wrap on zoom-in / narrow viewport, the
      // wrapper grows and --bw-topbar-h grows with it. Content below uses
      // `padding-top: var(--bw-topbar-h)` so it automatically reflows.
      // Controls dropdown's `top` is also kept under the wrapper.
      function _bwR80p78pt2bSyncHeight() {
        var h = wrap.offsetHeight || 128;
        document.documentElement.style.setProperty('--bw-topbar-h', h + 'px');
        var d = document.getElementById('bw-r80p78pt2a-controls-drop');
        if (d) d.style.top = h + 'px';
      }
      if (typeof ResizeObserver !== 'undefined') {
        var ro = new ResizeObserver(_bwR80p78pt2bSyncHeight);
        ro.observe(wrap);
      } else {
        window.addEventListener('resize', _bwR80p78pt2bSyncHeight);
      }
      _bwR80p78pt2bSyncHeight();
      setTimeout(_bwR80p78pt2bSyncHeight, 100);
      setTimeout(_bwR80p78pt2bSyncHeight, 500);

      // BW_R80P78PT2B — Reflow after paint.
      setTimeout(function() { if (W._bwReflow) W._bwReflow(); }, 150);
    }
    // ──────────────────────────────────────────────────────────────────────


    /* BW_R61: model/timeout setters for the popover (used on non-chat pages) */
    W.BW_ctrlSaveModel = function(tier, val) {
      if (!val || val === 'loading\u2026') return;
      var key = tier === 'w6' ? 'w6_model' : 'ollama_model';
      api.post('/settings/save', {[key]: val}).then(function() {
        notify.ok(tier.toUpperCase() + ' \u2192 ' + val);
      }).catch(function() { notify.warn('Model save failed'); });
      try { var p = JSON.parse(localStorage.getItem('bw_model_prefs')||'{}'); p[tier]=val; localStorage.setItem('bw_model_prefs',JSON.stringify(p)); } catch(e) {}
    };
    W.BW_ctrlSaveKv = function(tier, val) {
      api.post('/settings/save', {kv_cache_type: val}).then(function() { notify.ok('KV ' + tier + ': ' + (val||'std') + ' \u2014 applies next request'); }).catch(function(){});
    };
    W.BW_ctrlSaveTimeout = function(tier, val) {
      try { localStorage.setItem('bw_timeout_' + tier, String(val)); } catch(e) {}
      notify.ok(tier.toUpperCase() + ' timeout: ' + val + 's');
    };
    W.BW_ctrlBias = function(v) {
      var n = document.getElementById('bwcp-bias-n'); if (n) n.value = v;
      api.post('/settings/save', {brain_bias: parseInt(v)}).catch(function(){});
    };
    W.BW_ctrlBiasNum = function(v) {
      var s = document.getElementById('bwcp-bias'); if (s) s.value = v;
      api.post('/settings/save', {brain_bias: parseInt(v)}).catch(function(){});
    };
    /* BW_R64: MCP server controls */
    function _bwMcpNotify(d, action) {
      if (d.ok) notify.ok('MCP ' + action + ': ' + (d.message || 'ok'));
      else notify.warn('MCP ' + action + ' failed: ' + (d.error || 'unknown'));
    }
    W.BW_mcpStart = function() {
      api.post('/mcp/start', {}).then(function(d){ _bwMcpNotify(d,'start'); _bwMcpPoll(); }).catch(function(e){ notify.warn('MCP start error: '+e.message); });
    };
    W.BW_mcpStop = function() {
      api.post('/mcp/stop', {}).then(function(d){ _bwMcpNotify(d,'stop'); setTimeout(_bwMcpPoll,800); }).catch(function(e){ notify.warn('MCP stop error: '+e.message); });
    };
    W.BW_mcpRestart = function() {
      notify.ok('MCP restarting\u2026');
      api.post('/mcp/restart', {}).then(function(d){ _bwMcpNotify(d,'restart'); setTimeout(_bwMcpPoll,1500); }).catch(function(e){ notify.warn('MCP restart error: '+e.message); });
    };
    /* BW_R97: Hotload skills — POST /admin/restart_hotload, spinner + toast */
    W.BW_hotloadSkills = function() {
      var btn = document.getElementById('bw-hotload-btn');
      var orig = btn ? btn.innerHTML : '';
      if (btn) { btn.disabled = true; btn.innerHTML = '\u27f3 hotloading\u2026'; }
      api.post('/admin/restart_hotload', {}).then(function(d){
        var n = (d && (d.skills_loaded != null ? d.skills_loaded : d.count)) || 0;
        if (d && d.ok !== false) notify.ok('\u2713 ' + n + ' skills loaded');
        else notify.warn('Hotload failed: ' + ((d && d.error) || 'unknown'));
      }).catch(function(e){
        notify.warn('Hotload error: ' + e.message);
      }).then(function(){
        if (btn) { btn.disabled = false; btn.innerHTML = orig || '\u21bb Hotload skills'; }
      });
    };
    function _bwMcpPoll() {
      api.get('/mcp/status').then(function(d) {
        var dot = document.getElementById('bw-mcp-dot');
        if (!dot) return;
        dot.style.background = d.running ? '#4ade80' : 'var(--bw-red,#fc5050)';
        dot.title = 'MCP :' + (d.port||8765) + ' — ' + (d.running ? 'RUNNING' : 'STOPPED') + (d.pid ? ' pid='+d.pid : '');
        var sb = document.getElementById('bw-mcp-start-btn');
        var xb = document.getElementById('bw-mcp-stop-btn');
        if (sb) sb.style.opacity = d.running ? '0.4' : '1';
        if (xb) xb.style.opacity = d.running ? '1' : '0.4';
      }).catch(function() {
        var dot = document.getElementById('bw-mcp-dot');
        if (dot) { dot.style.background = 'var(--bw-text3)'; dot.title = 'MCP status unknown'; }
      });
    }
    /* Poll MCP status every 15s */
    setTimeout(_bwMcpPoll, 2000);
    setInterval(_bwMcpPoll, 15000);
    /* BW_R64: BW_ctrlStream — saves stream mode from any tab */
    W.BW_ctrlStream = function(mode) {
      try { localStorage.setItem('bw_stream_mode', mode); } catch(e) {}
      api.post('/settings/save', {stream_mode: mode}).catch(function(){});
      notify.ok('Stream: ' + mode + ' (applies in Chat tab)');
      /* Highlight active button */
      ['live','chunk','full'].forEach(function(k) {
        var b = document.getElementById('bwcp-s-' + k);
        if (!b) return;
        var isActive = (k === 'live' && mode === 'token') || (k === mode);
        b.style.borderColor = isActive ? 'var(--bw-gold)' : '';
        b.style.color       = isActive ? 'var(--bw-gold)' : 'var(--bw-text2)';
      });
    };

    // BW_R80P79_DELAYER — _bwNavExpanded + bw_nav_expanded localStorage removed.
    // Was: tracked the legacy "extra bars" collapsed/expanded state. The legacy
    // bars (bw-topbar-res, bw-topbar-bw, bw-topbar3) are no longer created.
    // The pinned PT2A layout uses the SYSTEM CONTROLS dropdown instead.

    /* BW_R108: after nav collapse/expand, reposition engine + perms panels */
    function _seResync() {
      if (typeof _seAdjust === 'function') {
        var p = document.getElementById('bw-shared-engine-panel');
        var open = p && p.style.display !== 'none';
        _seAdjust(open);
      }
    }
    function BW_toggleNavPanels() {
      // BW_R80P79_DELAYER — Simplified to always toggle the SYSTEM CONTROLS dropdown.
      // The legacy "extra bars" path (bw-topbar-res / bw-topbar-bw / bw-topbar3
      // show/hide) is gone with the legacy 5-bar block; those IDs are no longer
      // created in the pinned layout. The Controls button in PT2A Bar 3 is the
      // sole entry point, and it opens the #bw-r80p78pt2a-controls-drop dropdown.
      if (window._bwR80p78pt2aToggleControlsDrop) {
        window._bwR80p78pt2aToggleControlsDrop();
      }
    }
    window.BW_toggleNavPanels = BW_toggleNavPanels;

    // BW_R80P79_DELAYER — Saved-state restore for legacy extra bars REMOVED.
    // Was: if (!_bwNavExpanded) setTimeout(...) hiding bw-topbar-res/-bw/-3 and
    // updating the legacy collapse button. Those legacy IDs are no longer
    // created, so the restore was a no-op. Controls dropdown is per-session.
    // ── End nav collapse ─────────────────────────────────────────────────────

    if (!document.getElementById('bw-topbar2-css')) {
      var s2 = document.createElement('style');
      s2.id = 'bw-topbar2-css';
      s2.textContent = [
        '#bw-topbar { min-height:32px !important; height:auto !important; z-index:1001 !important; overflow-x:auto !important; scrollbar-width:none !important; }', /* BW_R136 */
        '#bw-topbar2 { z-index:1000 !important; }',
        '#bw-topbar3 { z-index:999  !important; }',
        /* BW_R65: sidebar z-index restored — theme.css handles expansion correctly */
        '#bw-sidebar { z-index:1002 !important; }',
        '#bw-indicators::-webkit-scrollbar,#bw-topbar2::-webkit-scrollbar,#bw-topbar3::-webkit-scrollbar { display:none; }',
        '#bw-topbar-res, #bw-topbar-bw { left:var(--bw-sidebar-w); }',
        '#bw-sidebar:hover~#bw-topbar,#bw-sidebar:hover~#bw-topbar-res,#bw-sidebar:hover~#bw-topbar-bw,#bw-sidebar:hover~#bw-topbar2,#bw-sidebar:hover~#bw-topbar3 { left:var(--bw-sidebar-w-exp) !important; transition:left .18s ease; }',
        '#bw-topbar-res { z-index:1000 !important; }',
        '.bw-term-item{padding:8px 14px;font-family:var(--bw-mono);font-size:11px;color:var(--bw-text2);cursor:pointer;border-bottom:1px solid var(--bw-border);white-space:nowrap}',
        '.bw-term-item:last-child{border-bottom:none}',
        '.bw-term-item:hover{background:var(--bw-bg4);color:var(--bw-text)}',
        'body.bw-panel-open .bw-page { margin-right:var(--bw-copilot-w,420px); }',
        'body.bw-panel-open #chat-wrap,body.bw-panel-open #input-area,body.bw-panel-open #preprompt-wrap { margin-right:var(--bw-copilot-w,420px); }' /* BW_R143 */
      ].join('\n');
      document.head.appendChild(s2);
    }
    /* BW_R133: topbar split responsive CSS */
    if (!document.getElementById('bw-tb-split-css')) {
      var _tbSplit = document.createElement('style');
      _tbSplit.id = 'bw-tb-split-css';
      _tbSplit.textContent = [
        '/* BW_R133: topbar split */',
        '#bw-tb-status { min-width:0; }',
        '#bw-tb-status #bw-indicators { max-width:min(520px, 50vw); }',
        '#bw-tb-utilities { gap:4px; flex-wrap:wrap; overflow-x:visible; }', /* BW_R136 */
        '#bw-tb-utilities button { white-space:nowrap; }',
        '@media (max-width: 1100px) {',
        '  #bw-tb-status #bw-indicators { max-width: 320px; }',
        '}',
      ].join('\n');
      document.head.appendChild(_tbSplit);
    }
  }

  /* ── Log panel ────────────────────────────────────────────── */
  var _logOpen = false;

  function createLogPanel() {
    if (document.getElementById('bw-logpanel')) return;
    const el = document.createElement('div');
    el.id = 'bw-logpanel';
    el.style.cssText = 'position:fixed;bottom:0;right:0;width:540px;height:300px;'
      + 'background:var(--bw-bg2);border:1px solid var(--bw-border2);'
      + 'border-radius:10px 0 0 0;z-index:8000;display:flex;'
      + 'flex-direction:column;font-family:var(--bw-mono);font-size:11px';

    const BS = 'background:transparent;border:1px solid var(--bw-border2);'
             + 'color:var(--bw-text2);border-radius:3px;padding:3px 8px;'
             + 'cursor:pointer;font-size:10px;font-family:var(--bw-mono)';

    var header = document.createElement('div');
    header.style.cssText = 'display:flex;align-items:center;padding:8px 12px;'
      + 'border-bottom:1px solid var(--bw-border);gap:6px;'
      + 'background:var(--bw-bg3);flex-shrink:0;border-radius:10px 0 0 0';
    header.innerHTML = '<span style="color:var(--bw-gold);font-weight:700;letter-spacing:.12em;font-size:11px">SESSION LOG</span>'
      + '<span id="bw-log-path" style="color:var(--bw-text3);font-size:10px;flex:1;overflow:hidden;text-overflow:ellipsis;white-space:nowrap"></span>';

    /* Refresh button */
    var btnRefresh = document.createElement('button');
    btnRefresh.style.cssText = BS;
    btnRefresh.title = 'Reload log';
    btnRefresh.textContent = '\u21BA refresh';
    btnRefresh.onclick = refreshLogs;

    /* Export button — with visual feedback */
    var btnExport = document.createElement('button');
    btnExport.style.cssText = BS;
    btnExport.title = 'Download log — drag to Claude';
    btnExport.textContent = '\u2B07 export';
    btnExport.onclick = function() {
      /* Trigger download via hidden link */
      var a = document.createElement('a');
      a.href = API_BASE + '/logs/export';
      a.download = 'beewid_session.log';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      /* Visual feedback */
      var orig = btnExport.textContent;
      btnExport.textContent = '\u2713 exported';
      btnExport.style.color = 'var(--bw-green)';
      btnExport.disabled = true;
      setTimeout(function() {
        btnExport.textContent = orig;
        btnExport.style.color = '';
        btnExport.disabled = false;
      }, 2000);
      notify.ok('Log exported — check Downloads');
    };

    /* Open folder button */
    var btnDebug = document.createElement('button');
    btnDebug.style.cssText = BS + ';color:var(--bw-amber);border-color:rgba(237,137,54,0.4)';
    btnDebug.title = 'Download debug bundle (all source files + log) — drag to Claude';
    btnDebug.textContent = '\u25A6 debug bundle';
    btnDebug.onclick = function() {
      var orig = btnDebug.textContent;
      btnDebug.textContent = '\u25A6 bundling…';
      btnDebug.disabled = true;
      var a = document.createElement('a');
      a.href = API_BASE + '/logs/debug-bundle';
      a.style.display = 'none';
      document.body.appendChild(a);
      a.click();
      document.body.removeChild(a);
      setTimeout(function() {
        btnDebug.textContent = '\u2713 ready';
        btnDebug.style.color = 'var(--bw-green)';
        setTimeout(function() {
          btnDebug.textContent = orig;
          btnDebug.style.color = '';
          btnDebug.disabled = false;
        }, 2000);
      }, 1200);
      notify.ok('Debug bundle downloading — drag the zip to Claude');
    };

    var btnFolder = document.createElement('button');
    btnFolder.style.cssText = BS;
    btnFolder.title = 'Open log folder in file manager';
    btnFolder.textContent = '\uD83D\uDCC1 folder';
    btnFolder.onclick = function() {
      BW.api.post('/logs/open-folder', {})
        .then(function(d) {
          notify.ok('Opened log folder');
          var orig = btnFolder.textContent;
          btnFolder.textContent = '\u2713 opened';
          btnFolder.style.color = 'var(--bw-green)';
          setTimeout(function() { btnFolder.textContent = orig; btnFolder.style.color = ''; }, 1800);
        })
        .catch(function(e) { notify.error(e.message); });
    };

    /* Clear button */
    var btnClear = document.createElement('button');
    btnClear.style.cssText = BS + ';color:var(--bw-red)';
    btnClear.title = 'Clear log file';
    btnClear.textContent = '\u2715 clear';
    btnClear.onclick = function() {
      if (!confirm('Clear the session log file?')) return;
      BW.api.post('/logs/clear', {})
        .then(function() {
          notify.ok('Log cleared');
          var orig = btnClear.textContent;
          btnClear.textContent = '\u2713 cleared';
          setTimeout(function() { btnClear.textContent = orig; }, 1800);
          refreshLogs();
        })
        .catch(function(e) { notify.error(e.message); });
    };

    /* Close button */
    var btnClose = document.createElement('button');
    btnClose.style.cssText = 'background:transparent;border:none;color:var(--bw-text3);cursor:pointer;font-size:16px;padding:0 4px;margin-left:4px';
    btnClose.innerHTML = '&times;';
    btnClose.onclick = BW_toggleLog;

    header.appendChild(btnRefresh);
    header.appendChild(btnExport);
    header.appendChild(btnDebug);
    header.appendChild(btnFolder);
    header.appendChild(btnClear);
    header.appendChild(btnClose);

    var body = document.createElement('div');
    body.id = 'bw-loglines';
    body.style.cssText = 'flex:1;overflow-y:auto;padding:8px 12px;color:var(--bw-text2);line-height:1.8;font-size:11px';
    body.innerHTML = '<span style="color:var(--bw-text3)">Loading\u2026</span>';

    el.appendChild(header);
    el.appendChild(body);
    document.body.appendChild(el);
    refreshLogs();
  }

  function BW_toggleLog() {
    _logOpen = !_logOpen;
    var panel = document.getElementById('bw-logpanel');
    if (!panel) { _logOpen = true; createLogPanel(); return; }
    panel.style.display = _logOpen ? 'flex' : 'none';
    if (_logOpen) refreshLogs();
  }

  function refreshLogs() {
    BW.api.get('/logs?n=100').then(function(data) {
      var el = document.getElementById('bw-loglines');
      if (!el) return;
      var pathEl = document.getElementById('bw-log-path');
      if (pathEl && data.log_path) pathEl.textContent = data.log_path;
      if (!data.lines || !data.lines.length) {
        el.innerHTML = '<span style="color:var(--bw-text3)">No log entries yet — interact with Beewid to populate</span>';
        return;
      }
      el.innerHTML = data.lines.map(function(l) {
        var colour = l.includes('ERROR') || l.includes('→ 4') || l.includes('→ 5')
          ? 'color:var(--bw-red)' : l.includes('WARN') ? 'color:var(--bw-amber)' : '';
        return '<div style="border-bottom:1px solid var(--bw-border);padding:2px 0;' + colour + '">' + esc(l) + '</div>';
      }).join('');
      el.scrollTop = el.scrollHeight;
    }).catch(function() {});
  }

  /* ── Copilot panel ───────────────────────────────────────── */ /* BW_R143: resize handle */
  var _copilotOpen = false;
  var _bwSavedPanelW = (function(){ try { var v=parseInt(localStorage.getItem('bw_copilot_w')); return (v>=280&&v<=900)?v:420; } catch(e){return 420;} })();
  var _PANEL_W = _bwSavedPanelW; /* BW_R143: restored from localStorage */

  function _injectPanelCSS() { /* CSS now injected by injectTopbar — no-op */ }

  function createCopilotPanel() {
    if (document.getElementById('bw-copilot')) return;
    _injectPanelCSS();
    var panel = document.createElement('div');
    panel.id = 'bw-copilot';
    panel.style.cssText = 'position:fixed;top:var(--bw-topbar-h,160px);right:0;width:'+_PANEL_W+'px;' /* BW_R143 */      + 'height:calc(100vh - var(--bw-topbar-h));background:var(--bw-bg2);'      + 'border-left:1px solid var(--bw-border2);z-index:900;'      + 'display:flex;flex-direction:column;box-shadow:-4px 0 24px rgba(0,0,0,0.4);'      + 'transition:transform 0.2s ease';
    var hdr = document.createElement('div');
    hdr.style.cssText = 'display:flex;align-items:center;padding:7px 12px;gap:8px;'      + 'border-bottom:1px solid var(--bw-border);background:var(--bw-bg3);'      + 'flex-shrink:0;font-family:var(--bw-mono);font-size:11px';
    hdr.innerHTML = '<span style="color:var(--bw-gold);font-weight:700;letter-spacing:.1em">◈ BEEWID CHAT</span>'      + '<span style="font-size:9px;color:var(--bw-text3);background:var(--bw-bg4);'      + 'padding:1px 5px;border-radius:3px;border:1px solid var(--bw-border2)">all tabs</span>'      + '<span style="flex:1"></span>'      + '<label style="font-size:10px;color:var(--bw-text3);font-family:var(--bw-mono);'      + 'display:flex;align-items:center;gap:4px">'      + 'Zoom <input type="range" min="70" max="130" value="100" step="5"'      + 'style="width:60px" oninput="try{document.getElementById(\'bw-copilot-frame\').contentWindow.bwSetZoom(this.value)}'      + 'catch(e){}"></label>' /* BW_R131: avoid stale frame closure */      + '<button onclick="BW_toggleCopilot()" title="Hide panel"'      + ' style="background:transparent;border:none;color:var(--bw-text3);'      + 'cursor:pointer;font-size:15px;padding:0 4px;line-height:1">&times;</button>';
    var frame = document.createElement('iframe');
    frame.id = 'bw-copilot-frame';
    frame.src = '/static/beewid_chat.html?panel=1';
    frame.style.cssText = 'flex:1;border:none;width:100%;background:var(--bw-bg)';
    frame.title = 'Beewid Chat — all tabs';
    /* BW_R143: left-edge drag resize handle */
    var resizeHandle = document.createElement('div');
    resizeHandle.id = 'bw-copilot-resize';
    resizeHandle.style.cssText = 'position:absolute;left:0;top:0;bottom:0;width:6px;'
      + 'cursor:ew-resize;z-index:10;background:transparent;'
      + 'border-left:2px solid transparent;transition:border-color .15s';
    resizeHandle.title = 'Drag to resize panel';
    resizeHandle.addEventListener('mouseenter', function(){
      resizeHandle.style.borderLeftColor = 'var(--bw-gold,#f5c842)';
    });
    resizeHandle.addEventListener('mouseleave', function(){
      if (!_bwResizeDragging) resizeHandle.style.borderLeftColor = 'transparent';
    });
    var _bwResizeDragging = false;
    var _bwResizeStartX = 0;
    var _bwResizeStartW = 420;
    resizeHandle.addEventListener('mousedown', function(e) {
      e.preventDefault();
      _bwResizeDragging = true;
      _bwResizeStartX = e.clientX;
      _bwResizeStartW = panel.offsetWidth;
      document.body.style.userSelect = 'none';
    });
    document.addEventListener('mousemove', function(e) {
      if (!_bwResizeDragging) return;
      var delta = _bwResizeStartX - e.clientX; /* drag left = wider */
      var newW  = Math.min(900, Math.max(280, _bwResizeStartW + delta));
      panel.style.width = newW + 'px';
      _PANEL_W = newW;
      /* Update push margin */
      document.documentElement.style.setProperty('--bw-copilot-w', newW + 'px');
      var pushTargets = document.querySelectorAll('.bw-page,#chat-wrap,#input-area,#preprompt-wrap');
      pushTargets.forEach(function(el){ el.style.marginRight = newW + 'px'; });
      try { localStorage.setItem('bw_copilot_w', newW); } catch(e) {}
    });
    document.addEventListener('mouseup', function() {
      if (_bwResizeDragging) {
        _bwResizeDragging = false;
        document.body.style.userSelect = '';
        resizeHandle.style.borderLeftColor = 'transparent';
      }
    });
    panel.appendChild(resizeHandle);
    panel.appendChild(hdr);
    panel.appendChild(frame);
    document.body.appendChild(panel);
    document.body.classList.add('bw-panel-open');
  }

  function BW_toggleCopilot() {
    var panel = document.getElementById('bw-copilot');
    if (!panel) {
      _copilotOpen = true;
      createCopilotPanel();
      _updateCopilotBtn(true);
      sessionStorage.setItem('bw_copilot_closed', '');
      return;
    }
    _copilotOpen = panel.style.display === 'none';
    panel.style.display = _copilotOpen ? 'flex' : 'none';
    document.body.classList.toggle('bw-panel-open', _copilotOpen);
    /* Remember if user explicitly closed the panel */
    sessionStorage.setItem('bw_copilot_closed', _copilotOpen ? '' : '1');
    _updateCopilotBtn(_copilotOpen);
  }

  function _updateCopilotBtn(open) {
    var btn = document.getElementById('bw-copilot-btn');
    if (!btn) return;
    btn.innerHTML        = open ? '&#10005; HIDE CHAT' : '&#9672; CHAT';
    btn.style.background = open ? 'rgba(245,200,66,0.22)' : 'rgba(245,200,66,0.12)';
    btn.style.borderColor = open ? 'rgba(245,200,66,0.9)' : 'rgba(245,200,66,0.6)';
  }

  /* ── Quick Perms panel (topbar dropdown) ─────────────────── */
  var _bwQPCfg = {};

  function _createQPPanel() {
    if (document.getElementById('bw-qp-panel')) { BW_openQPerms(); return; }

    /* BW_R123: Add CSS for #bw-qp-wrap and #bw-qp-panel */
    if (!document.getElementById('bw-qp-style')) {
      var _qpStyle = document.createElement('style');
      _qpStyle.id = 'bw-qp-style';
      _qpStyle.textContent = [
        '/* BW_R123b: perms panel in-flow layout - wrap owns positioning */',
        '#bw-qp-wrap {',
        '  position: relative;', /* FIX 1 & 3: wrap owns positioning now */
        '  width: 100%;',
        '  background: var(--bw-bg2);',
        '  border-bottom: 2px solid var(--bw-border2);',
        '  box-shadow: 0 8px 28px rgba(0,0,0,0.6);',
        '}',
        '#bw-qp-wrap.hidden { display: none; }',
        '#bw-qp-panel {',
        '  /* BW_R80P53C: vertical-stacking grid. Was horizontal flex-wrap which',
        '     forced 9 sections into one row and required browser zoom-out. */',
        '  padding: 12px 16px 10px;',
        '  display: grid;',
        '  grid-template-columns: repeat(auto-fit, minmax(180px, 1fr));',
        '  gap: 10px 14px;',
        '  align-items: start;',
        '  font-family: var(--bw-mono);',
        '  font-size: 11px;',
        '  overflow-y: auto;',
        '  max-height: 75vh;',
        '  max-width: 100%;',
        '  box-sizing: border-box;',
        '}',
        '/* BW_R80P53C / BW_R80P54A: Identity Protection — collapsible section */',
        '#bw-qp-panel > .bw-qp-id-section {',
        '  grid-column: 1 / -1;',
        '  display: flex;',
        '  flex-direction: column;',
        '  padding-top: 8px;',
        '  border-top: 1px solid var(--bw-border);',
        '  margin-top: 4px;',
        '}',
        '/* BW_R80P54A: collapsible body — hidden until .expanded */',
        '#bwqp-id-body {',
        '  display: none;',
        '  grid-template-columns: minmax(220px, 1fr) minmax(280px, 2fr);',
        '  gap: 16px;',
        '  padding-left: 16px;',
        '  border-left: 2px solid var(--bw-border, #2a2a2e);',
        '  margin-left: 4px;',
        '}',
        '#bwqp-id-body.expanded {',
        '  display: grid;',
        '}',
        '/* BW_R80P53C: at narrow widths Identity body collapses to single column */',
        '@media (max-width: 720px) {',
        '  #bwqp-id-body {',
        '    grid-template-columns: 1fr;',
        '  }',
        '}',
        '/* BW_R80P53C: Identity sub-blocks */',
        '.bw-qp-id-section .bw-qp-id-block {',
        '  display: flex;',
        '  flex-direction: column;',
        '  gap: 4px;',
        '}',
        '#bw-qp-panel.hidden { display: none; }'
      ].join('\n');
      document.head.appendChild(_qpStyle);
    }

    var BS2 = 'font-family:var(--bw-mono);font-size:10px;border:1px solid var(--bw-border2);border-radius:3px;cursor:pointer;padding:3px 10px;background:transparent;color:var(--bw-text2);transition:all .15s';

    /* BW_R123: Wrap #bw-qp-panel in #bw-qp-wrap */
    var qpWrap = document.createElement('div');
    qpWrap.id = 'bw-qp-wrap';
    qpWrap.className = 'hidden';   /* starts closed */

    var panel = document.createElement('div');
    panel.id = 'bw-qp-panel';
    panel.className = 'hidden';
    /* No inline style — in-flow doesn't need it. */

    function sec(label) {
      var d = document.createElement('div');
      d.style.cssText = 'display:flex;flex-direction:column;gap:5px;min-width:130px;flex:1';
      if (label) {
        var h = document.createElement('div');
        h.style.cssText = 'font-size:9px;color:var(--bw-text3);letter-spacing:.1em;text-transform:uppercase;margin-bottom:2px';
        h.textContent = label;
        d.appendChild(h);
      }
      return d;
    }
    function chk(id, label) {
      var wrap = document.createElement('label');
      wrap.style.cssText = 'display:flex;align-items:center;gap:6px;cursor:pointer;font-size:11px;color:var(--bw-text2)';
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.id = 'bwqp-' + id;
      cb.style.accentColor = 'var(--bw-gold)';
      cb.onchange = function() { _bwUpdateRisk(); };
      wrap.appendChild(cb);
      wrap.appendChild(document.createTextNode(label));
      return wrap;
    }

    var modeSection = sec('AI Mode');
    function modeChk(id, label) {
      var wrap = document.createElement('label');
      wrap.style.cssText = 'display:flex;align-items:center;gap:6px;cursor:pointer;font-size:11px;color:var(--bw-text2)';
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.id = 'bwqp-mode-' + id;
      cb.style.accentColor = 'var(--bw-gold)';
      wrap.appendChild(cb); wrap.appendChild(document.createTextNode(label));
      return wrap;
    }
    modeSection.appendChild(modeChk('A', '🔵 Direct API'));
    modeSection.appendChild(modeChk('B', '🟡 Agent Zero'));
    modeSection.appendChild(modeChk('C', '🟠 AZ Live'));
    modeSection.appendChild(modeChk('N', '⚫ None / Standby'));

    var togSection = sec('Access');
    togSection.appendChild(chk('inet',         'Internet (Level 2)'));
    togSection.appendChild(chk('agentic',      'Agentic mode'));
    togSection.appendChild(chk('agentic_plus', 'Agentic+ (L4 auto-retry)')); /* BW_R63 */
    togSection.appendChild(chk('active',       'AI active'));

    var cloudSection = sec('Cloud AI');
    cloudSection.appendChild(chk('pollinations', 'Free Cloud (Pollinations)'));
    cloudSection.appendChild(chk('haiku',        'Paid Cloud (Haiku)'));
    var ks = document.createElement('div');
    ks.id = 'bwqp-key-status';
    ks.style.cssText = 'font-size:10px;color:var(--bw-text3)';
    cloudSection.appendChild(ks);

    // ── Cloud model tier for W5/W6 ─────────────────────────────────────────
    var cloudModelSection = sec('Cloud Models');
    var cloudNote = document.createElement('div');
    cloudNote.style.cssText = 'font-size:9px;color:var(--bw-amber);line-height:1.5;margin-bottom:4px';
    cloudNote.textContent = '⚠ Cloud AI sees your prompts. Enable only with permission.';
    cloudModelSection.appendChild(cloudNote);
    function mkCloudSel(tier, label) {
      var wrap = document.createElement('div');
      wrap.style.cssText = 'display:flex;align-items:center;gap:5px;font-size:10px;color:var(--bw-text2)';
      var lbl = document.createElement('span');
      lbl.style.cssText = 'min-width:24px;color:var(--bw-gold);font-weight:700';
      lbl.textContent = label;
      var sel = document.createElement('select');
      sel.id = 'bwqp-cloud-' + tier;
      sel.style.cssText = 'font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg3);'
        + 'border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);padding:1px 3px;flex:1';
      ['local (default)', 'claude-haiku-4-5', 'claude-sonnet-4-6', 'claude-opus-4-6'].forEach(function(m) {
        var o = document.createElement('option'); o.value = m; o.textContent = m; sel.appendChild(o);
      });
      wrap.appendChild(lbl); wrap.appendChild(sel);
      return wrap;
    }
    cloudModelSection.appendChild(mkCloudSel('w5', 'W5'));
    cloudModelSection.appendChild(mkCloudSel('w6', 'W6'));
    var cloudApplyBtn = document.createElement('button');
    cloudApplyBtn.style.cssText = 'font-size:9px;padding:2px 8px;margin-top:4px;background:rgba(99,102,241,0.1);'
      + 'border:1px solid rgba(99,102,241,0.4);border-radius:3px;color:#818cf8;cursor:pointer;font-family:var(--bw-mono);width:100%';
    cloudApplyBtn.textContent = 'Apply cloud models — requires 2-key confirm';
    cloudApplyBtn.onclick = function() { _bwCloudModelWizard(); };
    cloudModelSection.appendChild(cloudApplyBtn);

    /* BW_R124: Anthropic API key input */
    var anthRow = document.createElement('div');
    anthRow.style.cssText = 'display:flex;align-items:center;gap:6px;margin-top:6px;font-size:10px';
    anthRow.innerHTML = '<span style="white-space:nowrap;color:var(--bw-text2)">Anthropic key</span>'
      + '<input id="bwqp-anth-key" type="password" placeholder="sk-ant-..."'
      + ' style="flex:1;font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg3);'
      + 'border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);padding:2px 5px">'
      + '<button id="bwqp-anth-save" style="font-size:9px;padding:2px 8px;background:rgba(248,113,113,0.1);'
      + 'border:1px solid rgba(248,113,113,0.4);border-radius:3px;color:#f87171;cursor:pointer;font-family:var(--bw-mono)">'
      + 'Save</button>'
      + '<span id="bwqp-anth-status" style="font-size:9px;color:var(--bw-text3)"></span>';
    var anthSave  = anthRow.querySelector('#bwqp-anth-save');
    var anthStat  = anthRow.querySelector('#bwqp-anth-status');
    var anthInput = anthRow.querySelector('#bwqp-anth-key');
    anthSave.onclick = function() {
      var key = anthInput.value.trim();
      if (!key) { anthStat.textContent = '⚠ empty'; return; }
      fetch(W.BW._API_BASE + '/credentials/save', { /* BW_R129b */
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ anthropic_key: key })
      }).then(function(r){ return r.json(); })
        .then(function(d){ anthStat.textContent = d.ok ? '✓ saved' : '✗ failed'; })
        .catch(function(){ anthStat.textContent = '✗ failed'; });
    };
    fetch(W.BW._API_BASE + '/settings/creds/load')
      .then(function(r){ return r.json(); })
      .then(function(c){ if (c.anthropic_key) anthInput.value = '•'.repeat(8)+' (saved)'; })
      .catch(function(){});
    cloudModelSection.appendChild(anthRow);

    /* BW_R121: OpenRouter API key input */
    var orRow = document.createElement('div');
    orRow.style.cssText = 'display:flex;align-items:center;gap:6px;margin-top:6px;font-size:10px';
    orRow.innerHTML = '<span style="white-space:nowrap;color:var(--bw-text2)">OpenRouter key</span>'
      + '<input id="bwqp-or-key" type="password" placeholder="sk-or-..."'
      + ' style="flex:1;font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg3);'
      + 'border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);padding:2px 5px">'
      + '<button id="bwqp-or-save" style="font-size:9px;padding:2px 8px;background:rgba(99,102,241,0.1);'
      + 'border:1px solid rgba(99,102,241,0.4);border-radius:3px;color:#818cf8;cursor:pointer;font-family:var(--bw-mono)">'
      + 'Save</button>'
      + '<span id="bwqp-or-status" style="font-size:9px;color:var(--bw-text3)"></span>';
    var orSave  = orRow.querySelector('#bwqp-or-save');
    var orStat  = orRow.querySelector('#bwqp-or-status');
    var orInput = orRow.querySelector('#bwqp-or-key');
    orSave.onclick = function() {
      var key = orInput.value.trim();
      if (!key) { orStat.textContent = '\u26a0 empty'; return; }
      fetch(W.BW._API_BASE + '/credentials/save', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({ openrouter_key: key })
      }).then(function(r){ return r.json(); })
        .then(function(d){ orStat.textContent = d.ok ? '\u2713 saved' : '\u2717 failed'; })
        .catch(function(){ orStat.textContent = '\u2717 failed'; });
    };
    fetch(W.BW._API_BASE + '/settings/creds/load')
      .then(function(r){ return r.json(); })
      .then(function(c){ if (c.openrouter_key) orInput.value = '\u2022'.repeat(8)+' (saved)'; })
      .catch(function(){});
    cloudModelSection.appendChild(orRow);

    var azSection = sec('Agent Zero');
    azSection.appendChild(chk('az', 'Delegation enabled'));

    // ── BW_R80P53B / BW_R80P54A: Identity Protection section (collapsible) ──
    // Wrapped in collapsible header. Default collapsed — click header to expand.
    var idSection = document.createElement('div');
    idSection.className = 'bw-qp-id-section';
    idSection.style.cssText = 'display:flex;flex-direction:column;gap:5px';

    // Collapsible header
    var idHdr = document.createElement('div');
    idHdr.id = 'bwqp-id-header';
    idHdr.style.cssText = 'cursor:pointer;display:flex;align-items:center;gap:8px;font-size:9px;color:var(--bw-text3);letter-spacing:.1em;text-transform:uppercase;user-select:none;padding:4px 0';
    var idArrow = document.createElement('span');
    idArrow.id = 'bwqp-id-arrow';
    idArrow.style.cssText = 'display:inline-block;width:10px;color:var(--bw-text3);transition:transform 0.15s';
    idArrow.textContent = '▸'; // ▸
    idHdr.appendChild(idArrow);
    var idHdrLabel = document.createElement('span');
    idHdrLabel.textContent = 'IDENTITY PROTECTION';
    idHdr.appendChild(idHdrLabel);
    var idHdrSpacer = document.createElement('span');
    idHdrSpacer.style.cssText = 'flex:1';
    idHdr.appendChild(idHdrSpacer);
    var idStatus = document.createElement('div');
    idStatus.id = 'bwqp-id-status';
    idStatus.style.cssText = 'font-size:10px;color:var(--bw-gold)';
    idStatus.textContent = 'Loading...';
    idHdr.appendChild(idStatus);
    idSection.appendChild(idHdr);

    // Collapsible body — starts hidden (collapsed)
    var idBody = document.createElement('div');
    idBody.id = 'bwqp-id-body';
    idSection.appendChild(idBody);

    // Toggle handler — uses .expanded class so CSS controls grid layout
    idHdr.onclick = function() {
      var isOpen = idBody.classList.contains('expanded');
      idBody.classList.toggle('expanded');
      idArrow.style.transform = isOpen ? 'none' : 'rotate(90deg)';
      if (!isOpen) { try { _bwR53IdRefresh(); } catch(e) {} }
    };

    function _idChk(id, label) {
      var wrap = document.createElement('label');
      wrap.style.cssText = 'display:flex;align-items:center;gap:6px;cursor:pointer;font-size:11px;color:var(--bw-text2)';
      var cb = document.createElement('input');
      cb.type = 'checkbox'; cb.id = 'bwqp-id-' + id;
      cb.style.accentColor = 'var(--bw-gold)';
      wrap.appendChild(cb);
      wrap.appendChild(document.createTextNode(label));
      return wrap;
    }
    // BW_R80P53C: left column
    var idLeft = document.createElement('div');
    idLeft.className = 'bw-qp-id-block';
    idLeft.appendChild(_idChk('master',     'Master scrub layer'));
    idLeft.appendChild(_idChk('shellblock', 'Block cloud identity shells'));
    idLeft.appendChild(_idChk('localscrub', 'Scrub for local LLMs too'));
    idBody.appendChild(idLeft); // BW_R80P54A: into collapsible body
    // BW_R80P53C: right column
    var idRight = document.createElement('div');
    idRight.className = 'bw-qp-id-block';

    idSection.querySelector('#bwqp-id-master').onchange = function(ev) {
      var newVal = ev.target.checked;
      var commit = function() {
        fetch(W.BW._API_BASE + '/perms/identity', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({scrub_machine_identity: newVal}),
        }).then(_bwR53IdRefresh);
      };
      if (!newVal) {
        // BW_R80P54A: replaced browser confirm() with proper modal
        _bwIdModalConfirm({
          title: 'Disable identity scrub layer?',
          body: 'All cloud and local outbound text will contain real machine identifiers.',
          warn: 'This significantly weakens privacy.',
          okLabel: 'Disable',
          danger: true,
        }).then(function(yes) {
          if (!yes) { ev.target.checked = true; return; }
          commit();
        });
      } else {
        commit();
      }
    };
    idSection.querySelector('#bwqp-id-shellblock').onchange = function(ev) {
      fetch(W.BW._API_BASE + '/perms/identity', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({block_cloud_identity_shells: ev.target.checked}),
      }).then(_bwR53IdRefresh);
    };
    idSection.querySelector('#bwqp-id-localscrub').onchange = function(ev) {
      fetch(W.BW._API_BASE + '/perms/identity', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({scrub_for_local_llms: ev.target.checked}),
      }).then(_bwR53IdRefresh);
    };

    var idDetectedTitle = document.createElement('div');
    idDetectedTitle.style.cssText = 'font-size:9px;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.05em;margin-top:6px';
    idDetectedTitle.textContent = 'Detected:';
    idRight.appendChild(idDetectedTitle);

    var idRowsContainer = document.createElement('div');
    idRowsContainer.id = 'bwqp-id-rows';
    idRowsContainer.style.cssText = 'display:flex;flex-direction:column;gap:2px;margin-top:2px';
    idRight.appendChild(idRowsContainer);

    var idActions = document.createElement('div');
    idActions.style.cssText = 'display:flex;gap:6px;margin-top:4px';
    var _idBtnStyle = 'font-size:9px;padding:2px 8px;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);cursor:pointer;font-family:var(--bw-mono)';
    var redetectBtn = document.createElement('button');
    redetectBtn.style.cssText = _idBtnStyle;
    redetectBtn.textContent = '\u21BB Re-detect';
    redetectBtn.onclick = function() {
      // BW_R80P54A: visible feedback for re-detect
      _bwIdNotify('Re-detecting identity...', 'info');
      fetch(W.BW._API_BASE + '/skill/identity_redetect', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({args:{}})
      }).then(function(r) { return r.json(); }).then(function(d) {
        if (d.result && d.result.ok) {
          _bwIdNotify('Identity re-detected: ' + (d.result.pattern_count || 0) + ' patterns', 'ok');
          _bwR53IdRefresh();
        } else {
          _bwIdNotify('Re-detect failed: ' + ((d.result && d.result.error) || 'unknown'), 'warn');
        }
      }).catch(function(e) {
        _bwIdNotify('Re-detect error: ' + e.message, 'warn');
      });
    };
    var idRefreshBtn = document.createElement('button');
    idRefreshBtn.style.cssText = _idBtnStyle;
    idRefreshBtn.textContent = '\u21BB Refresh';
    idRefreshBtn.onclick = function() { _bwR53IdRefresh(); };
    idActions.appendChild(redetectBtn);
    idActions.appendChild(idRefreshBtn);
    idRight.appendChild(idActions);

    var pinTitle = document.createElement('div');
    pinTitle.style.cssText = 'font-size:9px;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.05em;margin-top:6px';
    pinTitle.textContent = 'Privacy PIN:';
    idRight.appendChild(pinTitle);

    var pinRow = document.createElement('div');
    pinRow.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:11px;margin-top:2px';
    var pinStatus = document.createElement('span');
    pinStatus.id = 'bwqp-id-pin-status';
    pinStatus.style.cssText = 'color:var(--bw-text3);flex:1';
    pinStatus.textContent = '...';
    pinRow.appendChild(pinStatus);

    var pinSetBtn = document.createElement('button');
    pinSetBtn.style.cssText = _idBtnStyle;
    pinSetBtn.textContent = 'Set PIN';
    pinSetBtn.onclick = function() {
      // BW_R80P54A: replaced prompt() with modal — and use API truth, not DOM text
      fetch(W.BW._API_BASE + '/perms/identity').then(function(r) { return r.json(); }).then(function(cfg) {
        var pinAlreadySet = !!cfg.pin_set;
        _bwIdModalPrompt({
          title: pinAlreadySet ? 'Change Privacy PIN' : 'Set Privacy PIN',
          body: pinAlreadySet
            ? 'Enter your CURRENT PIN to authorize the change.'
            : 'Choose a 4-32 character PIN. Required for sharing identity with cloud.',
          placeholder: pinAlreadySet ? 'Current PIN' : 'New PIN (4-32 chars)',
          kind: 'pin',
          okLabel: pinAlreadySet ? 'Verify' : 'Set',
        }).then(function(firstInput) {
          if (!firstInput) return;
          if (!pinAlreadySet) {
            return fetch(W.BW._API_BASE + '/skill/identity_pin_set', {
              method:'POST', headers:{'Content-Type':'application/json'},
              body: JSON.stringify({args:{new_pin: firstInput, current_pin: ''}})
            }).then(function(r) { return r.json(); }).then(function(d) {
              if (d.result && d.result.ok) {
                _bwIdNotify('PIN set successfully', 'ok');
                _bwR53IdRefresh();
              } else {
                _bwIdNotify('PIN set failed: ' + ((d.result && d.result.error) || 'unknown'), 'warn');
              }
            });
          }
          // Change path — first prompt was current PIN, now ask for new
          return _bwIdModalPrompt({
            title: 'New PIN',
            body: 'Enter your new PIN (4-32 characters).',
            placeholder: 'New PIN',
            kind: 'pin',
            okLabel: 'Save',
          }).then(function(newPin) {
            if (!newPin) return;
            return fetch(W.BW._API_BASE + '/skill/identity_pin_set', {
              method:'POST', headers:{'Content-Type':'application/json'},
              body: JSON.stringify({args:{new_pin: newPin, current_pin: firstInput}})
            }).then(function(r) { return r.json(); }).then(function(d) {
              if (d.result && d.result.ok) {
                _bwIdNotify('PIN updated', 'ok');
                _bwR53IdRefresh();
              } else {
                _bwIdNotify('PIN change failed: ' + ((d.result && d.result.error) || 'unknown'), 'warn');
              }
            });
          });
        });
      });
    };
    var pinClearBtn = document.createElement('button');
    pinClearBtn.style.cssText = _idBtnStyle;
    pinClearBtn.id = 'bwqp-id-pin-clear-btn';
    pinClearBtn.textContent = 'Clear PIN';
    pinClearBtn.style.display = 'none';
    pinClearBtn.onclick = function() {
      // BW_R80P54A: replaced prompt() with modal
      _bwIdModalPrompt({
        title: 'Clear Privacy PIN',
        body: 'Enter your current PIN to remove it.',
        placeholder: 'Current PIN',
        kind: 'pin',
        okLabel: 'Clear',
      }).then(function(current) {
        if (!current) return;
        fetch(W.BW._API_BASE + '/skill/identity_pin_clear', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify({args:{current_pin: current}})
        }).then(function(r) { return r.json(); }).then(function(d) {
          if (d.result && d.result.ok) {
            _bwIdNotify('PIN cleared', 'ok');
            _bwR53IdRefresh();
          } else {
            _bwIdNotify('PIN clear failed: ' + ((d.result && d.result.error) || 'unknown'), 'warn');
          }
        });
      });
    };
    pinRow.appendChild(pinSetBtn);
    pinRow.appendChild(pinClearBtn);

    // BW_R80P54A: Forgot PIN — operator recovery path when PIN is unknown
    var pinForgotBtn = document.createElement('button');
    pinForgotBtn.id = 'bwqp-id-pin-forgot-btn';
    pinForgotBtn.style.cssText = _idBtnStyle + ';color:#f87171;border-color:rgba(220,50,50,0.4)';
    pinForgotBtn.textContent = 'Forgot PIN';
    pinForgotBtn.title = 'Force-clear the PIN if you no longer remember it (logged for audit)';
    pinForgotBtn.style.display = 'none'; // Only shown when a PIN is set (toggled in _bwR53IdRefresh)
    pinForgotBtn.onclick = function() {
      _bwIdModalConfirm({
        title: 'Force-clear forgotten PIN?',
        body: 'This will remove the privacy PIN entirely. Used when you no longer remember it.\n\nFuture identity unlocks will use 2x click-confirm only (no PIN required).\n\nThe action will be logged.',
        warn: 'Anyone with localhost access to your Beewid API can perform this action.',
        okLabel: 'Force-clear PIN',
        danger: true,
      }).then(function(confirmed) {
        if (!confirmed) return;
        fetch(W.BW._API_BASE + '/perms/identity/pin_force_clear', {
          method: 'POST',
          headers: {'Content-Type': 'application/json'},
        }).then(function(r) { return r.json(); }).then(function(d) {
          if (d.ok) {
            _bwIdNotify('PIN force-cleared (had_pin=' + d.had_pin + ')', 'info');
            _bwR53IdRefresh();
          } else {
            _bwIdNotify('Force-clear failed: ' + (d.error || 'unknown'), 'warn');
          }
        });
      });
    };
    pinRow.appendChild(pinForgotBtn);
    idRight.appendChild(pinRow);

    var factsTitle = document.createElement('div');
    factsTitle.style.cssText = 'font-size:9px;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.05em;margin-top:6px';
    factsTitle.textContent = 'Approved Facts:';
    idRight.appendChild(factsTitle);

    var factsList = document.createElement('div');
    factsList.id = 'bwqp-id-facts-list';
    factsList.style.cssText = 'display:flex;flex-direction:column;gap:2px;margin-top:2px';
    idRight.appendChild(factsList);

    var factsAddRow = document.createElement('div');
    factsAddRow.style.cssText = 'display:flex;gap:4px;margin-top:4px';
    var factsInput = document.createElement('input');
    factsInput.id = 'bwqp-id-facts-input';
    factsInput.type = 'text';
    factsInput.placeholder = 'Approved fact';
    factsInput.style.cssText = 'flex:1;font-family:var(--bw-mono);font-size:10px;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);padding:2px 5px';
    factsInput.maxLength = 500;
    var factsAddBtn = document.createElement('button');
    factsAddBtn.style.cssText = _idBtnStyle;
    factsAddBtn.textContent = '+ Add';
    factsAddBtn.onclick = function() {
      var v = (factsInput.value || '').trim();
      if (!v) return;
      var existing = (window._bwR53IdState && window._bwR53IdState.cfg &&
                      window._bwR53IdState.cfg.approved_facts) || [];
      var next = existing.slice(); next.push(v);
      fetch(W.BW._API_BASE + '/perms/identity', {
        method:'POST', headers:{'Content-Type':'application/json'},
        body: JSON.stringify({approved_facts: next})
      }).then(function() { factsInput.value = ''; _bwR53IdRefresh(); });
    };
    factsAddRow.appendChild(factsInput);
    factsAddRow.appendChild(factsAddBtn);
    idRight.appendChild(factsAddRow);
    // BW_R80P53C: close right column
    idBody.appendChild(idRight); // BW_R80P54A: into collapsible body
    // ── End BW_R80P53B / BW_R80P53C / BW_R80P54A Identity Protection section build ──────

    // ── Model RAM control section ──────────────────────────────────────────
    var ramSection = sec('Model RAM');
    function mkLockBtn(tier, label) {
      var wrap = document.createElement('div');
      wrap.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:11px';
      var locked = localStorage.getItem('bw_lockout_' + tier) === '1';
      var btn = document.createElement('button');
      btn.id = 'bwqp-lock-' + tier;
      btn.style.cssText = 'font-size:9px;padding:2px 7px;border-radius:3px;cursor:pointer;font-family:var(--bw-mono);'
        + (locked ? 'background:rgba(252,80,80,0.15);border:1px solid rgba(252,80,80,0.5);color:var(--bw-red)'
                  : 'background:rgba(52,211,153,0.1);border:1px solid rgba(52,211,153,0.4);color:#34d399');
      btn.textContent = locked ? '🔒 ' + label + ' LOCKED OFF' : '● ' + label + ' auto';
      btn.title = 'Click to toggle kick-and-stay-off mode';
      btn.onclick = function() {
        var isLocked = localStorage.getItem('bw_lockout_' + tier) === '1';
        var newLocked = !isLocked;
        localStorage.setItem('bw_lockout_' + tier, newLocked ? '1' : '0');
        btn.style.background = newLocked ? 'rgba(252,80,80,0.15)' : 'rgba(52,211,153,0.1)';
        btn.style.borderColor = newLocked ? 'rgba(252,80,80,0.5)' : 'rgba(52,211,153,0.4)';
        btn.style.color       = newLocked ? 'var(--bw-red)' : '#34d399';
        btn.textContent = newLocked ? '🔒 ' + label + ' LOCKED OFF' : '● ' + label + ' auto';
        // Tell API
        fetch(W.BW._API_BASE + '/admin/model/lockout', {
          method: 'POST', headers: {'Content-Type':'application/json'},
          body: JSON.stringify({ model: tier, locked: newLocked })
        }).then(function() {
          notify.ok(newLocked
            ? tier.toUpperCase() + ' locked OFF — will not reload'
            : tier.toUpperCase() + ' unlocked — self-preservation ON');
        }).catch(function() {
          notify.warn('Lockout API call failed');
        });
      };
      wrap.appendChild(btn);
      return wrap;
    }
    ramSection.appendChild(mkLockBtn('w5', 'W5'));
    ramSection.appendChild(mkLockBtn('w6', 'W6'));
    var ramNote = document.createElement('div');
    ramNote.style.cssText = 'font-size:9px;color:var(--bw-text3);margin-top:4px;line-height:1.5';
    ramNote.innerHTML = '🔒 = kick & stay off<br>● = self-preservation';
    ramSection.appendChild(ramNote);

    var ramSection = sec('RAM / Models');
    function mkLockBtn(tier) {
      var btn = document.createElement('button');
      btn.id = 'bwqp-lock-' + tier;
      btn.style.cssText = 'font-size:10px;padding:3px 10px;border-radius:3px;cursor:pointer;width:100%;margin-bottom:3px;'
        + 'background:rgba(239,68,68,0.1);border:1px solid rgba(239,68,68,0.35);color:#f87171;font-family:var(--bw-mono)';
      btn.textContent = '🔒 Lock ' + tier.toUpperCase() + ' OFF';
      btn.title = 'Pin model off — will not reload until unlocked. Right-click topbar pill also works.';
      btn.onclick = function() {
        var isLocked = btn.textContent.includes('Unlock');
        var newLocked = !isLocked;
        api.post('/admin/model/lockout', { model: tier, locked: newLocked }).then(function(d) {
          if (d.ok) {
            btn.textContent = newLocked ? ('🔓 Unlock ' + tier.toUpperCase()) : ('🔒 Lock ' + tier.toUpperCase() + ' OFF');
            btn.style.background = newLocked ? 'rgba(52,211,153,0.1)' : 'rgba(239,68,68,0.1)';
            btn.style.borderColor = newLocked ? 'rgba(52,211,153,0.35)' : 'rgba(239,68,68,0.35)';
            btn.style.color = newLocked ? '#34d399' : '#f87171';
            notify.ok(newLocked ? tier.toUpperCase() + ' locked OFF — will not reload' : tier.toUpperCase() + ' unlocked');
          }
        }).catch(function(e) { notify.warn('Lockout failed: ' + e.message); });
      };
      return btn;
    }
    // Set initial state from config
    api.get('/config').then(function(d) {
      if (!d.ok && !d.config) return;
      var cfg = d.config || {};
      var lk = cfg.model_lockout || {};
      ['w5','w6'].forEach(function(tier) {
        var btn = document.getElementById('bwqp-lock-' + tier);
        if (!btn) return;
        var locked = !!lk[tier];
        btn.textContent = locked ? ('🔓 Unlock ' + tier.toUpperCase()) : ('🔒 Lock ' + tier.toUpperCase() + ' OFF');
        btn.style.background = locked ? 'rgba(52,211,153,0.1)' : 'rgba(239,68,68,0.1)';
        btn.style.borderColor = locked ? 'rgba(52,211,153,0.35)' : 'rgba(239,68,68,0.35)';
        btn.style.color = locked ? '#34d399' : '#f87171';
      });
    }).catch(function(){});
    ramSection.appendChild(mkLockBtn('w5'));
    ramSection.appendChild(mkLockBtn('w6'));
    var ramNote = document.createElement('div');
    ramNote.style.cssText = 'font-size:9px;color:var(--bw-text3);margin-top:2px';
    ramNote.textContent = 'Locked = unloaded + stays off';
    ramSection.appendChild(ramNote);

    var statusSection = sec('Status');
    var st = document.createElement('div');
    st.id = 'bwqp-status';
    st.style.cssText = 'font-size:10px;color:var(--bw-text3);line-height:1.7';
    var risk = document.createElement('div');
    risk.id = 'bwqp-risk';
    risk.style.cssText = 'font-size:10px;color:var(--bw-amber);margin-top:4px;display:none';
    statusSection.appendChild(st);
    statusSection.appendChild(risk);

    var actSection = sec('');
    actSection.style.cssText += ';flex-direction:row;align-items:center;flex-wrap:wrap;gap:5px'; /* BW_R108 */
    actSection.style.marginLeft = 'auto';
    var saveStatus = document.createElement('div');
    saveStatus.id = 'bwqp-save-status';
    saveStatus.style.cssText = 'font-size:9px;color:var(--bw-text3);flex-basis:100%;min-height:0';
    /* BW_R108: compact inline action row */
    var applyBtn = document.createElement('button');
    applyBtn.style.cssText = BS2 + ';color:var(--bw-gold);border-color:rgba(245,200,66,0.4);padding:2px 10px;flex:1';
    applyBtn.textContent = 'Apply';
    applyBtn.onclick = _bwApplyQP;
    var resetBtn = document.createElement('button');
    resetBtn.style.cssText = BS2 + ';color:var(--bw-red);border-color:rgba(252,80,80,0.3);padding:2px 10px;flex:1';
    resetBtn.textContent = 'Safe Reset';
    resetBtn.onclick = _bwResetQP;
    var closeBtn = document.createElement('button');
    closeBtn.style.cssText = BS2 + ';padding:2px 8px;flex-shrink:0';
    closeBtn.textContent = '× Close';
    closeBtn.onclick = BW_openQPerms;
    actSection.appendChild(saveStatus);
    actSection.appendChild(applyBtn);
    actSection.appendChild(resetBtn);

    /* BW_R103: tab jump buttons */
    var jumpWrap = document.createElement('div');
    jumpWrap.style.cssText = 'display:flex;gap:5px;align-items:center';
    ['⚙ Settings|/static/beewid_settings.html',
     '🤖 Agents|/static/beewid_agents.html',
     '🏛 Governance|/static/beewid_governance.html'].forEach(function(item) {
      var parts = item.split('|');
      var jb = document.createElement('button');
      jb.textContent = parts[0];
      jb.style.cssText = 'font-family:var(--bw-mono);font-size:9px;padding:2px 7px;' +
        'background:var(--bw-bg3);border:1px solid var(--bw-border2);' +
        'color:var(--bw-text3);border-radius:3px;cursor:pointer';
      jb.onclick = function() { window.location.href = parts[1]; };
      jumpWrap.appendChild(jb);
    });
    actSection.appendChild(jumpWrap);

    actSection.appendChild(closeBtn);

    panel.appendChild(modeSection);
    panel.appendChild(togSection);
    panel.appendChild(cloudSection);
    panel.appendChild(cloudModelSection);
    panel.appendChild(azSection);
    panel.appendChild(idSection);
    panel.appendChild(ramSection);
    panel.appendChild(ramSection);
    panel.appendChild(statusSection);
    panel.appendChild(actSection);

    /* BW_R123fix: append panel to wrapper, then position wrapper smartly */
    qpWrap.appendChild(panel);

    /* BW_R140b: Smart placement - prefer controls-panel-wrap on chat, se-wrap on other tabs */
    var _seW = document.getElementById('bw-se-wrap');
    var _nav = document.getElementById('bw-nav');
    var _ctrlWrap = document.getElementById('controls-panel-wrap');
    if (_seW && _seW.parentNode) {
      /* Non-chat tabs: insert after shared engine wrap */
      _seW.parentNode.insertBefore(qpWrap, _seW.nextSibling);
    } else if (_ctrlWrap && _ctrlWrap.parentNode) {
      /* Chat tab: insert AFTER controls-panel-wrap so Perms is below Engine */
      _ctrlWrap.parentNode.insertBefore(qpWrap, _ctrlWrap.nextSibling);
    } else if (_nav && _nav.parentNode) {
      /* Main chat + fallback: insert after sidebar nav, before page content */
      _nav.parentNode.insertBefore(qpWrap, _nav.nextSibling);
    } else {
      document.body.insertBefore(qpWrap, document.body.firstChild);
    }
    /* BW_R137: removed controls-panel-wrap branch — caused perms to float mid-page on main chat */

    /* Wire ResizeObserver so _bwReflow tracks height changes */
    if (W.ResizeObserver && W._bwQPObserver === undefined) {
      W._bwQPObserver = new ResizeObserver(function() {
        if (W._bwReflow) W._bwReflow();
      });
      W._bwQPObserver.observe(qpWrap);
    }
    requestAnimationFrame(function() { if (W._bwReflow) W._bwReflow(); });

    var qpBtn = document.getElementById('bw-qperms-btn');
    if (qpBtn) { qpBtn.style.color = 'var(--bw-gold)'; qpBtn.style.background = 'var(--bw-gold-dim)'; }
    /* BW_R123: load config immediately — no positioning needed */
    _bwLoadQPConfig();
  }

  function _bwLoadQPConfig() {
    /* Disable Apply until config is loaded — prevents race where user clicks
       Apply with stale/unchecked state before async /config returns */
    var applyBtnEl = document.querySelector('#bw-qp-panel button[style*="bw-gold"]');
    if (applyBtnEl) { applyBtnEl.disabled = true; applyBtnEl.textContent = 'Loading…'; }
    api.get('/config').then(function(d) {
      if (!d.ok) return;
      _bwQPCfg = d.config || {};
      _bwSyncQPUI(_bwQPCfg);
      if (applyBtnEl) { applyBtnEl.disabled = false; applyBtnEl.textContent = 'Apply'; }
    }).catch(function() {
      if (applyBtnEl) { applyBtnEl.disabled = false; applyBtnEl.textContent = 'Apply'; }
    });
  }

  function _bwChkSet(id, val) { var el = document.getElementById('bwqp-' + id); if (el) el.checked = !!val; }
  function _bwChkGet(id) { var el = document.getElementById('bwqp-' + id); return el ? el.checked : false; }

  function _bwSetAIMode(m) { /* legacy no-op: modes are now checkboxes */ }
  function _bwSyncModeChks(cfg) {
    var a = document.getElementById('bwqp-mode-A'); if (a) a.checked = cfg.ai_direct_enabled !== false;
    var b = document.getElementById('bwqp-mode-B'); if (b) b.checked = !!cfg.ai_az_enabled;
    var c = document.getElementById('bwqp-mode-C'); if (c) c.checked = !!cfg.ai_az_live;
    var n = document.getElementById('bwqp-mode-N'); if (n) n.checked = !!cfg.ai_standby;
  }

  function _bwSyncQPUI(cfg) {
    _bwSyncModeChks(cfg);
    _bwChkSet('inet',         (cfg.policy_level || 1) >= 2);
    _bwChkSet('agentic',      !!cfg.agentic_mode);
    _bwChkSet('agentic_plus', !!cfg.agentic_plus); /* BW_R63 */
    _bwChkSet('active',       !cfg.ai_disabled);
    _bwChkSet('pollinations', !!cfg.pollinations_enabled);
    _bwChkSet('haiku',        !!cfg.cloud_ai_enabled);
    _bwChkSet('az',           !!cfg.agent_zero_enabled);
    _bwChkSet('vault-read',   cfg.vault_read  !== false);
    _bwChkSet('vault-write',  cfg.vault_write !== false);
    _bwChkSet('sudo-prompt',  cfg.sudo_prompt !== false);
    var _hs = document.getElementById('bwqp-hallucin');
    if (_hs) _hs.value = cfg.hallucin_detect || 'warn';
    var ks = document.getElementById('bwqp-key-status');
    if (ks) ks.textContent = (cfg.anthropic_api_key || cfg.openai_api_key) ? 'API key set' : 'No key (Settings)';
    var st = document.getElementById('bwqp-status');
    if (st) st.innerHTML = 'Policy L' + (cfg.policy_level || 1) + '<br>'
      + (cfg.agentic_mode ? 'Agentic ON' : 'Agentic OFF') + '<br>'
      + (cfg.cloud_ai_enabled || cfg.cloud_w5_model || cfg.cloud_w6_model ? 'Cloud ON' : 'Cloud OFF');
    _bwUpdateRisk();
  }

  function _bwUpdateRisk() {
    var risks = [];
    if (_bwChkGet('inet'))    risks.push('Internet ON');
    if (_bwChkGet('agentic')) risks.push('Agentic ON — AI can call tools');
    var box = document.getElementById('bwqp-risk');
    if (box) { box.style.display = risks.length ? 'block' : 'none'; box.innerHTML = '&#9888; ' + risks.join(' &nbsp;·&nbsp; '); }
  }

  function _bwApplyQP() {
    var ss = document.getElementById('bwqp-save-status');
    var mA = document.getElementById('bwqp-mode-A');
    var mB = document.getElementById('bwqp-mode-B');
    var mC = document.getElementById('bwqp-mode-C');
    var mN = document.getElementById('bwqp-mode-N');
    var update = {
      policy_level:         _bwChkGet('inet') ? 2 : 1,
      agentic_mode:         _bwChkGet('agentic'),
      agentic_plus:         _bwChkGet('agentic_plus'), /* BW_R63 */
      pollinations_enabled: _bwChkGet('pollinations'),
      cloud_ai_enabled:     _bwChkGet('haiku'),
      agent_zero_enabled:   _bwChkGet('az'),
      ai_direct_enabled:    mA ? mA.checked : true,
      ai_az_enabled:        mB ? mB.checked : false,
      ai_az_live:           mC ? mC.checked : false,
      ai_standby:           mN ? mN.checked : false,
      vault_read:           _bwChkGet('vault-read'),
      vault_write:          _bwChkGet('vault-write'),
      sudo_prompt:          _bwChkGet('sudo-prompt'),
      hallucin_detect:      (function(){ var s=document.getElementById('bwqp-hallucin'); return s?s.value:'warn'; })(),
    };
    var isActive = _bwChkGet('active') && !(mN && mN.checked);
    api.post('/admin/killswitch', {enabled: isActive}).catch(function() {});
    api.post('/config/update', update).then(function(d) {
      console.log('[QP] config/update response:', JSON.stringify(d));
      if (d && d.ok) {
        if (ss) { ss.textContent = 'Saved'; setTimeout(function() { ss.textContent = ''; }, 2500); }
        _bwQPCfg = Object.assign(_bwQPCfg, update);
        notify.ok('Perms saved — L' + update.policy_level);
        if (typeof _updateIndicators === 'function') _updateIndicators(null, update);
        var sel = document.getElementById('bw-policy-select');
        if (sel) sel.value = update.policy_level;
        _sendToCopilot({action: 'reloadConfig'});
      } else {
        console.warn('[QP] Save failed. d=', d, 'update=', JSON.stringify(update));
        notify.warn('Save failed (check console for details)');
      }
    }).catch(function(e) {
      console.error('[QP] api.post error:', e);
      notify.error('QP save error: ' + e.message);
    });
  }

  function _bwResetQP() {
    if (!confirm('Reset to safe defaults?')) return;
    api.post('/config/reset', {}).then(function() { _bwLoadQPConfig(); notify.warn('Reset to safe defaults'); }).catch(function(e) { notify.error(e.message); });
  }

  /* ── Hardware autodetect (BW_R59) ────────────────────────── */
  function BW_autodetectHardware() {
    var btn = document.getElementById('bw-detect-btn');
    if (btn) { btn.textContent = '...'; btn.disabled = true; }
    api.post('/skill/ram_check', {}).then(function(d) {
      var out = (d.result && d.result.output) ? d.result.output : '';
      var match = out.match(/Mem:\s+([\d.]+)([GgMm])/);
      var ramGB = 0;
      if (match) { ramGB = parseFloat(match[1]); if (match[2].toLowerCase() === 'm') ramGB /= 1024; }

      /* Profile selection */
      var profile = ramGB >= 32 ? 'god' : ramGB >= 24 ? 'high' : ramGB >= 16 ? 'mid' : ramGB >= 8 ? 'low' : 'ultra_low';

      /* Model recommendations per RAM tier (CPU-only, BW_R59) */
      var recW5, recW6, recW5to, recW6to;
      if (ramGB >= 32) {
        recW5 = 'mistral:7b';          recW6 = 'qwen2.5:14b';
        recW5to = 360; recW6to = 600;
      } else if (ramGB >= 24) {
        recW5 = 'mistral:7b';          recW6 = 'qwen2.5:14b';
        recW5to = 420; recW6to = 720;
      } else if (ramGB >= 16) {
        recW5 = 'mistral:7b';          recW6 = 'llama3.1:8b';
        recW5to = 480; recW6to = 840;
      } else if (ramGB >= 8) {
        recW5 = 'qwen3:4b';            recW6 = 'mistral:7b';
        recW5to = 600; recW6to = 900;
      } else {
        recW5 = 'tinyllama:latest';     recW6 = 'qwen3:4b';
        recW5to = 900; recW6to = 1200;
      }

      var msg = 'Detected ' + (ramGB > 0 ? ramGB.toFixed(0) + 'GB RAM' : 'RAM unknown') + ' \u2014 CPU-only'
        + '\nProfile: ' + profile
        + '\n\nRecommended models:'
        + '\n  W5 (fast): ' + recW5
        + '\n  W6 (deep): ' + recW6
        + '\n\nStream timeouts:'
        + '\n  W5: ' + recW5to + 's   W6: ' + recW6to + 's'
        + '\n\nApply profile + set timeouts?';

      if (confirm(msg)) {
        BW_applyProfile(profile);
        var sel = document.getElementById('bw-res-profile');
        if (sel) sel.value = profile;
        /* Push recommended timeouts to chat.html inputs if present */
        var tw5 = document.getElementById('timeout-w5');
        var tw6 = document.getElementById('timeout-w6');
        if (tw5) tw5.value = recW5to;
        if (tw6) tw6.value = recW6to;
        /* Persist timeout to localStorage for cross-page access */
        try {
          localStorage.setItem('bw_timeout_w5', String(recW5to));
          localStorage.setItem('bw_timeout_w6', String(recW6to));
        } catch(e) {}
        notify.ok('Profile: ' + profile + ' \u2014 W5 ' + recW5to + 's / W6 ' + recW6to + 's');
      }
      if (btn) { btn.textContent = '\uD83D\uDD0D'; btn.disabled = false; }
    }).catch(function() {
      notify.warn('Could not read hardware info');
      if (btn) { btn.textContent = '\uD83D\uDD0D'; btn.disabled = false; }
    });
  }

  /* BW_R59: set model from the universal model bar (non-chat tabs) */
  function BW_setModelFromBar(tier, val) {
    if (!val || val === '— loading —') return;
    var key = tier === 'w6' ? 'w6_model' : 'ollama_model';
    api.post('/settings/save', JSON.stringify({ [key]: val }))
      .then(function() { notify.ok(tier.toUpperCase() + ' \u2192 ' + val); })
      .catch(function() { notify.warn('Model save failed'); });
  }

  /* ── Copilot bridge ──────────────────────────────────────── */
  function _sendToCopilot(msg) {
    var frame = document.getElementById('bw-copilot-frame');
    if (frame && frame.contentWindow) {
      try { frame.contentWindow.postMessage(JSON.stringify(msg), '*'); } catch(e) {}
    }
  }

  function BW_applyProfile(key) {
    if (!key) return;
    session.set('resource_profile', key);
    _sendToCopilot({ action: 'loadProfile', key: key });
    var sel = document.getElementById('bw-res-profile');
    if (sel) sel.value = key;
    notify.ok('Profile: ' + key + ' — models + context set');
  }

  function _bwCloudModelWizard() {
    var w5sel = document.getElementById('bwqp-cloud-w5');
    var w6sel = document.getElementById('bwqp-cloud-w6');
    var w5val = w5sel ? w5sel.value : 'local (default)';
    var w6val = w6sel ? w6sel.value : 'local (default)';
    if (w5val === 'local (default)' && w6val === 'local (default)') {
      notify.warn('No cloud model selected — both are set to local'); return;
    }
    // Step 1: Are you sure?
    var step = 1;
    var overlay = document.createElement('div');
    overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.7);z-index:99999;'
      + 'display:flex;align-items:center;justify-content:center';
    function showStep(n) {
      overlay.innerHTML = '';
      var box = document.createElement('div');
      box.style.cssText = 'background:var(--bw-bg2);border:2px solid rgba(252,80,80,0.6);border-radius:8px;'
        + 'padding:20px 24px;max-width:420px;width:90%;font-family:var(--bw-mono);font-size:11px';
      var steps = [
        { icon:'⚠', title:'WARNING — Cloud AI access', body:'You are about to route W5/W6 inference through a cloud AI model.<br><br>'
          + '<b>W5:</b> ' + w5val + '<br><b>W6:</b> ' + w6val + '<br><br>'
          + '☁ Cloud AI will receive your prompts and system context.<br>'
          + 'Privacy rules apply — no system secrets will be sent without your explicit permission.<br><br>'
          + 'Select access level for cloud models:',
          showLevels: true },
        { icon:'🔑', title:'TURNKEY 1 — Confirm authorization', body:'Type your sudo password to confirm you understand this action.<br><br>'
          + '<b>This authorizes cloud model access.</b><br>Password is used once and never stored.',
          showPassword: true },
        { icon:'🔑', title:'TURNKEY 2 — Final confirmation', body:'Enter your password again to activate cloud AI models.<br><br>'
          + 'After this, W5/W6 will route to cloud until you change them back in Quick Perms.',
          showPassword: true },
        { icon:'🤝', title:'Good luck, partner', body:'Cloud AI models are now active.<br><br>'
          + '<b>W5:</b> ' + w5val + '<br><b>W6:</b> ' + w6val + '<br><br>'
          + 'All prompts sent to W5/W6 will now go to the selected cloud model.<br>'
          + 'To revert: open Quick Perms → Cloud Models → set both to "local (default)".<br><br>'
          + '⚡ Guardrails active: cloud AI is prohibited from receiving filesystem paths, credentials, or internal config without explicit permission.',
          final: true }
      ];
      var s = steps[n-1];
      box.innerHTML = '<div style="color:var(--bw-red);font-size:14px;font-weight:700;margin-bottom:10px">'
        + s.icon + ' ' + s.title + '</div>'
        + '<div style="color:var(--bw-text2);line-height:1.6;margin-bottom:12px">' + s.body + '</div>';
      if (s.showLevels) {
        var lvl = document.createElement('div');
        lvl.style.cssText = 'display:flex;flex-direction:column;gap:4px;margin-bottom:12px';
        ['L1 — prompts only (safest)', 'L2 — prompts + active problems', 'L3 — prompts + problems + session context'].forEach(function(opt, i) {
          var lbl = document.createElement('label');
          lbl.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:10px;color:var(--bw-text2);cursor:pointer';
          var rb = document.createElement('input'); rb.type = 'radio'; rb.name = 'cloud-level'; rb.value = i+1;
          if (i === 0) rb.checked = true;
          lbl.appendChild(rb); lbl.appendChild(document.createTextNode(opt));
          lvl.appendChild(lbl);
        });
        box.appendChild(lvl);
      }
      if (s.showPassword) {
        var pw = document.createElement('input');
        pw.type = 'password'; pw.placeholder = 'sudo password…';
        pw.style.cssText = 'width:100%;box-sizing:border-box;background:var(--bw-bg3);border:1px solid var(--bw-border2);'
          + 'color:var(--bw-text1);border-radius:4px;padding:6px 8px;font-family:var(--bw-mono);font-size:11px;margin-bottom:10px;outline:none';
        box.appendChild(pw);
        setTimeout(function(){ pw.focus(); }, 100);
      }
      var btns = document.createElement('div');
      btns.style.cssText = 'display:flex;gap:8px;justify-content:flex-end';
      var cancel = document.createElement('button');
      cancel.textContent = '✕ Cancel'; cancel.style.cssText = 'padding:4px 12px;background:transparent;border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text3);cursor:pointer;font-family:var(--bw-mono);font-size:10px';
      cancel.onclick = function() { overlay.remove(); };
      var next = document.createElement('button');
      next.style.cssText = 'padding:4px 12px;background:rgba(252,80,80,0.15);border:1px solid rgba(252,80,80,0.5);border-radius:3px;color:var(--bw-red);cursor:pointer;font-family:var(--bw-mono);font-size:10px;font-weight:700';
      next.textContent = n < 4 ? 'Confirm →' : '✓ Activate';
      next.onclick = function() {
        if (n < 3) { showStep(n+1); }
        else if (n === 3) { showStep(4); }
        else {
          // Actually apply
          overlay.remove();
          var selectedLevel = document.querySelector('input[name="cloud-level"]:checked');
          var level = selectedLevel ? selectedLevel.value : '1';
          fetch(W.BW._API_BASE + '/config/update', {
            method:'POST', headers:{'Content-Type':'application/json'},
            body: JSON.stringify({
              cloud_w5_model: w5val === 'local (default)' ? null : w5val,
              cloud_w6_model: w6val === 'local (default)' ? null : w6val,
              cloud_model_level: parseInt(level)
            })
          }).then(function(){
            notify.ok('Cloud models activated — W5: ' + w5val + ' · W6: ' + w6val);
            /* BW_R132b: refresh engine panel so KV hides, Warm→Prime, cloud dot updates */
            if (W._seRefreshModels) setTimeout(W._seRefreshModels, 400);
          })
            .catch(function(){ notify.warn('Failed to save cloud model config'); });
        }
      };
      btns.appendChild(cancel); btns.appendChild(next);
      box.appendChild(btns);
      overlay.appendChild(box);
    }
    showStep(1);
    document.body.appendChild(overlay);
  }

  function BW_openQPerms() {
    var panel = document.getElementById('bw-qp-panel');
    var qpWrap = document.getElementById('bw-qp-wrap');

    /* BW_R123: create and mount if not exists — then open */
    if (!panel) { _createQPPanel(); return; }

    /* BW_R123: toggle via hidden class — panel mounts and opens */
    var isOpen = panel.classList.contains('hidden');  /* open = remove hidden */

    if (isOpen) {
      if (qpWrap) qpWrap.classList.remove('hidden');
      panel.classList.remove('hidden');
      _bwLoadQPConfig();                              /* load config on open */
      try { if (typeof _bwR53IdRefresh === 'function') _bwR53IdRefresh(); } catch(e) {}
    } else {
      panel.classList.add('hidden');
      if (qpWrap) qpWrap.classList.add('hidden');
    }

    /* Highlight topbar buttons */
    var btn   = document.getElementById('bw-qperms-btn');
    var tbBtn = document.getElementById('bw-bar1-perms-btn');
    if (btn)   { btn.style.color   = isOpen ? 'var(--bw-gold)' : ''; btn.style.background = isOpen ? 'var(--bw-gold-dim)' : 'transparent'; }
    if (tbBtn) { tbBtn.style.color = isOpen ? 'var(--bw-gold)' : ''; }

    try { localStorage.setItem('bw_qperms_open', isOpen ? '1' : '0'); } catch(e) {}

    /* Reflow so --bw-qp-h updates and page-body shifts */
    requestAnimationFrame(function() { if (W._bwReflow) W._bwReflow(); });
  } /* BW_R123 */

  // ── BW_R80P54A: Notify helper — uses showNotif if available, else console ──
  function _bwIdNotify(msg, kind) {
    try {
      if (typeof window.showNotif === 'function') {
        window.showNotif(msg, kind || 'info');
        return;
      }
    } catch (e) {}
    console.log('[Beewid Identity]', kind || 'info', msg);
  }

  // ── BW_R80P54A: Generic modal (replaces browser prompt() for PIN flows) ──
  // Lazily creates the modal DOM once, returns a Promise<string|null>.
  // kind: 'pin' (password input) or 'text' (visible input)
  function _bwIdModalPrompt(opts) {
    return new Promise(function(resolve) {
      var existing = document.getElementById('bw-id-modal-overlay');
      if (existing) existing.remove();

      var overlay = document.createElement('div');
      overlay.id = 'bw-id-modal-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:var(--bw-mono,monospace)';

      var card = document.createElement('div');
      card.style.cssText = 'background:var(--bw-bg2,#1a1a1f);border:1px solid var(--bw-border2,#404048);border-radius:6px;padding:18px 22px;min-width:380px;max-width:520px;box-shadow:0 12px 40px rgba(0,0,0,0.6)';

      var title = document.createElement('div');
      title.style.cssText = 'font-size:13px;font-weight:600;color:var(--bw-gold,#f5c842);margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--bw-border,#2a2a2e)';
      title.textContent = opts.title || 'Confirm';
      card.appendChild(title);

      if (opts.body) {
        var body = document.createElement('div');
        body.style.cssText = 'font-size:11px;color:var(--bw-text2,#a8a8b0);line-height:1.5;margin-bottom:12px';
        body.textContent = opts.body;
        card.appendChild(body);
      }

      var input = document.createElement('input');
      input.type = (opts.kind === 'pin') ? 'password' : 'text';
      input.placeholder = opts.placeholder || '';
      input.maxLength = opts.maxLength || 32;
      input.style.cssText = 'width:100%;box-sizing:border-box;font-family:var(--bw-mono,monospace);font-size:13px;padding:8px 10px;background:var(--bw-bg3,#0e0e12);border:1px solid var(--bw-border2,#404048);border-radius:4px;color:var(--bw-text2,#a8a8b0);margin-bottom:12px';
      card.appendChild(input);

      var actions = document.createElement('div');
      actions.style.cssText = 'display:flex;gap:8px;justify-content:flex-end';
      var cancelBtn = document.createElement('button');
      cancelBtn.textContent = 'Cancel';
      cancelBtn.style.cssText = 'font-family:var(--bw-mono,monospace);font-size:11px;padding:6px 14px;background:var(--bw-bg3,#0e0e12);border:1px solid var(--bw-border2,#404048);border-radius:4px;color:var(--bw-text2,#a8a8b0);cursor:pointer';
      var okBtn = document.createElement('button');
      okBtn.textContent = opts.okLabel || 'OK';
      okBtn.style.cssText = 'font-family:var(--bw-mono,monospace);font-size:11px;padding:6px 14px;background:rgba(245,200,66,0.15);border:1px solid rgba(245,200,66,0.4);border-radius:4px;color:var(--bw-gold,#f5c842);cursor:pointer';
      actions.appendChild(cancelBtn);
      actions.appendChild(okBtn);
      card.appendChild(actions);
      overlay.appendChild(card);
      document.body.appendChild(overlay);

      function _close(val) { try { overlay.remove(); } catch(e) {} resolve(val); }
      cancelBtn.onclick = function() { _close(null); };
      okBtn.onclick = function() { _close(input.value); };
      overlay.onclick = function(ev) { if (ev.target === overlay) _close(null); };
      input.onkeydown = function(ev) {
        if (ev.key === 'Enter') { ev.preventDefault(); _close(input.value); }
        else if (ev.key === 'Escape') { ev.preventDefault(); _close(null); }
      };
      setTimeout(function() { input.focus(); }, 50);
    });
  }

  // ── BW_R80P54A: Confirm modal (yes/no) ──────────────────────────────
  function _bwIdModalConfirm(opts) {
    return new Promise(function(resolve) {
      var existing = document.getElementById('bw-id-modal-overlay');
      if (existing) existing.remove();

      var overlay = document.createElement('div');
      overlay.id = 'bw-id-modal-overlay';
      overlay.style.cssText = 'position:fixed;inset:0;background:rgba(0,0,0,0.65);z-index:99999;display:flex;align-items:center;justify-content:center;font-family:var(--bw-mono,monospace)';

      var card = document.createElement('div');
      card.style.cssText = 'background:var(--bw-bg2,#1a1a1f);border:1px solid var(--bw-border2,#404048);border-radius:6px;padding:18px 22px;min-width:380px;max-width:520px';

      var title = document.createElement('div');
      title.style.cssText = 'font-size:13px;font-weight:600;color:var(--bw-gold,#f5c842);margin-bottom:10px;padding-bottom:8px;border-bottom:1px solid var(--bw-border,#2a2a2e)';
      title.textContent = opts.title || 'Confirm';
      card.appendChild(title);

      var body = document.createElement('div');
      body.style.cssText = 'font-size:11px;color:var(--bw-text2,#a8a8b0);line-height:1.5;margin-bottom:14px;white-space:pre-wrap';
      body.textContent = opts.body || '';
      card.appendChild(body);

      if (opts.warn) {
        var warn = document.createElement('div');
        warn.style.cssText = 'font-size:11px;color:#f87171;background:rgba(220,50,50,0.08);border:1px solid rgba(220,50,50,0.3);border-radius:4px;padding:8px 10px;margin-bottom:12px';
        warn.textContent = opts.warn;
        card.appendChild(warn);
      }

      var actions = document.createElement('div');
      actions.style.cssText = 'display:flex;gap:8px;justify-content:flex-end';
      var cancelBtn = document.createElement('button');
      cancelBtn.textContent = opts.cancelLabel || 'Cancel';
      cancelBtn.style.cssText = 'font-family:var(--bw-mono,monospace);font-size:11px;padding:6px 14px;background:var(--bw-bg3,#0e0e12);border:1px solid var(--bw-border2,#404048);border-radius:4px;color:var(--bw-text2,#a8a8b0);cursor:pointer';
      var okBtn = document.createElement('button');
      okBtn.textContent = opts.okLabel || 'Confirm';
      okBtn.style.cssText = 'font-family:var(--bw-mono,monospace);font-size:11px;padding:6px 14px;background:' + (opts.danger ? 'rgba(220,50,50,0.15);border:1px solid rgba(220,50,50,0.4);color:#f87171' : 'rgba(245,200,66,0.15);border:1px solid rgba(245,200,66,0.4);color:var(--bw-gold,#f5c842)') + ';border-radius:4px;cursor:pointer';
      actions.appendChild(cancelBtn);
      actions.appendChild(okBtn);
      card.appendChild(actions);
      overlay.appendChild(card);
      document.body.appendChild(overlay);

      function _close(val) { try { overlay.remove(); } catch(e) {} resolve(val); }
      cancelBtn.onclick = function() { _close(false); };
      okBtn.onclick = function() { _close(true); };
      overlay.onclick = function(ev) { if (ev.target === overlay) _close(false); };
    });
  }

  // ── BW_R80P53B: Identity Protection refresh + helpers ─────────────────────
  window._bwR53IdState = window._bwR53IdState || {cfg: null, heartbeatTimer: null};

  var SHARE_KEYS_R53 = [
    {key:'share_hostname',   label:'Hostname'},
    {key:'share_username',   label:'Username'},
    {key:'share_distro',     label:'OS / Distro'},
    {key:'share_kernel',     label:'Kernel'},
    {key:'share_ip',         label:'IPs'},
    {key:'share_mac',        label:'MACs'},
    {key:'share_machine_id', label:'machine-id'},
  ];

  function _bwR53IdRequestUnlock(key, label) {
    // BW_R80P54A: replaced prompt()/confirm()/alert() with modal flow
    fetch(W.BW._API_BASE + '/skill/identity_request_unlock', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({args:{key: key}})
    }).then(function(r) { return r.json(); }).then(function(d) {
      var req = d.result;
      if (!req || !req.ok) {
        _bwIdNotify('Request failed: ' + ((req && req.error) || 'unknown'), 'warn');
        return;
      }
      var pinPromise;
      if (req.pin_required) {
        pinPromise = _bwIdModalPrompt({
          title: 'Privacy PIN required',
          body: 'Enter your PIN to share ' + label + ' with cloud.',
          placeholder: 'PIN',
          kind: 'pin',
          okLabel: 'Confirm',
        });
      } else {
        pinPromise = _bwIdModalConfirm({
          title: 'Share ' + label + ' with cloud?',
          body: 'Cloud LLMs will see this identifier.',
          warn: 'Reversible at any time via Re-block.',
          okLabel: 'Share',
        }).then(function(yes) { return yes ? '' : null; });
      }
      pinPromise.then(function(pinOrNull) {
        if (pinOrNull === null) return;
        var body = (req.pin_required) ? {request_id: req.request_id, pin: pinOrNull} : {request_id: req.request_id};
        fetch(W.BW._API_BASE + '/perms/identity/confirm_unlock', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body: JSON.stringify(body)
        }).then(function(r2) { return r2.json(); }).then(function(d2) {
          if (d2.ok) {
            _bwIdNotify(label + ' now shared with cloud', 'ok');
            _bwR53IdRefresh();
          } else {
            _bwIdNotify('Unlock failed: ' + (d2.error || 'unknown'), 'warn');
          }
        });
      });
    });
  }

  function _bwR53IdBlock(key) {
    fetch(W.BW._API_BASE + '/skill/identity_block', {
      method:'POST', headers:{'Content-Type':'application/json'},
      body: JSON.stringify({args:{key: key}})
    }).then(function(r) { return r.json(); }).then(function(d) {
      if (d.result && d.result.ok) _bwR53IdRefresh();
    });
  }

  function _bwR53IdRefresh() {
    return fetch(W.BW._API_BASE + '/perms/identity').then(function(r) { return r.json(); }).then(function(cfg) {
      window._bwR53IdState.cfg = cfg;

      var master = document.getElementById('bwqp-id-master');
      var shell  = document.getElementById('bwqp-id-shellblock');
      var local  = document.getElementById('bwqp-id-localscrub');
      if (master) master.checked = !!cfg.scrub_machine_identity;
      if (shell)  shell.checked  = !!cfg.block_cloud_identity_shells;
      if (local)  local.checked  = !!cfg.scrub_for_local_llms;

      var sharedCount = SHARE_KEYS_R53.filter(function(s) { return cfg[s.key]; }).length;
      var protectedCount = SHARE_KEYS_R53.length - sharedCount;
      var statusEl = document.getElementById('bwqp-id-status');
      if (statusEl) {
        if (sharedCount === 0) {
          statusEl.textContent = '\uD83D\uDEE1 ' + protectedCount + ' protected';
          statusEl.style.color = 'var(--bw-gold)';
        } else {
          statusEl.textContent = '\u26A0 ' + protectedCount + ' protected, ' + sharedCount + ' shared';
          statusEl.style.color = 'var(--bw-amber)';
        }
      }

      var rowsEl = document.getElementById('bwqp-id-rows');
      if (rowsEl) {
        while (rowsEl.firstChild) rowsEl.removeChild(rowsEl.firstChild);
        var det = cfg.detected || {};
        SHARE_KEYS_R53.forEach(function(spec) {
          var shared = !!cfg[spec.key];
          var row = document.createElement('div');
          row.style.cssText = 'display:flex;align-items:center;gap:6px;font-size:10px;padding:1px 0';

          var labelSpan = document.createElement('span');
          labelSpan.style.cssText = 'min-width:70px;color:var(--bw-text3)';
          labelSpan.textContent = spec.label;

          var valSpan = document.createElement('span');
          valSpan.style.cssText = 'flex:1;font-family:var(--bw-mono);' +
            (shared ? 'color:var(--bw-gold)' : 'color:var(--bw-text3);font-style:italic');
          var valText = '';
          if (spec.key === 'share_ip') {
            valText = (det.ips && det.ips.length) ? det.ips.join(', ') : '(none)';
          } else if (spec.key === 'share_mac') {
            valText = (det.macs && det.macs.length) ? det.macs.join(', ') : '(none)';
          } else if (spec.key === 'share_machine_id') {
            valText = det.machine_id_set ? '(set)' : '(none)';
          } else {
            var detKey = spec.key.replace('share_', '');
            valText = (det[detKey] || '').toString();
          }
          valSpan.textContent = valText;

          var btn = document.createElement('button');
          btn.style.cssText = 'font-size:9px;padding:1px 6px;border-radius:3px;cursor:pointer;font-family:var(--bw-mono);' +
            (shared ? 'background:rgba(252,80,80,0.1);border:1px solid rgba(252,80,80,0.4);color:var(--bw-red)'
                    : 'background:rgba(245,200,66,0.1);border:1px solid rgba(245,200,66,0.4);color:var(--bw-gold)');
          btn.textContent = shared ? 'Re-block' : 'Share';
          (function(s, k, l) {
            btn.onclick = function() { if (s) _bwR53IdBlock(k); else _bwR53IdRequestUnlock(k, l); };
          })(shared, spec.key, spec.label);

          row.appendChild(labelSpan);
          row.appendChild(valSpan);
          row.appendChild(btn);
          rowsEl.appendChild(row);
        });
      }

      var pinStat = document.getElementById('bwqp-id-pin-status');
      if (pinStat) {
        if (cfg.pin_set) {
          pinStat.textContent = '\uD83D\uDD12 PIN set';
          pinStat.style.color = 'var(--bw-gold)';
        } else {
          pinStat.textContent = 'No PIN (2x click-confirm)';
          pinStat.style.color = 'var(--bw-text3)';
        }
      }
      // Toggle Set/Clear/Forgot PIN buttons
      var pinSetBtnEl = pinStat && pinStat.parentNode && pinStat.parentNode.querySelector('button:first-of-type');
      var pinClrBtnEl = document.getElementById('bwqp-id-pin-clear-btn');
      var pinFgtBtnEl = document.getElementById('bwqp-id-pin-forgot-btn'); // BW_R80P54A
      if (pinSetBtnEl) pinSetBtnEl.textContent = cfg.pin_set ? 'Change PIN' : 'Set PIN';
      if (pinClrBtnEl) pinClrBtnEl.style.display = cfg.pin_set ? '' : 'none';
      if (pinFgtBtnEl) pinFgtBtnEl.style.display = cfg.pin_set ? '' : 'none'; // BW_R80P54A

      var factsEl = document.getElementById('bwqp-id-facts-list');
      if (factsEl) {
        while (factsEl.firstChild) factsEl.removeChild(factsEl.firstChild);
        var facts = cfg.approved_facts || [];
        if (facts.length === 0) {
          var empty = document.createElement('div');
          empty.style.cssText = 'font-size:10px;color:var(--bw-text3);font-style:italic';
          empty.textContent = '(none yet)';
          factsEl.appendChild(empty);
        } else {
          facts.forEach(function(f, idx) {
            var fr = document.createElement('div');
            fr.style.cssText = 'display:flex;align-items:center;gap:4px;font-size:10px';
            var t = document.createElement('span');
            t.style.cssText = 'flex:1;color:var(--bw-text2);font-family:var(--bw-mono);overflow:hidden;text-overflow:ellipsis;white-space:nowrap';
            t.textContent = f; t.title = f;
            var rmBtn = document.createElement('button');
            rmBtn.style.cssText = 'font-size:9px;padding:0 5px;background:transparent;border:1px solid var(--bw-border2);color:var(--bw-text3);border-radius:3px;cursor:pointer';
            rmBtn.textContent = '\u2715';
            (function(i) {
              rmBtn.onclick = function() {
                var next = facts.slice(); next.splice(i, 1);
                fetch(W.BW._API_BASE + '/perms/identity', {
                  method:'POST', headers:{'Content-Type':'application/json'},
                  body: JSON.stringify({approved_facts: next})
                }).then(_bwR53IdRefresh);
              };
            })(idx);
            fr.appendChild(t); fr.appendChild(rmBtn);
            factsEl.appendChild(fr);
          });
        }
      }
    }).catch(function(e) {
      var statusEl = document.getElementById('bwqp-id-status');
      if (statusEl) statusEl.textContent = 'Error: ' + e.message;
    });
  }

  window._bwR53IdRefresh = _bwR53IdRefresh;

  // 5-min heartbeat: refresh while panel is visible
  if (!window._bwR53IdState.heartbeatTimer) {
    window._bwR53IdState.heartbeatTimer = setInterval(function() {
      var qpWrap = document.getElementById('bw-qp-wrap');
      if (qpWrap && !qpWrap.classList.contains('hidden')) {
        try { _bwR53IdRefresh(); } catch(e) {}
      }
    }, 5 * 60 * 1000);
  }
  // ── End BW_R80P53B ─────────────────────────────────────────────────────────

  /* ── API client ───────────────────────────────────────────── */
  var api = {
    get: function(endpoint) {
      return fetch(API_BASE + endpoint).then(function(r) {
        if (!r.ok) throw new Error('[' + r.status + '] ' + endpoint);
        return r.json();
      });
    },
    post: function(endpoint, data) {
      return fetch(API_BASE + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {})
      }).then(function(r) {
        if (!r.ok) return r.text().then(function(t) { throw new Error('[' + r.status + '] ' + endpoint + ': ' + t); });
        return r.json();
      });
    },
    stream: function(endpoint, data, onEvent, onDone, onError) {
      fetch(API_BASE + endpoint, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(data || {})
      }).then(function(res) {
        if (!res.ok) { if (onError) onError('[' + res.status + ']'); return; }
        var reader = res.body.getReader();
        var dec = new TextDecoder();
        var buf = '';
        function pump() {
          reader.read().then(function(x) {
            if (x.done) { if (onDone) onDone(); return; }
            buf += dec.decode(x.value, { stream: true });
            var lines = buf.split('\n');
            buf = lines.pop();
            lines.forEach(function(ln) {
              if (!ln.startsWith('data: ')) return;
              var raw = ln.slice(6).trim();
              if (raw === '[DONE]') { if (onDone) onDone(); return; }
              try { onEvent(JSON.parse(raw)); } catch(e) { onEvent({ text: raw }); }
            });
            pump();
          }).catch(function(e) { if (onError) onError(e.message); });
        }
        pump();
      }).catch(function(e) { if (onError) onError(e.message); });
    },
    skill: function(name) { return this.post('/skill/' + name, {}); }
  };

  /* ── Model status ─────────────────────────────────────────── */
  var _modState = { w5: 'cold', w6: 'cold', apiUp: false, aiEnabled: true };
  var _modInterval = null;

  var _keepaliveCounter = 0;

  function pollModels() {
    api.get('/health').then(function(data) {
      _modState.apiUp     = true;
      _modState.w5        = data.w5_warm ? 'warm' : 'cold';
      _modState.w6        = data.w6_warm ? 'warm' : 'cold';
      _modState.aiEnabled = data.ai_enabled !== false; // default true
      /* BW_R119: W7 + orchestrators */
      _modState.w7    = data.w7_host ? 'configured' : 'not configured';
      _modState.mcp   = data.mcp            || 'down';
      _modState.tools = data.beewid_tools    || 'down';
      updateDots();
      /* Sync AI toggle in topbar */
      _syncAiToggle(_modState.aiEnabled);
      // api ok indicator in Bar 1
      var apiPill = document.getElementById('bw-ind-api');
      if (apiPill) {
        apiPill.textContent = 'api ok';
        apiPill.style.color = 'var(--bw-green)';
      }
      W.dispatchEvent(new CustomEvent('bw:models', { detail: Object.assign({}, _modState) }));
      /* Keepalive: ping warm models every 6 polls (~3 min) to prevent Ollama eviction */
      _keepaliveCounter++;
      if (_keepaliveCounter >= 6) {
        _keepaliveCounter = 0;
        /* Only fire if not in full lockout mode — respect user's kick-and-stay-off */
        var _w5lock = localStorage.getItem('bw_lockout_w5') === '1';
        var _w6lock = localStorage.getItem('bw_lockout_w6') === '1';
        if (!(_w5lock && _w6lock)) {
          api.post('/admin/keepalive', {}).catch(function() {});
        }
      }
    }).catch(function() {
      _modState.apiUp = false;
      var apiPill = document.getElementById('bw-ind-api');
      if (apiPill) { apiPill.textContent = 'api down'; apiPill.style.color = 'var(--bw-red)'; }
      _modState.w5    = 'error';
      _modState.w6    = 'error';
      updateDots();
    });
  }

  function updateDots() {
    ['w5','w6'].forEach(function(m) {
      var d  = document.getElementById('bw-' + m + '-dot');
      var l  = document.getElementById('bw-' + m + '-label');
      var dt = document.getElementById('bw-' + m + '-dot-tb');
      if (d)  d.className  = 'bw-dot ' + _modState[m];
      if (l)  l.textContent = m.toUpperCase() + ' \u00B7 ' + _modState[m];
      if (dt) dt.className = 'bw-dot ' + _modState[m];
    });
    /* BW_R119: W7 dot + dynamic orchestrator boxes */
    var w7d = document.getElementById('bw-w7-dot');
    var w7l = document.getElementById('bw-w7-label');
    if (w7d) w7d.className = 'bw-dot ' + (_modState.w7 === 'configured' ? 'warm' : '');
    if (w7l) w7l.textContent = 'W7 \u00B7 ' + (_modState.w7 || 'not configured');
    var dyn = document.getElementById('bw-nav-agents-dynamic');
    if (dyn) {
      dyn.innerHTML = [
        { id: 'mcp',   label: 'MCP',        state: _modState.mcp   || 'down' },
        { id: 'tools', label: 'bwid-tools', state: _modState.tools || 'down' }
      ].map(function(a) {
        var st = a.state === 'ok' ? 'warm' : 'cold';
        return '<div class="bw-agent-box" data-agent="' + a.id + '"'
          + ' onclick="window._bwAgentJump(\'' + a.id + '\')" title="' + a.label + '">'
          + '<div class="bw-dot ' + st + '"></div>'
          + '<span class="bw-model-name">' + a.label + ' \u00B7 ' + a.state + '</span>'
          + '<button class="bw-agent-popout-btn"'
          + ' onclick="event.stopPropagation();window._bwAgentPopout(\'' + a.id + '\')"'
          + ' title="' + a.label + ' controls">⧉</button>'
          + '</div>';
      }).join('');
    }
    if (typeof _updateIndicators === 'function') _updateIndicators(_modState, null);
  }

  function _syncAiToggle(enabled) {
    var el  = document.getElementById('bw-ai-toggle');
    var lbl = document.getElementById('bw-ai-label-tb');
    _aiEnabled = enabled;
    if (el)  el.className  = 'bw-ai-status ' + (enabled ? 'enabled' : 'disabled');
    if (lbl) lbl.textContent = enabled ? 'ENABLED' : 'DISABLED';
  }

  var models = {
    get state() { return Object.assign({}, _modState); },
    poll: pollModels,
    start: function(ms) { pollModels(); _modInterval = setInterval(pollModels, ms || 30000); },
    stop:  function()   { if (_modInterval) clearInterval(_modInterval); }
  };

  /* ── Notifications ────────────────────────────────────────── */
  var ICONS = { ok: '\u2713', warn: '\u26A0', error: '\u2715', info: '\u2139' };

  function injectToasts() {
    if (document.getElementById('bw-toasts')) return;
    var el = document.createElement('div');
    el.id = 'bw-toasts';
    document.body.appendChild(el);
  }

  var notify = {
    show: function(msg, type, duration) {
      var c = document.getElementById('bw-toasts');
      if (!c) return null;
      var el = document.createElement('div');
      el.className = 'bw-toast bw-' + (type || 'info');
      el.innerHTML = '<span class="bw-toast-icon">' + (ICONS[type] || '\u2139') + '</span>'
                   + '<span class="bw-toast-msg">' + msg + '</span>';
      c.appendChild(el);
      var d = duration !== undefined ? duration : 4500;
      if (d > 0) {
        setTimeout(function() {
          el.style.opacity = '0';
          el.style.transition = 'opacity 0.25s';
          setTimeout(function() { el.remove(); }, 260);
        }, d);
      }
      return el;
    },
    ok:    function(m, d) { return this.show(m, 'ok',    d); },
    warn:  function(m, d) { return this.show(m, 'warn',  d); },
    error: function(m, d) { return this.show(m, 'error', d); },
    info:  function(m, d) { return this.show(m, 'info',  d); }
  };

  /* ── Session storage ──────────────────────────────────────── */
  var session = {
    get: function(k, def) {
      try { var v = sessionStorage.getItem('bw::' + k); return v !== null ? JSON.parse(v) : (def !== undefined ? def : null); }
      catch(e) { return def !== undefined ? def : null; }
    },
    set: function(k, v) { try { sessionStorage.setItem('bw::' + k, JSON.stringify(v)); } catch(e) {} },
    clear: function(k) {
      if (k) { sessionStorage.removeItem('bw::' + k); }
      else { Object.keys(sessionStorage).filter(function(x) { return x.startsWith('bw::'); }).forEach(function(x) { sessionStorage.removeItem(x); }); }
    }
  };

  /* ── Kill switch ──────────────────────────────────────────── */
  var _aiEnabled = true;

  var kill = {
    engage: function() {
      return api.post('/admin/killswitch', { enabled: false })
        .then(function(d) {
          _syncAiToggle(false);
          notify.warn('\u2B1B AI disabled — kill switch engaged', 0);
          W.dispatchEvent(new CustomEvent('bw:kill', { detail: { engaged: true } }));
        })
        .catch(function(e) { notify.error('Kill switch failed: ' + e.message); });
    },
    disengage: function() {
      return api.post('/admin/killswitch', { enabled: true })
        .then(function(d) {
          _syncAiToggle(true);
          notify.ok('\u25C8 AI re-enabled');
          W.dispatchEvent(new CustomEvent('bw:kill', { detail: { engaged: false } }));
        })
        .catch(function(e) { notify.error('Failed to enable AI: ' + e.message); });
    }
  };

  /* ── Topbar AI toggle ─────────────────────────────────────── */
  function BW_toggleAI() {
    if (_aiEnabled) kill.engage(); else kill.disengage();
  }

  /* ── Nuclear Ollama stop ──────────────────────────────────── */
  function BW_nukeOllama() {
    if (!confirm('☢ NUCLEAR STOP\n\nThis will kill all running Ollama model processes and unload all models from memory.\n\nContinue?')) return;
    var btn = document.getElementById('bw-nuke-btn');
    if (btn) { btn.textContent = '☢ stopping…'; btn.disabled = true; }
    api.post('/admin/ollama/stop', {})
      .then(function(d) {
        notify.warn('☢ Ollama models stopped — all VRAM/RAM freed', 6000);
        if (btn) { btn.textContent = '\u2713 stopped'; btn.style.color = 'var(--bw-amber)'; }
        setTimeout(function() {
          if (btn) { btn.textContent = '☢ NUKE'; btn.style.color = ''; btn.disabled = false; }
          pollModels();
        }, 3000);
      })
      .catch(function(e) {
        notify.error('Nuke failed: ' + e.message);
        if (btn) { btn.textContent = '☢ NUKE'; btn.disabled = false; }
      });
  }

  /* ── Ollama restart ───────────────────────────────────────── */
  function BW_restartOllama() {
    if (!confirm('Restart Ollama service?\n\nThis will briefly interrupt all local model inference.')) return;
    var btn = document.getElementById('bw-restart-btn');
    if (btn) { btn.textContent = '↺ restarting…'; btn.disabled = true; }
    api.post('/admin/ollama/restart', {})
      .then(function(d) {
        if (d.ok) {
          notify.ok('↺ Ollama restarted — models will need warming', 5000);
          if (btn) { btn.textContent = '\u2713 restarted'; btn.style.color = 'var(--bw-green)'; }
        } else {
          notify.warn('Ollama restart returned non-zero: ' + (d.stderr || d.error || ''), 6000);
          if (btn) { btn.textContent = '⚠ check log'; }
        }
        setTimeout(function() {
          if (btn) { btn.textContent = '↺ OLLAMA'; btn.style.color = ''; btn.disabled = false; }
          pollModels();
        }, 3500);
      })
      .catch(function(e) {
        notify.error('Restart failed: ' + e.message);
        if (btn) { btn.textContent = '↺ OLLAMA'; btn.disabled = false; }
      });
  }

  /* ── Policy quick-set ─────────────────────────────────────── */
  function BW_setPolicy(level) {
    var n = parseInt(level);
    session.set('policy_level', n);
    /* Persist to yaml — prevents session-restore from overwriting on reload */
    api.post('/config/update', { policy_level: n }).catch(function() {});
    /* Sync any per-page perm selector */
    var pageSelect = document.getElementById('perm-select');
    if (pageSelect) pageSelect.value = level;
    var pe = document.getElementById('bw-ind-policy');
    if (pe) { pe.textContent = 'L' + n; pe.style.color = n >= 2 ? '#ed8936' : 'var(--bw-text3)'; }
    notify.ok('Permission → L' + level);
    W.dispatchEvent(new CustomEvent('bw:policy', { detail: { level: n } }));
  }

  /* ── Hard refresh ─────────────────────────────────────────── */

  /* -- Free RAM ------------------------------------------------- */
  function BW_freeRam() {
    var btn = document.getElementById('bw-freeram-btn');
    if (!confirm('Unload AI models from RAM?\nModels will need to be reloaded on next use.')) return;
    if (btn) { btn.textContent = '…'; btn.disabled = true; }
    api.post('/admin/ollama/stop', {})
      .then(function() {
        notify.warn('Models unloaded — RAM freed. Warm again before chatting.', 5000);
        if (btn) { btn.textContent = 'freed';
          setTimeout(function() { btn.textContent = 'free'; btn.disabled = false; }, 3000); }
        pollModels();
      })
      .catch(function(e) {
        notify.error('Free RAM failed: ' + e.message);
        if (btn) { btn.textContent = 'free'; btn.disabled = false; }
      });
  }

  /* -- RAM polling ----------------------------------------------- */
  function _pollRam() {
    api.post('/skill/ram_check', {})
      .then(function(d) {
        var out = (d.result && d.result.output) ? d.result.output : '';
        var match = out.match(/Mem:\s+(\S+)\s+(\S+)/);
        var el = document.getElementById('bw-ram-val');
        if (el && match) {
          el.textContent = match[2] + '/' + match[1];
          var used  = parseFloat(match[2]);
          var total = parseFloat(match[1]);
          if (total > 0) {
            var pct = used / total;
            el.style.color = pct > 0.8 ? 'var(--bw-red)' : pct > 0.6 ? 'var(--bw-amber)' : 'var(--bw-text2)';
          }
        }
      })
      .catch(function() {});
  }

  function BW_hardRefresh() {
    var btn = document.getElementById('bw-refresh-btn');
    if (btn) { btn.textContent = '↺ refreshing…'; btn.disabled = true; }
    setTimeout(function() { W.location.reload(true); }, 100);
  }

  /* ── Utilities ────────────────────────────────────────────── */
  function esc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }
  function fmtBytes(n) {
    if (n < 1024) return n + ' B';
    if (n < 1048576) return (n/1024).toFixed(1) + ' KB';
    if (n < 1073741824) return (n/1048576).toFixed(1) + ' MB';
    return (n/1073741824).toFixed(2) + ' GB';
  }
  function fmtAgo(ts) {
    var s = Math.floor((Date.now() - ts) / 1000);
    if (s < 60) return s + 's ago';
    if (s < 3600) return Math.floor(s/60) + 'm ago';
    if (s < 86400) return Math.floor(s/3600) + 'h ago';
    return Math.floor(s/86400) + 'd ago';
  }
  function initInlineTabs(sel) {
    var c = document.querySelector(sel || '[data-bw-tabs]');
    if (!c) return;
    c.querySelectorAll('.bw-tab').forEach(function(tab) {
      tab.addEventListener('click', function() {
        var t = tab.dataset.tab;
        c.querySelectorAll('.bw-tab').forEach(function(x) { x.classList.toggle('active', x.dataset.tab === t); });
        c.querySelectorAll('.bw-tab-panel').forEach(function(x) { x.classList.toggle('active', x.id === t); });
      });
    });
  }

  /* ── Resource bar functions ─────────────────────────────────── */
  var _resRefreshRate = 8000;
  var _resPanelOpen   = false;
  var _resPollTimer   = null;
  var _barStatTimer   = null;

  function _barColor(pct) {
    if (pct >= 90) return 'var(--bw-red)';
    if (pct >= 70) return 'var(--bw-amber)';
    return 'var(--bw-green)';
  }
  function _setBar(barId, labelId, pct, label) {
    var b = document.getElementById(barId);
    var l = document.getElementById(labelId);
    if (b) { b.style.width = Math.min(pct,100)+'%'; b.style.background = _barColor(pct); }
    if (l) l.textContent = label;
  }

  function _pollResources() {
    api.post('/skill/resource_detail', {}).then(function(resp) {
      var d=(resp&&resp.result)?resp.result:resp;
      if (d.error) {
        // psutil missing — show fallback from /health RAM data
        var e = document.getElementById('bw-res-cpu'); if(e) e.textContent='—';
        return;
      }
      if (d.cpu    != null) _setBar('bw-bar-cpu',  'bw-res-cpu',  d.cpu,      d.cpu+'%');
      if (d.ram_pct!= null) _setBar('bw-bar-ram',  'bw-res-ram',  d.ram_pct,  d.ram_used);
      var _di=document.getElementById('bw-res-disk'); if(_di) _di.textContent=(d.disk_io_r?'↓'+d.disk_io_r+(d.disk_io_w?' ↑'+d.disk_io_w:''):'—');
      var _db=document.getElementById('bw-bar-dsk');
      if(_db){var _dpct=Math.min(100,(parseFloat(d.disk_io_r)||0)*2);_db.style.width=_dpct+'%';
        _db.style.background=_dpct>80?'var(--bw-red)':_dpct>40?'var(--bw-amber)':'var(--bw-green)';}
      if(d.net_rx){var _ne=document.getElementById('bw-res-net');if(_ne)_ne.textContent='↓'+d.net_rx+' ↑'+d.net_tx;
        var _nb=document.getElementById('bw-bar-net');if(_nb){var _npct=Math.min(100,(parseFloat(d.net_rx)||0)*10);_nb.style.width=_npct+'%';}}
      if (d.beewid_cpu!=null) _setBar('bw-bar-bw-cpu','bw-res-bw-cpu', d.beewid_cpu, d.beewid_cpu+'%');
      if (d.beewid_ram)  { var e=document.getElementById('bw-res-bw-ram'); if(e) e.textContent=d.beewid_ram; }
    }).catch(function(){});
  }

  function BW_toggleTermMenu() {
    var m = document.getElementById('bw-term-menu');
    if (!m) return;
    var isOpen = m.style.display === 'block';
    if (isOpen) { m.style.display = 'none'; return; }
    /* BW_TERM_TELEPORT — move menu to body to escape barRes overflow:hidden clip */
    if (m.parentElement !== document.body) {
      document.body.appendChild(m);
      m.style.position = 'fixed';
      m.style.zIndex   = '99999';
    }
    var btn = document.querySelector('#bw-res-terminal-wrap button');
    if (btn) {
      var r = btn.getBoundingClientRect();
      m.style.top  = (r.bottom + 4) + 'px';
      m.style.left = r.left + 'px';
    }
    m.style.display = 'block';
  }
  document.addEventListener('click', function(e) {
    /* BW_TERM_CLICKOUT_FIX — guard text nodes; also exclude teleported menu */
    var el = e.target instanceof Element ? e.target : e.target.parentElement;
    if (!el) return;
    if (el.closest('#bw-res-terminal-wrap') || el.closest('#bw-term-menu')) return;
    var m = document.getElementById('bw-term-menu');
    if (m) m.style.display = 'none';
  });

  function BW_openTerminal(target) {
    var m = document.getElementById('bw-term-menu');
    if (m) m.style.display = 'none';
    if (target==='n8n') { window.open('http://localhost:5679','_blank'); return; }
    if (target==='az')  { window.open('http://localhost:5000','_blank'); return; }
    api.post('/terminal/open', {target:target}).then(function(d){
      if (!d.ok) notify.warn('Terminal: '+(d.error||'failed'));
    }).catch(function(e){ notify.warn('Terminal: '+e.message); });
  }

  function BW_toggleResourcePanel() {
    var p = document.getElementById('bw-res-panel');
    if (!p) { _BW_buildResourcePanel(); return; }
    _resPanelOpen = !_resPanelOpen;
    p.style.display = _resPanelOpen ? 'flex' : 'none';
    if (_resPanelOpen) _BW_refreshResourcePanel();
  }

  function BW_setResRefresh(ms) {
    _resRefreshRate = parseInt(ms)||8000;
    if (_barStatTimer) { clearInterval(_barStatTimer); _barStatTimer = setInterval(_pollResources, _resRefreshRate); }
    if (_resPollTimer) { clearTimeout(_resPollTimer); if(_resPanelOpen) _BW_scheduleRefresh(); }
  }
  function _BW_renderBwPanel(d) {
    var b=document.getElementById('bw-rp-bw'); if(!b) return;
    b.innerHTML='CPU: <b style="color:var(--bw-gold)">'+(d.beewid_cpu!=null?d.beewid_cpu+'%':'—')+'</b><br>'
      +'RAM: <b style="color:var(--bw-gold)">'+(d.beewid_ram||'—')+'</b>'
      +(d.beewid_ram_pct?' <span style="color:var(--bw-text3)">('+d.beewid_ram_pct+'%)</span>':'')+'<br>'
      +'Disk I/O: '+(d.beewid_disk_r?'↓<b>'+d.beewid_disk_r+'</b>':'—')
      +' '+(d.beewid_disk_w?'↑<b>'+d.beewid_disk_w+'</b>':'')
      +'&nbsp; Conns: <b>'+(d.beewid_conn_count!=null?d.beewid_conn_count:'—')+'</b>'
      +(d.ollama_ram?'<br>Ollama: CPU <b style="color:var(--bw-gold)">'+(d.ollama_cpu!=null?d.ollama_cpu+'%':'—')+'</b>  RAM <b style="color:var(--bw-amber)">'+d.ollama_ram+'</b>'+(d.ollama_pct?' ('+d.ollama_pct+'%)':''):'');
  }
  function _BW_refreshSysOnly() {
    api.post('/skill/resource_detail',{}).then(function(resp){
      var d=(resp&&resp.result)?resp.result:resp;
      var s=document.getElementById('bw-rp-sys');
      if(s) {
        var rC=d.ram_pct>85?'var(--bw-red)':d.ram_pct>70?'var(--bw-amber)':'var(--bw-green)';
        var dC=d.disk_pct>90?'var(--bw-red)':d.disk_pct>75?'var(--bw-amber)':'var(--bw-green)';
        s.innerHTML='CPU: <b style="color:var(--bw-gold)">'+(d.cpu!=null?d.cpu+'%':'—')+'</b>'
          +'&nbsp; RAM: <b style="color:var(--bw-gold)">'+(d.ram_used||'—')+'</b>/'+(d.ram_total||'—')
          +' <span style="color:'+rC+';">('+d.ram_pct+'%)</span><br>'
          +'Disk: <b>'+(d.disk_used||'—')+'</b>/'+(d.disk_total||'—')
          +' <span style="color:'+dC+';">('+d.disk_pct+'%)</span><br>'
          +'Net ↓: <b>'+(d.net_rx||'—')+'</b> ↑: <b>'+(d.net_tx||'—')+'</b>';
      }
      var n=document.getElementById('bw-rp-net'); if(!n) return;
      var cs=d.connections||[];
      var _isInt=function(ip){return /^(10\.|172\.(1[6-9]|2\d|3[01])\.|192\.168\.|127\.|172\.22\.)/.test(ip);};
      var intC=cs.filter(function(c){return _isInt(c.remote);}); 
      var extC=cs.filter(function(c){return !_isInt(c.remote);});
      var fmt=function(c){var lbl=c.label?' <span style="color:var(--bw-gold);font-size:9px">['+c.label+']</span>':'';return '<span style="color:var(--bw-text3)">['+c.status+']</span> <b>'+c.remote+'</b>'+lbl;};
      var out='';
      if(intC.length)out+='<div style="font-size:9px;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.05em;margin-bottom:2px">Internal ('+intC.length+')</div>'+intC.map(fmt).join('<br>');
      if(extC.length)out+=(intC.length?'<br>':'')+'<div style="font-size:9px;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.05em;margin:4px 0 2px">External ('+extC.length+')</div>'+extC.map(fmt).join('<br>');
      n.innerHTML=out||'<span style="color:var(--bw-text3)">No connections</span>';
    }).catch(function(){});
  }
  function _BW_refreshBwOnly() {
    api.post('/skill/resource_detail',{}).then(function(resp){
      var d=(resp&&resp.result)?resp.result:resp;
      _BW_renderBwPanel(d);
    }).catch(function(){});
  }

  var _sysRefreshRate=8000,_bwRefreshRate=8000,_sysBarTimer=null,_bwBarTimer=null;
  function BW_refreshSysBar(){
    api.post('/skill/resource_detail',{}).then(function(r2){
      var d=(r2&&r2.result)?r2.result:r2; if(!d||d.error)return;
      if(d.cpu!=null)       _setBar('bw-bar-cpu','bw-res-cpu',d.cpu,d.cpu+'%');
      if(d.ram_pct!=null)   _setBar('bw-bar-ram','bw-res-ram',d.ram_pct,d.ram_used);
      var _di=document.getElementById('bw-res-disk'); if(_di) _di.textContent=(d.disk_io_r?'↓'+d.disk_io_r+(d.disk_io_w?' ↑'+d.disk_io_w:''):'—');
      var _db=document.getElementById('bw-bar-dsk');
      if(_db){var _dpct=Math.min(100,(parseFloat(d.disk_io_r)||0)*2);_db.style.width=_dpct+'%';
        _db.style.background=_dpct>80?'var(--bw-red)':_dpct>40?'var(--bw-amber)':'var(--bw-green)';}
      if(d.net_rx){var _ne2=document.getElementById('bw-res-net');if(_ne2)_ne2.textContent='↓'+d.net_rx+' ↑'+d.net_tx;
        var _nb2=document.getElementById('bw-bar-net');if(_nb2){var _npct2=Math.min(100,(parseFloat(d.net_rx)||0)*10);_nb2.style.width=_npct2+'%';}}
    }).catch(function(){});
  }
  function BW_refreshBwBar(){
    api.post('/skill/resource_detail',{}).then(function(r2){
      var d=(r2&&r2.result)?r2.result:r2; if(!d||d.error)return;
      if(d.beewid_cpu!=null)_setBar('bw-bar-bw-cpu','bw-res-bw-cpu',d.beewid_cpu,d.beewid_cpu+'%');
      if(d.beewid_ram){
        var eRam=document.getElementById('bw-res-bw-ram');
        if(eRam)eRam.textContent=d.beewid_ram+(d.ollama_ram?' | ◆'+d.ollama_ram:'');
      }
      var dsk=(d.beewid_disk_r?'↓'+d.beewid_disk_r:'')+(d.beewid_disk_w?' ↑'+d.beewid_disk_w:'');
      var ed=document.getElementById('bw-res-bw-disk');if(ed)ed.textContent=dsk||'—';
      if(d.beewid_conn_count!=null){var en=document.getElementById('bw-res-bw-net');if(en)en.textContent=d.beewid_conn_count+' conn';}
    }).catch(function(){});
  }
  function BW_setSysRate(ms){
    var parsed=parseInt(ms)||0;
    // Enforce minimum 8s floor — lower rates saturate the event loop on CPU-only hardware
    if(parsed>0&&parsed<8000) parsed=8000;
    _sysRefreshRate=parsed;
    if(_sysBarTimer)clearInterval(_sysBarTimer);
    try{localStorage.setItem('bw_sys_rate',String(parsed));}catch(e){}
    var sel=document.getElementById('bw-sys-rate'); if(sel) sel.value=String(parsed);
    if(_sysRefreshRate>0){BW_refreshSysBar();_sysBarTimer=setInterval(BW_refreshSysBar,_sysRefreshRate);}
  }
  function BW_setBwRate(ms){
    var parsed=parseInt(ms)||0;
    if(parsed>0&&parsed<8000) parsed=8000;
    _bwRefreshRate=parsed;
    if(_bwBarTimer)clearInterval(_bwBarTimer);
    try{localStorage.setItem('bw_bw_rate',String(parsed));}catch(e){}
    var sel=document.getElementById('bw-bw-rate'); if(sel) sel.value=String(parsed);
    if(_bwRefreshRate>0){BW_refreshBwBar();_bwBarTimer=setInterval(BW_refreshBwBar,_bwRefreshRate);}
  }

  function BW_popOutResources() {
    var p=document.getElementById('bw-res-panel');
    if(p){p.style.display='none';_resPanelOpen=false;if(_resPollTimer)clearTimeout(_resPollTimer);}
    var _mw=window.open('http://localhost:8506/monitor','bw_monitor',
      'width=460,height=680,menubar=no,toolbar=no,location=no,status=no,resizable=yes,scrollbars=yes');
    if(!_mw||_mw.closed) notify.warn('Pop-out blocked — allow popups for localhost:8506');
  }

  function _BW_scheduleRefresh() {
    _resPollTimer = setTimeout(function(){ if(_resPanelOpen) _BW_refreshResourcePanel(); }, _resRefreshRate);
  }

  function _BW_buildResourcePanel() {
    var p = document.createElement('div');
    p.id = 'bw-res-panel';
    p.style.cssText = 'position:fixed;top:200px;right:24px;width:430px;background:var(--bw-bg2);border:1px solid var(--bw-border2);border-radius:8px;z-index:8000;box-shadow:0 8px 32px rgba(0,0,0,.5);display:flex;flex-direction:column;overflow:hidden';
    p.innerHTML = ''
      + '<div id="bw-rp-hdr" style="display:flex;align-items:center;gap:6px;padding:7px 12px;background:var(--bw-bg3);border-bottom:1px solid var(--bw-border2);cursor:grab;user-select:none;flex-shrink:0">'
      +   '<span style="font-family:var(--bw-mono);font-size:11px;font-weight:700;color:var(--bw-gold)">⋆ Under the Hood</span>'
      +   '<span style="flex:1"></span>'
      +   '<span style="font-family:var(--bw-mono);font-size:9px;color:var(--bw-text3)">refresh:</span>'
      +   '<select id="bw-rp-rate" style="font-family:var(--bw-mono);font-size:9px;background:var(--bw-bg4);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);padding:1px 2px" onchange="BW_setResRefresh(this.value)">'
      +     '<option value="0">Off</option><option value="30000">Low 30s</option>'
      +     '<option value="8000" selected>Mid 8s</option><option value="3000">High 3s</option>'
      +   '</select>'
      +   '<button onclick="BW_toggleResourcePanel()" style="background:transparent;border:none;color:var(--bw-text3);cursor:pointer;font-size:15px;padding:0 4px;line-height:1">&times;</button>'
      + '</div>'
      + '<div style="padding:12px;flex:1;overflow-y:auto;display:flex;flex-direction:column;gap:8px;font-family:var(--bw-mono);font-size:11px;max-height:480px">'
      +   '<div id="bw-rp-sys" style="color:var(--bw-text2);line-height:1.9">Loading…</div>'
      +   '<div style="display:flex;align-items:center;gap:6px;margin-top:6px">'
      +     '<span style="font-size:9px;font-weight:600;color:var(--bw-gold);text-transform:uppercase;letter-spacing:.08em;flex:1">◆ Beewid Process</span>'
      +     '<button onclick="_BW_refreshBwOnly()" style="font-family:var(--bw-mono);font-size:9px;padding:1px 6px;background:var(--bw-bg4);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);cursor:pointer" title="Refresh Beewid stats">↺</button>'
      +   '</div>'
      +   '<div id="bw-rp-bw" style="color:var(--bw-text2);font-family:var(--bw-mono);font-size:11px;line-height:1.9">—</div>'
      +   '<div style="display:flex;align-items:center;gap:6px;margin-top:6px">'
      +     '<span style="font-size:9px;font-weight:600;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.08em;flex:1">Active Connections</span>'
      +     '<button onclick="_BW_refreshSysOnly()" style="font-family:var(--bw-mono);font-size:9px;padding:1px 6px;background:var(--bw-bg4);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text2);cursor:pointer" title="Refresh system stats">↺</button>'
      +   '</div>'
      +   '<div id="bw-rp-net" style="color:var(--bw-text2);line-height:1.7;max-height:110px;overflow-y:auto">—</div>'
      +   '<div style="font-size:9px;font-weight:600;color:var(--bw-text3);text-transform:uppercase;letter-spacing:.08em">Recent Actions</div>'
      +   '<div id="bw-rp-log" style="color:var(--bw-text2);line-height:1.7;max-height:130px;overflow-y:auto">—</div>'
      + '</div>';
    document.body.appendChild(p);
    var hdr = p.querySelector('#bw-rp-hdr');
    var ox=0,oy=0,mx=0,my=0;
    hdr.addEventListener('mousedown', function(e) {
      if (e.target.tagName==='SELECT'||e.target.tagName==='BUTTON') return;
      ox=p.offsetLeft; oy=p.offsetTop; mx=e.clientX; my=e.clientY;
      hdr.style.cursor='grabbing';
      function mv(e2){ p.style.left=(ox+e2.clientX-mx)+'px'; p.style.top=(oy+e2.clientY-my)+'px'; p.style.right='auto'; }
      function up2(){ hdr.style.cursor='grab'; document.removeEventListener('mousemove',mv); document.removeEventListener('mouseup',up2); }
      document.addEventListener('mousemove',mv);
      document.addEventListener('mouseup',up2);
    });
    _resPanelOpen = true;
    _BW_refreshResourcePanel();
  }

  function _BW_refreshResourcePanel() {
    if (_resPollTimer) clearTimeout(_resPollTimer);
    api.post('/skill/resource_detail', {}).then(function(resp) {
      var d=(resp&&resp.result)?resp.result:resp;
      var s = document.getElementById('bw-rp-sys');
      if (s) s.innerHTML =
        'CPU: <span style="color:var(--bw-gold)">'+(d.cpu||'—')+'%</span>'
        +'&nbsp;&nbsp;Beewid: <span style="color:var(--bw-amber)">'+(d.beewid_cpu!=null?d.beewid_cpu+'%':'—')+'</span><br>'
        +'RAM: <span style="color:var(--bw-gold)">'+(d.ram_used||'—')+'/'+d.ram_total+'</span>'
        +' (<span style="color:'+(d.ram_pct>85?'var(--bw-red)':'var(--bw-text)')+'">'+d.ram_pct+'%</span>)'
        +'&nbsp;Beewid: <span style="color:var(--bw-amber)">'+(d.beewid_ram||'—')+'</span><br>'
        +'Disk: <span style="color:var(--bw-text)">'+(d.disk_used||'—')+'/'+d.disk_total+'</span>'
        +' (<span style="color:'+(d.disk_pct>85?'var(--bw-red)':'var(--bw-text)')+'">'+d.disk_pct+'%</span>)<br>'
        +'Net ↓: <span style="color:var(--bw-text)">'+(d.net_rx||'—')+'</span>'
        +'&nbsp;&nbsp;↑: <span style="color:var(--bw-text)">'+(d.net_tx||'—')+'</span>';
      var n = document.getElementById('bw-rp-net');
      if (n) {
        var c2 = d.connections||[];
        n.innerHTML = c2.length
          ? c2.map(function(c){
              var lbl=c.label?' <span style="color:var(--bw-gold);font-size:9px">['+c.label+']</span>':'';
              return '<span style="color:var(--bw-text3)">['+c.status+']</span> <b>'+c.remote+'</b>'+lbl;
            }).join('<br>')
          : '<span style="color:var(--bw-text3)">No external connections</span>';
      }
    }).catch(function(){});
    api.get('/logs').then(function(d) {
      var el = document.getElementById('bw-rp-log');
      if (!el) return;
      var ents = (d.entries||d.logs||[]).slice(-20).reverse();
      el.innerHTML = ents.length
        ? ents.map(function(e){
            var t=typeof e==='string'?e:(e.msg||e.message||JSON.stringify(e));
            var c=t.includes('ERROR')||t.includes('FAIL')?'var(--bw-red)':t.includes('WARN')?'var(--bw-amber)':'var(--bw-text2)';
            return '<span style="color:'+c+'">'+t+'</span>';
          }).join('<br>')
        : '<span style="color:var(--bw-text3)">No actions yet</span>';
    }).catch(function(){});
    _BW_scheduleRefresh();
  }

  setTimeout(function(){
    try{
      var sr=localStorage.getItem('bw_sys_rate'); if(sr) BW_setSysRate(sr);
      var br=localStorage.getItem('bw_bw_rate');  if(br) BW_setBwRate(br);
    }catch(e){}
    if(!_sysBarTimer&&_sysRefreshRate>0){BW_refreshSysBar();_sysBarTimer=setInterval(BW_refreshSysBar,_sysRefreshRate);}
    if(!_bwBarTimer &&_bwRefreshRate>0) {BW_refreshBwBar(); _bwBarTimer=setInterval(BW_refreshBwBar,_bwRefreshRate);}
  }, 2500);

  /* ── Public namespace ─────────────────────────────────────── */
  W.BW = {
    api:     api,
    models:  models,
    notify:  notify,
    session: session,
    kill:    kill,
    res:     { toggle: BW_toggleResourcePanel, openTerm: BW_openTerminal, setRate: BW_setResRefresh },
    sys:     { setRate: function(ms){ BW_setSysRate(ms); BW_setBwRate(ms); } },
  nav:     { getActiveTab: getActiveTab, TABS: TABS },
    util:    { fmtBytes: fmtBytes, fmtAgo: fmtAgo, esc: esc, initInlineTabs: initInlineTabs },
    _API_BASE: API_BASE
  };

  /* Global helpers called from inline onclick */
  W.BW_toggleTermMenu      = BW_toggleTermMenu;
  W.BW_openTerminal        = BW_openTerminal;
  W.BW_toggleResourcePanel = BW_toggleResourcePanel;
  W.BW_popOutResources     = BW_popOutResources;
  W._BW_refreshSysOnly     = _BW_refreshSysOnly;
  W.BW_refreshSysBar=BW_refreshSysBar;
  W.BW_refreshBwBar=BW_refreshBwBar;
  W.BW_setSysRate=BW_setSysRate;
  W.BW_setBwRate=BW_setBwRate;
  W._BW_refreshBwOnly      = _BW_refreshBwOnly;
  W.BW_setResRefresh       = BW_setResRefresh;
  W.BW_freeRam         = BW_freeRam;
  W.BW_toggleAI        = BW_toggleAI;
  function BW_downloadHandoff(stamp) {
    var btn = document.getElementById('bw-handoff-btn');
    if (btn) { btn.textContent = '⏳…'; btn.disabled = true; }
    var url = '/admin/handoff' + (stamp ? '?stamp=true' : '');
    var a = document.createElement('a');
    a.href = url;
    a.download = '';
    document.body.appendChild(a);
    a.click();
    document.body.removeChild(a);
    setTimeout(function() {
      if (btn) { btn.textContent = '📎 handoff'; btn.disabled = false; }
      if (stamp) { console.log('[HANDOFF] Stamped copy saved'); }
    }, 1500);
  }
  (function(){
    if(document.getElementById('bw-hoff-style'))return;
    var s=document.createElement('style');s.id='bw-hoff-style';
    s.textContent='.bw-hoff-row{padding:8px 12px;cursor:pointer;color:var(--bw-text2)}'
      +'.bw-hoff-row:hover{background:var(--bw-bg4)}';
    document.head.appendChild(s);
  })();
  function BW_toggleHandoffMenu(){
    var m=document.getElementById('bw-handoff-menu');if(!m)return;
    if(m.style.display==='none'){
      m.style.display='block';
      setTimeout(function(){
        document.addEventListener('click',function _hc(e){
          var w=document.getElementById('bw-handoff-wrap');
          if(w&&!w.contains(e.target)){m.style.display='none';document.removeEventListener('click',_hc);}
        });
      },10);
    }else{m.style.display='none';}
  }
  function BW_closeHandoffMenu(){var m=document.getElementById('bw-handoff-menu');if(m)m.style.display='none';}
  W.BW_toggleHandoffMenu=BW_toggleHandoffMenu;
  W.BW_closeHandoffMenu=BW_closeHandoffMenu;
  W.BW_downloadHandoff=BW_downloadHandoff;  /* BW_HANDOFF_HELPERS */

  W.BW_toggleLog       = BW_toggleLog;
  W.BW_nukeOllama      = BW_nukeOllama;
  W.BW_restartOllama   = BW_restartOllama;
  W.BW_setPolicy       = BW_setPolicy;
  W.BW_hardRefresh     = BW_hardRefresh;
  W.BW_toggleCopilot   = BW_toggleCopilot;
  W.BW_applyProfile        = BW_applyProfile;
  W.BW_toggleProblems      = BW_toggleProblems;
  W._bwBringToChat         = _bwBringToChat;
  W._bwOpenCloudSelector   = _bwOpenCloudSelector;
  W.BW_toggleModelLockout  = function(tier, evt) { if (window.bwToggleLockout) bwToggleLockout(tier, evt); };
  W._bwCloudSend           = _bwCloudSend;
  W._bwCloudBrowser        = _bwCloudBrowser;
  W._bwSetProblemStatus    = _bwSetProblemStatus;
  W._bwAddProblemNote      = _bwAddProblemNote;
  W._bwExportProblems      = _bwExportProblems;
  W.BW_addProblem          = BW_addProblem;
  W.BW_clearProblems       = BW_clearProblems;
  W.BW_autodetectHardware = BW_autodetectHardware;
  W.BW_setModelFromBar    = BW_setModelFromBar;
  W.BW_openQPerms      = BW_openQPerms;
  W.refreshLogs        = refreshLogs;
  W.BW_setTopbarAlert  = function(msg, ms) {
    var el = document.getElementById('bw-topbar-alert');
    if (!el) return;
    el.textContent = msg;
    if (ms) setTimeout(function() { el.textContent = ''; }, ms);
  };


  /* ── Indicator pills (Bar 1) ─────────────────────────────── */
  function _updateIndicators(modState, cfg) {
    function pill(id, text, color) {
      var el = document.getElementById(id); if (!el) return;
      var dot = el.querySelector('span');
      if (dot) dot.style.background = color || 'var(--bw-text3)';
      /* Replace text node */
      var nodes = el.childNodes;
      for (var i = 0; i < nodes.length; i++) {
        if (nodes[i].nodeType === 3) { nodes[i].textContent = text; break; }
      }
      el.style.color = color || 'var(--bw-text3)';
    }
    if (modState) {
      pill('bw-ind-w5', 'W5 ' + (modState.w5 || 'cold'), modState.w5 === 'warm' ? '#48bb78' : '#ed8936');
      pill('bw-ind-w6', 'W6 ' + (modState.w6 || 'cold'), modState.w6 === 'warm' ? '#48bb78' : '#ed8936');
    }
    if (cfg) {
      var pol = cfg.policy_level || 1;
      var pe = document.getElementById('bw-ind-policy');
      if (pe) { pe.textContent = 'L' + pol; pe.style.color = pol >= 2 ? '#ed8936' : 'var(--bw-text3)'; }
      var ae = document.getElementById('bw-ind-agentic');
      if (ae) { ae.innerHTML = cfg.agentic_mode ? '&#129302; Agentic ON' : '&#128274; Agentic OFF'; ae.style.color = cfg.agentic_mode ? '#ed8936' : 'var(--bw-text3)'; }
      var ce = document.getElementById('bw-ind-cloud');
      if (ce) { var _anyCloud = !!(cfg.cloud_ai_enabled || cfg.cloud_w5_model || cfg.cloud_w6_model); ce.innerHTML = _anyCloud ? '&#9729; Cloud ON' : '&#9729; Cloud OFF'; ce.style.color = _anyCloud ? '#48bb78' : 'var(--bw-text3)'; }
    }
  }



  /* ── Problems panel (v2 — disk-backed, status tracking, export) ─── */
  var BW_PROB_KEY = 'bw_problems';

  function _bwGenId() {
    return Math.random().toString(36).slice(2,10) + Date.now().toString(36).slice(-4);
  }
  function _bwGetProblems() {
    try {
      var arr = JSON.parse(localStorage.getItem(BW_PROB_KEY) || '[]');
      // Migrate old-format entries: {ts, text} → add id, status, notes
      var changed = false;
      arr = arr.map(function(p) {
        if (!p.id) { p.id = Math.random().toString(36).slice(2,10) + Date.now().toString(36).slice(-4); changed = true; }
        if (!p.status) { p.status = 'open'; changed = true; }
        if (!p.notes)  { p.notes  = [];    changed = true; }
        return p;
      });
      if (changed) localStorage.setItem(BW_PROB_KEY, JSON.stringify(arr));
      return arr;
    } catch(e) { return []; }
  }
  function _bwSaveProblems(arr) {
    localStorage.setItem(BW_PROB_KEY, JSON.stringify(arr.slice(-40)));
    // Persist to disk asynchronously
    api.post('/problems/save', { problems: arr }).catch(function(){});
    _bwRenderProblems(); _bwUpdateProbBadge();
  }
  function BW_addProblem() {
    var inp = document.getElementById('bw-prob-input');
    var text = inp ? inp.value.trim() : '';
    if (!text) return;
    var ts = new Date().toISOString();
    // Post to API to get server-assigned ID
    api.post('/problems/add', { text: text, ts: ts }).then(function(d) {
      if (d && d.problem) {
        var arr = _bwGetProblems();
        arr.push(d.problem);
        localStorage.setItem(BW_PROB_KEY, JSON.stringify(arr.slice(-40)));
        _bwRenderProblems(); _bwUpdateProbBadge();
        notify.ok('Problem logged — ID: ' + d.problem.id);
      }
    }).catch(function() {
      // Fallback: local only
      var arr = _bwGetProblems();
      arr.push({ id: _bwGenId(), ts: ts, text: text, status: 'open', resolution: '', notes: [] });
      _bwSaveProblems(arr);
      notify.ok('Problem logged (local)');
    });
    if (inp) inp.value = '';
  }
  function BW_clearProblems() {
    if (!confirm('Clear ALL problems including resolved? This cannot be undone.')) return;
    localStorage.removeItem(BW_PROB_KEY);
    api.post('/problems/save', { problems: [] }).catch(function(){});
    _bwRenderProblems(); _bwUpdateProbBadge(); notify.warn('All problems cleared');
  }
  function _bwSetProblemStatus(id, status) {
    var arr = _bwGetProblems();
    var p = arr.find(function(x){ return x.id === id; });
    if (!p) return;
    p.status = status; p.updated_ts = new Date().toISOString();
    _bwSaveProblems(arr);
    api.post('/problems/update', { id: id, status: status, ts: p.updated_ts }).catch(function(){});
    notify.ok(status === 'resolved' ? '✅ Marked resolved' : '~ Marked partial');
  }
  function _bwAddProblemNote(id) {
    var noteText = prompt('Add a note to this problem (solution, workaround, context):');
    if (!noteText || !noteText.trim()) return;
    var ts = new Date().toISOString();
    var arr = _bwGetProblems();
    var p = arr.find(function(x){ return x.id === id; });
    if (!p) return;
    p.notes = p.notes || [];
    p.notes.push({ ts: ts, text: noteText.trim(), by: 'user' });
    p.updated_ts = ts;
    _bwSaveProblems(arr);
    api.post('/problems/update', { id: id, note: noteText.trim(), ts: ts, by: 'user' }).catch(function(){});
    notify.ok('Note added');
  }
  function _bwExportProblems(ids) {
    var url = API_BASE + '/problems/export' + (ids ? '?ids=' + ids.join(',') : '');
    fetch(url).then(function(r){ return r.json(); }).then(function(d) {
      if (!d.markdown) { notify.warn('Nothing to export'); return; }
      // Copy to clipboard
      navigator.clipboard.writeText(d.markdown).then(function() {
        notify.ok('📋 Copied ' + (d.count||'all') + ' problem(s) — paste into Claude chat');
      }).catch(function() {
        // Fallback: download as file
        var blob = new Blob([d.markdown], { type: 'text/markdown' });
        var a = document.createElement('a');
        a.href = URL.createObjectURL(blob);
        a.download = 'beewid_problems_' + Date.now() + '.md';
        document.body.appendChild(a); a.click(); document.body.removeChild(a);
        notify.ok('Problems exported as .md file');
      });
    }).catch(function(){ notify.warn('Export failed'); });
  }
  function BW_toggleProblems() {
    var panel = document.getElementById('bw-prob-panel');
    if (!panel) { _bwCreateProbPanel(); return; }
    var open = panel.style.display !== 'block';
    panel.style.display = open ? 'block' : 'none';
    if (open) { _bwRenderProblems(); _bwSyncProblemsFromDisk(); }
    var btn = document.getElementById('bw-problems-btn');
    if (btn) btn.style.background = open ? 'rgba(237,137,54,0.18)' : 'rgba(237,137,54,0.06)';
  }
  function _bwSyncProblemsFromDisk() {
    // Pull latest from disk on panel open — catches AI-added notes
    api.get ? api.get('/problems').then(function(d){
      if (d && d.problems && d.problems.length) {
        localStorage.setItem(BW_PROB_KEY, JSON.stringify(d.problems));
        _bwRenderProblems(); _bwUpdateProbBadge();
      }
    }).catch(function(){}) :
    fetch(API_BASE + '/problems').then(function(r){return r.json();}).then(function(d){
      if (d && d.problems && d.problems.length) {
        localStorage.setItem(BW_PROB_KEY, JSON.stringify(d.problems));
        _bwRenderProblems(); _bwUpdateProbBadge();
      }
    }).catch(function(){});
  }
  function _bwCreateProbPanel() {
    var BS2 = 'background:var(--bw-bg3);border:1px solid rgba(255,255,255,0.15);color:var(--bw-text2);border-radius:4px;padding:4px 10px;cursor:pointer;font-size:11px;font-family:var(--bw-mono)';
    var el = document.createElement('div'); el.id = 'bw-prob-panel';
    el.style.cssText = 'position:fixed;top:160px;right:0;width:360px;'
      + 'background:var(--bw-bg2);border-left:2px solid rgba(249,115,22,0.5);'
      + 'border-bottom:1px solid var(--bw-border2);z-index:1004;padding:16px;'
      + 'font-family:var(--bw-mono);font-size:11px;box-shadow:-4px 4px 24px rgba(0,0,0,0.5);'
      + 'max-height:80vh;overflow-y:auto';

    // Header
    var header = document.createElement('div');
    header.style.cssText = 'display:flex;justify-content:space-between;align-items:center;margin-bottom:10px';
    var title = document.createElement('span');
    title.style.cssText = 'color:var(--bw-amber);font-size:12px;font-weight:700;letter-spacing:.08em';
    title.innerHTML = '&#9888; PROBLEMS LOG';
    var hdrBtns = document.createElement('div');
    hdrBtns.style.cssText = 'display:flex;gap:5px;align-items:center';
    var expAllBtn = document.createElement('button');
    expAllBtn.style.cssText = BS2 + ';padding:2px 7px;font-size:10px;color:#34d399;border-color:rgba(52,211,153,0.35)';
    expAllBtn.title = 'Export open+partial problems — copies markdown to clipboard';
    expAllBtn.innerHTML = '&#128228; export';
    expAllBtn.onclick = function() { _bwExportProblems(); };
    var closeBtn = document.createElement('button');
    closeBtn.style.cssText = BS2 + ';padding:2px 8px;color:var(--bw-text3)';
    closeBtn.innerHTML = '&#10005;'; closeBtn.onclick = BW_toggleProblems;
    hdrBtns.appendChild(expAllBtn); hdrBtns.appendChild(closeBtn);
    header.appendChild(title); header.appendChild(hdrBtns);

    // Input
    var ta = document.createElement('textarea'); ta.id = 'bw-prob-input';
    ta.placeholder = 'Describe problem — press Enter or + Log...';
    ta.style.cssText = 'width:100%;box-sizing:border-box;background:var(--bw-bg3);'
      + 'border:1px solid rgba(255,255,255,0.15);color:var(--bw-text1);border-radius:4px;'
      + 'padding:8px;font-family:var(--bw-mono);font-size:11px;resize:none;height:64px;outline:none;margin-top:2px';
    ta.onkeydown = function(e) { if (e.key === 'Enter' && !e.shiftKey) { e.preventDefault(); BW_addProblem(); } };

    var btns = document.createElement('div'); btns.style.cssText = 'display:flex;gap:6px;margin-top:8px';
    var addBtn = document.createElement('button');
    addBtn.style.cssText = BS2 + ';flex:1;color:#f97316;border-color:rgba(249,115,22,0.45)';
    addBtn.innerHTML = '+ Log problem'; addBtn.onclick = BW_addProblem;
    var clrBtn = document.createElement('button');
    clrBtn.style.cssText = BS2 + ';color:var(--bw-red);border-color:rgba(252,80,80,0.3)';
    clrBtn.innerHTML = '&#128465; clear all'; clrBtn.onclick = BW_clearProblems;
    btns.appendChild(addBtn); btns.appendChild(clrBtn);

    // AI Repair section (preserved)
    var repairDiv = document.createElement('div');
    repairDiv.style.cssText = 'margin-top:10px;padding-top:8px;border-top:1px solid var(--bw-border2)';
    var repairTitle = document.createElement('div');
    repairTitle.style.cssText = 'color:var(--bw-text3);font-size:10px;margin-bottom:6px;letter-spacing:.06em';
    repairTitle.textContent = '⚡ AI-ASSISTED REPAIR';
    var repairBtns = document.createElement('div');
    repairBtns.style.cssText = 'display:flex;gap:5px;flex-wrap:wrap';
    var mkBtn = function(label, style, action) {
      var b = document.createElement('button');
      b.style.cssText = BS2 + ';' + style;
      b.innerHTML = label; b.onclick = action; return b;
    };
    repairBtns.appendChild(mkBtn('🤖 Fix local AI', 'color:#f97316;border-color:rgba(249,115,22,0.4)', function() {
      var prob = document.getElementById('bw-prob-input');
      var text = (prob && prob.value.trim()) || (_bwGetProblems().filter(function(p){return p.status==='open';}).slice(-1)[0] || {}).text || '';
      if (!text) { notify.warn('Log a problem first'); return; }
      if (prob && prob.value.trim()) BW_addProblem();
      var ci = document.getElementById('prompt-input') || document.getElementById('chat-input');
      if (ci) { ci.value = 'Fix this Beewid issue: ' + text; if (window.sendMessage) sendMessage(); }
    }));
    repairBtns.appendChild(mkBtn('☁ Cloud AI', 'color:#60a5fa;border-color:rgba(96,165,250,0.4)', function() {
      var prob = document.getElementById('bw-prob-input');
      var text = (prob && prob.value.trim()) || (_bwGetProblems().filter(function(p){return p.status==='open';}).slice(-1)[0] || {}).text || '';
      if (!text) { notify.warn('Log a problem first or type one above'); return; }
      if (prob && prob.value.trim()) BW_addProblem();
      _bwOpenCloudSelector(
        'Beewid problem: ' + text + '\n\nBeewid stack: FastAPI :8506, Ollama (llama3.1:8b W5, qwen2.5:14b W6), Kali Linux, CPU-only 32GB.',
        null
      );
    }));
    repairBtns.appendChild(mkBtn('&#128228; Export to Claude', 'color:#34d399;border-color:rgba(52,211,153,0.4)', function() {
      _bwExportProblems();
    }));
    repairDiv.appendChild(repairTitle); repairDiv.appendChild(repairBtns);

    // Problems list
    var listLabel = document.createElement('div');
    listLabel.style.cssText = 'color:var(--bw-text3);font-size:10px;margin-top:12px;margin-bottom:4px;letter-spacing:.06em';
    listLabel.textContent = 'LOGGED PROBLEMS';
    var list = document.createElement('div'); list.id = 'bw-prob-list';
    list.style.cssText = 'max-height:260px;overflow-y:auto';

    var hint = document.createElement('div');
    hint.style.cssText = 'margin-top:8px;color:var(--bw-text3);font-size:10px;border-top:1px solid var(--bw-border2);padding-top:6px';
    hint.innerHTML = 'Open+partial problems inject into AI context &nbsp;·&nbsp; <a href="#" style="color:var(--bw-text3)" onclick="_bwSyncProblemsFromDisk();return false">↻ sync</a>';

    el.appendChild(header); el.appendChild(ta); el.appendChild(btns);
    el.appendChild(repairDiv); el.appendChild(listLabel); el.appendChild(list); el.appendChild(hint);
    document.body.appendChild(el);
    _bwRenderProblems(); _bwSyncProblemsFromDisk();
    var btn = document.getElementById('bw-problems-btn');
    if (btn) btn.style.background = 'rgba(237,137,54,0.18)';
  }


  /* ── Cloud AI selector ─────────────────────────────────────────── */
  var _bwCloudPanelOpen = false;

  function _bwOpenCloudSelector(contextText, onResponse) {
    // Remove any existing selector
    var existing = document.getElementById('bw-cloud-selector');
    if (existing) { existing.remove(); _bwCloudPanelOpen = false; return; }
    _bwCloudPanelOpen = true;

    var panel = document.createElement('div');
    panel.id = 'bw-cloud-selector';
    panel.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);'
      + 'width:420px;max-width:92vw;background:var(--bw-bg2);border:1px solid rgba(99,102,241,0.5);'
      + 'border-radius:8px;z-index:9999;padding:18px;font-family:var(--bw-mono);font-size:11px;'
      + 'box-shadow:0 12px 48px rgba(0,0,0,0.7)';

    var header = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:14px">'
      + '<span style="color:#818cf8;font-size:12px;font-weight:700;letter-spacing:.08em">☁ CLOUD AI — SELECT DESTINATION</span>'
      + '<button onclick="document.getElementById(\'bw-cloud-selector\').remove()" '
      + 'style="background:transparent;border:none;color:var(--bw-text3);cursor:pointer;font-size:16px;padding:0 4px">&times;</button>'
      + '</div>';

    var statusDiv = '<div id="bw-cloud-rows" style="display:flex;flex-direction:column;gap:6px">'
      + '<div style="color:var(--bw-text3);font-size:10px">Checking connections…</div></div>';

    var footer = '<div style="margin-top:12px;padding-top:10px;border-top:1px solid var(--bw-border2);'
      + 'color:var(--bw-text3);font-size:9px">Browser tiers copy context to clipboard and open a new tab. '
      + 'API tiers send directly and show response in chat.</div>';

    panel.innerHTML = header + statusDiv + footer;
    document.body.appendChild(panel);

    // Fetch live status
    fetch(API_BASE + '/cloud/status').then(function(r){ return r.json(); }).then(function(d) {
      var rows = document.getElementById('bw-cloud-rows');
      if (!rows) return;
      var tiers = d.tiers || {};
      var order = ['claude_api','ddg','pollinations','openai_api','claude_browser','chatgpt_browser','private_server'];
      rows.innerHTML = order.map(function(key) {
        var t = tiers[key]; if (!t) return '';
        var isBrowser = !!t.browser;
        var isWired   = !!t.wired;
        var dotColor  = isWired ? 'var(--bw-green)' : '#6b7280';
        var dotLabel  = isWired ? '●' : '○';
        var badgeHtml = t.free ? '<span style="font-size:8px;background:rgba(52,211,153,0.15);color:#34d399;border-radius:3px;padding:1px 4px;margin-left:4px">free</span>' : '';
        var actionHtml;
        if (isBrowser) {
          actionHtml = '<button onclick="_bwCloudBrowser(\'' + key + '\',_bwCloudCtx)" '
            + 'style="font-size:9px;padding:2px 8px;background:rgba(96,165,250,0.1);border:1px solid rgba(96,165,250,0.35);'
            + 'border-radius:3px;color:#60a5fa;cursor:pointer">Copy + Open ↗</button>';
        } else if (isWired) {
          actionHtml = '<button onclick="_bwCloudSend(\'' + key + '\',_bwCloudCtx,_bwCloudCb)" '
            + 'style="font-size:9px;padding:2px 8px;background:rgba(99,102,241,0.15);border:1px solid rgba(99,102,241,0.4);'
            + 'border-radius:3px;color:#818cf8;cursor:pointer;font-weight:600">→ Send now</button>';
        } else {
          actionHtml = '<span style="font-size:9px;color:var(--bw-text3)">Not configured</span>';
        }
        return '<div style="display:flex;align-items:center;gap:8px;padding:7px 10px;'
          + 'background:var(--bw-bg3);border-radius:4px;border:1px solid var(--bw-border2)">'
          + '<span style="color:' + dotColor + ';font-size:11px">' + dotLabel + '</span>'
          + '<div style="flex:1">'
          + '<div style="color:var(--bw-text1);font-weight:600">' + t.label + badgeHtml + '</div>'
          + '<div style="color:var(--bw-text3);font-size:9px;margin-top:1px">' + t.detail + '</div>'
          + '</div>'
          + actionHtml
          + '</div>';
      }).join('');
    }).catch(function() {
      var rows = document.getElementById('bw-cloud-rows');
      if (rows) rows.innerHTML = '<div style="color:var(--bw-red);font-size:10px">Could not load status — is Beewid running?</div>';
    });

    // Store context + callback on window for inline onclick access
    window._bwCloudCtx = contextText || '';
    window._bwCloudCb  = onResponse  || null;
  }

  function _bwCloudSend(target, contextText, callback) {
    var panel = document.getElementById('bw-cloud-selector');
    if (panel) panel.remove();

    // Show sending indicator in chat
    var ci = document.getElementById('prompt-input') || document.getElementById('chat-input');
    notify.ok('Sending to ' + target + '…');

    fetch(API_BASE + '/cloud/send', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ target: target, prompt: contextText })
    }).then(function(r){ return r.json(); }).then(function(d) {
      if (!d.ok) {
        notify.warn('Cloud AI error: ' + (d.detail || d.error || 'unknown'));
        return;
      }
      // Inject response into chat as an AI message
      if (window.appendMsg) {
        var msgEl = appendMsg('ai', '', '☁ ' + (d.model || target));
        msgEl.textContent = d.response || '(empty response)';
        if (window.scrollBottom) scrollBottom();
        // Also push to history
        if (window.history && window.saveHistory) {
          history.push({ role: 'assistant', content: d.response || '', ts: Date.now() });
          saveHistory();
        }
      }
      // Fire callback (problem action bar resolution buttons)
      if (typeof callback === 'function') callback(d);
      notify.ok('Cloud AI (' + (d.model||target) + ') responded');
    }).catch(function(e) {
      notify.warn('Cloud AI failed: ' + e.message);
    });
  }

  function _bwCloudBrowser(target, contextText) {
    var panel = document.getElementById('bw-cloud-selector');
    if (panel) panel.remove();

    // Copy context to clipboard
    navigator.clipboard.writeText(contextText).then(function() {
      notify.ok('Context copied to clipboard');
    }).catch(function() {
      // Fallback: show in a textarea
      var tmp = document.createElement('textarea');
      tmp.value = contextText;
      tmp.style.cssText = 'position:fixed;top:-9999px';
      document.body.appendChild(tmp);
      tmp.select(); document.execCommand('copy');
      document.body.removeChild(tmp);
      notify.ok('Context copied (fallback)');
    });

    // Open appropriate service
    var urls = {
      claude_browser:  'https://claude.ai/new',
      chatgpt_browser: 'https://chat.openai.com/',
    };
    var url = urls[target];
    if (url) {
      setTimeout(function() { window.open(url, '_blank'); }, 400);
      notify.ok('Opening ' + target.replace('_browser','') + ' — paste your context there');
    }
  }

  function _bwBringToChat(id) {
    var arr = _bwGetProblems();
    var p = arr.find(function(x){ return x.id === id; });
    if (!p) { notify.warn('Problem not found'); return; }

    // Build context card
    var statusLabel = { open: '🔴 OPEN', partial: '🟡 PARTIAL', resolved: '✅ RESOLVED' }[p.status||'open'] || '🔴 OPEN';
    var lines = [
      '[PROBLEM ' + id + ' | ' + statusLabel + ']',
      'Problem: ' + p.text,
    ];
    if (p.notes && p.notes.length) {
      lines.push('Notes:');
      p.notes.forEach(function(n){ lines.push('  [' + n.by + '] ' + n.text); });
    }

    // Add sidebar context: other open/partial problems
    var others = arr.filter(function(x){ return x.id !== id && x.status !== 'resolved'; });
    if (others.length) {
      lines.push('');
      lines.push('Other open problems (' + others.length + '):');
      others.slice(0,4).forEach(function(x){ lines.push('  • ' + x.text); });
    }

    lines.push('');
    lines.push('Please diagnose this problem. Suggest a concrete fix. Consider:');
    lines.push('• Is there a root cause pattern across the open problems above?');
    lines.push('• Can this be fixed with a skill/shell command right now?');
    lines.push('• Should this go to W6 for deeper analysis, Autocode for a patch, or Cloud AI?');
    lines.push('After your analysis, I will be able to mark it solved, partial, or escalate.');

    var card = lines.join('\n');

    // Signal chat.html that this send is problem-context triggered
    window._bwActiveProblemId = id;
    window._bwActiveProblemText = p.text;

    // Close problems panel
    var panel = document.getElementById('bw-prob-panel');
    if (panel) panel.style.display = 'none';
    var pbtn = document.getElementById('bw-problems-btn');
    if (pbtn) pbtn.style.background = 'rgba(237,137,54,0.06)';

    // Inject into chat and fire
    var inp = document.getElementById('prompt-input') || document.getElementById('chat-input');
    if (!inp) { notify.warn('Chat input not found'); return; }
    inp.value = card;
    if (window.autoResize) autoResize(inp);
    if (window.sendMessage) {
      sendMessage();
    } else {
      notify.warn('sendMessage not available — navigate to Chat tab first');
    }
  }

  function _bwRenderProblems() {
    var list = document.getElementById('bw-prob-list'); if (!list) return;
    var arr = _bwGetProblems();
    if (!arr.length) {
      list.innerHTML = '<div style="color:var(--bw-text3);padding:6px 0;font-size:10px">No problems logged.</div>';
      return;
    }
    // Sort: open first, then partial, then resolved
    var order = { open: 0, partial: 1, resolved: 2 };
    // Sort: open first, then partial, then resolved — newest first within each group
    var sorted = arr.slice().sort(function(a,b){
      var statusDiff = (order[a.status]||0) - (order[b.status]||0);
      if (statusDiff !== 0) return statusDiff;
      // Within same status: newest first
      return (b.ts || '') > (a.ts || '') ? 1 : -1;
    });
    list.innerHTML = sorted.map(function(p) {
      var ts = p.ts ? new Date(p.ts).toLocaleTimeString([], {hour:'2-digit',minute:'2-digit'}) : '?';
      var statusIcon = { open: '<span style="color:var(--bw-red)">●</span>', partial: '<span style="color:var(--bw-amber)">◑</span>', resolved: '<span style="color:var(--bw-green)">✓</span>' }[p.status||'open'] || '●';
      var dimmed = p.status === 'resolved' ? 'opacity:0.5;' : '';
      var noteHtml = '';
      if (p.notes && p.notes.length) {
        noteHtml = '<div style="margin-top:3px;padding:3px 0 0 12px;border-left:2px solid var(--bw-border2);color:var(--bw-text3);font-size:9px">'
          + p.notes.slice(-2).map(function(n){ return '['+n.by+'] '+n.text; }).join('<br>')
          + '</div>';
      }
      return '<div style="'+dimmed+'padding:6px 0;border-bottom:1px solid var(--bw-border);font-size:10px">'
        + '<div style="display:flex;gap:6px;align-items:flex-start">'
        + '<span style="flex-shrink:0;margin-top:1px">'+statusIcon+'</span>'
        + '<span style="flex:1;color:var(--bw-text2);word-break:break-word">'+p.text+'</span>'
        + '<span style="color:var(--bw-text3);flex-shrink:0;font-size:9px">'+ts+'</span>'
        + '</div>'
        + noteHtml
        + '<div style="display:flex;gap:4px;margin-top:4px;flex-wrap:wrap">'
        + (p.status !== 'resolved' ? '<button onclick="_bwSetProblemStatus(\''+p.id+'\',\'resolved\')" style="font-size:9px;padding:1px 6px;background:rgba(52,211,153,0.1);border:1px solid rgba(52,211,153,0.3);border-radius:3px;color:#34d399;cursor:pointer">✓ solved</button>' : '')
        + (p.status === 'open' ? '<button onclick="_bwSetProblemStatus(\''+p.id+'\',\'partial\')" style="font-size:9px;padding:1px 6px;background:rgba(251,191,36,0.1);border:1px solid rgba(251,191,36,0.3);border-radius:3px;color:var(--bw-amber);cursor:pointer">~ partial</button>' : '')
        + '<button onclick="_bwAddProblemNote(\''+p.id+'\')" style="font-size:9px;padding:1px 6px;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text3);cursor:pointer">✎ note</button>'
        + (p.status !== 'resolved' ? '<button onclick="_bwBringToChat(\''+p.id+'\')" style="font-size:9px;padding:1px 6px;background:rgba(99,102,241,0.12);border:1px solid rgba(99,102,241,0.4);border-radius:3px;color:#818cf8;cursor:pointer;font-weight:600">&#128269; chat</button>' : '')
        + '<button onclick="_bwExportProblems([\''+p.id+'\'])" style="font-size:9px;padding:1px 6px;background:var(--bw-bg3);border:1px solid var(--bw-border2);border-radius:3px;color:var(--bw-text3);cursor:pointer">&#128228; export</button>'
        + '</div></div>';
    }).join('');
  }
  function _bwUpdateProbBadge() {
    var btn = document.getElementById('bw-problems-btn'); if (!btn) return;
    var count = _bwGetProblems().filter(function(p){ return p.status !== 'resolved'; }).length;
    var existing = btn.querySelector('.bw-prob-badge');
    if (count) {
      if (!existing) {
        var badge = document.createElement('span'); badge.className = 'bw-prob-badge';
        badge.style.cssText = 'margin-left:4px;background:var(--bw-amber);color:#000;border-radius:8px;padding:0 5px;font-size:9px;font-weight:700';
        btn.appendChild(badge);
      }
      btn.querySelector('.bw-prob-badge').textContent = count;
      btn.style.color = 'var(--bw-amber)';
    } else {
      if (existing) existing.remove();
      btn.style.color = '';
    }
  }

  /* ── Auto-init ────────────────────────────────────────────── */
  document.addEventListener('DOMContentLoaded', function() {
    /* Skip global chrome when embedded in copilot panel */
    var _qs = new URLSearchParams(W.location.search);
    var _isPanel  = _qs.get('panel')  === '1';
    var _isPopout = _qs.get('popout') === '1'; /* BW_R120: agents hub popout */
    if (!_isPanel && !_isPopout) {
      injectSidebar();
      injectTopbar();
      /* BW_R80P61 — feature-state badges on nav items
         Selectors target the href substring since injectSidebar uses href-based nav links. */
      setTimeout(function () {
        if (!window.BeewidBadge) return;
        BeewidBadge.attach('#bw-sidebar a.bw-nav-item[href*="beewid_trading.html"]',    'in-dev');
        BeewidBadge.attach('#bw-sidebar a.bw-nav-item[href*="beewid_governance.html"]', 'in-dev');
        /* Voice is disabled in TABS (href="#") — match by title since it's the only "Voice" entry */
        BeewidBadge.attach('#bw-sidebar a.bw-nav-item[title="Voice"]',
                           'coming-soon', { text: 'Coming as Secretary' });
      }, 50);
      /* Don't open copilot on the main chat tab — user is already in chat.
         BW_R80P79_SHIPREADY_FIX — Also don't autopop in autocode contexts.
         The chat overlapping the autocode output (especially during a streaming
         run) was distracting. The CHAT button still works for explicit open.
         Autocode context heuristic: the sub-tab manager (beewid_autocode.html),
         the in-iframe instance (beewid_autocode_instance.html), any popout
         window (?popout=1) or standalone server URL (?standalone=1). */
      var _curFile = W.location.pathname.split('/').pop() || '';
      var _isAutocodeFile = _curFile === 'beewid_autocode.html'
                         || _curFile === 'beewid_autocode_instance.html';
      var _isAutocodeQS = /[?&](popout|standalone)=1/.test(W.location.search || '')
                       || /\bautocode\b/i.test(W.location.search || '');
      if (_curFile !== 'beewid_chat.html' && !_isAutocodeFile && !_isAutocodeQS) {
        var _panelClosed = sessionStorage.getItem('bw_copilot_closed') === '1';
        if (!_panelClosed) { setTimeout(BW_toggleCopilot, 350); }
      }
    }
    injectToasts();
    models.start(30000);
    /* Warm models immediately on startup — don't wait for first 3-min poll cycle */
    setTimeout(function() { api.post('/admin/keepalive', {}).catch(function(){}); }, 2000);
    setTimeout(_bwUpdateProbBadge, 600);
    initInlineTabs();
    _pollRam();
    setInterval(_pollRam, 60000);
    // Live clock
    (function _tick() {
      var el = document.getElementById('bw-clock');
      if (el) el.textContent = new Date().toLocaleTimeString([], {hour:'2-digit',minute:'2-digit',second:'2-digit'});
      setTimeout(_tick, 1000);
    })();
    /* Restore policy level from yaml (authoritative) — do NOT call BW_setPolicy here
       as that would write back to yaml and clobber what the user set.
       Just update the UI elements silently. */
    api.get('/config').then(function(d) {
      var pol = (d && d.config && d.config.policy_level != null) ? d.config.policy_level : 2;
      session.set('policy_level', pol);
      var sel = document.getElementById('bw-policy-select');
      if (sel) sel.value = pol;
      var pe = document.getElementById('bw-ind-policy');
      if (pe) { pe.textContent = 'L' + pol; pe.style.color = pol >= 2 ? '#ed8936' : 'var(--bw-text3)'; }
      var ae = document.getElementById('bw-ind-agentic');
      if (ae && d && d.config) {
        ae.innerHTML   = d.config.agentic_mode ? '&#129302; Agentic ON' : '&#128274; Agentic OFF';
        ae.style.color = d.config.agentic_mode ? '#ed8936' : 'var(--bw-text3)';
      }
    }).catch(function() {
      /* fallback: session only, still don't write to yaml */
      var saved = session.get('policy_level', 2);
      var sel = document.getElementById('bw-policy-select');
      if (sel) sel.value = saved;
    });
  });

/* BW_R99 — Shared History Panel ------------------------------------------ */

(function() {
  var _bwSharedHistOpen = false;
  var _bwSharedHistMounted = false;

  /* CSS injected once */
  function _BW_injectHistCSS() {
    if (document.getElementById('bw-shared-hist-css')) return;
    var s = document.createElement('style');
    s.id = 'bw-shared-hist-css';
    s.textContent = [
      '#bw-hist-sidebar{position:fixed;top:0;left:0;bottom:0;width:290px;',
      'background:var(--bw-bg2,#1a1a2e);border-right:1px solid var(--bw-border,#2a2a3e);',
      'z-index:1100;display:flex;flex-direction:column;',
      'transform:translateX(-295px);transition:transform .22s cubic-bezier(.4,0,.2,1);',
      'font-family:var(--bw-mono,monospace);font-size:11px;}',
      '#bw-hist-sidebar.open{transform:translateX(0);}',
      '#bw-hist-overlay{position:fixed;inset:0;z-index:1099;',
      'background:rgba(0,0,0,0.45);display:none;}',
      '#bw-hist-overlay.open{display:block;}',
      '.bw-sh-row{padding:6px 10px;cursor:default;color:var(--bw-text3,#888);',
      'border-radius:3px;line-height:1.4;display:flex;gap:6px;align-items:flex-start;}',
      '.bw-sh-row:hover{background:var(--bw-bg3,#22223a);color:var(--bw-text,#e0e0e0);}',
      '.bw-sh-proj{padding:5px 10px;font-size:10px;font-weight:700;letter-spacing:.07em;',
      'text-transform:uppercase;color:var(--bw-text2,#aaa);border-top:1px solid var(--bw-border2,#333);',
      'margin-top:4px;}',
      '.bw-sh-del{background:transparent;border:none;color:var(--bw-text3,#888);',
      'cursor:pointer;font-size:12px;padding:0 4px;opacity:0.5;margin-left:auto;flex-shrink:0;}',
      '.bw-sh-del:hover{opacity:1;color:#fc5050;}'
    ].join('');
    document.head.appendChild(s);
  }

  /* Build and append sidebar + overlay to body */
  function _BW_mountHistoryPanel() {
    if (_bwSharedHistMounted) return;
    if (document.getElementById('bw-hist-sidebar')) {
      /* Chat tab already has its own sidebar — do not double-mount */
      _bwSharedHistMounted = true;
      return;
    }
    _BW_injectHistCSS();
    var overlay = document.createElement('div');
    overlay.id = 'bw-hist-overlay';
    overlay.onclick = function() { window.BW_toggleSharedHistory(); };

    var sidebar = document.createElement('div');
    sidebar.id = 'bw-hist-sidebar';
    sidebar.innerHTML = [
      /* BW_R100: relay panel — full history is inside copilot */
      '<div style="display:flex;align-items:center;gap:8px;padding:10px 12px;',
      'border-bottom:1px solid var(--bw-border,#2a2a3e);flex-shrink:0">',
      '<span style="color:var(--bw-gold,#f5c842);font-weight:700;font-size:12px;flex:1">',
      '📚 HISTORY</span>',
      '<button onclick="BW_toggleSharedHistory()" style="background:transparent;border:none;',
      'color:var(--bw-text3,#888);cursor:pointer;font-size:15px;padding:0 2px">&times;</button>',
      '</div>',
      '<div style="flex:1;display:flex;flex-direction:column;align-items:center;',
      'justify-content:center;gap:12px;padding:24px 16px;text-align:center">',
      '<div style="font-size:11px;color:var(--bw-text3,#888);font-family:var(--bw-mono,monospace);',
      'line-height:1.6">Full history panel<br>opens in Chat panel →</div>',
      '<button onclick="window.bwOpenHistory()" ',
      'style="font-family:var(--bw-mono,monospace);font-size:11px;padding:6px 18px;',
      'background:rgba(245,200,66,0.12);border:1px solid rgba(245,200,66,0.5);',
      'color:var(--bw-gold,#f5c842);border-radius:4px;cursor:pointer;font-weight:700">',
      '📚 Open Full History</button>',
      '<div style="font-size:9px;color:var(--bw-text3,#888);font-family:var(--bw-mono,monospace)">',
      'Opens in Chat panel · all features available</div>',
      '</div>'
    ].join('');

    document.body.appendChild(overlay);
    document.body.appendChild(sidebar);
    _bwSharedHistMounted = true;
  }

  /* Toggle open/close */
  window.BW_toggleSharedHistory = function() {
    var sidebar = document.getElementById('bw-hist-sidebar');
    var overlay = document.getElementById('bw-hist-overlay');
    if (!sidebar || !overlay) { _BW_mountHistoryPanel(); return; }
    _bwSharedHistOpen = !_bwSharedHistOpen;
    sidebar.classList.toggle('open', _bwSharedHistOpen);
    overlay.classList.toggle('open', _bwSharedHistOpen);
    if (_bwSharedHistOpen) window.BW_sharedHistLoad();
  };

  /* Load sessions from API */
  window.BW_sharedHistLoad = function(search) {
    var list = document.getElementById('bw-sh-list');
    if (!list) return;
    list.innerHTML = '<div style="color:var(--bw-text3,#888);padding:12px;font-size:10px;text-align:center">Loading…</div>';
    var api = window.API || 'http://127.0.0.1:8506';
    var qs = search ? '?search=' + encodeURIComponent(search) : '';
    Promise.all([
      fetch(api + '/history/sessions' + qs).then(function(r){return r.json();}),
      fetch(api + '/history/projects').then(function(r){return r.json();})
    ]).then(function(results) {
      var sessions  = (results[0].sessions  || []);
      var projects  = (results[1].projects  || ['General']);
      if (!sessions.length) {
        list.innerHTML = '<div style="color:var(--bw-text3,#888);padding:12px;font-size:10px;text-align:center">No sessions found</div>';
        return;
      }
      /* Group by project */
      var byProj = {};
      sessions.forEach(function(s) {
        var p = s.project || 'General';
        if (!byProj[p]) byProj[p] = [];
        byProj[p].push(s);
      });
      var html = '';
      projects.forEach(function(proj) {
        var rows = byProj[proj];
        if (!rows || !rows.length) return;
        html += '<div class="bw-sh-proj">📁 ' + _bwEsc(proj) + ' (' + rows.length + ')</div>';
        rows.slice(0, 30).forEach(function(s) {
          var title = _bwEsc(s.title || 'Untitled');
          var date  = s.updated ? new Date(s.updated).toLocaleString([],{month:'short',day:'numeric',hour:'2-digit',minute:'2-digit'}) : '';
          var iso   = s.context_isolated ? ' 🔒' : '';
          html += '<div class="bw-sh-row" onclick="BW_sharedHistOpenSession(\'' + s.id + '\')" style="cursor:pointer">'
            + '<div style="flex:1;min-width:0">'
            + '<div style="white-space:nowrap;overflow:hidden;text-overflow:ellipsis;font-size:10px">' + title + iso + '</div>'
            + (date ? '<div style="font-size:9px;color:var(--bw-text3,#888)">' + date + '</div>' : '')
            + '</div>'
            + '<button class="bw-sh-del" title="Delete session" onclick="BW_sharedHistDelete(\'' + s.id + '\',this)" >🗑</button>'
            + '</div>';
        });
      });
      list.innerHTML = html || '<div style="color:var(--bw-text3,#888);padding:12px;font-size:10px;text-align:center">No sessions</div>';
    }).catch(function(e) {
      list.innerHTML = '<div style="color:#fc5050;padding:12px;font-size:10px">Error loading history: ' + e.message + '</div>';
    });
  };

  /* BW_R99b: open session in copilot panel (non-chat tabs only) */
  window.BW_sharedHistOpenSession = function(sid) {
    /* Ensure copilot is open */
    if (typeof BW_toggleCopilot === 'function') {
      var panel = document.getElementById('bw-copilot');
      var isVisible = panel && panel.style.display !== 'none';
      if (!isVisible) BW_toggleCopilot();
    }
    /* Wait for iframe to be ready, then send load command */
    var attempts = 0;
    var interval = setInterval(function() {
      var frame = document.getElementById('bw-copilot-frame');
      if (frame && frame.contentWindow) {
        try {
          frame.contentWindow.postMessage(
            JSON.stringify({ action: 'loadSession', sessionId: sid }), '*'
          );
          clearInterval(interval);
        } catch(e) { attempts++; if (attempts > 10) clearInterval(interval); }
      } else {
        attempts++;
        if (attempts > 10) clearInterval(interval);
      }
    }, 200);
  };

  /* Search debounce */
  var _bwShHistTimer = null;
  window.BW_sharedHistSearch = function(val) {
    clearTimeout(_bwShHistTimer);
    _bwShHistTimer = setTimeout(function(){ window.BW_sharedHistLoad(val); }, 350);
  };

  /* Delete a session */
  window.BW_sharedHistDelete = function(sid, btn) {
    if (!confirm('Delete this session?')) return;
    var api = window.API || 'http://127.0.0.1:8506';
    fetch(api + '/history/session/' + encodeURIComponent(sid), {method:'DELETE'})
      .then(function(r){return r.json();})
      .then(function(d){
        if (d.ok) { var row = btn.closest('.bw-sh-row'); if(row) row.remove(); }
        else { alert('Delete failed: ' + (d.error||'unknown')); }
      }).catch(function(e){ alert('Delete error: ' + e.message); });
  };

  /* HTML escape helper */
  function _bwEsc(s) {
    return String(s).replace(/&/g,'&amp;').replace(/</g,'&lt;').replace(/>/g,'&gt;').replace(/"/g,'&quot;');
  }

  /* Auto-mount on DOMContentLoaded */
  if (document.readyState === 'loading') {
    document.addEventListener('DOMContentLoaded', _BW_mountHistoryPanel);
  } else {
    _BW_mountHistoryPanel();
  }

})(); /* end BW_R99 shared history */

/* BW_R99: updated bwOpenHistory — uses shared panel on non-chat tabs */
/* BW_R100: bwOpenHistory — chat tab uses local panel; all other tabs open copilot+history */
window.bwOpenHistory = function() {
  if (window.bwToggleHistory) { bwToggleHistory(); return; } /* chat tab — unchanged */
  /* Non-chat tabs: open copilot panel then trigger history inside it */
  if (typeof BW_toggleCopilot === 'function') {
    var panel = document.getElementById('bw-copilot');
    var isOpen = panel && panel.style.display !== 'none';
    if (!isOpen) BW_toggleCopilot();
  }
  /* Send toggleHistory to copilot iframe — poll until ready */
  var attempts = 0;
  var iv = setInterval(function() {
    var frame = document.getElementById('bw-copilot-frame');
    if (frame && frame.contentWindow) {
      try {
        frame.contentWindow.postMessage(
          JSON.stringify({ action: 'toggleHistory' }), '*'
        );
        clearInterval(iv);
      } catch(e) { if (++attempts > 15) clearInterval(iv); }
    } else { if (++attempts > 15) clearInterval(iv); }
  }, 150);
};

  /* BW_R120: agent helpers — window.* not W.* (rule 25), named windows (rule 32)
     All URLs include ?popout=1 so agents.html suppresses sidebar/topbars.
     _bwAgentJump uses postMessage if hub window is already open (rule 32 — no duplicates).
     w5/w6/w7 map to the 'llm' section since they live in LLM Agents. */
  var _llmIds = { w5: 'llm', w6: 'llm', w7: 'llm' };
  window._bwAgentJump = function(id) {
    var section = _llmIds[id] || id; /* w5/w6/w7 scroll to llm section */
    var url = '/static/beewid_agents.html?popout=1&focus=' + section + '&agent_highlight=' + id;
    var hub = window.open('', 'beewid_agents_hub');
    /* If window already exists and has a focus handler, use postMessage */
    if (hub && !hub.closed && hub.location && hub.location.href &&
        hub.location.href.indexOf('beewid_agents') !== -1) {
      try {
        hub.postMessage(JSON.stringify({ action: 'focus', section: section, highlight: id }), '*');
        hub.focus();
        return;
      } catch(e) { /* cross-origin not ready, fall through to open */ }
    }
    window.open(url, 'beewid_agents_hub', 'width=900,height=700,resizable=yes');
  };
  window._bwAgentPopout = function(id) {
    /* Single-agent popout — always opens fresh, no postMessage needed */
    var url = '/static/beewid_agents.html?popout=1&agent=' + id;
    window.open(url, 'beewid_agent_' + id, 'width=500,height=600,resizable=yes');
  };

  /* BW_R119: inject agent status CSS */
  (function() {
    if (document.getElementById('bw-agent-status-css')) return;
    var s = document.createElement('style');
    s.id = 'bw-agent-status-css';
    s.textContent = [
      '.bw-agent-status{display:flex;flex-direction:column;gap:1px;padding:6px 0 4px;border-top:1px solid var(--bw-border,#1e2733);}',
      '.bw-agent-box{display:flex;align-items:center;gap:6px;padding:4px 10px 4px 14px;cursor:pointer;border-radius:4px;transition:background .12s;}',
      '.bw-agent-box:hover{background:var(--bw-bg-hover,rgba(255,255,255,0.03));}',
      '.bw-agent-box .bw-model-name{flex:1;font-size:10px;color:var(--bw-text2,#8899aa);font-family:var(--bw-mono,monospace);white-space:nowrap;overflow:hidden;text-overflow:ellipsis;}',
      '.bw-agent-popout-btn{display:none;background:transparent;border:none;color:var(--bw-text3,#566677);cursor:pointer;font-size:11px;padding:0 2px;line-height:1;flex-shrink:0;}',
      '.bw-agent-box:hover .bw-agent-popout-btn{display:block;}',
      '.bw-agent-popout-btn:hover{color:var(--bw-gold,#f5c842);}',
      '.bw-agent-divider{height:1px;background:var(--bw-border,#1e2733);margin:3px 10px;}',
    ].join(' ');
    document.head.appendChild(s);
  })();

})(window);



/* BW_R107 — Shared Full Engine Panel (matches main chat) */
(function(W) {
  var _seOpen = false;

  /* BW_R115: _bwReflow hoisted to IIFE scope — available on all tabs at load,
     not just after _seMount() runs when engine panel is first opened. */
  function _bwReflow() {
    var h = 0;
    ['bw-topbar','bw-topbar-res','bw-topbar-bw','bw-topbar2','bw-topbar3'].forEach(function(id) {
      var el = document.getElementById(id);
      if (el && getComputedStyle(el).display !== 'none') h += el.offsetHeight || 0;
    });
    document.documentElement.style.setProperty('--bw-topbar-h', h + 'px');
    var seWrap = document.getElementById('bw-se-wrap');
    var eh = (seWrap && getComputedStyle(seWrap).display !== 'none') ? (seWrap.offsetHeight || 0) : 0;
    document.documentElement.style.setProperty('--bw-engine-h', eh + 'px');
    /* BW_R123: track perms panel height */
    var qpWrap = document.getElementById('bw-qp-wrap');
    var qh = (qpWrap && getComputedStyle(qpWrap).display !== 'none') ? (qpWrap.offsetHeight || 0) : 0;
    document.documentElement.style.setProperty('--bw-qp-h', qh + 'px');
    /* Combined offset: topbars + engine + perms */
    document.documentElement.style.setProperty('--bw-combined-h', (h + eh + qh) + 'px');
  }
  W._bwReflow = _bwReflow;

  W.BW_toggleSharedEngine = function() {
    /* BW_R110: chat tab uses its own engine panel — don't mount shared one */
    var _f = W.location.pathname.split('/').pop() || '';
    if (_f === 'beewid_chat.html') {
      if (W.bwToggleControls) W.bwToggleControls();
      return;
    }
    /* BW_R112: panel is now #bw-se-panel inside #bw-se-wrap (in-flow) */
    if (!document.getElementById('bw-se-wrap')) {
      _seMount();
      setTimeout(function() {
        var pp = document.getElementById('bw-se-panel');
        if (pp) {
          var pw2 = document.getElementById('bw-se-wrap');
          if(pw2) pw2.classList.remove('hidden');
          pp.classList.remove('hidden');
          _seOpen = true;
          requestAnimationFrame(function() { if(W._bwReflow) W._bwReflow(); });
          if(W._seRefreshModels) W._seRefreshModels();
        }
        try { localStorage.setItem('bw_engine_open', '1'); } catch(e) {}
      }, 60);
      return;
    }
    var p = document.getElementById('bw-se-panel');
    var pw = document.getElementById('bw-se-wrap');
    if (!p) return;
    _seOpen = !_seOpen;
    /* BW_R114: hide wrap too so border-bottom doesn't leave a void stub */
    if(_seOpen) {
      if(pw) pw.classList.remove('hidden');
      p.classList.remove('hidden');
    } else {
      p.classList.add('hidden');
      if(pw) pw.classList.add('hidden');
    }
    /* BW_R114: defer measurement until after layout reflow */
    requestAnimationFrame(function() { if(W._bwReflow) W._bwReflow(); });
    if(_seOpen && W._seRefreshModels) W._seRefreshModels();
    var cb = document.getElementById('bw-universal-ctrl-btn');
    if (cb) cb.style.color = _seOpen ? 'var(--bw-gold)' : '';
    try { localStorage.setItem('bw_engine_open', _seOpen ? '1' : '0'); } catch(e) {}
  };

  /* BW_R110: restore engine open state — SKIP on main chat (has its own panel) */
  document.addEventListener('DOMContentLoaded', function() {
    setTimeout(function() {
      var _curFile = W.location.pathname.split('/').pop() || '';
      if (_curFile === 'beewid_chat.html') {
        /* BW_R115: fire _bwReflow on chat too — fixes ghost void on load */
        if (W._bwReflow) W._bwReflow();
        _seAdjust(false);
        return;
      }
      if (typeof _seAdjust === 'function') {
        var wasOpen = false;
        try { wasOpen = localStorage.getItem('bw_engine_open') === '1'; } catch(e) {}
        if (wasOpen) {
          W.BW_toggleSharedEngine();
          /* BW_R112: trading has its own controls-panel-wrap — point its toggle at shared engine */
          if (_curFile === 'beewid_trading.html') {
            setTimeout(function() {
              if (typeof W.bwToggleControls === 'function') {
                W.bwToggleControls = function() { W.BW_toggleSharedEngine(); };
              }
            }, 100);
          }
        } else {
          _seAdjust(false);
          if (_curFile === 'beewid_trading.html') {
            setTimeout(function() {
              if (typeof W.bwToggleControls === 'function') {
                W.bwToggleControls = function() { W.BW_toggleSharedEngine(); };
              }
            }, 100);
          }
        }
      }
      /* BW_R115: ensure correct topbar height on non-chat tabs at load */
      if (W._bwReflow) W._bwReflow();
      /* BW_R117: restore per-tab zoom */
      try {
        var _tabKey = 'bw_zoom_' + (W.location.pathname.split('/').pop()||'tab');
        var _savedZ = localStorage.getItem(_tabKey);
        if (_savedZ && W._bwSE && W._bwSE.zm) W._bwSE.zm(_savedZ);
      } catch(e) {}
      /* BW_R114: restore QPerms open state */
      var permsWasOpen = false;
      try { permsWasOpen = localStorage.getItem('bw_qperms_open') === '1'; } catch(e) {}
      if (permsWasOpen) {
        setTimeout(function() {
          if (W.BW_openQPerms) W.BW_openQPerms();
        }, 500); /* after engine panel has mounted */
      }
    }, 400);
  });

  /* BW_R112: _seMount — in-flow panel injection + ResizeObserver for void fix */
  function _seMount() {
    /* Guard: only run on non-chat tabs */
    var _curFile = W.location.pathname.split('/').pop() || '';
    if (_curFile === 'beewid_chat.html') return;
    /* BW_R126: bail if popout=1 (agents in popout windows suppress their own panels) */
    if (W.location.search.indexOf('popout=1') !== -1) return;
    /* Idempotent */
    if (document.getElementById('bw-se-wrap')) return;

    var api = W.API || 'http://127.0.0.1:8506';

    /* ── Inject shared CSS (scoped) ──────────────────────────────────── */
    var style = document.createElement('style');
    style.id = 'bw-se-style';
    style.textContent = [
      '#bw-se-wrap {',
      '  background:var(--bw-bg2,#1a1a1f);',
      '  border-bottom:2px solid var(--bw-border2,#333);',
      '  width:100%;box-sizing:border-box;',
      '  display:block;',   /* in-flow — not fixed */
      '}',
      /* BW_R114: hide the whole wrap (incl border) when panel is closed */
      '#bw-se-wrap.hidden { display:none; }',
      '#bw-se-panel { padding:8px 14px 10px; display:flex; flex-direction:column; gap:8px; }',
      '#bw-se-panel.hidden { display:none; }',
      '#bw-se-wrap .ctrls-row { display:flex; align-items:center; gap:6px; flex-wrap:wrap; }',
      '#bw-se-wrap .ctrls-row.nowrap { flex-wrap:nowrap; overflow-x:auto; scrollbar-width:none; }',
      '#bw-se-wrap .ctrls-row.nowrap::-webkit-scrollbar { display:none; }',
      '#bw-se-wrap .warmup-btn { font-family:var(--bw-mono,monospace); font-size:10px; padding:3px 9px;',
      '  background:var(--bw-bg3,#222); border:1px solid var(--bw-border2,#333);',
      '  color:var(--bw-text2,#aaa); border-radius:4px; cursor:pointer; white-space:nowrap; }',
      '#bw-se-wrap .warmup-btn:hover { background:var(--bw-bg4,#2a2a2f); color:var(--bw-text,#eee); }',
      '#bw-se-wrap .model-select { background:var(--bw-bg3,#222); border:1px solid var(--bw-border,#333);',
      '  color:var(--bw-text,#eee); font-family:var(--bw-mono,monospace); font-size:11px;',
      '  padding:4px 8px; border-radius:4px; cursor:pointer; min-width:120px; }',
      '#bw-se-wrap .stream-toggle { display:flex; align-items:center; gap:2px;',
      '  background:var(--bw-bg3,#222); border:1px solid var(--bw-border,#333);',
      '  border-radius:4px; padding:2px; flex-shrink:0; }',
      '#bw-se-wrap .stream-btn { font-family:var(--bw-mono,monospace); font-size:10px;',
      '  padding:4px 9px; border-radius:4px; border:none;',
      '  background:transparent; color:var(--bw-text2,#aaa); cursor:pointer; white-space:nowrap; }',
      '#bw-se-wrap .stream-btn.active { background:var(--bw-bg4,#2a2a2f); color:var(--bw-gold,#f5c842); }',
      '#bw-se-wrap .warm-dot { width:7px; height:7px; border-radius:50%;',
      '  background:var(--bw-text3,#666); flex-shrink:0; transition:background .4s; }',
      '#bw-se-wrap .warm-dot.warm { background:var(--bw-green,#4ade80); box-shadow:0 0 5px var(--bw-green,#4ade80); }',
      '#bw-se-wrap .warm-dot.cold { background:var(--bw-text3,#666); }',
      '#bw-se-wrap .bw-pin-btn { font-family:var(--bw-mono,monospace); font-size:9px; padding:2px 6px;',
      '  background:transparent; border:1px solid var(--bw-border2,#333);',
      '  color:var(--bw-text3,#666); border-radius:3px; cursor:pointer; flex-shrink:0; }',
      '#bw-se-wrap .bw-pin-btn.pinned { color:var(--bw-gold,#f5c842); border-color:var(--bw-gold,#f5c842); }',
      '#bw-se-wrap input[type=range] { -webkit-appearance:none; height:4px; border-radius:2px;',
      '  background:var(--bw-border2,#333); cursor:pointer; width:70px; }',
      '#bw-se-wrap input[type=number] { background:var(--bw-bg3,#222); border:1px solid var(--bw-border2,#333);',
      '  color:var(--bw-text2,#aaa); font-family:var(--bw-mono,monospace); font-size:9px;',
      '  border-radius:3px; padding:1px 3px; text-align:center; }',
      '#bw-se-tools-row { padding-top:5px; border-top:1px solid var(--bw-border,#333); }',
    ].join('\n');
    document.head.appendChild(style);

    /* ── Build panel HTML ────────────────────────────────────────────── */
    /* Reuses _bwSE.* namespace from R109 — event handlers untouched     */
    var wrap = document.createElement('div');
    wrap.id = 'bw-se-wrap';

    var panel = document.createElement('div');
    panel.id = 'bw-se-panel';
    panel.className = 'hidden';   /* starts closed — toggled by BW_toggleSharedEngine */

    panel.innerHTML = [
      /* ── engine-collapsible: starts hidden, shown by BW_toggleSharedEngine ─ */
      '<div id="bw-se-engine-collapsible" class="hidden">',

      /* ── ctrl-row-a: W5 model / KV / warm / free RAM ──────────────────── */
      '<div class="ctrls-row nowrap" id="bw-se-ctrl-row-a" style="gap:6px;justify-content:flex-start">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:10px;font-weight:700;color:var(--bw-gold,#f5c842)">W5</span>',
      '<select class="model-select" id="bw-se-w5-select" title="W5 model (fast lane)" onchange="_bwSE.sm(\'w5\',this.value)">',
      '<option value="__none__">— loading —</option></select>',
      '<select title="W5 KV cache quantization" id="bw-se-kv-w5" onchange="_bwSE.sk(\'w5\',this.value)"',
      ' style="font-family:var(--bw-mono,monospace);font-size:9px;height:22px;background:var(--bw-bg3,#1a1a2e);',
      'border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;padding:0 3px;cursor:pointer;max-width:70px">',
      '<option value="">KV std</option><option value="f16">KV f16</option>',
      '<option value="q8_0">KV q8</option><option value="q5_K_M">KV q5_K</option>',
      '<option value="q4_K_M">KV q4_K &#9733;</option><option value="q4_0">KV q4</option></select>',
      '<div class="warm-indicator" id="bw-se-w5-warm-wrap"',
      ' onclick="_bwSE.warm(\'w5\')" oncontextmenu="_bwSE.lk(\'w5\',event)"',
      ' style="display:flex;align-items:center;gap:3px;cursor:pointer;flex-shrink:0"',
      ' title="Click: warm W5 · Right-click: lock/unlock">',
      '<div class="warm-dot cold" id="bw-se-w5-dot"></div>',
      '<span id="bw-se-w5-label" style="font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666)">cold</span>',
      '<span id="bw-se-w5-lock" style="display:none;font-size:8px;color:var(--bw-red,#f87171)">&#128274;</span>',
      '</div>',
      '<button class="warmup-btn" style="padding:1px 7px;font-size:9px" title="Free W5 RAM (unload model)" onclick="_bwSE.unld(\'w5\')">&#9660; free RAM</button>',
      '</div>',

      /* ── ctrl-row-b: W5 pin/timeout · Brain Bias · W6 timeout/pin · Warm Both ─ */
      '<div class="ctrls-row nowrap" id="bw-se-ctrl-row-b" style="gap:6px;justify-content:center;align-items:center">',
      '<button class="bw-pin-btn" id="bw-se-pin-btn-w5" onclick="_bwSE.pin(\'w5\',this)"',
      ' title="Pin W5 — force all requests to W5, disable auto-routing">&#128204;W5</button>',
      '<input type="number" id="bw-se-timeout-w5" min="120" max="7200" step="60" value="720"',
      ' title="W5 stream timeout (s) — raise for slow CPU models"',
      ' style="width:46px;font-family:var(--bw-mono,monospace);font-size:9px;background:var(--bw-bg3,#1a1a2e);',
      'border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;padding:1px 3px;text-align:center"',
      ' onchange="_bwSE.to(\'w5\',this.value)">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:8px;color:var(--bw-text3,#666)">s</span>',
      '<div id="bw-se-brain-bias-wrap" style="display:flex;align-items:center;gap:4px;flex:1;max-width:320px;padding:0 10px">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:8px;color:var(--bw-gold,#f5c842)">W5</span>',
      '<input type="range" id="bw-se-bias" min="0" max="100" value="50"',
      ' style="-webkit-appearance:none;flex:1;height:3px;border-radius:2px;',
      'background:linear-gradient(to right,var(--bw-gold,#f5c842),#818cf8);cursor:pointer;"',
      ' oninput="_bwSE.bi(this.value)" onchange="_bwSE.bi(this.value)"',
      ' title="Brain Bias: 0=W5 always, 100=W6 always, 50=auto">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:8px;color:#818cf8">W6</span>',
      '<input type="number" id="bw-se-bias-n" min="0" max="100" value="50"',
      ' style="width:32px;font-family:var(--bw-mono,monospace);font-size:8px;background:var(--bw-bg3,#1a1a2e);',
      'border:1px solid var(--bw-border2,#444);color:var(--bw-text2,#aaa);border-radius:3px;padding:1px 2px;text-align:center;"',
      ' oninput="_bwSE.bn(this.value)" onchange="_bwSE.bi(this.value)"',
      ' onkeydown="if(event.key===\'Enter\'){_bwSE.bi(this.value);this.blur();}">',
      '</div>',
      '<input type="number" id="bw-se-timeout-w6" min="120" max="7200" step="60" value="900"',
      ' title="W6 stream timeout (s) — raise for large CPU models"',
      ' style="width:46px;font-family:var(--bw-mono,monospace);font-size:9px;background:var(--bw-bg3,#1a1a2e);',
      'border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;padding:1px 3px;text-align:center"',
      ' onchange="_bwSE.to(\'w6\',this.value)">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:8px;color:var(--bw-text3,#666)">s</span>',
      '<button class="bw-pin-btn" id="bw-se-pin-btn-w6" onclick="_bwSE.pin(\'w6\',this)"',
      ' title="Pin W6 — force all requests to W6, disable auto-routing">W6&#128204;</button>',
      '<button id="bw-se-auto-btn" data-auto="0"',
      ' onclick="_bwSE.auto();_bwSE.warm(\'all\')"',
      ' title="Auto-route by prompt complexity AND warm both W5+W6 now"',
      ' style="font-size:9px;padding:2px 8px;background:transparent;border:1px solid var(--bw-border2,#444);',
      'color:var(--bw-text3,#666);border-radius:3px;cursor:pointer;white-space:nowrap;flex-shrink:0">',
      '&#129302; Warm Both Models</button>',
      '</div>',

      /* ── ctrl-row-c: W6 model / KV / warm / free RAM ──────────────────── */
      '<div class="ctrls-row nowrap" id="bw-se-ctrl-row-c" style="gap:6px;justify-content:flex-end">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:10px;font-weight:700;color:#818cf8">W6</span>',
      '<select class="model-select" id="bw-se-w6-select" title="W6 model (deep lane)" onchange="_bwSE.sm(\'w6\',this.value)">',
      '<option value="__none__">— loading —</option></select>',
      '<select title="W6 KV cache quantization" id="bw-se-kv-w6" onchange="_bwSE.sk(\'w6\',this.value)"',
      ' style="font-family:var(--bw-mono,monospace);font-size:9px;height:22px;background:var(--bw-bg3,#1a1a2e);',
      'border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;padding:0 3px;cursor:pointer;max-width:70px">',
      '<option value="">KV std</option><option value="f16">KV f16</option>',
      '<option value="q8_0">KV q8</option><option value="q5_K_M">KV q5_K</option>',
      '<option value="q4_K_M">KV q4_K &#9733;</option><option value="q4_0">KV q4</option></select>',
      '<div class="warm-indicator" id="bw-se-w6-warm-wrap"',
      ' onclick="_bwSE.warm(\'w6\')" oncontextmenu="_bwSE.lk(\'w6\',event)"',
      ' style="display:flex;align-items:center;gap:3px;cursor:pointer;flex-shrink:0"',
      ' title="Click: warm W6 · Right-click: lock/unlock">',
      '<div class="warm-dot cold" id="bw-se-w6-dot"></div>',
      '<span id="bw-se-w6-label" style="font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666)">cold</span>',
      '<span id="bw-se-w6-lock" style="display:none;font-size:8px;color:var(--bw-red,#f87171)">&#128274;</span>',
      '</div>',
      '<button class="warmup-btn" style="padding:1px 7px;font-size:9px" title="Free W6 RAM (unload model)" onclick="_bwSE.unld(\'w6\')">&#9660; free RAM</button>',
      '</div>',

      /* ── ctrl-row-d: Delivery · Engine · Zoom ──────────────────────────── */
      '<div class="ctrls-row nowrap" id="bw-se-ctrl-row-d" style="gap:10px;padding-top:6px;border-top:1px solid var(--bw-border,#333);justify-content:center;align-items:center">',
      '<span style="font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666)" title="How tokens stream to browser">&#128225; Delivery:</span>',
      '<div class="stream-toggle" id="bw-se-stream-toggle" title="How tokens stream to browser">',
      '<button class="stream-btn active" id="bw-se-s-live" data-mode="token" onclick="_bwSE.str(\'token\',this)" title="Stream each token as generated">&#9889; Live</button>',
      '<button class="stream-btn" id="bw-se-s-chunk" data-mode="chunked" onclick="_bwSE.str(\'chunked\',this)" title="Stream in small chunks">&#128230; Chunked</button>',
      '<button class="stream-btn" id="bw-se-s-full" data-mode="full" onclick="_bwSE.str(\'full\',this)" title="Wait for full response before rendering">&#9632; Buffered</button>',
      '</div>',
      '<span style="color:var(--bw-border2,#444)">|</span>',
      '<span style="font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666)" title="Ollama resource allocation">&#9881; Engine:</span>',
      '<div class="stream-toggle" id="bw-se-perf-toggle" title="Ollama resource allocation">',
      '<button class="stream-btn" id="bw-se-p-fast" data-perf="fast" onclick="_bwSE.pf(\'fast\',this)" title="Minimal context, max speed">Fast</button>',
      '<button class="stream-btn active" id="bw-se-p-bal" data-perf="balanced" onclick="_bwSE.pf(\'balanced\',this)" title="Default balance of speed and quality">Balanced</button>',
      '<button class="stream-btn" id="bw-se-p-qual" data-perf="quality" onclick="_bwSE.pf(\'quality\',this)" title="Larger context, deeper reasoning">Quality</button>',
      '</div>',
      '<span style="color:var(--bw-border2,#444)">|</span>',
      '<span style="font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666)">Zoom</span>',
      '<input type="range" id="bw-se-zoom" min="70" max="130" value="100" step="5"',
      ' oninput="_bwSE.zm(this.value)" title="Chat font zoom">',
      '<input type="number" id="bw-se-zoom-n" min="70" max="130" value="100"',
      ' style="width:38px;font-family:var(--bw-mono,monospace);font-size:9px;background:var(--bw-bg3,#1a1a2e);border:1px solid var(--bw-border2,#444);color:var(--bw-text2,#aaa);border-radius:3px;padding:1px 3px;text-align:center;"',
      ' oninput="_bwSE.zm(this.value)"',
      ' onkeydown="if(event.key===\'Enter\'){_bwSE.zm(this.value);this.blur();}">',
      '</div>',

      /* ── ctrl-row-e: History / Debug / Health / Clear / Export + Service Worker ─ */
      '<div class="ctrls-row" id="bw-se-ctrl-row-e" style="flex-wrap:wrap;gap:6px;padding-top:6px;border-top:1px solid var(--bw-border,#333)">',
      '<button class="warmup-btn" id="bw-se-hist-btn" onclick="_bwSE.hist()" title="Chat History">&#128451; History</button>',
      '<button class="warmup-btn" id="bw-se-debug-btn" onclick="_bwSE.dbg()" title="Debug bundle" style="color:var(--bw-amber,#f59e0b)">&#128027; Debug</button>',
      '<button class="warmup-btn" id="bw-se-health-btn" onclick="_bwSE.hlth()" title="Deep Ollama health — tests real token generation" style="color:var(--bw-text3,#666)">&#10084; Health</button>',
      '<button class="warmup-btn" id="bw-se-clear-btn" onclick="_bwSE.clr()" title="Clear chat" style="color:var(--bw-red,#f87171)">&#10005; Clear</button>',
      '<div style="position:relative;flex-shrink:0" data-export-trigger>',
      '<button class="warmup-btn" onclick="_bwSE.exp(event)" title="Export chat">&#8595; Export</button>',
      '</div>',
      '<div class="divider" style="margin:0 6px"></div>',
      '<label style="display:flex;align-items:center;gap:6px;font-family:var(--bw-mono,monospace);font-size:10px;color:var(--bw-text2,#aaa)">',
      '<input type="checkbox" id="bw-se-sw-toggle" onchange="_bwSE.sw(this.checked)">',
      'Service Worker (keeps stream alive when switching tabs)',
      '</label>',
      '<div id="bw-se-sw-status" style="font-family:var(--bw-mono,monospace);font-size:10px;color:var(--bw-text3,#666);margin-left:8px"></div>',
      '</div>',

      '</div>', /* /#bw-se-engine-collapsible */

      /* ── ai-tools-row: visible by default, toggleable by Tools button ─── */
      '<div class="ctrls-row" id="bw-se-ai-tools-row" style="flex-wrap:wrap;gap:6px;padding-top:5px;border-top:1px solid var(--bw-border,#333)">',
      '<button class="warmup-btn" id="bw-se-scrutinize-btn" onclick="_bwSE.scr()" title="Auto-scrutinize messages after each response">&#128270; Scrutinize</button>',
      '<button class="warmup-btn" id="bw-se-scope-btn" onclick="_bwSE.scp()" title="Scrutinize last N">&#128270; Scope</button>',
      '<div class="divider" style="margin:0 4px"></div>',
      '<button class="warmup-btn" onclick="_bwSE.drpt()" title="Generate AI debug report from active problems">&#128027; Debug Report</button>',
      '<button class="warmup-btn" id="bw-se-unload-btn" onclick="_bwSE.uld()" title="Unload all except W5+W6">&#128465; Unload unused</button>',
      '<div class="divider" style="margin:0 4px"></div>',
      '<button class="warmup-btn" id="bw-se-ap-btn" onclick="_bwSE.ap()" title="Agentic+ L4: auto-retry on empty/failed response with reduced context">&#9889;+ Agentic+</button>',
      '<button class="warmup-btn" onclick="window.location=\'/static/beewid_knowledge.html\'" title="Knowledge Tab v0.85 — Vault ingestion and search">&#128218; Knowledge</button>',
      '<div class="divider" style="margin:0 4px"></div>',
      '<button class="warmup-btn" id="bw-se-mcp-status-btn" onclick="_bwSE.mst()" title="Check MCP server status (port 8765)" style="color:var(--bw-text3,#666)">&#128299; MCP</button>',
      '<button class="warmup-btn" id="bw-se-mcp-start-btn" onclick="_bwSE.ms()" title="Start MCP server">&#9654; Start</button>',
      '<button class="warmup-btn" id="bw-se-mcp-stop-btn" onclick="_bwSE.mx()" title="Stop MCP server" style="color:var(--bw-red,#f87171)">&#9646; Stop</button>',
      '<button class="warmup-btn" onclick="_bwSE.mr()" title="Restart MCP server">&#8635; Restart</button>',
      '</div>',
    ].join(''); /* BW_R134 */

    /* ── Header bar (BEEWID logo + Engine/Tools/Perms + utilities) ─────── */
    var BS = 'font-family:var(--bw-mono,monospace);font-size:10px;padding:2px 8px;'
           + 'background:var(--bw-bg3,#1a1a2e);border:1px solid var(--bw-border,#333);'
           + 'color:var(--bw-text2,#aaa);border-radius:3px;cursor:pointer;white-space:nowrap';
    var hdrEl = document.createElement('div');
    hdrEl.innerHTML = '<div id="bw-se-header" style="display:flex;align-items:center;gap:4px;padding:6px 10px;'
      + 'background:var(--bw-bg3,#1a1a2e);border-bottom:1px solid var(--bw-border,#333);">'
      +   '<div style="display:flex;align-items:center;gap:6px;flex-shrink:0">'
      +     '<div style="width:28px;height:28px;background:var(--bw-gold,#f5c842);border-radius:6px;'
      +       'display:flex;align-items:center;justify-content:center;font-size:14px">B</div>'
      +     '<div>'
      +       '<div style="font-family:var(--bw-mono,monospace);font-size:11px;font-weight:700;'
      +         'color:var(--bw-gold,#f5c842);letter-spacing:.12em">BEEWID</div>'
      +       '<div style="font-family:var(--bw-mono,monospace);font-size:8px;color:var(--bw-text3,#666)">v0.81 \xb7 ALPHA</div>'
      +     '</div>'
      +   '</div>'
      +   '<button onclick="BW_toggleSharedEngine()" title="Show/hide engine controls"'
      +     ' style="' + BS + '">&#8964; &#9881; Engine</button>'
      +   '<button id="bw-se-tools-btn" onclick="_bwSE.toggleTools()" title="Show/hide AI tools row"'
      +     ' style="' + BS + '">&#8964; &#129513; Tools</button>'
      +   '<button onclick="window.BW_openQPerms&&BW_openQPerms()" title="Quick permissions"'
      +     ' style="' + BS + '">&#128273; Perms</button>'
      +   '<div style="flex:1"></div>'
      +   '<button onclick="_bwSE.rfr()" title="Hard refresh" style="' + BS + '">&#8635; refresh</button>'
      +   '<button onclick="_bwSE.hl()" title="Hotload skills" style="' + BS + '">&#8987; hotload</button>'
      +   '<button onclick="_bwSE.log()" title="Session log" style="' + BS + '">log</button>'
      +   '<button onclick="_bwSE.hoff(event)" title="Handoff" style="' + BS + '">&#128206; handoff &#9660;</button>'
      +   '<button onclick="_bwSE.prob()" title="Log problems"'
      +     ' style="font-family:var(--bw-mono,monospace);font-size:10px;padding:2px 8px;'
      +       'background:rgba(249,115,22,0.07);border:1px solid rgba(249,115,22,0.5);'
      +       'color:#f97316;border-radius:3px;cursor:pointer;white-space:nowrap" id="bw-se-problems-btn">'
      +     '&#9888; problems</button>'
      + '</div>';
    wrap.appendChild(hdrEl.firstChild);
    wrap.appendChild(panel);

    /* ── Inject into DOM: immediately after #bw-nav ──────────────────── */
    var nav = document.getElementById('bw-nav');
    if (nav && nav.parentNode) {
      nav.parentNode.insertBefore(wrap, nav.nextSibling);
    } else {
      document.body.insertBefore(wrap, document.body.firstChild);
    }

    /* ── ResizeObserver: wire to hoisted _bwReflow (BW_R115) ─────────── */
    if (W.ResizeObserver) {
      var _ro = new ResizeObserver(function() { _bwReflow(); });
      ['bw-topbar','bw-topbar-res','bw-topbar-bw','bw-topbar2','bw-topbar3'].forEach(function(id) {
        var el = document.getElementById(id); if (el) _ro.observe(el);
      });
      _ro.observe(wrap);
    } else {
      window.addEventListener('resize', _bwReflow);
    }
    /* Measure now that wrap is in DOM */
    requestAnimationFrame(_bwReflow);

    /* ── _bwSE namespace: extend/replace handlers (R109 preserved) ───── */
    /* Only override zm() for per-tab zoom; all other methods kept as-is  */
    if (!W._bwSE) W._bwSE = {};

    /* BW_R117: per-tab zoom — CSS zoom scales everything (layout + text + borders)
       Targets .bw-page which is the full-height content container on non-chat tabs */
    W._bwSE.zm = function(val) {
      var v = Math.max(70, Math.min(130, parseInt(val, 10) || 100));
      var container = document.querySelector('.bw-page')
                   || document.querySelector('.kn-root')
                   || document.querySelector('.bw-page-body')
                   || document.querySelector('#main')
                   || document.body;
      container.style.zoom = v + '%';
      var zsl = document.getElementById('bw-se-zoom');  if (zsl) zsl.value = v;
      var zn  = document.getElementById('bw-se-zoom-n'); if (zn)  zn.value  = v;
      try { localStorage.setItem('bw_zoom_' + (W.location.pathname.split('/').pop()||'tab'), v); } catch(e) {}
    };
    W._seZoom = W._bwSE.zm; /* keep shim name too */

    /* ── R122: Button Manifest System ─────────────────────────────────── */
    /* Canonical button definitions for shared engine panel and Full Coms */
    W._bwBtnManifest = [
      // ROW E: History/Debug/Health/Clear/Export
      { id: 'hist', label: 'History', icon: '📚', onclick: '_bwSE.hist()', section: 'row_e', style: '' },
      { id: 'dbg', label: 'Debug', icon: '🐛', onclick: '_bwSE.dbg()', section: 'row_e', style: 'color:var(--bw-amber,#f59e0b)' },
      { id: 'hlth', label: 'Health', icon: '❤', onclick: '_bwSE.hlth()', section: 'row_e', style: 'color:var(--bw-text3,#666)' },
      { id: 'clr', label: 'Clear', icon: '🗑', onclick: '_bwSE.clr()', section: 'row_e', style: 'color:var(--bw-red,#f87171)' },
      { id: 'exp', label: 'Export', icon: '⬇', onclick: '_bwSE.exp(event)', section: 'row_e', style: 'color:var(--bw-green,#4ade80)' },

      // ROW F: Scope/Debug Report/Restart
      { id: 'scp', label: 'Scope', icon: '🔍', onclick: '_bwSE.scp()', section: 'row_f', style: 'color:var(--bw-blue,#60a5fa)' },
      { id: 'drpt', label: 'Debug Report', icon: '📋', onclick: '_bwSE.drpt()', section: 'row_f', style: 'color:var(--bw-amber,#f59e0b)' },
      { id: 'rst', label: 'Restart', icon: '↻', onclick: '_bwSE.rst()', section: 'row_f', style: 'color:var(--bw-red,#f87171)' },

      // UTIL: refresh/hotload/log/handoff/problems
      { id: 'rfr', label: 'refresh', icon: '⟳', onclick: '_bwSE.rfr()', section: 'util', style: 'color:var(--bw-text2,#aaa)' },
      { id: 'hl', label: 'hotload', icon: '↻', onclick: '_bwSE.hl()', section: 'util', style: 'color:var(--bw-amber,#f59e0b)' },
      { id: 'log', label: 'log', icon: '📜', onclick: '_bwSE.log()', section: 'util', style: 'color:var(--bw-text3,#666)' },
      { id: 'hoff', label: 'handoff', icon: '🤝', onclick: '_bwSE.hoff()', section: 'util', style: 'color:var(--bw-gold,#f5c842)' },
      { id: 'prob', label: 'problems', icon: '⚠', onclick: '_bwSE.prob()', section: 'util', style: 'color:var(--bw-red,#f87171)' }
    ];

    /* ── R122: Missing button handlers ──────────────────────────────────── */
    W._bwSE.clr = function() {
      if (confirm('Clear all chat history and logs?')) {
        fetch(api+'/admin/clear',{method:'POST'}).then(function(r){return r.json();}).then(function(d){
          if(W.BW&&W.BW.notify) W.BW.notify.ok('✓ Cleared: ' + (d.cleared || 'unknown'));
        }).catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('Clear failed');});
      }
    };
    W._bwSE.exp = function(evt) {
      /* Remove any existing export dropdown */
      var existing = document.getElementById('bw-se-export-menu');
      if (existing) { existing.remove(); return; }

      var menu = document.createElement('div');
      menu.id = 'bw-se-export-menu';
      menu.style.cssText = 'position:fixed;z-index:9999;background:var(--bw-bg3,#222);'
        +'border:1px solid var(--bw-border2,#333);border-radius:4px;'
        +'font-family:var(--bw-mono,monospace);font-size:10px;min-width:180px;'
        +'box-shadow:0 8px 24px rgba(0,0,0,0.6);';

      var btn = evt && evt.target ? evt.target : document.getElementById('bw-se-exp-btn');
      if (btn) {
        var r = btn.getBoundingClientRect();
        menu.style.top  = (r.bottom + 4) + 'px';
        menu.style.left = r.left + 'px';
      } else {
        menu.style.top = '160px'; menu.style.left = '200px';
      }

      var opts = [
        { label: '📄 Download with reasoning', fn: function(){ W._bwSE._doExport('full'); }},
        { label: '✦ Download clean',           fn: function(){ W._bwSE._doExport('clean'); }},
        { label: '📦 Export to vault',          fn: function(){ W._bwSE._doExport('vault'); }},
        { label: '🔒 Context breakaway',        fn: function(){ W._bwSE._doExport('vault_breakaway'); }},
        { label: '📁 Save to exports folder',   fn: function(){ W._bwSE._doExport('folder'); }},
      ];

      opts.forEach(function(o) {
        var item = document.createElement('div');
        item.textContent = o.label;
        item.style.cssText = 'padding:6px 14px;cursor:pointer;color:var(--bw-text2,#aaa);';
        item.onmouseenter = function(){ this.style.background='var(--bw-bg4,#2a2a2f)'; };
        item.onmouseleave = function(){ this.style.background=''; };
        item.onclick = function(){ menu.remove(); o.fn(); };
        menu.appendChild(item);
      });

      document.body.appendChild(menu);
      setTimeout(function(){
        document.addEventListener('click', function _close(e){
          if (!menu.contains(e.target)){ menu.remove(); document.removeEventListener('click',_close); }
        });
      }, 50);
    }; /* BW_R127 */

    W._bwSE._doExport = function(type) {
      fetch(api+'/export/session', {
        method: 'POST',
        headers: {'Content-Type':'application/json'},
        body: JSON.stringify({export_type: type})
      }).then(function(r){
        if (type === 'full' || type === 'clean' || type === 'folder') {
          return r.blob().then(function(b){
            var a = document.createElement('a');
            a.href = URL.createObjectURL(b);
            a.download = 'beewid_export_' + new Date().toISOString().slice(0,10) + '.md';
            document.body.appendChild(a); a.click(); document.body.removeChild(a);
          });
        }
        return r.json().then(function(d){
          if(W.BW&&W.BW.notify) W.BW.notify.ok('Exported: ' + (d.path||type));
        });
      }).catch(function(){ if(W.BW&&W.BW.notify) W.BW.notify.warn('Export failed'); });
    }; /* BW_R127 */
    W._bwSE.scp = function() {
      if (W.BW_toggleScope) W.BW_toggleScope();
      else if(W.BW&&W.BW.notify) W.BW.notify.warn('Scope panel not available on this tab');
    };
    W._bwSE.drpt = function() {
      fetch(api+'/debug/report',{method:'GET'}).then(function(r){return r.json();}).then(function(d){
        var w = window.open('','debug_report','width=800,height=600,resizable=yes,scrollbars=yes');
        if(w) { w.document.write('<pre>' + JSON.stringify(d, null, 2) + '</pre>'); w.document.close(); }
      }).catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('Debug report failed');});
    };
    W._bwSE.rst = function() {
      if (confirm('Restart Beewid core services?')) {
        if(W.BW&&W.BW.notify) W.BW.notify.ok('🔄 Restarting...');
        fetch(api+'/admin/restart',{method:'POST'}).catch(function(){});
      }
    };
    W._bwSE.rfr = function() {
      if (W._seRefreshModels) W._seRefreshModels();
      if(W.BW&&W.BW.notify) W.BW.notify.ok('⟳ Refreshed');
    };
    W._bwSE.log = function() {
      if (W.BW_toggleLog) W.BW_toggleLog();
      else if(W.BW&&W.BW.notify) W.BW.notify.warn('Log panel not available');
    };
    W._bwSE.hl = function() {
      fetch(api+'/admin/hotload',{method:'POST'}).then(function(r){return r.json();}).then(function(d){
        if(W.BW&&W.BW.notify) W.BW.notify.ok('↻ Hotload: '+(d.reloaded||'done'));
      }).catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('Hotload failed');});
    };
    W._bwSE.hoff = function() {
      var zip = api + '/admin/handoff';
      var a = document.createElement('a'); a.href = zip; a.download = 'beewid_handoff.zip';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
      if(W.BW&&W.BW.notify) W.BW.notify.ok('📦 Handoff package downloaded');
    };
    W._bwSE.prob = function() {
      fetch(api+'/health/problems',{method:'GET'}).then(function(r){return r.json();}).then(function(d){
        var issues = (d.problems || []).length;
        if(W.BW&&W.BW.notify) W.BW.notify.ok(issues + ' problems found - check logs');
      }).catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('Problems check failed');});
    };

    /* BW_R125: Missing _bwSE handlers — wired to same backend endpoints as main chat */

    /* Model select — mirrors bwSaveModelPref() in chat.html */
    W._bwSE.sm = function(tier, val) {
      // BW_R80P54A: cloud:<model> picker → save to cloud_<tier>_model via /config/update
      // (don't save the 'cloud:...' string as a local model name)
      if (val && val.indexOf('cloud:') === 0) {
        var cm = val.slice(6);
        var cBody = {};
        cBody['cloud_' + tier + '_model'] = cm;
        fetch(api+'/config/update', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify(cBody)
        }).catch(function(){});
        if (W._seRefreshModels) setTimeout(W._seRefreshModels, 400);
        return;
      }
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({[tier+'_model']:val})}).catch(function(){});
      /* BW_R135: if user picks local model, clear cloud override so poll doesn't snap back */
      if (val) {
        var clearBody = {};
        clearBody[(tier === 'w5') ? 'cloud_w5_model' : 'cloud_w6_model'] = null;
        fetch(api+'/config/update', {
          method:'POST', headers:{'Content-Type':'application/json'},
          body:JSON.stringify(clearBody)
        }).catch(function(){});
        if (W._seRefreshModels) setTimeout(W._seRefreshModels, 400);
      }
    }; /* BW_R135 / BW_R80P54A */

    /* KV cache — mirrors bwSetKVCacheTier() in chat.html */
    W._bwSE.sk = function(tier, val) {
      fetch(api+'/settings/kv',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({tier:tier, kv_cache_type:val})}).catch(function(){});
    };

    /* Pin toggle — mirrors bwTogglePin() in chat.html */
    W._bwSE.pin = function(tier, btn) {
      var pinned = btn.classList.toggle('pinned');
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({[tier+'_pinned']:pinned})}).catch(function(){});
    };

    /* Brain bias slider input */
    W._bwSE.bi = function(val) {
      var n = document.getElementById('bw-se-bias-n'); if (n) n.value = val;
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({brain_bias:parseInt(val,10)})}).catch(function(){});
    };

    /* Brain bias number input */
    W._bwSE.bn = function(val) {
      var s = document.getElementById('bw-se-bias'); if (s) s.value = val;
      W._bwSE.bi(val);
    };

    /* Timeout input */
    W._bwSE.to = function(tier, val) {
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({[tier+'_timeout']:parseInt(val,10)})}).catch(function(){});
    };

    /* Auto-route toggle */
    W._bwSE.auto = function() {
      var btn = document.getElementById('bw-se-auto-btn');
      var on = btn ? (btn.dataset.auto = btn.dataset.auto==='1' ? '0' : '1') === '1' : false;
      if (btn) { btn.style.color = on ? 'var(--bw-gold,#f5c842)' : ''; btn.style.borderColor = on ? 'var(--bw-gold,#f5c842)' : ''; }
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({auto_route:on})}).catch(function(){});
    };

    /* Warm model(s) — mirrors showWarmup() in chat.html */
    W._bwSE.warm = function(tier) {
      /* BW_R130: visual feedback — flash button text */
      var btn = document.getElementById('bw-se-'+(tier==='all'?'w5':tier)+'-warm-btn');
      var orig = btn ? btn.textContent : '';
      if (btn) { btn.textContent = '⏳ ...'; btn.style.opacity = '0.6'; }
      fetch(api+'/admin/keepalive',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify(tier==='all' ? {} : {tier:tier})})
        .then(function(){ if(W.BW&&W.BW.notify) W.BW.notify.ok('▲ Warming '+(tier==='all'?'W5+W6':tier.toUpperCase())+'...'); })
        .catch(function(){ if(W.BW&&W.BW.notify) W.BW.notify.warn('Warm failed'); });
      setTimeout(function(){
        if (btn) { btn.textContent = orig || '▲ Warm'; btn.style.opacity = ''; }
        if (W._seRefreshModels) W._seRefreshModels();
      }, 2000);
    }; /* BW_R130 */

    /* Unload model */
    W._bwSE.unld = function(tier) {
      fetch(api+'/admin/unload/'+tier,{method:'POST'}).catch(function(){});
      if (W._seRefreshModels) setTimeout(W._seRefreshModels, 800);
    };
    W._bwSE.uld = W._bwSE.unld.bind(null, 'unused'); /* "Unload unused" in row F */

    /* Stream mode — aliases to _seStream */
    W._bwSE.str = function(mode, btn) {
      if (W._seStream) W._seStream(mode, btn);
    };

    /* Performance mode — aliases to _sePerfMode */
    W._bwSE.pf = function(mode, btn) {
      if (W._sePerfMode) W._sePerfMode(mode, btn);
    };

    /* Scrutinize */
    W._bwSE.scr = function() {
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({scrutinize:true})}).catch(function(){});
      if(W.BW&&W.BW.notify) W.BW.notify.ok('🔍 Scrutinize queued');
    };

    /* MCP Start */
    W._bwSE.ms = function() {
      fetch(api+'/mcp/start',{method:'POST'}).then(function(r){return r.json();})
        .then(function(d){if(W.BW&&W.BW.notify) W.BW.notify.ok('▶ MCP started');})
        .catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('MCP start failed');});
    };

    /* MCP Stop */
    W._bwSE.mx = function() {
      fetch(api+'/mcp/stop',{method:'POST'}).then(function(r){return r.json();})
        .then(function(){if(W.BW&&W.BW.notify) W.BW.notify.ok('⏹ MCP stopped');})
        .catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('MCP stop failed');});
    };

    /* MCP Restart */
    W._bwSE.mr = function() {
      fetch(api+'/mcp/restart',{method:'POST'}).then(function(r){return r.json();})
        .then(function(){if(W.BW&&W.BW.notify) W.BW.notify.ok('↺ MCP restarted');})
        .catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('MCP restart failed');});
    };

    /* Close panel */
    W._bwSE.cl = function() { if (W.BW_toggleSharedEngine) W.BW_toggleSharedEngine(); };

    W._bwSE.toggleTools = function() {
      var row = document.getElementById('bw-se-ai-tools-row');
      if (row) { row.style.display = row.style.display === 'none' ? '' : 'none'; }
      var btn = document.getElementById('bw-se-tools-btn');
      if (btn) btn.style.color = (row && row.style.display !== 'none') ? 'var(--bw-gold,#f5c842)' : '';
    }; /* BW_R134 */

    /* History */
    W._bwSE.hist = function() { if (W.BW_toggleSharedHistory) W.BW_toggleSharedHistory(); };

    /* Debug bundle download */
    W._bwSE.dbg = function() {
      var a = document.createElement('a');
      a.href = api + '/admin/debug_bundle';
      a.download = 'beewid_debug_' + new Date().toISOString().slice(0,16).replace(/[T:]/g,'_') + '.zip';
      document.body.appendChild(a); a.click(); document.body.removeChild(a);
    };

    /* Health check */
    W._bwSE.hlth = function() {
      fetch(api+'/health').then(function(r){return r.json();}).then(function(d){
        var msg = 'W5: '+(d.w5_warm?'warm':'cold')+' | W6: '+(d.w6_warm?'warm':'cold')+' | Models: '+(d.models||[]).length;
        if(W.BW&&W.BW.notify) W.BW.notify.ok('❤ '+msg);
      }).catch(function(){if(W.BW&&W.BW.notify) W.BW.notify.warn('Health check failed');});
    };

    /* Agentic+ toggle */
    W._bwSE.ap = function() {
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({agentic_plus:true})}).catch(function(){});
      if(W.BW&&W.BW.notify) W.BW.notify.ok('⚡+ Agentic+ queued');
    };

    /* Service Worker registration */
    W._bwSE.sw = function(checked) {
      var stat = document.getElementById('bw-se-sw-status');
      if (!('serviceWorker' in navigator)) {
        if (stat) stat.textContent = '(not supported)';
        return;
      }
      if (checked) {
        navigator.serviceWorker.register('/static/sw.js')
          .then(function() { if (stat) stat.textContent = '✓ registered'; })
          .catch(function() { if (stat) stat.textContent = '✗ failed'; });
      } else {
        navigator.serviceWorker.getRegistrations().then(function(regs) {
          regs.forEach(function(r) { r.unregister(); });
          if (stat) stat.textContent = 'unregistered';
        });
      }
    }; /* BW_R127 */

    /* MCP status check */
    W._bwSE.mst = function() {
      fetch(api+'/mcp/status').then(function(r){return r.json();})
        .then(function(d){
          var msg = d.running ? '🟢 MCP running (port '+d.port+')' : '🔴 MCP stopped';
          if(W.BW&&W.BW.notify) W.BW.notify.ok(msg); else alert(msg);
        })
        .catch(function(){ if(W.BW&&W.BW.notify) W.BW.notify.warn('MCP status check failed'); });
    }; /* BW_R127 */

    /* Lock/unlock model (right-click on warm indicator) */
    W._bwSE.lk = function(tier, evt) {
      evt.preventDefault();
      var badge = document.getElementById('bw-se-'+tier+'-lock');
      var locked = badge ? badge.style.display === 'none' : false;
      if (badge) badge.style.display = locked ? 'inline' : 'none';
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({[tier+'_locked']:locked})}).catch(function(){});
    };

    /* ── R122: Button renderer helper ────────────────────────────────────── */
    W._bwRenderButtons = function(section) {
      return W._bwBtnManifest.filter(function(btn){ return btn.section === section; })
        .map(function(btn){
          var style = btn.style ? (' style="' + btn.style + '"') : '';
          return '<button class="warmup-btn" onclick="' + btn.onclick + '" title="' + btn.label + '"' + style + '>' + btn.icon + ' ' + btn.label + '</button>';
        }).join('');
    };

    /* ── JS shims (same as R109/R110, kept for compatibility) ─────────── */
    W._seStream = function(mode, btn) {
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({stream_mode:mode})}).catch(function(){});
      ['live','chunk','full'].forEach(function(id){
        var b=document.getElementById('bw-se-s-'+id);
        if(b) b.classList.toggle('active',
          (id==='live'&&mode==='token')||(id==='chunk'&&mode==='chunked')||(id==='full'&&mode==='full'));
      });
      if(W.BW&&W.BW.notify) W.BW.notify.ok('Stream: '+mode);
    };
    W._sePerfMode = function(mode, btn) {
      fetch(api+'/settings/save',{method:'POST',headers:{'Content-Type':'application/json'},
        body:JSON.stringify({engine_quality:mode})}).catch(function(){});
      ['fast','bal','qual'].forEach(function(id){
        var b=document.getElementById('bw-se-p-'+id);
        if(b) b.classList.toggle('active',
          (id==='fast'&&mode==='fast')||(id==='bal'&&mode==='balanced')||(id==='qual'&&mode==='quality'));
      });
    };

    /* ── FIX 3: Model populate — improved key fallback chain ──────────── */
    /* BW_R116: single /health call — returns models[], w5_model, w6_model,
       w5_warm, w6_warm. /settings GET and /models/list do not exist. */
    /* BW_R121: _seRefreshModels — /health + /config for cloud models + KV */
    W._seRefreshModels = function() {
      var _hd = {}, _cd = {};
      function _render() {
        if (!_hd.done || !_cd.done) return;
        var d = _hd.data || {};
        var cfg = (_cd.data && _cd.data.config) || {};
        var w5m = d.w5_model || '', w6m = d.w6_model || '';
        var cw5 = cfg.cloud_w5_model || '', cw6 = cfg.cloud_w6_model || '';
        var kv  = cfg.kv_cache_type  || '';
        var models = (d.models || []).map(function(m){ return m.name || m; });
        [['bw-se-w5-select', w5m, cw5], ['bw-se-w6-select', w6m, cw6]].forEach(function(t){
          var sel = document.getElementById(t[0]); if (!sel) return;
          var html = models.map(function(m){
            return '<option value="'+m+'"'+(m===t[1]&&!t[2]?' selected':'')+'>-local- '+m+'</option>';
          }).join('');
          // BW_R80P54A: always offer cloud model options (haiku/sonnet/opus).
          // Selecting one routes through _bwSE.sm which saves to cloud_<tier>_model.
          var cloudOpts = ['claude-haiku-4-5', 'claude-sonnet-4-6', 'claude-opus-4-6'];
          if (t[2] && cloudOpts.indexOf(t[2]) === -1) cloudOpts.unshift(t[2]); // include currently-selected cloud if non-standard
          html += cloudOpts.map(function(cm) {
            return '<option value="cloud:'+cm+'"'+(t[2]===cm?' selected':'')+'>\u2601 '+cm+'</option>';
          }).join('');
          if (!models.length && !t[2] && t[1]) html = '<option value="'+t[1]+'" selected>-local- '+t[1]+'</option>' + html;
          sel.innerHTML = html;
        });
        if (kv) { ['bw-se-kv-w5','bw-se-kv-w6'].forEach(function(id){
          var el = document.getElementById(id); if (el) el.value = kv;
        }); }
        ['w5','w6'].forEach(function(t){
          var dot   = document.getElementById('bw-se-'+t+'-dot');
          var lbl   = document.getElementById('bw-se-'+t+'-label');
          var kvEl  = document.getElementById('bw-se-kv-'+t);
          var ramBtn= document.getElementById('bw-se-'+t+'-free-ram');
          var warmBn= document.getElementById('bw-se-'+t+'-warm-btn');
          var warm  = d[t+'_warm'], isCloud = !!(t==='w5' ? cw5 : cw6);

          /* Dot + label */
          if (dot) {
            if (isCloud) { dot.className='warm-dot'; dot.textContent='\u2601'; dot.style.fontSize='10px'; }
            else { dot.className='warm-dot '+(warm?'warm':'cold'); dot.textContent=''; dot.style.fontSize=''; }
          }
          if (lbl) lbl.textContent = isCloud ? '\u2601 cloud' : (warm ? 'warm' : 'cold');

          /* KV dropdown \u2014 hide for cloud, show for local */
          if (kvEl) {
            kvEl.style.display = isCloud ? 'none' : '';
            /* Show a cloud label next to the hidden KV when cloud active */
            var kvCloud = document.getElementById('bw-se-kv-cloud-'+t);
            if (!kvCloud) {
              kvCloud = document.createElement('span');
              kvCloud.id = 'bw-se-kv-cloud-'+t;
              kvCloud.style.cssText = 'font-family:var(--bw-mono,monospace);font-size:9px;color:var(--bw-text3,#666);display:none';
              kvCloud.textContent = '\u2601 no local cache';
              kvEl.parentNode && kvEl.parentNode.insertBefore(kvCloud, kvEl.nextSibling);
            }
            kvCloud.style.display = isCloud ? 'inline' : 'none';
          }

          /* free RAM button \u2014 hide for cloud, show for local */
          if (ramBtn) ramBtn.style.display = isCloud ? 'none' : '';

          /* Warm button \u2192 rename to Prime when cloud active */
          if (warmBn) warmBn.textContent = isCloud ? '\u2601 Prime' : '\u25b2 Warm';

          /* BW_R130 */
        });

        /* BW_R132: rename the standalone Warm-all row F button */
        var warmAllBtn = document.getElementById('bw-se-warm-all-btn');
        if (warmAllBtn) {
          var anyCw5 = !!(cfg.cloud_w5_model||''), anyCw6 = !!(cfg.cloud_w6_model||'');
          warmAllBtn.textContent = (anyCw5 || anyCw6) ? '\u2601 Prime' : '\u25b2 Warm';
          warmAllBtn.title = (anyCw5 || anyCw6)
            ? 'Prime: send system prompt to active cloud model(s)'
            : 'Warm both models';
        }
      }
      fetch(api+'/health').then(function(r){return r.json();}).then(function(d){_hd={done:1,data:d};_render();}).catch(function(){_hd={done:1};_render();});
      fetch(api+'/config').then(function(r){return r.json();}).then(function(d){_cd={done:1,data:d};_render();}).catch(function(){_cd={done:1};_render();});
    };

    /* Initial data load after a short delay */
    setTimeout(function() {
      W._seRefreshModels();
    }, 300);
  }

  /* BW_R112: _seAdjust kept as no-op shim — ResizeObserver handles layout now */
  function _seGetBase() {
    var h = 0;
    ['bw-topbar','bw-topbar-res','bw-topbar-bw','bw-topbar2','bw-topbar3'].forEach(function(id){
      var el = document.getElementById(id);
      if(el && getComputedStyle(el).display !== 'none') h += (el.offsetHeight || 32);
    });
    return h || 64;
  }

  /* BW_R112: dynamic base height — sums VISIBLE bar heights, no stored value */
  function _seGetBase() {
    var ids = ['bw-topbar','bw-topbar-res','bw-topbar-bw','bw-topbar2','bw-topbar3'];
    var h = 0;
    ids.forEach(function(id) {
      var el = document.getElementById(id);
      if (el && getComputedStyle(el).display !== 'none') h += (el.offsetHeight || 32);
    });
    return h || 64;
  }

  function _seAdjust(open) { /* BW_R112: no-op shim — ResizeObserver drives layout */
    if (W._bwReflow) W._bwReflow();
  }

})(window); /* end BW_R107 */


/* BW_R132: Full Coms — explicit popup flag, no blank-tab race */
window.BW_openFullComs = function() {
  /* BW_R140b: Full Coms = live chat.html with Engine+Perms auto-opened, chat hidden */
  var w = window.open(
    '/static/beewid_fullcoms.html',
    'bw_fullcoms', /* BW_R141: standalone fullcoms.html wrapper */
    'width=900,height=700,resizable=yes,scrollbars=yes,popup=yes'
  );
  if (w) { setTimeout(function(){ if(w && !w.closed) w.focus(); }, 200); }
}; /* BW_R141 */

/* --- REMOVED BW_R113 document.write block (472 lines) --- */
/* placeholder to prevent parse errors */ void 0;


/* ═══════════════════════════════════════════════════════════════════════════
 * BW_R80P61 — UI PRIMITIVES (BeewidPopout, BeewidBadge, Capture Diag stub)
 * ═══════════════════════════════════════════════════════════════════════════ */

/* BW_R80P61 — BeewidPopout: standard popout button primitive for every tab/sub-tab.
   Usage:
     BeewidPopout.attach('autocode');                    // tab-level popout
     BeewidPopout.attach('autocode', { subTab: 'logs' });// sub-tab popout
     BeewidPopout.button('autocode')                     // returns element to place manually
   Per Rule 32: named window.open targets prevent duplicate popouts. */
window.BeewidPopout = (function () {
  var _openWindows = new Map();

  function _buildUrl(tabName, opts) {
    var u = new URL(window.location.origin + '/beewid_' + tabName + '.html');
    u.searchParams.set('popout', '1');
    if (opts && opts.subTab) u.searchParams.set('sub', opts.subTab);
    if (opts && opts.instance_id) u.searchParams.set('instance_id', opts.instance_id);
    return u.toString();
  }

  function open(tabName, opts) {
    var target = 'beewid-popout-' + tabName
               + (opts && opts.subTab ? '-' + opts.subTab : '')
               + (opts && opts.instance_id ? '-' + opts.instance_id : '');
    var features = 'width=1100,height=820,resizable=yes,scrollbars=yes,toolbar=no,menubar=no';
    var w = window.open(_buildUrl(tabName, opts), target, features);
    if (w) { _openWindows.set(target, w); w.focus(); }
    return w;
  }

  function button(tabName, opts) {
    var btn = document.createElement('button');
    btn.className = 'bw-popout-btn';
    btn.title = 'Open ' + tabName + (opts && opts.subTab ? ' / ' + opts.subTab : '')
              + ' in standalone window';
    btn.setAttribute('aria-label', btn.title);
    btn.innerHTML = '<span style="font-size:14px;line-height:1">⧉</span>';
    btn.onclick = function () { open(tabName, opts); };
    return btn;
  }

  function attach(tabName, opts) {
    // BW_R80P64 — mount into BeewidTabBar instead of the unreliable .bw-tab-header query.
    // The previous strategy worked for tabs with .bw-tab-header but fell through to document.body
    // on tabs like trading.html that use .bw-trading-header. The tab bar gives us a single
    // reliable host for tab-level utility buttons.
    if (!window.BeewidTabBar) return null;
    var id = 'popout' + (opts && opts.subTab ? '-' + opts.subTab : '');
    return BeewidTabBar.addButton({
      id: id,
      icon: '⧉',
      label: '',
      title: 'Open ' + tabName + (opts && opts.subTab ? ' / ' + opts.subTab : '') + ' in standalone window',
      onclick: function () { open(tabName, opts); }
    });
  }

  return { open: open, button: button, attach: attach };
})();

/* BW_R80P61 — BeewidBadge: standard "In Dev" / "Coming Soon" / "Beta" pill.
   Usage:
     BeewidBadge.attach(elementOrSelector, 'in-dev')
     BeewidBadge.attach('#nav-trading',    'coming-soon', { text: 'Coming as Secretary' }) */
window.BeewidBadge = (function () {
  var _styles = {
    'in-dev':       { bg: 'rgba(243,156,18,0.18)',  fg: '#f5b041', label: 'In Dev'       },
    'coming-soon':  { bg: 'rgba(155,89,182,0.18)',  fg: '#bb8fce', label: 'Coming Soon'  },
    'beta':         { bg: 'rgba(52,152,219,0.18)',  fg: '#5dade2', label: 'Beta'         },
    'experimental': { bg: 'rgba(231,76,60,0.18)',   fg: '#ec7063', label: 'Experimental' }
  };

  function span(variant, opts) {
    var s = _styles[variant] || _styles['in-dev'];
    var el = document.createElement('span');
    el.className = 'bw-badge bw-badge-' + variant;
    el.textContent = (opts && opts.text) || s.label;
    el.title = (opts && opts.title)
            || (s.label + ' — feature in active development; beta testers see vault/coming_soon.md for notes');
    el.style.cssText =
        'display:inline-block;font-size:9px;font-weight:600;padding:2px 6px;border-radius:8px;'
      + 'margin-left:6px;letter-spacing:0.5px;text-transform:uppercase;'
      + 'background:' + s.bg + ';color:' + s.fg + ';vertical-align:middle;';
    return el;
  }

  function attach(target, variant, opts) {
    var host = (typeof target === 'string') ? document.querySelector(target) : target;
    if (!host) return null;
    if (host.querySelector('.bw-badge-' + variant)) return null;
    var badge = span(variant, opts);
    host.appendChild(badge);
    return badge;
  }

  return { span: span, attach: attach };
})();

/* BW_R80P62 — BeewidUtilityStrip: floating bottom-right strip for utility buttons.
   Standard surface for one-click utilities that shouldn't crowd the topbar.
   Scales: future buttons (Bug Report, Quick Note, Clear Cache, etc.) attach here. */
window.BeewidUtilityStrip = (function () {
  var STRIP_ID = 'bw-utility-strip';

  function _injectCSS() {
    if (document.getElementById('bw-utility-strip-css')) return;
    var style = document.createElement('style');
    style.id = 'bw-utility-strip-css';
    style.textContent = ''
      + '#bw-utility-strip {'
      + '  position: fixed; right: 12px; bottom: 12px; z-index: 9000;'
      + '  display: flex; flex-direction: column; gap: 6px;'
      + '  opacity: 0.55; transition: opacity 200ms;'
      + '  pointer-events: auto;'
      + '}'
      + '#bw-utility-strip:hover { opacity: 1; }'
      + '#bw-utility-strip .bw-util-btn {'
      + '  display: flex; align-items: center; gap: 6px;'
      + '  background: var(--bw-bg, #1a1a1a);'
      + '  color: var(--bw-fg, #d4d4d8);'
      + '  border: 1px solid var(--bw-border, rgba(255,255,255,0.18));'
      + '  border-radius: 6px; padding: 6px 10px;'
      + '  font-size: 11px; font-family: var(--bw-mono, monospace);'
      + '  cursor: pointer; box-shadow: 0 2px 8px rgba(0,0,0,0.3);'
      + '  transition: background 120ms, transform 80ms;'
      + '  white-space: nowrap;'
      + '}'
      + '#bw-utility-strip .bw-util-btn:hover {'
      + '  background: var(--bw-gold-dim, rgba(212,165,84,0.22));'
      + '  transform: translateY(-1px);'
      + '}'
      + '#bw-utility-strip .bw-util-btn:active { transform: translateY(0); }'
      + '#bw-utility-strip .bw-util-icon { font-size: 13px; line-height: 1; }'
      + '@media (max-width: 600px) {'
      + '  #bw-utility-strip { right: 6px; bottom: 6px; }'
      + '  #bw-utility-strip .bw-util-btn .bw-util-label { display: none; }'
      + '}';
    (document.head || document.documentElement).appendChild(style);
  }

  function ensure() {
    _injectCSS();
    var strip = document.getElementById(STRIP_ID);
    if (strip) return strip;
    strip = document.createElement('div');
    strip.id = STRIP_ID;
    strip.setAttribute('data-bw-version', 'r80p62');
    if (document.body) {
      document.body.appendChild(strip);
    } else {
      document.addEventListener('DOMContentLoaded', function () {
        document.body.appendChild(strip);
      });
    }
    return strip;
  }

  function addButton(opts) {
    var strip = ensure();
    if (!opts || !opts.id) return null;
    if (strip.querySelector('#bw-util-' + opts.id)) return strip.querySelector('#bw-util-' + opts.id);
    var btn = document.createElement('button');
    btn.id = 'bw-util-' + opts.id;
    btn.className = 'bw-util-btn';
    btn.title = opts.title || opts.label || opts.id;
    btn.innerHTML =
        '<span class="bw-util-icon">' + (opts.icon || '·') + '</span>'
      + '<span class="bw-util-label">' + (opts.label || '') + '</span>';
    btn.onclick = opts.onclick || function () {};
    if (document.body) {
      strip.appendChild(btn);
    } else {
      document.addEventListener('DOMContentLoaded', function () { strip.appendChild(btn); });
    }
    return btn;
  }

  function remove(id) {
    var strip = document.getElementById(STRIP_ID);
    if (!strip) return;
    var btn = strip.querySelector('#bw-util-' + id);
    if (btn) btn.remove();
  }

  return { ensure: ensure, addButton: addButton, remove: remove };
})();

/* BW_R80P64 — BeewidTabBar: top-right tab-utility zone.
   Fixed-position bar that hosts tab-level utility buttons (popout, capture diag, etc.).
   Sits just below the topbar at the right edge. Hidden in popout windows. */
window.BeewidTabBar = (function () {
  var BAR_ID = 'bw-tab-bar';

  function _injectCSS() {
    if (document.getElementById('bw-tab-bar-css')) return;
    var style = document.createElement('style');
    style.id = 'bw-tab-bar-css';
    style.textContent = ''
      /* BW_R80P72 — inline mount: TabBar now sits inside #bw-topbar-bw (brand bar's
         right-cluster) instead of floating fixed-position above it. No more
         layered overlap on any tab. Fixed-position rules removed. */
      + '#bw-tab-bar {'
      + '  display: inline-flex;'
      + '  align-items: center;'
      + '  gap: 6px;'
      + '  margin-left: 6px;'
      + '  vertical-align: middle;'
      + '  flex-shrink: 0;'
      + '}'
      + '#bw-tab-bar .bw-tab-util-btn {'
      + '  display: inline-flex;'
      + '  align-items: center;'
      + '  gap: 6px;'
      + '  background: var(--bw-bg, #1a1a1a);'
      + '  color: var(--bw-fg, #d4d4d8);'
      + '  border: 1px solid var(--bw-border, rgba(255,255,255,0.18));'
      + '  border-radius: 5px;'
      + '  padding: 4px 9px;'
      + '  font-size: 11px;'
      + '  font-family: var(--bw-mono, monospace);'
      + '  cursor: pointer;'
      + '  white-space: nowrap;'
      + '  opacity: 0.85;'
      + '  transition: background 120ms, transform 80ms;'
      + '}'
      + '#bw-tab-bar .bw-tab-util-btn:hover {'
      + '  opacity: 1;'
      + '  background: var(--bw-gold-dim, rgba(212,165,84,0.22));'
      + '  transform: translateY(-1px);'
      + '}'
      + '#bw-tab-bar .bw-tab-util-btn:active { transform: translateY(0); }'
      + '#bw-tab-bar .bw-tab-util-icon { font-size: 13px; line-height: 1; }'
      + 'body.bw-popout-mode #bw-tab-bar { display: none; }'
      + '@media (max-width: 600px) {'
      + '  #bw-tab-bar .bw-tab-util-btn .bw-tab-util-label { display: none; }'
      + '}';
    (document.head || document.documentElement).appendChild(style);
  }

  // BW_R80P72 — obsolete: TabBar is now inline-mounted in #bw-topbar-bw brand bar.
  // Functions kept as no-ops in case anything externally calls them.
  function _measureTopbar() { /* BW_R80P72 — no-op (inline mount) */ }
  var _topbarObserver = null;
  function _watchTopbar()   { /* BW_R80P72 — no-op (inline mount) */ }
  function _scheduleTopbarMeasurements() { /* BW_R80P72 — no-op (inline mount) */ }

  function ensure() {
    _injectCSS();
    var bar = document.getElementById(BAR_ID);
    if (bar) return bar;
    bar = document.createElement('span'); /* BW_R80P72 — span for inline mount */
    bar.id = BAR_ID;
    bar.setAttribute('data-bw-version', 'r80p72');

    function _mount() {
      // BW_R80P79_GUI_HARDEN — Priority-ordered mount targets per §1.15 tier-1.
      // Always visible; no longer hidden in PT2A mode (was display:none in bar4).
      // Tries preferred targets first; falls back to body only after all fail.
      var MOUNT_TARGETS = [
        '#bw-topbar-bw',    // Legacy brand bar (preferred inline mount)
        '#bw-topbar3-new',  // PT2A bar 3 (panel toggles)
        '#bw-topbar2-new',  // PT2A bar 2 (stats)
        '#bw-topbar',       // PT2A bar 1 / legacy bar 1
        'header',           // Generic header element
        'body',             // Last-resort fallback
      ];
      var mount = null;
      var usedFallback = false;
      for (var i = 0; i < MOUNT_TARGETS.length; i++) {
        mount = document.querySelector(MOUNT_TARGETS[i]);
        if (mount) {
          if (MOUNT_TARGETS[i] === 'body') usedFallback = true;
          break;
        }
      }
      if (!mount) {
        console.error('[BW_R80P79_GUI_HARDEN] No mount target found for BeewidTabBar');
        return;
      }
      if (usedFallback) {
        bar.style.cssText += ';position:fixed;top:0;right:0;z-index:9999;';
        document.body.prepend(bar);
      } else {
        mount.appendChild(bar);
      }
      console.log('[BW_R80P79_GUI_HARDEN] BeewidTabBar mounted to',
                  (mount.id ? '#' + mount.id : mount.tagName),
                  usedFallback ? '(FALLBACK)' : '');
    }

    if (document.body) {
      _mount();
    } else {
      document.addEventListener('DOMContentLoaded', _mount);
    }
    return bar;
  }

  function addButton(opts) {
    var bar = ensure();
    if (!opts || !opts.id) return null;
    var existing = bar.querySelector('#bw-tabutil-' + opts.id);
    if (existing) return existing;
    var btn = document.createElement('button');
    btn.id = 'bw-tabutil-' + opts.id;
    btn.className = 'bw-tab-util-btn';
    btn.title = opts.title || opts.label || opts.id;
    var hasLabel = !!opts.label;
    btn.innerHTML =
        '<span class="bw-tab-util-icon">' + (opts.icon || '·') + '</span>'
      + (hasLabel ? '<span class="bw-tab-util-label">' + opts.label + '</span>' : '');
    btn.onclick = opts.onclick || function () {};
    // Position: 'first' prepends (leftmost); default appends (rightmost)
    if (opts.position === 'first') {
      bar.insertBefore(btn, bar.firstChild);
    } else {
      bar.appendChild(btn);
    }
    return btn;
  }

  function remove(id) {
    var bar = document.getElementById(BAR_ID);
    if (!bar) return;
    var btn = bar.querySelector('#bw-tabutil-' + id);
    if (btn) btn.remove();
  }

  return { ensure: ensure, addButton: addButton, remove: remove };
})();

/* BW_R80P62 — BeewidDiagnostics: real capture pipeline.
   Reads from __bwDiagBuffers and current DOM, posts a markdown report to
   POST /diagnostics/save, which writes it to vault/diagnostics/{tab}_{ts}.md
   and returns the saved filename. */
window.BeewidDiagnostics = (function () {

  function _currentTab() {
    var path = window.location.pathname;
    var m = path.match(/beewid_([a-z_]+)\.html/);
    if (m) return m[1];
    return 'unknown';
  }

  function _truncate(s, n) {
    if (!s) return '';
    return (s.length > n) ? s.slice(0, n) + '\n…(truncated, original ' + s.length + ' bytes)' : s;
  }

  function _gatherBrowserMeta() {
    return {
      userAgent:     navigator.userAgent,
      platform:      navigator.platform,
      language:      navigator.language,
      cookieEnabled: navigator.cookieEnabled,
      onLine:        navigator.onLine,
      viewport:      window.innerWidth + 'x' + window.innerHeight,
      screen:        (screen && (screen.width + 'x' + screen.height)) || '?',
      url:           window.location.href,
      referrer:      document.referrer || '(none)',
      capturedAt:    new Date().toISOString()
    };
  }

  function _gatherInputs() {
    var out = [];
    var fields = document.querySelectorAll('input, textarea, select');
    fields.forEach(function (el) {
      try {
        if (el.offsetParent === null) return;       // skip hidden
        if (el.type === 'hidden') return;
        var rec = {
          tag: el.tagName.toLowerCase(),
          type: el.type || '',
          id: el.id || '',
          name: el.name || '',
          placeholder: el.placeholder || '',
          value: ''
        };
        if (el.type === 'password' || /pass|secret|key|token/i.test(el.id + el.name)) {
          rec.value  = el.value ? '*'.repeat(Math.min(el.value.length, 8)) : '';
          rec.masked = true;
        } else {
          rec.value = _truncate(String(el.value || ''), 200);
        }
        out.push(rec);
      } catch (e) { /* skip on error */ }
    });
    return out;
  }

  function _gatherVersionMarkers() {
    try {
      var html = document.body ? document.body.innerHTML : '';
      var snippet = html.slice(0, 200 * 1024);
      var markers = snippet.match(/BW_R8\dP\d+[A-Z]?/g) || [];
      var counts = {};
      markers.forEach(function (m) { counts[m] = (counts[m] || 0) + 1; });
      return counts;
    } catch (e) {
      return {};
    }
  }

  function _gatherDomSnapshot() {
    try {
      var root = document.querySelector('main, .bw-tab-content, #main, #content') || document.body;
      var clone = root.cloneNode(true);
      clone.querySelectorAll('script, style').forEach(function (n) { n.remove(); });
      clone.querySelectorAll('img').forEach(function (n) { n.setAttribute('src', '(stripped)'); });
      var html = clone.outerHTML || '';
      return _truncate(html, 50 * 1024);
    } catch (e) {
      return '(error gathering DOM: ' + e.message + ')';
    }
  }

  function _buildMarkdown(tabName) {
    var meta = _gatherBrowserMeta();
    var buf  = window.__bwDiagBuffers || { console: [], network: [], errors: [], startedAt: '?' };
    var md = [];

    md.push('# Beewid Diagnostic Capture');
    md.push('');
    md.push('**Tab**: `' + tabName + '`');
    md.push('**Captured**: ' + meta.capturedAt);
    md.push('**Instrumentation started**: ' + buf.startedAt);
    md.push('**URL**: ' + meta.url);
    md.push('**User-Agent**: ' + meta.userAgent);
    md.push('');

    md.push('## Browser / Environment');
    md.push('```json');
    md.push(JSON.stringify(meta, null, 2));
    md.push('```');
    md.push('');

    md.push('## Version markers found in DOM');
    md.push('```json');
    md.push(JSON.stringify(_gatherVersionMarkers(), null, 2));
    md.push('```');
    md.push('');

    md.push('## Console buffer (' + buf.console.length + ' entries)');
    if (buf.console.length === 0) {
      md.push('_(empty — no console output since instrumentation install)_');
    } else {
      md.push('```');
      buf.console.forEach(function (e) {
        md.push('[' + e.t + '] [' + e.level.toUpperCase() + '] ' + _truncate(e.msg, 1000));
      });
      md.push('```');
    }
    md.push('');

    md.push('## Failed / non-OK network requests (' + buf.network.length + ' entries)');
    if (buf.network.length === 0) {
      md.push('_(none)_');
    } else {
      md.push('| Time | Method | URL | Status | Duration |');
      md.push('|---|---|---|---|---|');
      buf.network.forEach(function (e) {
        md.push('| ' + e.t + ' | ' + e.method + ' | `' + _truncate(e.url, 80) + '` | '
              + e.status + ' ' + (e.statusText || '') + ' | ' + e.durationMs + 'ms |');
      });
    }
    md.push('');

    md.push('## JS errors / unhandled rejections (' + buf.errors.length + ' entries)');
    if (buf.errors.length === 0) {
      md.push('_(none)_');
    } else {
      buf.errors.forEach(function (e, i) {
        md.push('### Error ' + (i + 1) + ' — ' + e.kind);
        md.push('- **Time**: ' + e.t);
        md.push('- **Message**: ' + e.msg);
        if (e.src)   md.push('- **Source**: ' + e.src + ':' + e.line + ':' + e.col);
        if (e.stack) {
          md.push('- **Stack**:');
          md.push('```');
          md.push(_truncate(e.stack, 2000));
          md.push('```');
        }
        md.push('');
      });
    }

    md.push('## Form / input state (visible only, secrets masked)');
    var inputs = _gatherInputs();
    if (inputs.length === 0) {
      md.push('_(no visible inputs)_');
    } else {
      md.push('```json');
      md.push(JSON.stringify(inputs, null, 2));
      md.push('```');
    }
    md.push('');

    md.push('## DOM snapshot (capped at 50KB, scripts/styles/img-src stripped)');
    md.push('```html');
    md.push(_gatherDomSnapshot());
    md.push('```');
    md.push('');

    md.push('---');
    md.push('');
    md.push('_Generated by Beewid Diagnostics r80p62. Paste this entire file to W5 or your Beewid Opus session for analysis._');

    return md.join('\n');
  }

  async function capture() {
    var tab = _currentTab();
    var markdown = _buildMarkdown(tab);
    var payload = { tab: tab, markdown: markdown };

    try {
      var resp = await fetch('/diagnostics/save', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      var data = await resp.json();
      if (data && data.ok) {
        return { ok: true, path: data.path, sizeBytes: markdown.length, tab: tab };
      }
      return { ok: false, error: (data && data.error) || 'unknown error', markdown: markdown };
    } catch (err) {
      return { ok: false, error: 'network: ' + err.message, markdown: markdown };
    }
  }

  return { capture: capture };
})();

/* BW_R80P62 — Capture Diagnostics: real implementation wired to BeewidDiagnostics. */
window.bwCaptureDiagnostics = async function () {
  var btn = document.getElementById('bw-util-capture-diag');
  if (btn) {
    btn.disabled = true;
    var lbl = btn.querySelector('.bw-util-label');
    if (lbl) lbl.textContent = 'Capturing...';
  }
  var result;
  try {
    result = await BeewidDiagnostics.capture();
  } catch (e) {
    result = { ok: false, error: 'capture exception: ' + e.message };
  }
  if (btn) {
    btn.disabled = false;
    var lbl2 = btn.querySelector('.bw-util-label');
    if (lbl2) lbl2.textContent = 'Capture Diag';
  }

  if (result.ok) {
    var msg = '✓ Diagnostic saved\n\n' + result.path + '\n\n(' + result.sizeBytes + ' bytes)';
    if (window.bwToast) window.bwToast(msg, { kind: 'success', timeout: 5000 });
    else alert(msg);
  } else {
    console.error('[BW_R80P62] Diagnostic save failed:', result.error);
    if (result.markdown) {
      try {
        await navigator.clipboard.writeText(result.markdown);
        var msg2 = '✗ Save to vault failed (' + result.error + ').\n\nMarkdown copied to clipboard — paste into chat.';
        if (window.bwToast) window.bwToast(msg2, { kind: 'warn', timeout: 8000 });
        else alert(msg2);
      } catch (clipErr) {
        var w = window.open('', 'beewid-diag-fallback', 'width=900,height=700');
        if (w) {
          w.document.write('<pre style="font-family:monospace;white-space:pre-wrap;padding:12px">'
                         + result.markdown.replace(/</g, '&lt;') + '</pre>');
        } else {
          alert('Diagnostic save failed and clipboard blocked. Open devtools console to read the captured markdown.');
          console.log(result.markdown);
        }
      }
    }
  }
};

// BW_R80P79_TABPLACE_FIX — BW_R80P64's BeewidTabBar 'capture-diag' button REMOVED.
// HARD RULE: tab-specific actions belong in tab contents, not in any topbar/tab-bar.
// Capture Diag now lives inside beewid_autocode_instance.html's .bw-autocode-actions
// row (operator actions are rendered per-tab at the top of the Autocode tab).
// The handler window.bwCaptureDiagnostics is still defined below; only the
// tab-bar button that invoked it from a global location is gone.

// ════════════════════════════════════════════════════════════════════════════
// BW_R80P79_GUI_HARDEN — Tier-1 BeewidTabBar action handlers
// ════════════════════════════════════════════════════════════════════════════

// BW_R80P79_DELAYER — _bwR80p79_restoreDefaultLayout REMOVED. Was the handler
// behind the broken "Restore Layout" BeewidTabBar button (removed below). The
// only thing it cleared (bw_topbar_layout) is now cleared one-time at injectTopbar
// load (line ~209). A proper future Nav/Topbar Resurrection button (Hermes-skill-
// triggered) will replace this in the topbar reorganization phase.

window._bwR80p79_openDebugLog = function() {
  if (typeof window.bwCaptureDiagnostics === 'function') {
    window.bwCaptureDiagnostics();
  } else if (typeof window.captureDiagnostics === 'function') {
    window.captureDiagnostics();
  } else {
    alert('Debug log: tail -f /tmp/beewid_api.log\n\nUse: bash ~/Downloads/beewid/scripts/check_triple_redundancy.sh');
  }
};

function _bwR80p79_buildDiagnosticModal() {
  var modal = document.createElement('div');
  modal.style.cssText = 'position:fixed;top:50%;left:50%;transform:translate(-50%,-50%);background:var(--bw-bg2,#1a1a1a);border:1px solid var(--bw-border,#2a2a2a);padding:20px;max-width:80vw;max-height:80vh;overflow:auto;z-index:99999;border-radius:6px;font-family:monospace;font-size:11px;color:var(--bw-text,#e8e8e8);';
  modal.innerHTML = '<div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:10px">'
    + '<strong>🔧 Autocode Diagnostic</strong>'
    + '<button onclick="this.parentNode.parentNode.remove()" style="background:transparent;color:var(--bw-text,#e8e8e8);border:1px solid var(--bw-border,#2a2a2a);padding:2px 8px;cursor:pointer">✕ Close</button>'
    + '</div>'
    + '<pre class="bw-diag-results" style="background:var(--bw-bg3,#0a0a0a);padding:10px;border-radius:4px;white-space:pre-wrap;min-height:60px">Running diagnostic...</pre>';
  return modal;
}

window._bwR80p79_diagnoseAutocode = async function() {
  var modal = _bwR80p79_buildDiagnosticModal();
  document.body.appendChild(modal);
  var results = [];

  try {
    var r1 = await fetch('/triple-redundancy/status').then(function(r){return r.json();});
    results.push('✓ Triple-redundancy:\n' + JSON.stringify(r1.redundancy, null, 2));
  } catch (e) {
    results.push('✗ Triple-redundancy fetch failed: ' + e.message);
  }

  try {
    var r2 = await fetch('/autocode/runs/active').then(function(r){return r.json();});
    results.push('✓ Active runs: ' + r2.count + '\n' + JSON.stringify((r2.runs || []).map(function(x){
      return {run_id:x.run_id, pid_alive:x.pid_alive, terminal_state:x.terminal_state,
              seconds_since_last_event:x.seconds_since_last_event, is_active:x.is_active};
    }), null, 2));
  } catch (e) {
    results.push('✗ Active runs fetch failed: ' + e.message);
  }

  var autocodeFrame = document.querySelector('iframe[src*="beewid_autocode"]');
  if (autocodeFrame && autocodeFrame.contentWindow) {
    try {
      var w = autocodeFrame.contentWindow;
      results.push('✓ Autocode iframe SM: ' + (w._bwR80p79PhaseC_SM ? w._bwR80p79PhaseC_SM.state : 'undefined'));
      results.push('✓ Tab token: ' + (w._bwR80p79PhaseB_tabToken || 'undefined'));
      results.push('✓ Resource chip: ' + (w.document.getElementById('bw-phased-resource-chip') ? 'present' : 'missing'));
      results.push('✓ Scroll-pin: ' + (w.document.getElementById('bw-phased-scroll-pin') ? 'present' : 'missing'));
    } catch (e) {
      results.push('⚠ Iframe inspection failed (cross-origin?): ' + e.message);
    }
  } else {
    results.push('⚠ No autocode iframe in this view');
  }

  try {
    var r3 = await fetch('/skills/autocode_diagnose').then(function(r){return r.json();});
    results.push('✓ Subprocess inventory:\n' + JSON.stringify(r3, null, 2));
  } catch (e) {
    results.push('✗ Diagnostic skill fetch failed: ' + e.message);
  }

  modal.querySelector('.bw-diag-results').textContent = results.join('\n\n');
};

// BW_R80P79_TABPLACE_FIX — BW_R80P79_GUI_HARDEN's tier-1 BeewidTabBar buttons REMOVED.
// HARD RULE: tab-specific actions belong in tab contents, not in any topbar/tab-bar.
//
// Removed (all tab-specific — they captured / diagnosed the CURRENT tab):
//   - 'r80p79-restore-layout' — already removed by r80p79-DELAYER
//   - 'r80p79-debug-log'      — Log button calling window._bwR80p79_openDebugLog,
//                               which calls bwCaptureDiagnostics (per-tab capture)
//   - 'r80p79-diagnose-autocode' — Diagnose Autocode button
//
// All three handlers (_bwR80p79_openDebugLog, _bwR80p79_diagnoseAutocode,
// bwCaptureDiagnostics) remain defined. The Autocode tab now invokes them
// via .bw-autocode-actions inside beewid_autocode_instance.html.
// Diagnose Autocode has also been ported INTO instance.html so it runs in the
// iframe's own context (where the Phase C SM / Phase D chip / tab token actually
// live) — permanently fixing the GUI HARDEN diagnose function's iframe-traversal
// dance. The core.js definition remains for any non-Autocode-tab callers.

// BW_R80P79_GUI_HARDEN — Periodic BeewidTabBar safety re-mount (re-mounts if DOM wipe removes it).
setInterval(function() {
  if (window.BeewidTabBar) window.BeewidTabBar.ensure();
}, 5000);

// BW_R80P79_DELAYER — storage listener for bw_topbar_layout REMOVED.
// Was re-mounting BeewidTabBar on layout flip; layout flipping no longer happens.

// ════════════════════════════════════════════════════════════════════════════
// BW_R80P79_GUI_HARDEN — Brain bias button universal placement.
// Per Rule discovered 2026-05-20: brain bias required in every tab, not just chat.
// ════════════════════════════════════════════════════════════════════════════

window.cycleBrainBias = window.cycleBrainBias || function() {
  var el = document.querySelector('#bw-brain-bias-floating, .bw-brain-bias-btn');
  var labels = ['🧠 Auto', '🧠 W5+', '🧠 W6+'];
  var curIdx = el ? parseInt(el.getAttribute('data-bias-mode') || '0', 10) : 0;
  var nextIdx = (curIdx + 1) % labels.length;
  var biasVal = [50, 10, 90][nextIdx];
  if (el) { el.textContent = labels[nextIdx]; el.setAttribute('data-bias-mode', String(nextIdx)); }
  var api = window.API || 'http://127.0.0.1:8506';
  fetch(api + '/settings/save', {method:'POST', headers:{'Content-Type':'application/json'},
    body: JSON.stringify({brain_bias: biasVal})}).catch(function(){});
};

function _bwR80p79_injectBrainBiasUniversal() {
  if (document.querySelector('.bw-brain-bias-btn')) return;
  var enginePanel = document.querySelector('#bw-engine-panel, .engine-panel, [data-bw-engine="true"]');
  if (!enginePanel) {
    if (document.querySelector('#bw-brain-bias-floating')) return;
    var btn = document.createElement('button');
    btn.id = 'bw-brain-bias-floating';
    btn.className = 'bw-brain-bias-btn';
    btn.setAttribute('data-bias-mode', '0');
    btn.title = 'Brain Bias: cycle Auto / W5-prefer / W6-prefer';
    btn.style.cssText = 'position:fixed;bottom:20px;right:90px;z-index:1000;font-size:11px;padding:6px 12px;background:var(--bw-bg3,#1a1a2e);border:1px solid var(--bw-border2,#444);color:var(--bw-text2,#aaa);border-radius:4px;cursor:pointer;font-family:var(--bw-mono,monospace);';
    btn.textContent = '🧠 Auto';
    btn.onclick = window.cycleBrainBias;
    document.body.appendChild(btn);
    return;
  }
  var btn2 = document.createElement('button');
  btn2.className = 'bw-brain-bias-btn';
  btn2.setAttribute('data-bias-mode', '0');
  btn2.title = 'Brain Bias';
  btn2.textContent = '🧠 Auto';
  btn2.onclick = window.cycleBrainBias;
  btn2.style.cssText = 'font-size:9px;padding:2px 8px;background:transparent;border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;cursor:pointer;font-family:var(--bw-mono,monospace);';
  enginePanel.appendChild(btn2);
}

function _bwR80p79_injectMiniCodeButton() {
  if (document.querySelector('.bw-minicode-btn')) return;
  var enginePanel = document.querySelector('#bw-engine-panel, .engine-panel, [data-bw-engine="true"]');
  if (!enginePanel) return;
  var btn = document.createElement('button');
  btn.className = 'bw-minicode-btn';
  btn.title = 'Mini-code — engage autocode subtasks (COMING SOON)';
  btn.textContent = '⚡ Mini-code';
  btn.style.cssText = 'font-size:9px;padding:2px 8px;background:transparent;border:1px solid var(--bw-border2,#444);color:var(--bw-text3,#666);border-radius:3px;cursor:pointer;opacity:0.5;font-family:var(--bw-mono,monospace);';
  btn.disabled = true;
  btn.onclick = function() { alert('Mini-code coming soon. Roadmap: W5/W6 mediated autocode dispatch.'); };
  enginePanel.appendChild(btn);
}

if (document.readyState !== 'loading') {
  _bwR80p79_injectBrainBiasUniversal();
  _bwR80p79_injectMiniCodeButton();
} else {
  document.addEventListener('DOMContentLoaded', function() {
    _bwR80p79_injectBrainBiasUniversal();
    _bwR80p79_injectMiniCodeButton();
  });
}
setInterval(_bwR80p79_injectBrainBiasUniversal, 2000);
setInterval(_bwR80p79_injectMiniCodeButton, 2000);

/* BW_R80P61 — primitives CSS (injected once) */
(function _bwInjectPrimitivesCSS() {
  if (document.getElementById('bw-primitives-css-r80p61')) return;
  var s = document.createElement('style');
  s.id = 'bw-primitives-css-r80p61';
  s.textContent =
      '.bw-popout-btn{position:relative;float:right;'
    + 'background:var(--bw-bg-dim,rgba(255,255,255,0.04));'
    + 'border:1px solid var(--bw-border,rgba(255,255,255,0.12));'
    + 'color:var(--bw-fg,#d4d4d8);width:28px;height:28px;border-radius:4px;cursor:pointer;'
    + 'display:inline-flex;align-items:center;justify-content:center;margin-left:6px;'
    + 'transition:background 120ms,transform 80ms;}'
    + '.bw-popout-btn:hover{background:var(--bw-gold-dim,rgba(212,165,84,0.18));transform:translateY(-1px);}'
    + '.bw-popout-btn:active{transform:translateY(0);}'
    + 'body.bw-popout-mode{padding:0;margin:0;}'
    + 'body.bw-popout-mode .bw-tab-content{padding:12px;}'
    /* BW_R80P79_GUI_HARDEN — NAV section divider between main/settings regions */
    + '.bw-nav-divider{height:1px;margin:12px 14px;background:linear-gradient(to right,transparent,var(--bw-border,#2a2a2a),transparent);}'
    /* BW_R80P79_GUI_HARDEN — PT2A bar 2 visibility hardening */
    + '#bw-topbar2-new{display:flex!important;min-height:24px!important;background:var(--bw-bg3,#1a1a1a)!important;}';
  (document.head || document.documentElement).appendChild(s);
})();
/* end BW_R80P61 primitives */
