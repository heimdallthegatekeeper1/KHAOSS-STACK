"""
Beewid Autocode Engine — backend dispatcher and TUI/Backend abstraction layer.
================================================================================

Single source of truth for autocode execution. Imported by:
  - beewid_api.py        (main API, port 8506)
  - beewid_watchdog.py   (Phase 2.A.4, port 8507)
  - beewid_autocode_spawn.py (deferred follow-on dispatch, port 8508)

PHASE 2.A.1 (r80p58) — engine extraction with NO behavior change.
The api.py endpoints /autocode/run and /autocode/fix-patch now delegate here.
Pluggable backends (proxy routing, openrouter, ollama) and pluggable TUIs
(aider, opencode, custom-shell) arrive in subsequent dispatches (2A.2, 2A.3).

Public API (forward-compatible — populated incrementally across 2A.x):
  detect_tuis()           -> list[dict]
  detect_backends()       -> list[dict]
  get_compat_matrix()     -> dict
  resolve_api_key(...)    -> str
  build_subprocess_env(...) -> dict
  async run_autocode(...)   -> dict   # parity wrapper for /autocode/run
  async run_fix_patch(...)  -> dict   # parity wrapper for /autocode/fix-patch

BW_R80P58 — Phase 2.A.1 engine extraction
"""
from __future__ import annotations

import asyncio
import json
import os
import shutil
import signal
import time
import uuid
from pathlib import Path
from typing import Any, Callable, Optional

# ── PATHS ─────────────────────────────────────────────────────────────────
COCKPIT_DIR = Path(__file__).parent
CONFIG_DIR  = COCKPIT_DIR.parent / 'config'
CREDS_FILE  = CONFIG_DIR / 'credentials.json'
TMP_DIR     = Path('/tmp')
PROXY_TOKEN_FILE = Path.home() / '.beewid' / 'proxy.token'
PROXY_BASE_URL   = 'http://localhost:8506/anthropic_proxy'  # BW_R80P59
# BW_R80P74K — Engine version label bumped from r80p74b. Pure cosmetic; the
# meta event's `engine` field is informational only and not used for any logic
# gating. Operator flagged stale label across 7+ dispatches; fixed at r80p74k.
ENGINE_VERSION = 'r80p74k'  # BW_R80P74K (was r80p74b / BW_R80P74B)

# BW_R80P73E — StreamReader byte limit for subprocess stdout. The asyncio
# default is 64KB which can be exceeded by single-line JSON tool_results from
# claude-code (e.g., reading a 100KB+ file). Raising this prevents the run
# from dying mid-stream with LimitOverrunError → [ERROR] Error in input stream.
BW_R80P73E_STREAM_LIMIT = 10 * 1024 * 1024  # 10 MB per line ceiling

# BW_R80P73F — Seconds of stdout silence before a heartbeat event is emitted.
# Subprocess stays alive but produces no output (CC thinking, network stall).
# Previously: engine waited indefinitely with no operator-visible signal.
BW_R80P73F_HEARTBEAT_TIMEOUT = 90.0


def _load_proxy_token() -> str:
    """Load Beewid privacy proxy token from ~/.beewid/proxy.token.
    Returns empty string if missing — caller is responsible for handling that.
    """
    try:
        if PROXY_TOKEN_FILE.exists():
            tok = PROXY_TOKEN_FILE.read_text(encoding='utf-8').strip()
            if tok and len(tok) >= 32:
                return tok
    except Exception:
        pass
    return ''


# ── REGISTRIES ─────────────────────────────────────────────────────────────
# These are stubs in 2A.1 — populated in 2A.2/2A.3 as pluggability lands.

# TUI registry: each TUI maps to (binary, env requirements, command template).
# BW_R80P60 — aider added. opencode + custom-shell still deferred.
_TUI_REGISTRY: dict[str, dict[str, Any]] = {
    'claude-code': {
        'binary':       'claude',
        'requires':     ['ANTHROPIC_API_KEY or ANTHROPIC_API_BASE'],
        'cmd_template': '{binary} --print {auto_flags} < {prompt_file} > {out_file} 2>&1',
        'description':  'Claude Code by Anthropic',
        # Op-type intrusion: claude-code's --auto-approve-tools accepts a CSV
        # allowlist. Level 2 allows non-destructive auto-approve (edit, write
        # new); never delete/bash/git-commit (those stay gated at the TUI level
        # regardless of intrusion_level).
        'auto_flags_by_level': {
            0: '--no-tools',
            1: '',  # default behavior — TUI prompts inline
            2: '--auto-approve-tools edit_file,write_file',
        },
    },
    'aider': {
        'binary':       'aider',
        'requires':     ['ANTHROPIC_API_KEY or ANTHROPIC_API_BASE'],
        'cmd_template': '{binary} --no-show-model-warnings --message-file {prompt_file} {auto_flags} > {out_file} 2>&1',
        'description':  'aider — multi-backend AI pair programmer',
        'auto_flags_by_level': {
            0: '--no-auto-commits --dry-run',
            1: '--no-auto-commits',
            2: '--yes-always --no-auto-commits',  # never auto-commit at any level
        },
    },
    # 'opencode':     {...}   # follow-on dispatch
    # 'custom-shell': {...}   # follow-on dispatch
}

# Backend registry: AI provider configurations.
# 2A.2 (BW_R80P59) — proxy backend added and made default. Direct mode remains
# available as opt-in escape hatch (privacy_warn=True, requires explicit selection).
_BACKEND_REGISTRY: dict[str, dict[str, Any]] = {
    'cloud-anthropic-proxy': {
        'kind':         'cloud',
        'provider':     'anthropic',
        'env_keys':     ['ANTHROPIC_API_KEY', 'ANTHROPIC_API_BASE', 'ANTHROPIC_BASE_URL'],
        'description':  'Anthropic via Beewid privacy proxy (default, scrubbed at Layer 3)',
        'privacy_warn': False,
        'use_proxy':    True,
    },
    'cloud-anthropic-direct': {
        'kind':         'cloud',
        'provider':     'anthropic',
        'env_keys':     ['ANTHROPIC_API_KEY'],
        'description':  'Anthropic API (direct — bypasses Beewid privacy proxy)',
        'privacy_warn': True,  # bypasses scrub
        'use_proxy':    False,
    },
    # 'cloud-openrouter':        {...}   # 2A.3
    # 'local-ollama':            {...}   # 2A.3
    # 'local-llamacpp':          {...}   # R150
    # 'private-server':          {...}   # 2A.3
}

# Compatibility matrix: which TUI works with which backend.
# BW_R80P60 — aider added (proxy + direct).
_COMPAT_MATRIX: dict[str, list[str]] = {
    'claude-code': ['cloud-anthropic-proxy', 'cloud-anthropic-direct'],
    'aider':       ['cloud-anthropic-proxy', 'cloud-anthropic-direct'],
    # opencode + custom-shell filled in follow-on
}


# ── PUBLIC: DETECTION ────────────────────────────────────────────────────

def detect_tuis() -> list[dict]:
    """Return list of TUIs with availability status (which-detected)."""
    out = []
    for name, spec in _TUI_REGISTRY.items():
        path = shutil.which(spec['binary'])
        out.append({
            'name':        name,
            'available':   path is not None,
            'path':        path or '',
            'description': spec['description'],
        })
    return out


def detect_backends() -> list[dict]:
    """Return list of backends with configuration status (vault-checked)."""
    creds = _load_creds()
    out = []
    for name, spec in _BACKEND_REGISTRY.items():
        configured = False
        if spec['provider'] == 'anthropic':
            configured = bool(creds.get('anthropic_key', '').strip())
        out.append({
            'name':         name,
            'kind':         spec['kind'],
            'configured':   configured,
            'description':  spec['description'],
            'privacy_warn': spec.get('privacy_warn', False),
        })
    return out


def get_compat_matrix() -> dict:
    """Return TUI → [backend] compatibility map."""
    return {k: list(v) for k, v in _COMPAT_MATRIX.items()}


# ── PUBLIC: CREDENTIALS ──────────────────────────────────────────────────

def _load_creds() -> dict:
    """Load credentials.json — returns empty dict if missing or unreadable."""
    try:
        if CREDS_FILE.exists():
            return json.loads(CREDS_FILE.read_text(encoding='utf-8'))
    except Exception:
        pass
    return {}


def resolve_api_key(backend: str, fallback: str = '') -> str:
    """
    Resolve the API key for a backend.

    For proxy backends (use_proxy=True): reads ~/.beewid/proxy.token.
    For direct backends: reads vault (credentials.json).

    BW_R80P59 — proxy mode added. Browser-supplied fallback only used for
    direct mode; proxy mode ignores fallback (it has its own token).
    """
    spec = _BACKEND_REGISTRY.get(backend)
    if not spec:
        return fallback
    if spec.get('use_proxy'):
        # Proxy backend uses local proxy token, not the real Anthropic key.
        # Fallback is intentionally ignored — proxy auth is not browser-supplied.
        return _load_proxy_token()
    if spec['provider'] == 'anthropic':
        creds = _load_creds()
        return creds.get('anthropic_key', '').strip() or fallback
    return fallback


def build_subprocess_env(tui: str, backend: str, api_key: str) -> dict:
    """
    Build the env-var dict for spawning the TUI subprocess.
    Inherits os.environ as base, overlays AI provider keys per backend.

    BW_R80P59 — proxy backend now sets BOTH ANTHROPIC_API_BASE (Python SDK
    convention, used by Hermes) AND ANTHROPIC_BASE_URL (TS SDK convention,
    used by claude-code). Setting both is harmless — each SDK reads only its
    own. This avoids dispatching by-TUI when the env semantics are stable.

    BW_R80P67 — OAuth path: in direct mode without an api_key, ensure
    ANTHROPIC_API_KEY is NOT inherited from the parent shell — claude-code must
    read OAuth credentials from ~/.claude/.credentials.json instead. HOME/PATH
    flow through via dict(os.environ).
    """
    env = dict(os.environ)
    spec = _BACKEND_REGISTRY.get(backend, {})
    if spec.get('provider') == 'anthropic':
        if api_key:
            env['ANTHROPIC_API_KEY'] = api_key
            if spec.get('use_proxy'):
                env['ANTHROPIC_API_BASE'] = PROXY_BASE_URL
                env['ANTHROPIC_BASE_URL'] = PROXY_BASE_URL
            else:
                # Direct mode with key: clear any inherited proxy URL so we hit Anthropic directly
                env.pop('ANTHROPIC_API_BASE', None)
                env.pop('ANTHROPIC_BASE_URL', None)
        else:
            # BW_R80P67 — OAuth mode: scrub any inherited key + proxy URLs so
            # claude-code falls through to ~/.claude/.credentials.json.
            env.pop('ANTHROPIC_API_KEY', None)
            env.pop('ANTHROPIC_API_BASE', None)
            env.pop('ANTHROPIC_BASE_URL', None)
    return env


# ── BW_R80P70 — ACTIVE RUNS REGISTRY + LIFECYCLE HARDENING ───────────────
# Each in-flight autocode subprocess registers itself here; the SSE handler
# can kill it on disconnect, timeout, or operator command. Process group
# isolation (start_new_session=True) lets killpg() reap claude's children too.

_ACTIVE_RUNS: dict = {}   # run_id → {pid, started_at, instance_id, tui, proc, prompt_preview}

# BW_R80P79_PHASED — CPU poll history for delta-based CPU% calculation.
# Keyed by pid; each value is {ticks: int, time: float}.
_LAST_CPU_POLL: dict = {}


# BW_R80P74J — In-memory approval response queue keyed by instance_id.
# Panel POSTs operator decisions to /autocode/approval-response; the api drops
# them here; the engine's claude-code spawn block runs a pump task that reads
# from this queue and writes the decisions to the running subprocess's stdin
# (when claude-code is run with --input-format=stream-json). If stdin is closed
# (text-input mode), the pump exits quietly — the decision is still recorded
# and a future dispatch can pivot to a file-poll delivery path.
_BW_R80P74J_APPROVAL_QUEUES: dict = {}  # instance_id -> asyncio.Queue


def _bw_r80p77_detect_rate_limit(stderr_text: str, result_text: str) -> dict:
    """BW_R80P77 — Scan stderr + result for 429 / rate-limit signals.
    Returns dict with 'detected', 'retry_after_seconds', 'message'."""
    import re as _re_rl
    combined = (stderr_text or '') + ' ' + (result_text or '')
    detected = (
        'rate_limit_error' in combined
        or '"status":429' in combined
        or 'Too Many Requests' in combined
        or 'too_many_requests' in combined.lower()
        or ' 429 ' in combined
    )
    if not detected:
        return {'detected': False, 'retry_after_seconds': None, 'message': ''}
    retry_after = None
    m = _re_rl.search(r'retry[-_]after[":\s]+(\d+)', combined, _re_rl.IGNORECASE)
    if m:
        try: retry_after = int(m.group(1))
        except Exception: pass
    message = ''
    m2 = _re_rl.search(r'"message"\s*:\s*"([^"]+)"', combined)
    if m2: message = m2.group(1)[:200]
    return {'detected': True, 'retry_after_seconds': retry_after, 'message': message}


def _bw_r80p74j_get_queue(instance_id: str) -> asyncio.Queue:
    """Return (creating if needed) the approval queue for an instance."""
    q = _BW_R80P74J_APPROVAL_QUEUES.get(instance_id)
    if q is None:
        q = asyncio.Queue()
        _BW_R80P74J_APPROVAL_QUEUES[instance_id] = q
    return q


def _bw_r80p74j_post_response(instance_id: str, approval_id: str, decision: str) -> bool:
    """Called from api.py /autocode/approval-response handler. Enqueues an
    operator decision for the engine's pump task to forward. Returns True if
    the decision was enqueued, False otherwise (queue full / engine gone)."""
    try:
        q = _bw_r80p74j_get_queue(instance_id)
        q.put_nowait({'approval_id': approval_id, 'decision': decision})
        return True
    except Exception:
        return False


# ─────────────────────────────────────────────────────────────────────────
# BW_R80P79PT1A — Tool classifier + partial state tracker.
# Classifies every tool_use into 'idempotent' / 'state_mutating' / 'destructive'.
# The classification drives PT1B's auto-continuation strategy:
# - idempotent + state_mutating tools that completed can be safely declared
#   "already done" to a resumed subprocess.
# - destructive tools that were IN-FLIGHT at moment of severance trigger
#   operator-handoff (never auto-redo).
# Destructive-bash patterns mirror the r80p74i PreToolUse hook. Keep both
# in sync.
_BW_R80P79PT1A_DESTRUCTIVE_BASH_PATTERNS = [
    r'\brm\s+-r',
    r'\brm\s+-f',
    r'\brm\s+/',
    r'\bmv\s+\S+\s+/',
    r'\bdd\s+',
    r'\bmkfs\.',
    r'\bshred\s+',
    r'\bcurl\s+.*-X\s*(POST|PUT|DELETE|PATCH)',
    r'\bwget\s+.*--post',
    r'>\s*/dev/sd[a-z]',
    r'\bchmod\s+777\s+/',
    r'\bchown\s+.*\s+/',
    r'\bgit\s+push\s+--force',
    r'\bdocker\s+(rm|kill)',
    r'\bkill\s+-9',
    r'\bpkill\s+-9',
    r'\bsystemctl\s+stop',
]
_BW_R80P79PT1A_STATE_MUTATING_TOOLS = {
    'Edit', 'str_replace', 'create_file', 'Write',
    'NotebookEdit', 'WebFetch', 'TodoWrite',
}
_BW_R80P79PT1A_IDEMPOTENT_TOOLS = {
    'Read', 'View', 'Glob', 'Grep', 'GlobSearch',
    'ToolSearch', 'Tool',
}
_BW_R80P79PT1A_READONLY_BASH_HEADS = {
    'ls', 'cat', 'head', 'tail', 'grep', 'find',
    'wc', 'awk', 'sed', 'echo', 'pwd', 'which',
    'whereis', 'ps', 'df', 'du', 'free', 'top',
    'date', 'curl',  # curl is GET by default; POST/PUT etc caught above
}


def _bw_r80p79pt1a_classify_tool(tool_name: str, tool_input: dict) -> str:
    """BW_R80P79PT1A — Return 'idempotent' | 'state_mutating' | 'destructive'."""
    import re as _re_cls
    if tool_name in _BW_R80P79PT1A_IDEMPOTENT_TOOLS:
        return 'idempotent'
    if tool_name == 'Bash':
        cmd = (tool_input or {}).get('command') or ''
        for pat in _BW_R80P79PT1A_DESTRUCTIVE_BASH_PATTERNS:
            if _re_cls.search(pat, cmd):
                return 'destructive'
        cmd_stripped = cmd.strip()
        first_word = cmd_stripped.split()[0] if cmd_stripped else ''
        if first_word in _BW_R80P79PT1A_READONLY_BASH_HEADS:
            return 'idempotent'
        # Default Bash to state_mutating (safer than calling unknown bash idempotent).
        return 'state_mutating'
    if tool_name in _BW_R80P79PT1A_STATE_MUTATING_TOOLS:
        return 'state_mutating'
    # Unknown tool — assume state_mutating as a safe middle ground.
    return 'state_mutating'


# BW_R80P79PT1A — Module-level registry of partial state by run_id.
# Populated by the streaming loop in run_autocode_stream; read by api.py
# at severance time via _bw_r80p79pt1a_get_partial_state.
_BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID: dict = {}


def _bw_r80p79pt1a_init_partial_state(run_id: str, prompt: str, instance_id: str, mode: str) -> dict:
    """BW_R80P79PT1A — Initialize partial state for a new run and register."""
    ps = {
        'prompt': prompt,
        'instance_id': instance_id,
        'mode': mode,
        'started_at': time.time(),
        'tools_completed': [],
        # BW_R80P79PT1BFIX — Parallel tool tracking. Multiple tool_use
        # events can be in-flight simultaneously (Sonnet 4.6 issues
        # Read+Bash in parallel as standard practice). Keyed by
        # tool_use_id; each value is the same shape as the old
        # single-slot in_flight dict. tool_in_flight kept as backward-
        # compat alias holding the MOST RECENT in-flight tool for any
        # legacy reader.
        'tools_in_flight': {},
        'tool_in_flight': None,
        'last_event_type': None,
        'todo_state': None,
        'events_count': 0,
    }
    _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID[run_id] = ps
    return ps


def _bw_r80p79pt1a_get_partial_state(run_id: str):
    """BW_R80P79PT1A — Snapshot reader, used by api.py severance backstop."""
    # BW_R80P79PT1BFIX2 — lazy GC of expired partial states on every read.
    _bw_r80p79pt1bfix2_sweep_expired()
    ps = _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.get(run_id)
    return dict(ps) if ps else None


def _bw_r80p79pt1a_clear_partial_state(run_id: str) -> None:
    """BW_R80P79PT1A — Free memory on clean completion."""
    _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.pop(run_id, None)


# BW_R80P79PT1BFIX2 — Delayed eviction. The engine's _unregister_run used to
# call clear_partial_state immediately when a run ended. That created a TOCTOU
# race: Python runs the engine's `finally` block AS PART of the async
# generator's `return` (force-severance path), so partial state was already
# wiped by the time api.py's severance backstop tried to read it. The
# severance event ended up with empty tools_completed / classification
# 'severance_unknown' — visible in the first PT1BFIX e2e re-test.
# Switch to: mark the entry with `_evict_at = now + EVICT_AFTER` and let a
# lazy sweep (called from get / mark) drop expired entries. Gives api.py a
# 30s window to read partial state before GC; bounded memory in steady state.
_BW_R80P79PT1BFIX2_EVICT_AFTER_SECONDS = 30


def _bw_r80p79pt1bfix2_sweep_expired() -> None:
    """BW_R80P79PT1BFIX2 — Lazy GC, O(N) where N = recently-finished runs.
    Drops entries whose `_evict_at` has elapsed. Called from get/mark."""
    _now = time.time()
    _stale = [
        _rid for _rid, _ps in _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.items()
        if isinstance(_ps, dict) and _ps.get('_evict_at') and _ps['_evict_at'] < _now
    ]
    for _rid in _stale:
        _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.pop(_rid, None)


def _bw_r80p79pt1bfix2_mark_for_eviction(run_id: str) -> None:
    """BW_R80P79PT1BFIX2 — Mark a run's partial state for delayed cleanup so
    api.py's severance backstop has time to read it. Sweeps any already-
    expired entries on the way through."""
    _bw_r80p79pt1bfix2_sweep_expired()
    _ps = _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.get(run_id)
    if isinstance(_ps, dict):
        _ps['_evict_at'] = time.time() + _BW_R80P79PT1BFIX2_EVICT_AFTER_SECONDS
# ─────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────
# BW_R80P79PT1C_P1 — Per-run event ring buffer + sequence numbers.
# The browser can disconnect mid-stream (large outputs, idle timeout,
# tab close, etc.) but the engine subprocess keeps running. The ring
# buffer holds the last N events PER active run so a reconnecting client
# can call GET /autocode/run-stream/{run_id}?since={seq} and pick up where
# it left off. Combined with PHASE2's frontend reconnect, this makes the
# browser side of autocode indistinguishable from terminal CC.
# ─────────────────────────────────────────────────────────────────────────
import collections as _bw_r80p79pt1c_p1_collections

_BW_R80P79PT1C_P1_EVENT_RING_CAP = 500   # events per run held in memory
_BW_R80P79PT1C_P1_RING_EVICT_AFTER_SECONDS = 30  # match PT1BFIX2 cadence

_BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID: dict = {}


def _bw_r80p79pt1c_p1_sweep_expired_rings() -> None:
    """Lazy GC. Called from get/append/mark. O(N) over active rings."""
    now = time.time()
    expired = []
    for rid, ring in _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.items():
        evict_at = ring.get('_evict_at')
        if evict_at is not None and now >= evict_at:
            expired.append(rid)
    for rid in expired:
        _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.pop(rid, None)


# BW_TRIO_A1 — Raw subprocess-stdout passthrough. INTENTIONALLY SEPARATE from the
# PT1C event ring: when the ring is missing at attach time ('no_ring'), this raw
# tail + live feed still works because it is fed directly from the stdout pump and
# kept in its own dict with its own lifecycle. Escape hatch of last resort.
_BW_TRIO_A1_RAW_BY_RUN_ID = {}      # run_id -> deque[str] of raw stdout lines
_BW_TRIO_A1_SUBS_BY_RUN_ID = {}     # run_id -> set[asyncio.Queue] live followers
_BW_TRIO_A1_RAW_CAP = 4000


def _bw_trio_a1_raw_capture(run_id, line):
    """Append a raw stdout line + fan out to live subscribers. Best-effort; the
    pump wraps this in try/except so it can NEVER break a run (BW_TRIO_A1)."""
    if not run_id:
        return
    dq = _BW_TRIO_A1_RAW_BY_RUN_ID.get(run_id)
    if dq is None:
        dq = _bw_r80p79pt1c_p1_collections.deque(maxlen=_BW_TRIO_A1_RAW_CAP)
        _BW_TRIO_A1_RAW_BY_RUN_ID[run_id] = dq
    dq.append(line)
    subs = _BW_TRIO_A1_SUBS_BY_RUN_ID.get(run_id)
    if subs:
        for q in list(subs):
            try:
                q.put_nowait(line)
            except Exception:
                pass


def _bw_trio_a1_get_raw_tail(run_id):
    """Return the captured raw tail for a run (list of lines). Ring-independent."""
    dq = _BW_TRIO_A1_RAW_BY_RUN_ID.get(run_id)
    return list(dq) if dq else []


def _bw_trio_a1_subscribe(run_id):
    """Register a live-follow queue for a run. Returns an asyncio.Queue."""
    import asyncio as _aio
    q = _aio.Queue()
    _BW_TRIO_A1_SUBS_BY_RUN_ID.setdefault(run_id, set()).add(q)
    return q


def _bw_trio_a1_unsubscribe(run_id, q):
    subs = _BW_TRIO_A1_SUBS_BY_RUN_ID.get(run_id)
    if subs:
        subs.discard(q)
        if not subs:
            _BW_TRIO_A1_SUBS_BY_RUN_ID.pop(run_id, None)


def _bw_trio_a1_mark_for_eviction(run_id):
    """On run end: wake live followers (None sentinel) so their streams close.
    The raw tail is KEPT for post-mortem viewing (bounded per-run by maxlen);
    it clears on the next Beewid restart. (BW_TRIO_A1)"""
    subs = _BW_TRIO_A1_SUBS_BY_RUN_ID.get(run_id)
    if subs:
        for q in list(subs):
            try:
                q.put_nowait(None)
            except Exception:
                pass


def _bw_r80p79pt1c_p1_init_ring(run_id: str) -> None:
    """Called once per run, just after _register_run."""
    if not run_id:
        return
    _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID[run_id] = {
        'events': _bw_r80p79pt1c_p1_collections.deque(maxlen=_BW_R80P79PT1C_P1_EVENT_RING_CAP),
        'next_seq': 0,
        'created_at': time.time(),
        '_evict_at': None,
    }


def _bw_r80p79pt1c_p1_append_event(run_id: str, event: dict) -> int:
    """Append an event to the ring buffer. Stamps event['_event_seq'] in place.
    Returns the assigned sequence number. Safe to call on missing run_id (no-op).
    """
    if not run_id:
        return -1
    ring = _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.get(run_id)
    if ring is None:
        return -1
    try:
        seq = ring['next_seq']
        ring['next_seq'] = seq + 1
        try:
            event['_event_seq'] = seq
        except (TypeError, AttributeError):
            pass
        ring['events'].append(event)
        # BW_R80P79_PHASEB — touch the run so list_active_runs has fresh last_event_at
        _touch_run(run_id)
        return seq
    except Exception:
        return -1


def _bw_r80p79pt1c_p1_get_ring_events_since(run_id: str, since_seq: int = -1) -> list:
    """Return all events in the ring with seq > since_seq, in order.
    Caller passes since_seq=-1 for 'all events still in ring'.
    """
    if not run_id:
        return []
    _bw_r80p79pt1c_p1_sweep_expired_rings()
    ring = _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.get(run_id)
    if ring is None:
        return []
    out = []
    for ev in ring['events']:
        sq = ev.get('_event_seq', -1) if isinstance(ev, dict) else -1
        if sq > since_seq:
            out.append(ev)
    return out


def _bw_r80p79pt1c_p1_get_ring_info(run_id: str) -> dict:
    """Return ring metadata. Useful for the attach endpoint and diagnostics."""
    if not run_id:
        return {}
    ring = _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.get(run_id)
    if ring is None:
        return {}
    return {
        'run_id': run_id,
        'event_count': len(ring['events']),
        'next_seq': ring['next_seq'],
        'cap': _BW_R80P79PT1C_P1_EVENT_RING_CAP,
        'created_at': ring['created_at'],
        '_evict_at': ring['_evict_at'],
    }


def _bw_r80p79pt1c_p1_mark_ring_for_eviction(run_id: str) -> None:
    """Called from _unregister_run alongside the PT1BFIX2 partial-state mark."""
    ring = _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.get(run_id)
    if ring is None:
        return
    ring['_evict_at'] = time.time() + _BW_R80P79PT1C_P1_RING_EVICT_AFTER_SECONDS


# BW_R80P79_PHASEB — _bw_r80p79pt1c_p1_list_active_runs is DEPRECATED.
# Both /autocode/runs/active and /autocode/active-runs API endpoints now call
# list_active_runs() directly. Wrapper kept for one release only.
def _bw_r80p79pt1c_p1_list_active_runs() -> list:
    """DEPRECATED in Phase B (BW_R80P79_PHASEB) — use list_active_runs() instead.

    This wrapper exists for one release to keep any external callers working.
    The returned shape from list_active_runs() is a strict superset of what this
    function used to return.

    Will be removed in a future cleanup pass (likely Phase G).
    """
    # Note: not using warnings.warn() because the codebase uses logging style.
    # The single log line at module import time is sufficient signal.
    return list_active_runs()

# ─────────────────────────────────────────────────────────────────────────
# BW_R80P79PT1C_P1 end — ring buffer helpers
# ─────────────────────────────────────────────────────────────────────────


# ─────────────────────────────────────────────────────────────────────────
# BW_R80P79PT1B — Continuation prompt builder + force-severance flag.
# Builds a structured "resume from here" prompt from PT1A's partial state.
# Target: <5% token overhead vs straight-line terminal CC.
# ─────────────────────────────────────────────────────────────────────────

# Force-severance flag — when True, the next active streaming generator
# returns without emitting `done`, triggering PT1A's severance backstop.
# Used only by the /autocode/diag/force-severance endpoint for testing.
# Cleared automatically after one use OR 60s if not consumed.
_BW_R80P79PT1B_FORCE_SEVERANCE_FLAG: dict = {'armed': False, 'armed_at': None}


def _bw_r80p79pt1b_arm_force_severance() -> None:
    """BW_R80P79PT1B — Arm the flag. Next active run returns without done."""
    _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed'] = True
    _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed_at'] = time.time()


def _bw_r80p79pt1b_check_and_consume_force_severance() -> bool:
    """BW_R80P79PT1B — Check the flag and consume it. Returns True iff armed.
    Stale-flag protection: armed for >60s = ignored and cleared."""
    if not _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed']:
        return False
    armed_at = _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG.get('armed_at') or 0
    if time.time() - armed_at > 60:
        _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed'] = False
        _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed_at'] = None
        return False
    _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed'] = False
    _BW_R80P79PT1B_FORCE_SEVERANCE_FLAG['armed_at'] = None
    return True


def _bw_r80p79pt1b_build_continuation_prompt(partial_state: dict, strategy: str) -> str:
    """BW_R80P79PT1B — Build a structured continuation prompt from PT1A
    partial state. Tells the resumed LLM what already ran + per-strategy
    guidance. Token overhead target: <5% of a typical full run.
    Completed tool outputs truncated to 1KB each in the prompt body
    (full outputs persist in partial_state for audit)."""
    original_prompt = partial_state.get('prompt', '<unknown>')
    tools_completed = partial_state.get('tools_completed', []) or []
    tool_in_flight = partial_state.get('tool_in_flight')

    lines = [
        '[META: This is a CONTINUATION of a previously-interrupted run.',
        ' The original task is below. Tools listed under "ALREADY COMPLETED"',
        ' have been executed successfully and their outputs are shown.',
        ' DO NOT re-execute these tools. Pick up where the previous run',
        ' left off and complete the original task.]',
        '',
        '═══ ORIGINAL TASK ═══',
        original_prompt,
        '',
        '═══ ALREADY COMPLETED ═══',
    ]
    if not tools_completed:
        lines.append('(No tools completed before tear — restart from beginning of task.)')
    else:
        for i, t in enumerate(tools_completed, 1):
            name = t.get('name', '?')
            inp = t.get('input', {})
            cls = t.get('classification', '?')
            out = (t.get('output_truncated') or '')[:1024]
            is_err = t.get('is_error', False)
            try:
                inp_str = json.dumps(inp) if isinstance(inp, (dict, list)) else str(inp)
            except Exception:
                inp_str = str(inp)
            inp_str = inp_str[:300]
            lines.append(f'{i}. {name}({inp_str}) [class={cls}]')
            if is_err:
                lines.append(f'   → ERROR: {out}')
            else:
                lines.append(f'   → {out}')
            lines.append('')

    if strategy == 'continue':
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            'The previous run was severed at a clean break between tool calls.',
            'Pick up the original task using the completed tool outputs above.',
            'Do not redo any completed tool — their outputs are above.',
        ])
    elif strategy == 'continue_with_inflight_replay':
        inflight_name = (tool_in_flight or {}).get('name', '?')
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            f'The previous run was severed during a {inflight_name} call.',
            f'The {inflight_name} call did NOT complete and needs to be re-executed.',
            'Re-execute it once with the same parameters as the original intent,',
            'then continue the task using its output + the completed tools above.',
        ])
    elif strategy == 'continue_with_inflight_skip':
        inflight_name = (tool_in_flight or {}).get('name', '?')
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            f'The previous run was severed during a {inflight_name} call.',
            f'The {inflight_name} call has been SKIPPED per operator decision.',
            'Continue the task WITHOUT that tool — work with the completed tools above.',
        ])
    elif strategy == 'fresh_with_context':
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            'The previous run severed in an unknown state.',
            'Use the completed tool outputs as context and proceed with the original task.',
            'You may re-execute any tool you think necessary, but the completed ones above',
            'are confirmed-done and their outputs are accurate.',
        ])
    elif strategy == 'wait_and_continue':
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            'The previous run hit a rate limit and was paused.',
            'Continue the original task from where it left off.',
            'Do not redo completed tools above.',
        ])
    else:
        lines.extend([
            '═══ RESUME INSTRUCTION ═══',
            'Continue the original task using the completed tool outputs above.',
        ])

    return '\n'.join(lines)
# ─────────────────────────────────────────────────────────────────────────
# BW_R80P79PT1B end — continuation prompt builder + force-severance helpers
# ─────────────────────────────────────────────────────────────────────────


def _register_run(run_id: str, proc, instance_id: str, tui: str, prompt: str,
                  owner_tab_token: str = '') -> None:
    """BW_R80P79_PHASEB — extended schema includes:
      - last_event_at: float — updated by _touch_run on every ring-buffer append
      - terminal_state: str — 'running' | 'done' | 'severed' | 'errored' | 'killed'
      - owner_tab_token: str — per-browser-tab session token from sessionStorage,
        used to scope active-run-detect to the tab that originated the run.
    """
    now = time.time()
    _ACTIVE_RUNS[run_id] = {
        'run_id': run_id,
        'pid': proc.pid if proc else None,
        'proc': proc,
        'started_at': now,
        'last_event_at': now,                  # BW_R80P79_PHASEB
        'terminal_state': 'running',           # BW_R80P79_PHASEB
        'owner_tab_token': owner_tab_token,    # BW_R80P79_PHASEB
        'instance_id': instance_id,
        'tui': tui,
        'prompt_preview': (prompt or '')[:200],
    }
    # BW_R80P79PT1C_P1 — Initialize event ring for this run. Best-effort:
    # ring buffer is a resilience layer; never block run on its failure.
    try:
        _bw_r80p79pt1c_p1_init_ring(run_id)
    except Exception:
        pass


def _touch_run(run_id: str) -> None:
    """BW_R80P79_PHASEB — Update last_event_at to now. Cheap; called on every
    ring-buffer append. No-op if the run is no longer in _ACTIVE_RUNS (already
    unregistered)."""
    entry = _ACTIVE_RUNS.get(run_id)
    if entry is not None:
        entry['last_event_at'] = time.time()


def _set_terminal_state(run_id: str, state: str) -> None:
    """BW_R80P79_PHASEB — Mark the terminal state of a run. Valid states:
    'running' (default at registration) | 'done' | 'severed' | 'errored' | 'killed'.

    Also bumps last_event_at so 'a stale-but-marked-done' run can be distinguished
    from 'a stale and still-marked-running' run (the latter is the 'engine lost
    contact' signal that Phase C will render).
    """
    entry = _ACTIVE_RUNS.get(run_id)
    if entry is not None:
        entry['terminal_state'] = state
        entry['last_event_at'] = time.time()


def _unregister_run(run_id: str) -> None:
    # BW_R80P79_PHASEB — if not already set by a kill/severance path, mark as done
    entry = _ACTIVE_RUNS.get(run_id)
    if entry is not None and entry.get('terminal_state', 'running') == 'running':
        entry['terminal_state'] = 'done'
        entry['last_event_at'] = time.time()
    # BW_R80P79PT1A — Free partial state when the run record is dropped.
    # BW_R80P79PT1BFIX2 — Switched from immediate clear to delayed eviction
    # (30s TTL via lazy sweep). Otherwise the engine's `finally` block runs
    # AS PART OF the async generator's `return`, wiping partial state before
    # api.py's severance backstop can read it. Detected during the PT1BFIX
    # e2e re-test — severance event came back with empty tools_completed.
    _bw_r80p79pt1bfix2_mark_for_eviction(run_id)
    # BW_R80P79PT1C_P1 — Mark ring buffer for eviction at the same cadence
    # so attaching/replaying clients see consistent lifecycle vs partial state.
    try:
        _bw_r80p79pt1c_p1_mark_ring_for_eviction(run_id)
    except Exception:
        pass
    # BW_TRIO_A1 — close live raw followers when the run unregisters
    try:
        _bw_trio_a1_mark_for_eviction(run_id)
    except Exception:
        pass
    _ACTIVE_RUNS.pop(run_id, None)


def _is_proc_alive(proc) -> bool:
    try:
        return proc.returncode is None
    except Exception:
        return False


def _get_proc_resources(run_id: str) -> dict:
    """BW_R80P79_PHASED — Read CPU/RAM stats for a run's subprocess.

    Uses /proc/<pid>/stat and /proc/<pid>/status for zero-dependency reading.
    Returns:
      {
        'pid': int | None,
        'pid_alive': bool,
        'cpu_percent': float | None,   # 0-100, approx (delta-based per call)
        'rss_mb': float | None,        # resident set size in MB
        'vms_mb': float | None,        # virtual memory size in MB
        'threads': int | None,
        'state': str | None,           # 'R' running, 'S' sleeping, 'D' iowait, 'Z' zombie
      }
    """
    _empty = {'pid': None, 'pid_alive': False, 'cpu_percent': None,
               'rss_mb': None, 'vms_mb': None, 'threads': None, 'state': None}
    entry = _ACTIVE_RUNS.get(run_id)
    if not entry:
        return _empty

    proc = entry.get('proc')
    pid = entry.get('pid')
    pid_alive = _is_proc_alive(proc) if proc else False

    if not pid or not pid_alive:
        return {**_empty, 'pid': pid}

    try:
        with open(f'/proc/{pid}/stat') as f:
            s = f.read()
        # comm field may contain spaces; find last ')' to skip it safely
        rparen = s.rfind(')')
        fields = s[rparen + 2:].split()
        # After ')': state(0) ppid(1) ... utime(11) stime(12) ... num_threads(17)
        proc_state = fields[0]
        utime = int(fields[11])
        stime = int(fields[12])
        threads = int(fields[17])
        total_ticks = utime + stime

        # CPU% via delta from last poll
        prev = _LAST_CPU_POLL.get(pid, {})
        prev_ticks = prev.get('ticks', 0)
        prev_time = prev.get('time', time.time())
        now = time.time()
        elapsed = max(0.001, now - prev_time)
        ticks_per_sec = os.sysconf('SC_CLK_TCK')
        cpu_pct = ((total_ticks - prev_ticks) / ticks_per_sec) / elapsed * 100.0
        _LAST_CPU_POLL[pid] = {'ticks': total_ticks, 'time': now}

        rss_kb = 0
        vms_kb = 0
        with open(f'/proc/{pid}/status') as f:
            for line in f:
                if line.startswith('VmRSS:'):
                    rss_kb = int(line.split()[1])
                elif line.startswith('VmSize:'):
                    vms_kb = int(line.split()[1])

        return {
            'pid': pid,
            'pid_alive': True,
            'cpu_percent': round(min(100.0, max(0.0, cpu_pct)), 1),
            'rss_mb': round(rss_kb / 1024.0, 1),
            'vms_mb': round(vms_kb / 1024.0, 1),
            'threads': threads,
            'state': proc_state,
        }
    except (FileNotFoundError, ProcessLookupError):
        return {**_empty, 'pid': pid}
    except Exception as e:
        return {**_empty, 'pid': pid, 'pid_alive': pid_alive, 'error': str(e)}


def list_active_runs() -> list:
    """BW_R80P79_PHASEB — Authoritative active-runs listing.

    Returns one dict per run in _ACTIVE_RUNS. Each dict combines:
      - Original registry-A fields (run_id, pid, instance_id, tui, started_at, prompt_preview)
      - PHASE B fields (last_event_at, terminal_state, owner_tab_token)
      - Derived fields (age_seconds, seconds_since_last_event, pid_alive, alive)
      - Ring buffer fields (event_count, ring_evict_at)
      - Convenience flag (is_active) re-defined as 'still actually running'

    Backward compatibility:
      - 'alive' is kept as an alias for 'pid_alive' (was the old name)
      - 'is_active' is preserved but semantically corrected: was 'ring buffer not
        yet evicted' (which lingered 30s after completion); now means
        'terminal_state == running AND pid_alive AND seconds_since_last_event < 60'.
        This is what frontend callers actually wanted.
    """
    now = time.time()
    out = []
    for run_id, entry in list(_ACTIVE_RUNS.items()):
        proc = entry.get('proc')
        pid_alive = _is_proc_alive(proc) if proc is not None else False
        last_event = entry.get('last_event_at') or entry.get('started_at') or now
        seconds_since_last = max(0.0, now - last_event)
        terminal = entry.get('terminal_state', 'running')

        # Ring buffer event count (if any)
        ring = _BW_R80P79PT1C_P1_EVENT_RING_BY_RUN_ID.get(run_id)
        event_count = len(ring['events']) if ring and 'events' in ring else 0
        ring_evict_at = ring.get('_evict_at') if ring else None

        is_active = (terminal == 'running' and pid_alive and seconds_since_last < 60.0)

        out.append({
            'run_id':                   run_id,
            'pid':                      entry.get('pid'),
            'instance_id':              entry.get('instance_id', ''),
            'tui':                      entry.get('tui', ''),
            'started_at':               entry.get('started_at'),
            'last_event_at':            last_event,
            'age_seconds':              max(0.0, now - (entry.get('started_at') or now)),
            'seconds_since_last_event': seconds_since_last,
            'prompt_preview':           entry.get('prompt_preview', ''),
            'terminal_state':           terminal,
            'owner_tab_token':          entry.get('owner_tab_token', ''),
            'pid_alive':                pid_alive,
            'alive':                    pid_alive,          # legacy alias
            'event_count':              event_count,
            'ring_evict_at':            ring_evict_at,
            'is_active':                is_active,          # corrected semantics
        })
    return out


async def kill_run(run_id: str, escalate_seconds: int = 3) -> dict:
    """SIGTERM → wait → SIGKILL escalation on a single run.

    Targets the whole process group (claude may spawn children for tool exec).
    """
    rec = _ACTIVE_RUNS.get(run_id)
    if not rec:
        return {'ok': False, 'error': 'run not found', 'run_id': run_id}
    # BW_R80P79_PHASEB — mark terminal state before the kill takes effect
    _set_terminal_state(run_id, 'killed')
    proc = rec['proc']
    if proc.returncode is not None:
        _unregister_run(run_id)
        return {'ok': True, 'note': 'already exited',
                'run_id': run_id, 'returncode': proc.returncode}
    try:
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        except ProcessLookupError:
            pass
        try:
            await asyncio.wait_for(proc.wait(), timeout=escalate_seconds)
            _unregister_run(run_id)
            return {'ok': True, 'method': 'SIGTERM',
                    'run_id': run_id, 'returncode': proc.returncode}
        except asyncio.TimeoutError:
            pass
        try:
            os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
        except ProcessLookupError:
            pass
        await proc.wait()
        _unregister_run(run_id)
        return {'ok': True, 'method': 'SIGKILL',
                'run_id': run_id, 'returncode': proc.returncode}
    except Exception as e:
        return {'ok': False, 'error': repr(e), 'run_id': run_id}


async def kill_all_runs() -> list:
    """Kill every active run. Returns list of kill_run results."""
    results = []
    for rid in list(_ACTIVE_RUNS.keys()):
        results.append(await kill_run(rid))
    return results


def reap_orphan_claude_processes() -> list:
    """Scan for stale ``claude -p --output-format stream-json`` processes from
    previous API instances and SIGKILL them. 30-second "young" threshold avoids
    racing legitimate fresh runs.
    """
    import subprocess as _sp
    import re as _re
    try:
        out = _sp.run(['ps', '-eo', 'pid,etime,args'],
                      capture_output=True, text=True, timeout=5)
        reaped = []
        for line in out.stdout.splitlines():
            if 'claude -p' not in line or '--output-format stream-json' not in line:
                continue
            m = _re.match(r'\s*(\d+)\s+(\S+)\s+(.*)', line)
            if not m:
                continue
            pid = int(m.group(1))
            etime = m.group(2)
            # ps etime format: [[DD-]HH:]MM:SS. Plain seconds → no colon → young.
            if ':' not in etime:
                continue
            try:
                os.kill(pid, signal.SIGKILL)
                reaped.append({'pid': pid, 'etime': etime})
            except ProcessLookupError:
                pass
            except PermissionError:
                pass
        return reaped
    except Exception as e:
        return [{'error': repr(e)}]


# ── BW_R80P67 — MODE FLAG COMPOSITION + STRUCTURED REPORT ────────────────

# Six named modes (5 visible + Custom). Each preset declares an auto_approve
# tool set and a default token budget. Custom is operator-driven (None).
_MODE_FLAG_PRESETS = {
    'safe': {
        # Read-only. claude-code lacks a strict read-only flag; we pass an
        # empty allow-list so any write/shell tool errors and surfaces the
        # approval card client-side.
        'auto_approve': [],
        'budget_cap': 50_000,
    },
    'fix-patch': {
        # Single-file edits; nothing auto-approved.
        'auto_approve': [],
        'budget_cap': 100_000,
    },
    'standard': {
        # Default. Approval-gated. No auto-approval flags.
        'auto_approve': [],
        'budget_cap': 200_000,
    },
    'auto': {
        # Routine writes auto-approved; shell still gated.
        'auto_approve': ['Edit', 'Write', 'NotebookEdit'],
        'budget_cap': 500_000,
    },
    'yolo': {
        # All permissions skipped — uses --dangerously-skip-permissions.
        'auto_approve': '__SKIP_PERMS__',
        'budget_cap': 1_000_000,
    },
    'custom': {
        # Driven entirely by custom_flags + auto_approve_tools args.
        'auto_approve': None,
        'budget_cap': None,
    },
}


def _flags_for_mode(mode: str, intrusion_level: int, custom_flags: dict | None,
                    auto_approve_tools: list | None, tui: str) -> list[str]:
    """BW_R80P74I — Explicit mode → claude-code permission-flag mapping.

    Replaces the prior _MODE_FLAG_PRESETS-only mapping with direct flag emission.
    Mode names match the panel UI (BW_R80P67):
      safe       — full prompts, manual approval
      standard   — Read/Grep/Glob/Edit allowed; prompt for rest
      fix-patch  — --permission-mode acceptEdits + file-ops allowed
      auto       — --permission-mode auto (Anthropic classifier)
      yolo       — --dangerously-skip-permissions + PreToolUse hook safety net
      custom     — operator supplies custom_flags.extra_flags
    """
    flags: list[str] = []
    if tui != 'claude-code':
        # aider has its own flag grammar; engine-internal aider stream handles it.
        return flags

    if mode == 'yolo':
        flags.extend([
            '--dangerously-skip-permissions',
            '--disallowedTools',
            'Bash(rm -rf /:*),Bash(sudo:*),Bash(dd if=/dev/zero:*),Bash(mkfs.:*)'
        ])
    elif mode == 'auto':
        flags.extend(['--permission-mode', 'auto'])
    elif mode == 'fix-patch':
        flags.extend([
            '--permission-mode', 'acceptEdits',
            '--allowedTools',
            'Read,Grep,Glob,Edit,Write,Bash(cp:*),Bash(mv:*),Bash(mkdir:*),Bash(touch:*)',
        ])
    elif mode == 'standard':
        flags.extend(['--allowedTools', 'Read,Grep,Glob,Edit'])
    elif mode == 'safe':
        pass  # full prompts
    elif mode == 'custom':
        if custom_flags:
            extra = custom_flags.get('extra_flags') or []
            flags += [str(x) for x in extra]

    # auto_approve_tools (any mode): merge into existing --allowedTools or append
    if auto_approve_tools:
        new_tools = ','.join(auto_approve_tools)
        try:
            idx = flags.index('--allowedTools')
            flags[idx + 1] = flags[idx + 1] + ',' + new_tools
        except ValueError:
            flags.extend(['--allowedTools', new_tools])

    return flags


def budget_for_mode(mode: str, operator_override: int = 0) -> int:
    """Return the token budget for a mode, unless operator overrode it."""
    if operator_override and operator_override > 0:
        return operator_override
    preset = _MODE_FLAG_PRESETS.get(mode, _MODE_FLAG_PRESETS['standard'])
    return preset['budget_cap'] or 200_000


_STRUCTURED_REPORT_TEMPLATE = """\
Before executing, plan briefly. Then execute. When done, emit a final report
formatted as the following Markdown sections (each is required even if empty):

## Goal
(one sentence — what was asked)

## Plan
(numbered steps you intended to take)

## Files Touched
(bulleted list with absolute paths)

## Changes
(brief per-file summary of what changed and why)

## Verification
(what you ran to confirm; AST/syntax/test results if any)

## Next Steps
(anything deferred, unresolved, or flagged for operator)

---

OPERATOR REQUEST:

"""


def _wrap_with_structured_report(prompt: str) -> str:
    """Prepend the structured-report instruction to the operator's prompt."""
    return _STRUCTURED_REPORT_TEMPLATE + prompt


# BW_R80P67 — stream-json event parser. Translates one claude-code JSONL event
# into one or more Beewid SSE events. Yields nothing for events we ignore.
async def _parse_claude_event(ev: dict):
    """Translate a claude-code stream-json event into Beewid SSE event(s)."""
    et = ev.get('type', '')

    if et == 'system':
        yield {'type': 'system', 'subtype': ev.get('subtype', ''), 'data': ev}

    elif et == 'rate_limit_event':
        # BW_R80P77 — Rate-limit utilization from claude-code stream-json.
        # Claude-code emits these periodically; we surface warnings above 0.95
        # so the operator has advance notice before the hard 429 hits.
        util = ev.get('utilization') or 0
        resets_at = ev.get('resetsAt')
        surpassed = ev.get('surpassedThreshold')
        event = {
            'type': 'rate_limit_info',
            'utilization': util,
            'resets_at_unix': resets_at,
            'surpassed_threshold': surpassed,
        }
        yield event
        if util > 0.95:
            yield {
                'type': 'rate_limit_warning',
                'text': (f'[BW_R80P77] Rate limit at {util:.0%} — approaching hard limit. '
                         f'Window resets at unix {resets_at}. '
                         f'Consider pausing until window resets to avoid rc=1 death.'),
                'utilization': util,
                'resets_at_unix': resets_at,
            }

    elif et == 'assistant':
        msg = ev.get('message', {}) or {}
        for block in msg.get('content', []) or []:
            bt = block.get('type', '')
            if bt == 'text':
                yield {'type': 'text_delta', 'text': block.get('text', '')}
            elif bt == 'thinking':
                yield {'type': 'thinking',
                       'text': block.get('thinking', ''),
                       'signature': block.get('signature', '')}
            elif bt == 'tool_use':
                # BW_R80P79PT1A — Emit classification alongside the existing fields
                # so the frontend banner and the consumption loop (run_autocode_stream)
                # can read it without re-classifying. Function is module-level + pure.
                _tu_name = block.get('name', '')
                _tu_input = block.get('input', {}) or {}
                _tu_class = _bw_r80p79pt1a_classify_tool(_tu_name, _tu_input)
                yield {'type': 'tool_use',
                       'id': block.get('id', ''),
                       'name': _tu_name,
                       'input': _tu_input,
                       'classification': _tu_class}

    elif et == 'user':
        # Tool result envelope returned back to the model
        msg = ev.get('message', {}) or {}
        for block in msg.get('content', []) or []:
            if block.get('type') == 'tool_result':
                yield {'type': 'tool_result',
                       'tool_use_id': block.get('tool_use_id', ''),
                       'content': block.get('content', ''),
                       'is_error': block.get('is_error', False)}

    elif et == 'result':
        is_err = bool(ev.get('is_error', False))
        result_text = ev.get('result', '') or ''
        yield {'type': 'result_summary',
               'duration_ms': ev.get('duration_ms', 0),
               'cost_usd': ev.get('total_cost_usd', 0),
               'num_turns': ev.get('num_turns', 0),
               'is_error': is_err,
               'result': result_text}
        # Heuristic: detect permission errors so the UI can render an approval card.
        # BW_R80P74K — approval_id added so the panel can pair operator decisions
        # back to a specific request via /autocode/approval-response.
        if is_err and 'permission' in result_text.lower():
            import re as _re
            m = _re.search(r'tool\s+["\']?(\w+)["\']?', result_text, _re.I)
            if m:
                yield {'type': 'approval_request',
                       'tool_name': m.group(1),
                       'approval_id': uuid.uuid4().hex[:12]}

    else:
        yield {'type': 'unknown', 'subtype': et, 'data': ev}


# ── PUBLIC: RUN ─────────────────────────────────────────────────────────

async def run_autocode(
    prompt: str,
    tui: str = 'claude-code',
    backend: str = 'cloud-anthropic-proxy',  # BW_R80P59
    model: str = 'claude-sonnet-4-6',
    budget: int = 50000,
    api_key_override: str = '',
    timeout_seconds: int = 300,
    instance_id: str = 'main',         # BW_R80P60 — multi-instance hook
    intrusion_level: int = 1,          # BW_R80P60 — 0=read 1=approve 2=auto
    owner_tab_token: str = '',         # BW_R80P79_PHASEB — accepted for signature parity
) -> dict:
    """
    Execute an autocode run — TUI subprocess invocation with backend env wiring.

    Phase 2.A.1: matches existing /autocode/run behavior exactly.
    Returns the same shape the api.py endpoint used to return:
      {success, output, tokens_used, engine, tui, backend}
    """
    # Validate TUI
    spec = _TUI_REGISTRY.get(tui)
    if not spec:
        raise ValueError(f'Unknown TUI: {tui!r}')
    binary_path = shutil.which(spec['binary'])
    if not binary_path:
        raise FileNotFoundError(f'{tui} not found in PATH (binary={spec["binary"]!r})')

    # Resolve API key — vault first, then caller fallback
    api_key = resolve_api_key(backend, fallback=api_key_override)

    # Output paths — instance_id keeps multi-instance state isolated.
    # BW_R80P60 — tmpfile names include instance_id so concurrent runs from
    # different instances don't trample each other's output.
    safe_inst   = ''.join(c for c in instance_id if c.isalnum() or c in '-_')[:32] or 'main'
    out_file    = TMP_DIR / f'beewid_autocode_out_{safe_inst}.txt'
    prompt_file = TMP_DIR / f'beewid_autocode_prompt_{safe_inst}.txt'
    prompt_file.write_text(prompt, encoding='utf-8')

    # Env + cmd
    env = build_subprocess_env(tui, backend, api_key)
    auto_flags = spec.get('auto_flags_by_level', {}).get(intrusion_level, '')
    cmd = spec['cmd_template'].format(
        binary=binary_path,
        prompt_file=str(prompt_file),
        out_file=str(out_file),
        auto_flags=auto_flags,
    )

    # Spawn subprocess
    proc = None
    try:
        proc = await asyncio.create_subprocess_shell(
            cmd,
            cwd=str(COCKPIT_DIR),
            env=env,
            stdout=asyncio.subprocess.DEVNULL,
            stderr=asyncio.subprocess.DEVNULL,
        )
        await asyncio.wait_for(proc.wait(), timeout=timeout_seconds)
        output = out_file.read_text(encoding='utf-8') if out_file.exists() else '(no output)'
        return {
            'success':         proc.returncode == 0,
            'output':          output,
            'tokens_used':     min(len(output) // 4, budget),
            'engine':          ENGINE_VERSION,
            'tui':             tui,
            'backend':         backend,
            'instance_id':     instance_id,         # BW_R80P60
            'intrusion_level': intrusion_level,     # BW_R80P60
        }
    except asyncio.TimeoutError:
        if proc:
            try: proc.kill()
            except Exception: pass
        return {
            'success':         False,
            'output':          f'[TIMEOUT] Run exceeded {timeout_seconds}s',
            'tokens_used':     0,
            'engine':          ENGINE_VERSION,
            'tui':             tui,
            'backend':         backend,
            'instance_id':     instance_id,         # BW_R80P60
            'intrusion_level': intrusion_level,     # BW_R80P60
        }


async def run_autocode_stream(
    prompt: str,
    tui: str = 'claude-code',
    backend: str = 'cloud-anthropic-proxy',
    model: str = 'claude-sonnet-4-6',
    budget: int = 50000,
    api_key_override: str = '',
    timeout_seconds: int = 600,             # BW_R80P67 — was 300
    instance_id: str = 'main',
    intrusion_level: int = 1,
    mode: str = 'standard',                  # BW_R80P67
    custom_flags: dict | None = None,        # BW_R80P67
    auto_approve_tools: list | None = None,  # BW_R80P67
    structured_report: bool = True,          # BW_R80P67
    owner_tab_token: str = '',               # BW_R80P79_PHASEB
):
    """
    BW_R80P60 — Streaming variant of run_autocode. Yields events as they
    arrive from the TUI subprocess stdout/stderr. Caller wraps these as SSE.

    BW_R80P67 — claude-code path now uses --output-format=stream-json --verbose
    and parses JSONL events into structured Beewid events (text_delta,
    thinking, tool_use, tool_result, result_summary, approval_request).
    aider path is unchanged (line-based). OAuth direct mode no longer requires
    an api_key; claude-code reads ~/.claude/.credentials.json.
    """
    # Validate TUI
    spec = _TUI_REGISTRY.get(tui)
    if not spec:
        yield {'type': 'error', 'message': f'Unknown TUI: {tui!r}'}
        return
    binary_path = shutil.which(spec['binary'])
    if not binary_path:
        yield {'type': 'error', 'message': f'{tui} not found in PATH'}
        return

    # BW_R80P67 — OAuth mode: api_key may legitimately be empty (claude-code
    # reads ~/.claude/.credentials.json). Only error if proxy backend has no key.
    api_key = resolve_api_key(backend, fallback=api_key_override)
    backend_spec = _BACKEND_REGISTRY.get(backend, {})
    if backend_spec.get('use_proxy') and not api_key:
        yield {'type': 'error',
               'message': 'Proxy backend requires an API key (vault or override). Use direct mode for OAuth.'}
        return

    # BW_R80P67 — optional structured "report back" pre-prompt wrapping.
    effective_prompt = _wrap_with_structured_report(prompt) if structured_report else prompt

    safe_inst = ''.join(c for c in instance_id if c.isalnum() or c in '-_')[:32] or 'main'
    prompt_file = TMP_DIR / f'beewid_autocode_prompt_{safe_inst}.txt'
    prompt_file.write_text(effective_prompt, encoding='utf-8')

    env = build_subprocess_env(tui, backend, api_key)
    auto_flags_legacy = spec.get('auto_flags_by_level', {}).get(intrusion_level, '')
    # BW_R80P67 — mode-driven flag composition (supersedes the old auto_flags
    # string for claude-code; aider still uses the legacy intrusion-level map).
    mode_flags = _flags_for_mode(mode, intrusion_level, custom_flags, auto_approve_tools, tui)

    binary = binary_path

    yield {
        'type': 'meta',
        'engine': ENGINE_VERSION,
        'tui': tui,
        'backend': backend,
        'model': model,
        'instance_id': instance_id,
        'intrusion_level': intrusion_level,
        'mode': mode,
        'flags': mode_flags,
        'structured_report': structured_report,
        'oauth_mode': not bool(api_key) and not backend_spec.get('use_proxy'),
        'started_at': time.time(),
    }

    proc = None
    output_chars = 0
    run_id = uuid.uuid4().hex[:12]  # BW_R80P70 — track this run
    registered = False
    _bw_stderr_task = None  # BW_R80P73F — set after claude-code subprocess spawns
    _bw_r80p74k_pump_task = None  # BW_R80P74K — approval-decision pump task
    _bw_r80p77_result_text = ''    # BW_R80P77 — accumulate result text for rate-limit detection
    try:
        if tui == 'claude-code':
            # BW_R80P74E — Last-mile ANTHROPIC env clear. Strips all four keys
            # from the child env regardless of what build_subprocess_env set.
            # Forces claude-code onto its OAuth credentials chain
            # (~/.claude/.credentials.json, Max Plan) even if upstream backend
            # resolution or vault key resolution set a proxy URL or API key.
            # This is the final enforcement point — nothing after this can
            # redirect claude-code to the local proxy.
            for _bw_r80p74e_k in ('ANTHROPIC_API_KEY', 'ANTHROPIC_API_BASE',
                                    'ANTHROPIC_BASE_URL', 'ANTHROPIC_AUTH_TOKEN'):
                env.pop(_bw_r80p74e_k, None)

            # BW_R80P74I — Wire PreToolUse hook for Yolo mode. The hook script
            # at ~/.beewid/claude_code_pretooluse_hook.sh blocks destructive
            # patterns (rm -rf /, dd, mkfs.*, etc.) even when permissions are
            # bypassed. Safety net against model error / prompt injection.
            if mode == 'yolo':
                env['CLAUDE_HOOKS_DIR'] = str(Path.home() / '.beewid')

            # BW_R80P67 — exec form, stream-json, OAuth-friendly
            # BW_R80P70 — start_new_session=True for process-group isolation
            argv = [binary, '-p',
                    '--output-format', 'stream-json',
                    '--verbose',
                    '--model', model] + mode_flags
            # BW_R80P73E — Raise StreamReader limit from default 64KB to 10MB.
            # claude-code emits single-line JSON tool_results that can be much
            # larger than 64KB (e.g., reading a 100KB HTML file). Without this
            # raise, readline() on line 742 throws asyncio.LimitOverrunError
            # which was not caught, killing the run mid-stream with the
            # operator-observed [ERROR] Error in input stream. 10MB is a
            # generous ceiling — memory is held only briefly per line.
            proc = await asyncio.create_subprocess_exec(
                *argv,
                cwd=str(COCKPIT_DIR),
                env=env,
                stdin=asyncio.subprocess.PIPE,
                stdout=asyncio.subprocess.PIPE,
                stderr=asyncio.subprocess.PIPE,
                start_new_session=True,  # BW_R80P70 — own process group for killpg
                limit=BW_R80P73E_STREAM_LIMIT,  # BW_R80P73E
            )
            _register_run(run_id, proc, instance_id, tui, prompt,
                          owner_tab_token=owner_tab_token)  # BW_R80P79_PHASEB
            registered = True
            # BW_R80P79PT1A — Initialize partial-state tracker for this run.
            # api.py severance backstop reads this via _bw_r80p79pt1a_get_partial_state.
            try:
                _bw_r80p79pt1a_init_partial_state(run_id, prompt, instance_id, mode)
            except Exception:
                pass  # Defensive — tracking is best-effort
            yield {'type': 'run_started', 'run_id': run_id,
                   'pid': proc.pid, 'instance_id': instance_id, 'mode': mode}

            # BW_R80P73F — Parallel stderr reader. claude-code writes useful
            # info to stderr (OAuth refresh, startup messages, error notices)
            # that the engine previously discarded. We pump it into a shared
            # list and drain that list in the main read loop so those messages
            # appear inline in the panel. Non-fatal — never aborts the run.
            _bw_stderr_lines: list = []

            async def _bw_pump_stderr():
                try:
                    while True:
                        try:
                            _sl = await proc.stderr.readline()
                        except Exception:
                            return
                        if not _sl:
                            return  # EOF
                        _st = _sl.decode('utf-8', errors='replace').rstrip('\r\n')
                        if _st:
                            _bw_stderr_lines.append(_st)
                except asyncio.CancelledError:
                    return

            _bw_stderr_task = asyncio.create_task(_bw_pump_stderr())

            # BW_R80P74K — Approval pumper. Reads operator decisions from the
            # in-memory queue and writes them as JSON lines to claude-code's
            # stdin. Wakes every 1s to check returncode so it exits cleanly on
            # subprocess death. If stdin is already closed (current text-input
            # path), write attempts return and the task exits quietly — the
            # decision is still recorded for a future file-poll delivery path.
            _bw_r80p74k_pump_task = None

            async def _bw_r80p74k_pump_approvals():
                q = _bw_r80p74j_get_queue(instance_id)
                while True:
                    try:
                        try:
                            resp = await asyncio.wait_for(q.get(), timeout=1.0)
                        except asyncio.TimeoutError:
                            if proc.returncode is not None:
                                return
                            continue
                        try:
                            line = json.dumps(resp) + '\n'
                            if proc.stdin and not proc.stdin.is_closing():
                                proc.stdin.write(line.encode('utf-8'))
                                await proc.stdin.drain()
                        except Exception:
                            return
                    except asyncio.CancelledError:
                        return
                    except Exception:
                        try:
                            await asyncio.sleep(0.1)
                        except Exception:
                            return

            _bw_r80p74k_pump_task = asyncio.create_task(_bw_r80p74k_pump_approvals())

            # BW_R80P73F — Timestamp of last received stdout line; used to
            # detect hangs and emit heartbeat events (STEP 1).
            _bw_last_stdout_t = time.time()

            # Feed the (possibly wrapped) prompt via stdin
            try:
                proc.stdin.write(effective_prompt.encode('utf-8'))
                await proc.stdin.drain()
                proc.stdin.close()
            except Exception:
                pass

            deadline = time.time() + timeout_seconds
            while True:
                # BW_R80P74I — Ultra-defensive top-level try/except wrapping the
                # entire read-loop body. Any exception that escapes the nested
                # specific handlers (r80p73e LimitOverrunError, r80p73f Timeout,
                # parser bugs, yield consumer errors) becomes a [warn] event and
                # the stream continues. After r80p74i the only way the stream
                # ends is via 'done' event or subprocess death.
                try:
                    # BW_R80P73F — Drain any stderr lines buffered by the pump task.
                    while _bw_stderr_lines:
                        yield {'type': 'stderr', 'text': _bw_stderr_lines.pop(0)[:1024]}
                    if time.time() > deadline:
                        # BW_R80P70 — process-group kill on timeout
                        try:
                            os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                            await asyncio.wait_for(proc.wait(), timeout=3)
                        except (ProcessLookupError, asyncio.TimeoutError):
                            try:
                                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                            except ProcessLookupError:
                                pass
                        yield {'type': 'error',
                               'message': f'[TIMEOUT] Exceeded {timeout_seconds}s — subprocess killed',
                               'run_id': run_id}
                        break
                    try:
                        line_bytes = await asyncio.wait_for(proc.stdout.readline(), timeout=1.0)
                    except asyncio.TimeoutError:
                        if proc.returncode is not None:
                            break
                        # BW_R80P73F — Heartbeat
                        if time.time() - _bw_last_stdout_t >= BW_R80P73F_HEARTBEAT_TIMEOUT:
                            _bw_last_stdout_t = time.time()
                            yield {'type': 'heartbeat',
                                   'note': (f'no stdout for {BW_R80P73F_HEARTBEAT_TIMEOUT}s; '
                                            'subprocess still alive'),
                                   'pid': proc.pid}
                        continue
                    except asyncio.LimitOverrunError as _bw_loe:
                        # BW_R80P73E — oversized line: drain + warn + continue
                        try:
                            await proc.stdout.readexactly(_bw_loe.consumed)
                        except Exception:
                            pass
                        yield {'type': 'raw',
                               'text': (f'[warn BW_R80P73E] line exceeded '
                                        f'{BW_R80P73E_STREAM_LIMIT}-byte limit; skipped')}
                        continue
                    except Exception as _bw_re:
                        # BW_R80P73E — belt-and-suspenders read exception handler
                        yield {'type': 'raw',
                               'text': (f'[warn BW_R80P73E] stdout read: '
                                        f'{type(_bw_re).__name__}: {_bw_re}')}
                        if proc.returncode is not None:
                            break
                        continue
                    if not line_bytes:
                        break  # EOF
                    _bw_last_stdout_t = time.time()  # BW_R80P73F — reset heartbeat
                    line = line_bytes.decode('utf-8', errors='replace').rstrip('\n')
                    output_chars += len(line) + 1
                    # BW_TRIO_A1 — raw passthrough capture (best-effort; never raises into pump)
                    try:
                        _bw_trio_a1_raw_capture(run_id, line)
                    except Exception:
                        pass
                    if not line.strip():
                        continue
                    try:
                        raw = json.loads(line)
                        async for parsed in _parse_claude_event(raw):
                            # BW_R80P77 — capture result text for rate-limit detection
                            if parsed.get('type') == 'result_summary':
                                _bw_r80p77_result_text = parsed.get('result', '') or ''
                            # BW_R80P79PT1A — Track partial state by run_id so the
                            # api.py severance backstop can read it. tool_use marks
                            # the tool as in-flight; tool_result moves it to
                            # tools_completed. Wrapped in try/except — never block
                            # the yield path.
                            try:
                                _ps = _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.get(run_id)
                                if _ps is not None:
                                    _pt = parsed.get('type', '')
                                    if _pt == 'tool_use':
                                        # BW_R80P79PT1BFIX — Track multiple in-flight tools.
                                        # Single-slot tool_in_flight is kept as the most-recent
                                        # entry for backward compat with any existing readers.
                                        _tu_id = parsed.get('id', '')
                                        _tu_record = {
                                            'name': parsed.get('name', ''),
                                            'input': parsed.get('input', {}),
                                            'classification': parsed.get('classification', 'state_mutating'),
                                            'tool_use_id': _tu_id,
                                            'started_at': time.time(),
                                        }
                                        _ps.setdefault('tools_in_flight', {})
                                        _ps['tools_in_flight'][_tu_id] = _tu_record
                                        _ps['tool_in_flight'] = _tu_record  # back-compat alias
                                        _ps['last_event_type'] = 'tool_use'
                                        _ps['events_count'] += 1
                                    elif _pt == 'tool_result':
                                        # BW_R80P79PT1BFIX — Look up in-flight tool by
                                        # tool_use_id in the dict, NOT in the single-slot
                                        # legacy field. The dict supports parallel tool
                                        # execution; single-slot would have been overwritten
                                        # if 2+ tool_use events came back-to-back before any
                                        # tool_result arrived.
                                        _tif = _ps.setdefault('tools_in_flight', {})
                                        _rid = parsed.get('tool_use_id', '')
                                        _inflight = _tif.get(_rid)
                                        if _inflight:
                                            _content = parsed.get('content', '')
                                            _content_str = _content if isinstance(_content, str) else json.dumps(_content, default=str)
                                            _ps['tools_completed'].append({
                                                'name': _inflight.get('name', ''),
                                                'input': _inflight.get('input', {}),
                                                'classification': _inflight.get('classification', 'state_mutating'),
                                                'output_truncated': (_content_str or '')[:4096],
                                                'is_error': bool(parsed.get('is_error', False)),
                                                'completed_at': time.time(),
                                                'tool_use_id': _rid,
                                            })
                                            if _inflight.get('name') == 'TodoWrite':
                                                _ps['todo_state'] = (_inflight.get('input') or {}).get('todos')
                                            # Remove from in-flight dict
                                            _tif.pop(_rid, None)
                                            # Backward-compat: point single-slot at next
                                            # remaining in-flight tool, or None if empty.
                                            if _tif:
                                                _ps['tool_in_flight'] = next(iter(_tif.values()))
                                            else:
                                                _ps['tool_in_flight'] = None
                                        _ps['last_event_type'] = 'tool_result'
                                        _ps['events_count'] += 1
                                    elif _pt in ('text_delta', 'thinking', 'result_summary', 'system'):
                                        _ps['last_event_type'] = _pt
                                        _ps['events_count'] += 1
                            except Exception:
                                pass
                            yield parsed
                            # BW_R80P79PT1B — Force-severance check. If the diag
                            # flag was armed via /autocode/diag/force-severance,
                            # return from the generator after the first
                            # tool_result so PT1A partial state has content,
                            # and the api.py severance backstop fires.
                            # BW_R80P79PT1BFIX — Only consume the flag when there's
                            # at least one tool fully completed AND no other tools
                            # currently in-flight (so we tear at a clean boundary
                            # between turns, not mid-parallel-batch). This ensures
                            # the resulting partial state has something useful in
                            # tools_completed for the continuation prompt.
                            try:
                                if parsed.get('type') == 'tool_result':
                                    _ps_check = _BW_R80P79PT1A_PARTIAL_STATE_BY_RUN_ID.get(run_id) or {}
                                    _completed_count = len(_ps_check.get('tools_completed', []) or [])
                                    _inflight_count = len(_ps_check.get('tools_in_flight', {}) or {})
                                    if _completed_count >= 1 and _inflight_count == 0:
                                        if _bw_r80p79pt1b_check_and_consume_force_severance():
                                            return
                            except Exception:
                                pass
                    except json.JSONDecodeError:
                        # Non-JSON line (banner, etc.) — emit verbatim
                        yield {'type': 'raw', 'text': line}
                except Exception as _bw_r80p74i_top_e:
                    # BW_R80P74I — Catch-all. Yield a warn event, sleep briefly,
                    # break only if subprocess is gone. Anything else: continue.
                    _bw_r80p74i_msg = f'{type(_bw_r80p74i_top_e).__name__}: {str(_bw_r80p74i_top_e)[:300]}'
                    try:
                        yield {'type': 'warn',
                               'text': f'[BW_R80P74I] read-loop exception caught: {_bw_r80p74i_msg}'}
                    except Exception:
                        pass
                    try:
                        if proc and proc.returncode is not None:
                            yield {'type': 'error',
                                   'error': f'subprocess died with rc={proc.returncode}'}
                            break
                    except Exception:
                        break
                    try:
                        await asyncio.sleep(0.1)
                    except Exception:
                        break
                    continue

            # BW_R80P73F — Stop the stderr pump; drain any remaining buffered lines.
            # (Replaces the old one-shot proc.stderr.read() which could race the pump.)
            _bw_stderr_task.cancel()
            try:
                await _bw_stderr_task
            except (asyncio.CancelledError, Exception):
                pass
            while _bw_stderr_lines:
                yield {'type': 'stderr', 'text': _bw_stderr_lines.pop(0)[:1024]}

            rc = await proc.wait()

            # BW_R80P74K — rc=-9 diagnostic capture. When subprocess dies
            # abnormally, emit a subprocess_died event with signal name + last
            # stderr + memory snapshot so future failures self-diagnose. r80p74j
            # itself died with rc=-9 during an Edit; this prevents the next
            # mystery kill from being a guessing game.
            if rc != 0:
                diag = {
                    'returncode': rc,
                    'signal_name': None,
                    'last_stderr': '',
                    'memory_mb': None,
                }
                if rc < 0:
                    try:
                        signum = -rc
                        for _sn, _sv in vars(signal).items():
                            if (_sn.startswith('SIG') and not _sn.startswith('SIG_')
                                    and isinstance(_sv, int) and _sv == signum):
                                diag['signal_name'] = _sn
                                break
                    except Exception:
                        pass
                try:
                    if _bw_stderr_lines:
                        diag['last_stderr'] = '\n'.join(_bw_stderr_lines[-50:])[-3000:]
                except Exception:
                    pass
                try:
                    import psutil as _psutil_diag
                    _vm = _psutil_diag.virtual_memory()
                    diag['memory_mb'] = {
                        'available': _vm.available // 1024 // 1024,
                        'percent': _vm.percent,
                    }
                except ImportError:
                    pass
                except Exception:
                    pass
                _sig_suffix = f' ({diag["signal_name"]})' if diag['signal_name'] else ''
                yield {
                    'type': 'subprocess_died',
                    'text': f'[BW_R80P74K] subprocess died: rc={rc}{_sig_suffix}',
                    'diagnostic': diag,
                    'run_id': run_id,
                }

            # BW_R80P77 — Rate-limit post-mortem. rc=1 with 429 signals in
            # stderr or result text → surface a [rate_limited] event so the
            # operator sees the real cause instead of a silent rc=1 failure.
            # Full retry-respawn deferred (requires spawn-block restructure);
            # for now the event alone tells the operator exactly what happened
            # and when to retry manually.
            if rc == 1:
                _bw_r80p77_rl = _bw_r80p77_detect_rate_limit(
                    diag.get('last_stderr', '') if rc != 0 else '',
                    _bw_r80p77_result_text,
                )
                if _bw_r80p77_rl['detected']:
                    _bw_r80p77_sleep = min(
                        _bw_r80p77_rl.get('retry_after_seconds') or 30, 90)
                    yield {
                        'type': 'rate_limited',
                        'text': (f'[BW_R80P77] Rate limit detected in rc=1 exit. '
                                 f'retry-after hint: {_bw_r80p77_rl.get("retry_after_seconds") or "unknown"}s. '
                                 f'Wait ~{_bw_r80p77_sleep}s then re-run. '
                                 f'Msg: {_bw_r80p77_rl["message"][:200]}'),
                        'retry_after_seconds': _bw_r80p77_rl.get('retry_after_seconds'),
                        'suggested_wait_seconds': _bw_r80p77_sleep,
                        'run_id': run_id,
                    }

            yield {
                'type': 'done',
                'ok': rc == 0,
                'success': rc == 0,
                'returncode': rc,
                'tokens_used': min(output_chars // 4, budget),
                'engine': ENGINE_VERSION,
                'tui': tui,
                'backend': backend,
                'instance_id': instance_id,
                'intrusion_level': intrusion_level,
                'mode': mode,
                'run_id': run_id,  # BW_R80P70
            }
            return

        # ── aider / generic fallback (line-by-line, BW_R80P60 behavior preserved) ──
        if tui == 'aider':
            cmd = f'{binary} --no-show-model-warnings --message-file {prompt_file} {auto_flags_legacy}'
        else:
            cmd = f'{binary} {auto_flags_legacy}'

        stdin_target = asyncio.subprocess.DEVNULL
        proc = await asyncio.create_subprocess_shell(
            cmd,
            cwd=str(COCKPIT_DIR),
            env=env,
            stdin=stdin_target,
            stdout=asyncio.subprocess.PIPE,
            stderr=asyncio.subprocess.STDOUT,
        )

        deadline = time.time() + timeout_seconds
        while True:
            if time.time() > deadline:
                proc.kill()
                yield {'type': 'error', 'message': f'[TIMEOUT] Exceeded {timeout_seconds}s'}
                break
            try:
                line_bytes = await asyncio.wait_for(proc.stdout.readline(), timeout=1.0)
            except asyncio.TimeoutError:
                if proc.returncode is not None:
                    break
                continue
            if not line_bytes:
                break
            line = line_bytes.decode('utf-8', errors='replace').rstrip('\n')
            output_chars += len(line) + 1
            yield {'type': 'line', 'data': line}

        rc = await proc.wait()
        yield {
            'type': 'done',
            'ok': rc == 0,
            'success': rc == 0,
            'returncode': rc,
            'tokens_used': min(output_chars // 4, budget),
            'engine': ENGINE_VERSION,
            'tui': tui,
            'backend': backend,
            'instance_id': instance_id,
            'intrusion_level': intrusion_level,
            'mode': mode,
        }
    except asyncio.CancelledError:
        # BW_R80P70 — SSE client disconnect or upstream cancel: kill subprocess group
        if proc is not None and proc.returncode is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
                try:
                    await asyncio.wait_for(proc.wait(), timeout=3)
                except asyncio.TimeoutError:
                    try:
                        os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                    except ProcessLookupError:
                        pass
                    await proc.wait()
            except ProcessLookupError:
                pass
        raise
    except Exception as e:
        if proc is not None and proc.returncode is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
            except Exception:
                try: proc.kill()
                except Exception: pass
        yield {'type': 'error', 'message': f'Engine exception: {e}', 'run_id': run_id}
        yield {
            'type': 'done', 'ok': False, 'success': False, 'returncode': -1,
            'tokens_used': 0, 'engine': ENGINE_VERSION, 'tui': tui,
            'backend': backend, 'instance_id': instance_id, 'mode': mode,
            'run_id': run_id,
        }
    finally:
        # BW_R80P70 — guarantee no orphan + always unregister
        # BW_R80P73F — also cancel stderr pump task on any exit path
        # BW_R80P74K — also cancel approval pump task + drop the per-instance queue
        if _bw_stderr_task is not None and not _bw_stderr_task.done():
            _bw_stderr_task.cancel()
        if _bw_r80p74k_pump_task is not None and not _bw_r80p74k_pump_task.done():
            _bw_r80p74k_pump_task.cancel()
        try:
            _BW_R80P74J_APPROVAL_QUEUES.pop(instance_id, None)
        except Exception:
            pass
        if proc is not None and proc.returncode is None:
            try:
                os.killpg(os.getpgid(proc.pid), signal.SIGKILL)
                await proc.wait()
            except ProcessLookupError:
                pass
            except Exception:
                pass
        if registered:
            _unregister_run(run_id)


# ── BW_R80P67 — PER-RUN REPORT EXPORT ────────────────────────────────────

# BW_R80P79_SHIPREADY_FIX — Honest outcome classification + derived report titles.
# Operator's bug report: the ac_gpjhpo run halted on inventory mismatch (model
# said "HALT" and "No edits applied") but the report header said ✓ success
# because rc=0. A model-initiated halt is NOT a success — the model declined
# to proceed. Distinguish 4 outcomes:
#   - cancelled : operator killed the run
#   - failed    : non-zero return code, engine-lost, error event
#   - halted    : rc=0 but model output contains a clear halt/decline marker
#   - success   : rc=0 and no halt markers
# Heuristic: only labels halt on specific markers drawn from the actual
# ac_gpjhpo halt language. Conservative — false-labeling a real success as
# halted would be annoying, so the marker list is short and specific.

_BW_R80P79_HALT_MARKERS = (
    'HALT',                # ac_gpjhpo's literal token
    'halted',
    'halting',
    'do not proceed',
    'premise is wrong',
    'not in the state',
    'aborting',
    'plan was aborted',
    'no edits applied',
    'declining to',
    'i will not proceed',
    'cannot proceed',
)


def _bw_classify_outcome(rc, output_text: str = '', killed: bool = False,
                         engine_lost: bool = False) -> str:
    """BW_R80P79_SHIPREADY_FIX — classify run outcome honestly.
    Returns one of: 'cancelled' | 'failed' | 'halted' | 'success'."""
    if killed:
        return 'cancelled'
    if engine_lost:
        return 'failed'
    try:
        rc_int = int(rc)
    except (TypeError, ValueError):
        rc_int = -1  # unknown rc → treat as failure
    if rc_int != 0:
        return 'failed'
    # rc == 0: scan the assistant output for a clear model-initiated halt marker.
    low = (output_text or '').lower()
    for marker in _BW_R80P79_HALT_MARKERS:
        if marker.lower() in low:
            return 'halted'
    return 'success'


_BW_R80P79_OUTCOME_LABELS = {
    'success':   '✓ success',
    'halted':    '⊘ halted',
    'failed':    '✗ failed',
    'cancelled': '✕ cancelled',
}


def _bw_derive_report_title(prompt: str, goal: str = '', outcome: str = 'success') -> str:
    """BW_R80P79_SHIPREADY_FIX — scannable report title.

    Prefers the explicit Goal line (from the structured-report scaffold), falls
    back to the first non-empty non-header line of the operator prompt, truncated
    to 60 chars. Appended with the outcome label so the Recent Reports list
    surfaces 'List /tmp files — ✓ success' not just 'ac_xxx_timestamp.md'.
    """
    base = (goal or '').strip()
    if not base and prompt:
        for line in prompt.splitlines():
            line = line.strip()
            if line and not line.startswith('#'):
                base = line
                break
        if len(base) > 60:
            base = base[:60].rstrip() + '…'
    if not base:
        base = 'Autocode run'
    marker = _BW_R80P79_OUTCOME_LABELS.get(outcome, outcome)
    return f'{base} — {marker}'


def export_autocode_report(instance_id: str, prompt: str,
                           events: list, outcome: dict) -> dict:
    """Write a Markdown report of an autocode run to
    ``~/Downloads/beewid/vault/autocode_reports/``.

    Returns ``{ok, path, filename, size_bytes}`` on success, or
    ``{ok: False, error: str}`` on failure. Never raises.
    """
    from datetime import datetime
    import re as _re

    try:
        vault_root = Path('~/Downloads/beewid/vault').expanduser()
        report_dir = vault_root / 'autocode_reports'
        report_dir.mkdir(parents=True, exist_ok=True)

        safe_instance = _re.sub(r'[^a-z0-9_-]', '_', (instance_id or 'main').lower())[:32] or 'main'
        ts = datetime.now().strftime('%Y-%m-%d-%H%M%S')
        filename = f'{safe_instance}_{ts}.md'
        full_path = report_dir / filename

        # BW_R80P79_SHIPREADY_FIX — derive honest outcome + title from prompt + events.
        # Gather assistant text early so the classifier can scan it for halt markers.
        _assistant_text = ''.join(
            (e.get('text', '') or '') for e in (events or [])
            if e.get('type') == 'text_delta'
        )
        _classified = _bw_classify_outcome(
            rc=outcome.get('returncode'),
            output_text=_assistant_text,
            killed=bool(outcome.get('killed') or outcome.get('cancelled')),
            engine_lost=bool(outcome.get('engine_lost')),
        )
        # Preserve the legacy outcome.get('ok') boolean as a safety guard: if the
        # engine itself reported ok=False (e.g. exception during run), don't let
        # the classifier upgrade it to success.
        if not outcome.get('ok', True) and _classified == 'success':
            _classified = 'failed'
        # Try to extract the Goal line from the structured-report scaffold if present.
        _goal = ''
        for _line in _assistant_text.splitlines():
            _s = _line.strip()
            if _s.startswith('## Goal'):
                # next non-empty line is the goal text (scaffold puts it on the line after)
                continue
            if _s and not _s.startswith('#') and not _goal:
                # first non-empty non-header line — this only matters if we already saw '## Goal'
                # so we don't pick a random first line. Simple heuristic: only use if the
                # assistant text starts with the structured scaffold.
                pass
        # Simpler goal extraction: regex for '## Goal\n<text>' block in the assistant output.
        _goal_match = _re.search(r'^##\s*Goal\s*\n+([^\n#]+)', _assistant_text or '', _re.MULTILINE)
        if _goal_match:
            _goal = _goal_match.group(1).strip()
        _title = _bw_derive_report_title(prompt or '', goal=_goal, outcome=_classified)
        _outcome_label = _BW_R80P79_OUTCOME_LABELS.get(_classified, _classified)

        md: list[str] = []
        md.append(f'# Beewid Autocode Run — {safe_instance} @ {ts}')
        md.append('')
        # BW_R80P79_SHIPREADY_FIX — Title line. Parsed by api.py
        # /autocode/reports/recent for the Recent Reports list display.
        md.append(f'**Title**: {_title}')
        md.append(f'**Outcome**: {_outcome_label} '
                  f'(rc={outcome.get("returncode", "?")})')
        cost = outcome.get('cost_usd', 0) or 0
        dur = (outcome.get('duration_ms', 0) or 0) / 1000.0
        md.append(f'**Cost**: ${cost:.4f} | **Duration**: {dur:.1f}s')
        md.append(f'**Engine**: {ENGINE_VERSION}')
        md.append(f'**Mode**: {outcome.get("mode", "?")}')
        md.append('')

        md.append('## Operator Prompt')
        md.append('```')
        md.append((prompt or '')[:8000])
        if prompt and len(prompt) > 8000:
            md.append(f'(truncated; original {len(prompt)} chars)')
        md.append('```')
        md.append('')

        tool_uses = [e for e in events if e.get('type') == 'tool_use']
        text_blocks = [e.get('text', '') for e in events if e.get('type') == 'text_delta']
        thinking = [e.get('text', '') for e in events if e.get('type') == 'thinking']
        errors = [e for e in events if e.get('type') in ('error', 'stderr')]

        md.append('## Files Touched / Tool Uses')
        if not tool_uses:
            md.append('_(none)_')
        else:
            for tu in tool_uses:
                inp = str(tu.get('input', {}))[:300]
                md.append(f'- **{tu.get("name", "?")}** — input: `{inp}`')
        md.append('')

        md.append('## Assistant Text')
        md.append('```')
        md.append((''.join(text_blocks))[:8000] or '(empty)')
        md.append('```')
        md.append('')

        if thinking:
            md.append('## Thinking blocks')
            md.append(f'{len(thinking)} thinking block(s) captured; '
                      f'total {sum(len(t) for t in thinking)} chars.')
            md.append('')

        if errors:
            md.append('## Errors / stderr')
            for e in errors:
                msg = (e.get('message') or e.get('text') or '')[:500]
                md.append(f'- {e.get("type")}: `{msg}`')
            md.append('')

        md.append('---')
        md.append(f'_Total events: {len(events)}. '
                  f'Generated by Beewid autocode engine {ENGINE_VERSION}._')

        text = '\n'.join(md)
        full_path.write_text(text, encoding='utf-8')
        return {'ok': True, 'path': str(full_path),
                'filename': filename, 'size_bytes': len(text.encode())}
    except Exception as e:
        return {'ok': False, 'error': str(e)}


async def run_fix_patch(
    broken_patch: str,
    error_output: str = '',
    target_filename: str = 'beewid_api.py',
    api_key_override: str = '',
    intrusion_level: int = 1,
    backend: str = 'cloud-anthropic-proxy',  # BW_R80P59 (was cloud-anthropic-direct)
    model: str = 'claude-sonnet-4-6',
    scrub_callback: Optional[Callable[[str], str]] = None,
    log_callback: Optional[Callable[[str], None]] = None,
) -> dict:
    """
    Repair a broken patch script using cloud Sonnet.

    BW_R80P59 — Default backend is now 'cloud-anthropic-proxy'. In proxy mode
    the request goes to Beewid's local /anthropic_proxy/v1/messages, which
    applies _scrub_for_cloud at Layer 3. The scrub_callback parameter is now
    only invoked in direct mode (proxy mode does its own scrub server-side).

    Backwards-compat: callers may pass backend='cloud-anthropic-direct' for the
    legacy behavior. The api.py shim does this on opt-in.
    """
    import httpx

    if not broken_patch.strip():
        raise ValueError('broken_patch required')

    spec = _BACKEND_REGISTRY.get(backend)
    if not spec:
        raise ValueError(f'Unknown backend: {backend!r}')
    use_proxy = bool(spec.get('use_proxy'))

    # Resolve key — proxy.token if proxy mode, vault Anthropic key if direct
    api_key = resolve_api_key(backend, fallback=api_key_override)
    if not api_key:
        if use_proxy:
            raise ValueError('proxy.token missing — check ~/.beewid/proxy.token')
        raise ValueError('api_key required — save it in Autocode → Credentials')

    # Read target file context (first 300 lines — protect token budget)
    target_path = COCKPIT_DIR / target_filename
    target_context = ''
    if target_path.exists() and target_path.suffix in ('.py', '.js', '.html', '.css'):
        try:
            lines = target_path.read_text(encoding='utf-8').splitlines()
            target_context = '\n'.join(lines[:300])
        except Exception:
            target_context = '(could not read target file)'
    else:
        target_context = f'(target file {target_filename!r} not found in cockpit)'

    # Build prompt (identical to original)
    prompt = (
        'You are a Python patch script repair specialist for the Beewid project.\n\n'
        '## BROKEN PATCH SCRIPT\n'
        '```python\n' + broken_patch + '\n```\n\n'
        '## ERROR OUTPUT (from running the broken patch)\n'
        '```\n' + (error_output or '(no error output provided)') + '\n```\n\n'
        '## TARGET FILE CONTEXT (first 300 lines of ' + target_filename + ')\n'
        '```python\n' + target_context + '\n```\n\n'
        '## TASK\n'
        'Return a CORRECTED version of the patch script that will succeed.\n\n'
        'RULES:\n'
        '1. The most common failure: OLD marker string does not exactly match file content.\n'
        '   Find the correct string in the target file context and update OLD accordingly.\n'
        '2. Every fix must: check if OLD in src, print "Fix N OK" or "FIX N FAILED", sys.exit(1) if FAILED\n'
        '3. Create a .bak file before writing\n'
        '4. AST validate if target is a .py file\n'
        '5. Never write the output file if ANY fix has FAILED\n\n'
        'Return ONLY the corrected Python script. No markdown fences. No explanation. '
        'Start with the shebang line or the docstring.'
    )

    if log_callback:
        mode = 'proxy' if use_proxy else 'direct'
        log_callback(f'[FIX-PATCH] target={target_filename} level={intrusion_level} mode={mode}')

    # In direct mode, apply caller-provided scrub callback. In proxy mode the
    # proxy handles scrub server-side, so we skip the callback (it would
    # double-scrub or fight with the proxy's audit log).
    if scrub_callback and not use_proxy:
        try:
            prompt = scrub_callback(prompt)
        except Exception as e:
            if log_callback:
                log_callback(f'[SCRUB] WARN failed: {e}')

    # Pick endpoint URL based on backend mode
    if use_proxy:
        endpoint = PROXY_BASE_URL + '/v1/messages'
    else:
        endpoint = 'https://api.anthropic.com/v1/messages'

    # Anthropic API call (proxy or direct — request shape is identical)
    try:
        async with httpx.AsyncClient(timeout=90) as client:
            r = await client.post(
                endpoint,
                headers={
                    'x-api-key':         api_key,
                    'anthropic-version': '2023-06-01',
                    'content-type':      'application/json',
                },
                json={
                    'model':      model,
                    'max_tokens': 4096,
                    'messages':   [{'role': 'user', 'content': prompt}],
                },
            )
    except Exception as e:
        raise RuntimeError(f'Anthropic API error: {e}')

    if r.status_code != 200:
        raise RuntimeError(f'Anthropic returned {r.status_code}: {r.text[:200]}')

    data = r.json()
    fixed_patch = ''
    for block in data.get('content', []):
        if block.get('type') == 'text':
            fixed_patch += block['text']
    fixed_patch = fixed_patch.strip()
    if not fixed_patch:
        raise RuntimeError('Sonnet returned empty response')

    # Save (intrusion_level >= 1)
    saved_as = None
    apply_output = None
    applied = False

    if intrusion_level >= 1:
        ts = int(time.time())
        fixed_name = f'patch_fixed_{ts}.py'
        fixed_path = COCKPIT_DIR / fixed_name
        fixed_path.write_text(fixed_patch, encoding='utf-8')
        saved_as = fixed_name
        if log_callback:
            log_callback(f'[FIX-PATCH] Fixed patch saved as {fixed_name}')

    # Auto-apply (intrusion_level >= 2)
    if intrusion_level >= 2 and saved_as:
        import subprocess
        result = subprocess.run(
            ['python3', saved_as],
            capture_output=True, text=True, cwd=str(COCKPIT_DIR), timeout=60,
        )
        apply_output = result.stdout + result.stderr
        applied = True
        if log_callback:
            log_callback(f'[FIX-PATCH] Auto-applied: rc={result.returncode}')

    return {
        'ok':           True,
        'fixed_patch':  fixed_patch,
        'saved_as':     saved_as,
        'applied':      applied,
        'apply_output': apply_output,
        'tokens_used':  data.get('usage', {}).get('output_tokens', 0),
        'mode':         'proxy' if use_proxy else 'direct',
        'engine':       ENGINE_VERSION,
    }


# End of beewid_autocode_engine.py — BW_R80P60 (was BW_R80P59)
