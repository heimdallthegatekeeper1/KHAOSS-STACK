@echo off
REM BW_R80P79_STANDALONE_PKG - Beewid Autocode Standalone launcher (Windows cmd)
REM First run: creates .venv + installs requirements. Subsequent runs: just boots.
cd /d "%~dp0"

REM BW_STANDALONE_DIST=1 tells the server to inject ?dist=1 into its /popout
REM redirect, which the instance.html then reads to mark "BEEWID ONLY" features.
set BW_STANDALONE_DIST=1

if not exist ".venv" (
  echo First run - setting up Python virtual environment ^(one-time, ~30s^)...
  python -m venv .venv
  if errorlevel 1 (
    echo.
    echo ERROR: python not found. Install Python 3.10+ from https://python.org
    pause
    exit /b 1
  )
  .venv\Scripts\pip install --quiet --upgrade pip
  .venv\Scripts\pip install --quiet -r requirements.txt
  echo Setup complete.
)

if not defined BEEWID_STANDALONE_AUTOCODE_PORT set BEEWID_STANDALONE_AUTOCODE_PORT=8508

echo.
echo ================================================================
echo   Beewid Autocode Standalone
echo   ^> http://127.0.0.1:%BEEWID_STANDALONE_AUTOCODE_PORT%
echo   Ctrl+C to stop
echo ================================================================
echo.
.venv\Scripts\python beewid_autocode_standalone_server.py --port %BEEWID_STANDALONE_AUTOCODE_PORT%
pause
