# Beewid Autocode — Standalone

A self-contained autocode dispatch runner with bulletproof reliability:
triple-redundancy, SSE reconnect with sequence replay, engine-lost detection,
honest run outcomes, dual-key safety gating for Yolo mode.

This is the standalone distribution — the autocode engine, sub-tab manager,
and UI bundled into a single directory that runs without the rest of the
Beewid stack.

---

## Quick start

| Platform | Action |
|---|---|
| **Windows** (cmd) | Double-click `run.bat` |
| **Windows** (PowerShell) | Right-click `run.ps1` → Run with PowerShell |
| **Mac / Linux** | `./run.sh` (or double-click if your file manager runs `.sh`) |

First run creates a Python virtual environment in `.venv/` and installs the
small set of dependencies (~30 seconds). Subsequent runs just boot.

Then open <http://127.0.0.1:8508> in your browser.

To change the port: set `BEEWID_STANDALONE_AUTOCODE_PORT` before launching
(e.g. `BEEWID_STANDALONE_AUTOCODE_PORT=8520 ./run.sh`).

---

## Requirements

- **Python 3.10+** (3.13 tested)
- **`claude` CLI** installed and authenticated — this is the dispatch engine.
  Get it from <https://docs.claude.com/en/docs/claude-code> or your package
  manager. Verify with `claude --version`.

---

## What's bulletproof about it

- **Triple-redundancy serving** — even in standalone, the SSE stream uses
  sequence-tracked reconnect logic; an interrupted stream resumes from the
  last seen sequence number instead of restarting.
- **Engine-lost detection** — the UI distinguishes a hang from a real
  failure via pid-liveness + event-staleness checks.
- **Honest run outcomes** — reports use one of `✓ success`, `⊘ halted`,
  `✗ failed`, `✕ cancelled` (not just rc=0 as success).
- **Dual-key arming for Yolo mode** — Yolo (auto-approve all) requires
  explicit arming; arm persists across reloads and turns until you uncheck
  it or switch modes.
- **Resource chip** — live CPU/RAM/threads of the run subprocess, color-coded
  by load (green / amber / red), pulse animation during streaming.

---

## Important notes

### ⚠️ "Engine lost contact" that recovers is NORMAL

If you see an engine-lost banner during a run but the run then reconnects and
finishes (✓ success), that's the triple-redundancy + EventSource reconnect
working as **designed** — not a failure. The standalone has its own
run-stream proxy fallback for resilience.

Only treat engine-lost as a real problem if the run does **not** recover and
does **not** finish.

### Features marked "BEEWID ONLY"

A few features require the full Beewid stack and aren't available standalone:

- **Hand to W5/W6** — needs the W5/W6 local-model agents
- (More marked "BEEWID ONLY" if/when their backend isn't reachable)

Capture Diag still works (browser download); Diagnose Autocode still works
(local state inspection). Their full Beewid-vault integrations gracefully
fail-fast through the standalone's proxy (2.5s timeout) when the full Beewid
API isn't there.

---

## What's in this directory

```
beewid_autocode_standalone_server.py    The Starlette server (port 8508 by default)
beewid_autocode.html                     Sub-tab manager (multi-instance UI)
beewid_autocode_instance.html            The autocode UI (one per tab, in iframe)
beewid_autocode_engine.py                The dispatch engine (spawns claude-code)
beewid_core.js                           Shared cockpit JS (chrome injection)
beewid_theme.css                         Shared cockpit theme
requirements.txt                         Python deps (starlette / uvicorn / httpx / python-multipart)
run.sh                                   Linux/Mac launcher
run.bat                                  Windows cmd launcher
run.ps1                                  Windows PowerShell launcher
README.md                                You are here
```

The launcher sets `BW_STANDALONE_DIST=1` which tells the server to inject
`?dist=1` into the popout redirect — that's the signal the UI uses to mark
"BEEWID ONLY" features.

---

## Logs

The server writes per-port logs to `../../logs/standalone_<port>.log`
(relative to the cockpit directory). In this packaged dist, that resolves to
`logs/standalone_8508.log` next to this README.

---

## Troubleshooting

| Symptom | Likely cause |
|---|---|
| `python: command not found` | Install Python 3.10+ from <https://python.org> |
| `claude: command not found` | Install the Claude CLI (see Requirements) |
| Port 8508 already in use | Set `BEEWID_STANDALONE_AUTOCODE_PORT=8509` (or any free port) |
| Engine-lost banner that DOESN'T recover | Check `logs/standalone_8508.log` for the actual error |

---

🐝 Beewid — "If-Need-Bee"

Part of the KHAOSS toolkit. Standalone packaging: `r80p79-STANDALONE-PKG` (2026-05-23).
