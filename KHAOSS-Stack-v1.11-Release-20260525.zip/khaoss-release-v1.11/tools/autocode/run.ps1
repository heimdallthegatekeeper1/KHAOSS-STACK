# BW_R80P79_STANDALONE_PKG — Beewid Autocode Standalone launcher (PowerShell)
# First run: creates .venv + installs requirements. Subsequent runs: just boots.
Set-Location $PSScriptRoot

# BW_STANDALONE_DIST=1 tells the server to inject ?dist=1 into its /popout
# redirect, which the instance.html then reads to mark "BEEWID ONLY" features.
$env:BW_STANDALONE_DIST = "1"

if (-not (Test-Path ".venv")) {
    Write-Host "First run - setting up Python virtual environment (one-time, ~30s)..."
    try {
        python -m venv .venv
    } catch {
        Write-Host ""
        Write-Host "ERROR: python not found. Install Python 3.10+ from https://python.org" -ForegroundColor Red
        Read-Host "Press Enter to exit"
        exit 1
    }
    & .\.venv\Scripts\pip install --quiet --upgrade pip
    & .\.venv\Scripts\pip install --quiet -r requirements.txt
    Write-Host "Setup complete."
}

$port = if ($env:BEEWID_STANDALONE_AUTOCODE_PORT) { $env:BEEWID_STANDALONE_AUTOCODE_PORT } else { "8508" }

Write-Host ""
Write-Host "================================================================"
Write-Host "  Beewid Autocode Standalone"
Write-Host "  -> http://127.0.0.1:$port"
Write-Host "  Ctrl+C to stop"
Write-Host "================================================================"
Write-Host ""
& .\.venv\Scripts\python beewid_autocode_standalone_server.py --port $port
