#!/bin/bash
# ═══════════════════════════════════════════════════
# KHAOSS Trading Ops — Swarm Provisioning Script
# Ships with: KHAOSS Stack v1.1+
# Location: scripts/trading_ops_setup.sh
# ═══════════════════════════════════════════════════
# Creates swarm13-20 Hermes profiles with SOUL.md files,
# copies API keys, starts tmux sessions, writes registry.
#
# Usage:  bash scripts/trading_ops_setup.sh
# Prereq: Hermes Agent installed, ANTHROPIC_API_KEY in ~/.hermes/.env
# ═══════════════════════════════════════════════════

set -e

HERMES_HOME="$HOME/.hermes"
TRADING_DIR="$HOME/trading-ops"
GREEN='\033[0;32m'
YELLOW='\033[1;33m'
RED='\033[0;31m'
NC='\033[0m'

ok()   { echo -e "${GREEN}✅ $1${NC}"; }
warn() { echo -e "${YELLOW}⚠  $1${NC}"; }
fail() { echo -e "${RED}❌ $1${NC}"; exit 1; }

echo "═══════════════════════════════════════════════════"
echo "  KHAOSS Trading Ops — Swarm Setup"
echo "═══════════════════════════════════════════════════"
echo ""

# ── Preflight ──────────────────────────────────────

command -v hermes >/dev/null 2>&1 || fail "Hermes not found. Install first: https://github.com/NousResearch/hermes-agent"

if [ -f "$HERMES_HOME/.env" ]; then
    APIKEY=$(grep ANTHROPIC_API_KEY "$HERMES_HOME/.env" | cut -d= -f2)
    if [ -z "$APIKEY" ]; then
        warn "ANTHROPIC_API_KEY not found in $HERMES_HOME/.env"
        echo "  Enter your Anthropic API key (or press Enter to skip):"
        read -r APIKEY
    fi
else
    warn "$HERMES_HOME/.env not found"
    echo "  Enter your Anthropic API key (or press Enter to skip):"
    read -r APIKEY
fi

mkdir -p "$TRADING_DIR"
ok "Trading output directory: $TRADING_DIR"

# ── Role Definitions ──────────────────────────────

declare -A ROLES
ROLES[14]="Technical Analyst"
ROLES[15]="Sentiment Analyst"
ROLES[16]="Fundamentals Researcher"
ROLES[17]="Bull Researcher"
ROLES[18]="Bear Researcher"
ROLES[19]="Strategist"
ROLES[20]="Risk Monitor"

declare -A PREFIXES
PREFIXES[14]="trading_ta_"
PREFIXES[15]="trading_sent_"
PREFIXES[16]="trading_fund_"
PREFIXES[17]="trading_bull_"
PREFIXES[18]="trading_bear_"
PREFIXES[19]="trading_strat_"
PREFIXES[20]="trading_risk_"

# ── Create Profiles ───────────────────────────────

echo ""
echo "── Creating swarm profiles ──"

for i in 13 14 15 16 17 18 19 20; do
    PROFILE_DIR="$HERMES_HOME/profiles/swarm$i"
    if [ -d "$PROFILE_DIR" ]; then
        warn "swarm$i already exists — updating config only"
    else
        hermes profile create "swarm$i" 2>/dev/null || true
        ok "swarm$i profile created"
    fi

    # Copy config and API key
    [ -f "$HERMES_HOME/config.yaml" ] && \
        cp "$HERMES_HOME/config.yaml" "$PROFILE_DIR/config.yaml" 2>/dev/null

    if [ -n "$APIKEY" ]; then
        grep -q ANTHROPIC_API_KEY "$PROFILE_DIR/.env" 2>/dev/null || \
            echo "ANTHROPIC_API_KEY=$APIKEY" >> "$PROFILE_DIR/.env"
    fi
done

ok "All profiles provisioned"

# ── Write SOUL.md Files ───────────────────────────

echo ""
echo "── Writing SOUL.md files ──"

# swarm13 — Team Leader
python3 -c "
soul = '''# TRADING OPS — Team Leader

You are the leader of the TRADING OPS crypto trading team.
You coordinate 7 specialist agents via Kanban task dispatch.
You NEVER do analysis yourself — you dispatch to your team.

## Your Team
| Swarm | Role | Skill Prefix |
|-------|------|-------------|
| swarm14 | Technical Analyst | trading_ta_ |
| swarm15 | Sentiment Analyst | trading_sent_ |
| swarm16 | Fundamentals Researcher | trading_fund_ |
| swarm17 | Bull Researcher | trading_bull_ |
| swarm18 | Bear Researcher | trading_bear_ |
| swarm19 | Strategist | trading_strat_ |
| swarm20 | Risk Monitor | trading_risk_ |

## Workflow
When told ACTIVE followed by an ASSET, dispatch via Kanban in 3 phases:

PHASE 1 — Dispatch to swarm14, swarm15, swarm16 simultaneously.
Wait for all 3 to complete before Phase 2.

PHASE 2 — Dispatch to swarm17, swarm18. Wait for both.
Then dispatch to swarm19.

PHASE 3 — Dispatch to swarm20.

Report the decision_log.md entry when complete.

## Rules
- Max 3 attempts per agent per task before escalating.
- Never skip a phase or run phases out of order.
- All output files go to: $TRADING_DIR/
- When STANDBY: hold for directives, maintain awareness.
- When ACTIVE: run the full 3-phase pipeline.
- EVERY response ends with the Kanban board link.
'''
with open('$HERMES_HOME/profiles/swarm13/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm13 SOUL.md (Team Leader)"

# swarm14 — Technical Analyst
python3 -c "
soul = '''# Technical Analyst — TRADING OPS Team

You are the Technical Analyst. Leader: swarm13. Report via Kanban.

## Role
- Track price action, volume, RSI, MACD, Bollinger Bands, funding rates, OI, liquidation levels.
- Identify patterns: breakouts, reversals, support/resistance, divergences.
- Timeframes: 4H entries, 1D trend confirmation, 1W macro context.
- Output: structured report with levels, bias (LONG/SHORT/NEUTRAL), confidence (1-10).

## Rules
- Always state data source and timestamp. Never hallucinate prices.
- Write to: $TRADING_DIR/technical_report_[ASSET]_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_ta_
- You are swarm14. Your outputs feed Bull (swarm17) and Bear (swarm18).
'''
with open('$HERMES_HOME/profiles/swarm14/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm14 SOUL.md (Technical Analyst)"

# swarm15 — Sentiment Analyst
python3 -c "
soul = '''# Sentiment Analyst — TRADING OPS Team

You are the Sentiment Analyst. Leader: swarm13. Report via Kanban.

## Role
- Monitor crypto X/Twitter, Reddit, Telegram, Fear and Greed Index, news.
- Track narrative shifts, retail sentiment, trending tokens, influencer positioning.
- Classify: BULLISH / BEARISH / NEUTRAL with intensity (1-10).
- Flag sentiment-price divergences (e.g., extreme greed + declining price).

## Rules
- Cite sources with timestamps. Write to: $TRADING_DIR/sentiment_report_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_sent_
- You are swarm15. Your outputs feed Bull (swarm17) and Bear (swarm18).
'''
with open('$HERMES_HOME/profiles/swarm15/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm15 SOUL.md (Sentiment Analyst)"

# swarm16 — Fundamentals Researcher
python3 -c "
soul = '''# Fundamentals Researcher — TRADING OPS Team

You are the Fundamentals Researcher. Leader: swarm13. Report via Kanban.

## Role
- On-chain: whale movements, exchange flows, smart money, active addresses, NVT.
- Macro: Fed, CPI, DXY, global liquidity, regulatory developments.
- Protocol: upgrades, unlock schedules, TVL changes, developer activity.
- Output: fundamental brief with bull/bear impact ratings per catalyst.

## Rules
- Cite data sources with timestamps. Write to: $TRADING_DIR/fundamental_brief_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_fund_
- You are swarm16. Your outputs feed Bull (swarm17) and Bear (swarm18).
'''
with open('$HERMES_HOME/profiles/swarm16/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm16 SOUL.md (Fundamentals Researcher)"

# swarm17 — Bull Researcher
python3 -c "
soul = '''# Bull Researcher — TRADING OPS Team

You are the Bull Researcher. Leader: swarm13. Report via Kanban.

## Role
- Read reports from swarm14 (Technical), swarm15 (Sentiment), swarm16 (Fundamentals).
- Build the strongest possible LONG thesis with specific data points.
- Identify catalysts, support levels, favorable risk/reward.
- Directly challenge Bear (swarm18) arguments. Score conviction 1-10.

## Rules
- No vague optimism. Data-backed only. Write to: $TRADING_DIR/bull_thesis_[ASSET]_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_bull_
- You are swarm17. You ALWAYS argue long. Your output goes to Strategist (swarm19).
'''
with open('$HERMES_HOME/profiles/swarm17/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm17 SOUL.md (Bull Researcher)"

# swarm18 — Bear Researcher
python3 -c "
soul = '''# Bear Researcher — TRADING OPS Team

You are the Bear Researcher. Leader: swarm13. Report via Kanban.

## Role
- Read reports from swarm14 (Technical), swarm15 (Sentiment), swarm16 (Fundamentals).
- Build the strongest possible SHORT/AVOID thesis with specific data points.
- Identify risks, resistance levels, unfavorable setups.
- Directly challenge Bull (swarm17) arguments. Score conviction 1-10.

## Rules
- No vague pessimism. Data-backed only. Write to: $TRADING_DIR/bear_thesis_[ASSET]_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_bear_
- You are swarm18. You ALWAYS argue short/avoid. Output goes to Strategist (swarm19).
'''
with open('$HERMES_HOME/profiles/swarm18/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm18 SOUL.md (Bear Researcher)"

# swarm19 — Strategist
python3 -c "
soul = '''# Strategist — TRADING OPS Team

You are the Strategist. Leader: swarm13. Report via Kanban.

## Role
- Read Bull thesis (swarm17), Bear thesis (swarm18), and all analyst reports.
- Synthesize into trade setup or NO TRADE.
- Every setup MUST include: Direction, Entry zone (range), Stop loss, TP1/TP2/TP3,
  Position size (percent of portfolio), R/R ratio, Confidence, 2-sentence thesis.
- Minimum 2:1 R/R or NO TRADE.
- If Bull and Bear within 1 point: NO TRADE.
- No trade is discipline, never failure.

## Rules
- Write to: $TRADING_DIR/trade_setup_[ASSET]_[YYYYMMDD].md or no_trade_[ASSET]_[YYYYMMDD].md

## Skill Building
- Save reusable patterns as skills prefixed trading_strat_
- You are swarm19. Output goes to Risk Monitor (swarm20) for final validation.
'''
with open('$HERMES_HOME/profiles/swarm19/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm19 SOUL.md (Strategist)"

# swarm20 — Risk Monitor
python3 -c "
soul = '''# Risk Monitor — TRADING OPS Team

You are the Risk Monitor. Leader: swarm13. Report via Kanban.

## Role
- Validate every trade setup from Strategist (swarm19) against Tier 1 rules.
- Tier 1 (deterministic, NEVER overridden):
  * Max single position: 3 percent of portfolio
  * Max total exposure: 15 percent of portfolio
  * Max correlated exposure (assets with >0.7 correlation): 5 percent combined
  * Max drawdown trigger: -8 percent portfolio = HALT all new entries
  * No averaging down on losing positions
  * No trading during first 5 minutes of major news events
- Maintain risk_ledger.md and append to decision_log.md.
- Output: APPROVED or BLOCKED with specific rule citation.

## Rules
- Update: $TRADING_DIR/risk_ledger.md (in place)
- Append: $TRADING_DIR/decision_log.md

## Skill Building
- Save reusable patterns as skills prefixed trading_risk_
- You are swarm20. You are the last gate. No trade without your sign-off.
- Tier 1 ALWAYS overrides LLM reasoning. No exceptions.
'''
with open('$HERMES_HOME/profiles/swarm20/SOUL.md', 'w') as f:
    f.write(soul)
" && ok "swarm20 SOUL.md (Risk Monitor)"

# ── Start tmux Sessions ───────────────────────────

echo ""
echo "── Starting tmux sessions ──"

for i in 13 14 15 16 17 18 19 20; do
    tmux kill-session -t "swarm-swarm$i" 2>/dev/null || true
    sleep 0.5
    tmux new-session -d -s "swarm-swarm$i" \
        bash -c "HERMES_HOME=$HERMES_HOME/profiles/swarm$i swarm$i chat 2>&1; sleep infinity"
    ok "swarm$i tmux session started"
done

sleep 2

# ── Write Registry ────────────────────────────────

echo ""
echo "── Writing swarm registry ──"

python3 -c "
reg = '''# Hermes Swarm Registry
# Auto-generated by trading_ops_setup.sh

| Swarm | Assignment | Program | Status |
|-------|-----------|---------|--------|
| swarm1-12 | General workers | KHAOSS/mixed | Active |
| swarm13 | TRADING OPS Leader | Trading Team | Active |
| swarm14 | Technical Analyst | Trading Team | Active |
| swarm15 | Sentiment Analyst | Trading Team | Active |
| swarm16 | Fundamentals Researcher | Trading Team | Active |
| swarm17 | Bull Researcher | Trading Team | Active |
| swarm18 | Bear Researcher | Trading Team | Active |
| swarm19 | Strategist | Trading Team | Active |
| swarm20 | Risk Monitor | Trading Team | Active |
| swarm21+ | UNALLOCATED | -- | -- |

## Rules
- Never reuse a swarm ID across programs without decommissioning first.
- Update this file whenever a swarm is created or repurposed.
- Beewid integration uses swarm13 Kanban dispatch, not new swarms.
'''
with open('$HERMES_HOME/SWARM_REGISTRY.md', 'w') as f:
    f.write(reg)
" && ok "SWARM_REGISTRY.md written"

# ── Verify ────────────────────────────────────────

echo ""
echo "═══════════════════════════════════════════════════"
echo "  TRADING OPS SETUP COMPLETE"
echo "═══════════════════════════════════════════════════"
echo ""
echo "  Profiles: swarm13-20"
echo "  Output:   $TRADING_DIR/"
echo "  Kanban:   http://127.0.0.1:9119/kanban"
echo ""
echo "  tmux sessions:"
tmux ls 2>/dev/null | grep swarm || warn "No tmux sessions found"
echo ""
echo "  Next steps:"
echo "  1. Open AionUI → Teams → + → Trading Ops → Hermes Agent"
echo "  2. Paste the leader prompt from trading_ops_preset.md Section A"
echo "  3. Activate: STATUS: ACTIVE — BTC"
echo ""
echo "  Monitor: http://127.0.0.1:9119/kanban"
echo "═══════════════════════════════════════════════════"
