#!/usr/bin/env bash
# KHAOSS Debug Helper — generates a report for Terminal CC
OUT="/tmp/khaoss_debug_$(date +%Y%m%d_%H%M%S).md"
{
  echo "# KHAOSS Debug Report"
  echo "Generated: $(date)"
  echo "Machine: $(hostname) / $(uname -r)"
  echo "User: $(whoami)"
  echo ""
  echo "## Service Status"
  for svc in screenpipe hermes aionui vault_watcher sanitizer screen_assistant; do
    if pgrep -f "$svc" &>/dev/null; then
      echo "- $svc: RUNNING (PID $(pgrep -f "$svc" | head -1))"
    else
      echo "- $svc: NOT RUNNING"
    fi
  done

  echo ""
  echo "## Port Status"
  for port in 7842 8642 9119 3030 3000; do
    if curl -sf --max-time 2 "http://localhost:$port/" &>/dev/null; then
      echo "- :$port RESPONDING"
    else
      echo "- :$port NOT RESPONDING"
    fi
  done

  echo ""
  echo "## Recent Errors"
  echo "### panel_server.log (last 20)"
  tail -20 /tmp/panel_server.log 2>/dev/null

  echo "### screenpipe log (last 10)"
  tail -10 ~/.screenpipe/screenpipe.log 2>/dev/null

  echo "### hermes dashboard log (last 10)"
  tail -10 /tmp/hermes-dashboard.log 2>/dev/null

  echo ""
  echo "## System"
  echo "- Display: $DISPLAY"
  echo "- Memory free: $(grep MemFree /proc/meminfo)"
  echo "- Disk: $(df -h ~ | tail -1)"
  echo "- Hermes version: $(hermes --version 2>/dev/null)"
  echo "- Node: $(node --version 2>/dev/null)"
  echo "- Python: $(python3 --version 2>/dev/null)"
} > "$OUT"

# Append a Terminal CC fix prompt (referencing the report file itself,
# avoids self-recursive append)
{
  echo ""
  echo "## Terminal CC Fix Prompt"
  echo '```'
  echo "I am running the KHAOSS stack and have issues. Debug report follows."
  echo "(See above sections of this file.)"
  echo '```'
} >> "$OUT"

echo "Debug report written to: $OUT"
echo ""
echo "To fix with Terminal CC:"
echo "  cd ~ && claude"
echo "  Then paste the contents of $OUT"
echo ""
cat "$OUT"
