# AionUI Swarm Agent Registration (corrected)

Register hermes `swarm13`–`swarm20` as individual **custom ACP agent** cards in
AionUI — each with its role name and emoji, like the built-in Codex/Claude cards.

> This supersedes the earlier draft that targeted `acp.customAgents` with a
> `cliPath`/`backend` shape and a leveldb/CDP injector. Those were wrong for
> AionUI 1.9.25 — see **What changed** below.

## How AionUI actually loads custom agents (verified against source)

- Storage: `~/.config/AionUi-Dev/config/aionui-config.txt`
  Codec: `base64(encodeURIComponent(JSON.stringify(data)))` (`initStorage.ts`).
  **Not** leveldb. One JSON blob holds every config key.
- Key: `acp.customAgents` — typed `AcpBackendConfig[]` (`storage.ts:65`).
- Loader: `AcpDetector.detectCustomAgents()` (`AcpDetector.ts:231`) keeps an entry
  only if **`enabled !== false` AND not `isPreset` AND `defaultCliPath` is set**,
  then marks it `available: true` (no `which`/init probe — they can't be hidden
  the way the gateway leader was).
- Spawn: `createAcpSpawnConfig()` (`acpConnectors.ts:286`) appends
  `--experimental-acp` **only if `acpArgs` is `undefined`**. We set `acpArgs: []`
  so nothing extra is appended; on Unix a `defaultCliPath` with spaces is split
  into command + args, then `acpArgs` is appended.

## The correct schema (per agent)

```json
{
  "id": "hermes-swarm14",
  "name": "📊 Technical Analyst (swarm14)",
  "description": "Price action, RSI, MACD, funding rates, OI, liquidations",
  "avatar": "📊",
  "defaultCliPath": "/home/boq/beewid-privacy/aionui-swarm-bridges/swarm14-acp.sh",
  "acpArgs": [],
  "enabled": true,
  "supportsStreaming": false,
  "authRequired": false
}
```

Each bridge script execs the verified-working invocation:
`hermes --profile <swarmN> acp` (confirmed via `hermes --profile swarm14 acp --check`
→ "Hermes ACP check OK").

## Apply it (bulletproof method)

AionUI rewrites the whole config file from its in-memory cache on every settings
write, so a disk edit made while it runs gets clobbered. Therefore:

1. **Fully quit AionUI** (exit the process, not just the window).
2. Run the injector (it refuses to run if AionUI is still live on CDP :9230):
   ```bash
   python3 ~/beewid-privacy/inject_swarm_customagents.py
   ```
   It backs up the config, merge-adds the 8 entries (preserving all other keys),
   round-trip-verifies the encoding, and confirms what landed.
3. **Launch AionUI** → 8 swarm cards appear under custom ACP agents; each is
   chattable and team-assignable.

### Manual alternative (Settings UI)
AionUI → Settings → Agents → Custom Agents → **+** → set Name, and CLI path to
`~/beewid-privacy/aionui-swarm-bridges/swarmN-acp.sh`. Repeat for swarm13–20.

## Files

- Bridge scripts: `~/beewid-privacy/aionui-swarm-bridges/swarm{13..20}-acp.sh`
- Manifest (`AcpBackendConfig[]`): `~/beewid-privacy/aionui_swarm_agents.json`
- Injector: `~/beewid-privacy/inject_swarm_customagents.py`

## What changed vs. the earlier draft

| Earlier draft | Reality (1.9.25) |
|---|---|
| field `cliPath` | **`defaultCliPath`** (required by the detector; `cliPath` is ignored → agent never shows) |
| field `backend: "custom"` | no such field; detector sets `backend` itself |
| stored in leveldb / via `ipcRenderer.invoke('storage.get','agent.config',…)` | stored in `aionui-config.txt`, base64+encodeURIComponent JSON |
| CDP injection while running | clobbered by the cache; quit-then-write instead |

## Note on swarm13 / swarm14

`swarm13` is already wired as the **aionrs/gateway** Team Leader (HTTP → :8642,
model `swarm13`); `swarm14` is the Beewid engine default. Registering them here
adds a separate **local ACP launch** path — both can coexist. The ACP card spawns
a local `hermes --profile swarmN acp` process; it does not require the gateway.
