#!/usr/bin/env bash
# Run with: sudo bash /home/boq/beewid-privacy/install_aionui_resume.sh
set -e

cat > /etc/systemd/system/aionui-resume.service << 'EOF'
[Unit]
Description=Restart AionUI renderer after suspend resume
After=suspend.target hibernate.target hybrid-sleep.target
After=systemd-sleep.service

[Service]
User=boq
Type=oneshot
Environment=DISPLAY=:0.0
Environment=XAUTHORITY=/home/boq/.Xauthority
ExecStart=/home/boq/beewid-privacy/aionui_resume.sh
RemainAfterExit=no

[Install]
WantedBy=suspend.target hibernate.target hybrid-sleep.target
EOF

systemctl daemon-reload
systemctl enable aionui-resume.service
echo "--- aionui-resume.service status ---"
systemctl status aionui-resume.service --no-pager || true
