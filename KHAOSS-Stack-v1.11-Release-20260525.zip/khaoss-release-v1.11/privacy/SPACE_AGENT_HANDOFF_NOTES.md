# Space Agent Setup & Integration Handoff Notes
**Machine:** Cornholio (Kali Linux, user: boq)
**Date:** 2026-05-18
**Space Agent version:** v0.36
**Status:** Working — GUI generation confirmed

---

## Setup (what actually worked)

### Login
- `node space user create` runs but login fails on v0.36
- **Working path:** `node space set SINGLE_USER_APP=true` then restart
- After setting, always kill the existing process before restarting:
  ```bash
  kill $(lsof -t -i:3000) && sleep 2
  cd ~/agents/space-agent && PORT=3000 node space serve
  ```
- If `lsof` returns nothing (port already dead), skip the kill and just run serve

### Model config
- **Working model:** `gpt-5.5` via OpenAI API (`https://api.openai.com/v1/chat/completions`)
- **Do NOT set temperature** — gpt-5.5 only supports default (1), setting 0.2 causes 400 error
- Clear the Params field in Admin → Agent settings entirely
- gpt-4o hits 30k TPM rate limit quickly — use gpt-5.5 or gpt-4o-mini for sustained work
- Custom Instructions field: paste Beewid/KHAOSS context here (persists across sessions)

### Custom Instructions to paste
```
You are operating on Cornholio (Kali Linux, user: boq).
Key rules:
- Never touch ~/Downloads/beewid/ unless explicitly told to
- Never touch ~/beewid-privacy/
- Never touch ~/aionui-stack-panel.html
- Safe working directories: ~/agents/space-agent/, ~/vault/workspace/, ~/obsidian-vault/
- The KHAOSS panel runs at localhost:7842
- Hermes runs at localhost:8642
```

---

## Filesystem — critical facts

### Where files actually go
- Space Agent's `~` does NOT map to `/home/boq/`
- `~` maps to `CUSTOMWARE_PATH/L2/user/` (the authenticated user's layer)
- Default (no CUSTOMWARE_PATH): `~/agents/space-agent/app/L2/admin/`
- With `CUSTOMWARE_PATH=/home/boq`: files land at `/home/boq/L2/user/`

### Hard sandbox — no escape
- `space.api.fileWrite()` only accepts logical L2 paths
- Absolute paths like `/home/boq/Downloads/beewid/cockpit/file.html` are **rejected**
- Symlinks inside L2 pointing to host directories are **not followed**
- `CUSTOMWARE_PATH` only relocates where L2 lives — it does not open host filesystem access

### Verified working write path
```
CUSTOMWARE_PATH=/home/boq → writes land at /home/boq/L2/user/
Verify: ls /home/boq/L2/user/
View: firefox /home/boq/L2/user/filename.html &
```

---

## Two paths for Beewid integration

### Path 1 — Direct (recommended for Beewid project)
Space Agent authors HTML in L2. A single copy command deploys to Beewid:
```bash
cp /home/boq/L2/user/beewid_agents.html ~/Downloads/beewid/cockpit/beewid_agents.html
```
Time Travel in Space Agent provides rollback if something breaks.
After copy, verify at: `http://localhost:8505` (Beewid Streamlit port)

### Path 2 — Beta tester path
Space Agent authors in L2, tester reviews visually, then manually deploys.
More steps but safer for people unfamiliar with the codebase.

---

## Beewid tab editing rules for Space Agent

When giving Space Agent tasks involving Beewid tabs, always include:
```
RULES:
1. Only edit content inside the tab's section div (e.g. #section-workflow, #section-trading)
2. Do NOT touch: nav bars, topbars, shared panel structure, or other tabs
3. Do NOT modify script imports or beewid_core.js references
4. Write to ~/beewid_agents_draft.html first, never directly overwrite the original
5. The </script> tag inside JS template literals must use \u003c/script\u003e
6. After writing, confirm: space.api.fileWrite path returned must be L2/user/
```

---

## Communication style — what works
- One small step per message
- User pastes Space Agent output back here for analysis
- Screenshot after every visible result
- GUI-first always: try in Space Agent browser/files panel before using terminal
- Terminal CC only when Space Agent GUI path is confirmed blocked

---

## Known issues / bugs (v0.36)
| Issue | Status |
|-------|--------|
| `node space user create` login fails | Workaround: SINGLE_USER_APP=true |
| `~` path does not expand to /home/boq | By design — maps to L2/user/ |
| Symlinks in L2 not followed | By design — hard sandbox |
| Absolute paths rejected by fileWrite | By design — no workaround |
| Lower models (gpt-4o-mini) silently fail writes | Use gpt-5.5 |
| Space Agent browser can't render file:/// | Use Firefox directly for verification |
| temperature:0.2 breaks gpt-5.5 | Clear Params field entirely |

---

## Demo spaces (built-in, useful for reference)
- Daily News, Crypto Dashboard, Retro Arcade, Agent Zero Videos
- These show what Space Agent can build — useful for beta tester onboarding

---

## Host Bridge — BREAKTHROUGH (2026-05-18)

Space Agent can read/write ANY host file via a local HTTP bridge.

### How it works
1. A small HTTP server runs on `:7842` (KHAOSS panel_server.py)
2. Space Agent calls it via `space.fetchExternal()` — bypasses sandbox entirely
3. No L2 path restrictions — full host filesystem access

### Proven working
```javascript
const res = await space.fetchExternal("http://localhost:7842/bridge/read?path=" + encodeURIComponent("/home/boq/Downloads/beewid/cockpit/beewid_agents.html"))
const text = await res.text()
// Returns full file contents — confirmed working 2026-05-18
```

### Skills written to L2/user/ext/skills/
| Skill | Path | Purpose |
|-------|------|---------|
| `beewid-host-files` | L2/user/ext/skills/beewid-host-files/SKILL.md | Beewid-specific read/write via bridge |
| `host-bridge` | L2/user/ext/skills/host-bridge/SKILL.md | General purpose read/write/list/exec via bridge |

### Skill load issue
- `space.skills.load("host-bridge")` fails with loadSkill error — skill not auto-discoverable yet
- Workaround: use `space.fetchExternal()` directly without loading skill first
- Fix: needs AGENTS.md + proper metadata frontmatter in SKILL.md (TODO)

### Bridge endpoints (production spec — sent to KHAOSS Sonnet)
- `GET /bridge/read?path=` — read file as text
- `POST /bridge/write` — write file with optional backup
- `GET /bridge/list?path=` — list directory
- `POST /bridge/exec` — run shell command
- `POST /bridge/config` — set BRIDGE_ENABLED + ALLOWED_PATHS
- Security: BRIDGE_ENABLED (default False), ALLOWED_PATHS (default [])
- KHAOSS panel UI: Space Agent Bridge card with toggle + path manager

### Test bridge (temporary, for testing only)
```bash
# Runs on :7843 — kill after testing
python3 bridge_test.py &
kill %1
```

### Workflow now possible
1. Space Agent loads host-bridge skill
2. Reads target file via bridge
3. Generates modified version
4. Writes back via bridge (with auto-backup)
5. User verifies at localhost:8506
6. Time Travel available for rollback in Space Agent

---

## Soul / Project Vision

Space Agent + KHAOSS stack goal: give any user (beginner to power user) 
the ability to do ANYTHING with AI on their local machine — file editing, 
GUI building, code patching, system automation — in the cleanest, simplest, 
most flexible way possible. The KHAOSS panel is the security governor and 
control surface. Space Agent is the AI hands. The bridge is what connects them.

---

*KHAOSS Sonnet · 2026-05-18 · Space Agent GUI Session*
