#!/usr/bin/env bash
# aionui_resume.sh — reload AionUI renderer after suspend
# Called by systemd on resume from suspend/hibernate

export DISPLAY=:0.0
export XAUTHORITY=/home/boq/.Xauthority

# Wait for X11 to be ready
sleep 3

# Check if AionUI electron is running
if ! pgrep -f "AionUi-main" > /dev/null 2>&1; then
  echo "$(date): AionUI not running, skipping resume fix" \
    >> /tmp/aionui_resume.log
  exit 0
fi

# Try to reload the renderer via CDP (Chrome DevTools Protocol)
# AionUI runs with CDP on port 9230
RELOAD_RESULT=$(curl -s --max-time 5 \
  -X POST \
  http://127.0.0.1:9230/json/list 2>/dev/null)

if echo "$RELOAD_RESULT" | grep -q "webSocketDebuggerUrl"; then
  # Get the first page's websocket URL and send a reload
  WS_URL=$(echo "$RELOAD_RESULT" | python3 -c "
import sys,json
pages = json.load(sys.stdin)
main = [p for p in pages if p.get('type')=='page']
if main: print(main[0].get('webSocketDebuggerUrl',''))
" 2>/dev/null)

  if [ -n "$WS_URL" ]; then
    python3 -c "
import asyncio, json, sys
try:
    import websockets
    async def reload():
        async with websockets.connect('$WS_URL', open_timeout=5) as ws:
            await ws.send(json.dumps({'id':1,'method':'Page.reload'}))
            await asyncio.sleep(1)
    asyncio.run(reload())
    print('CDP reload sent')
except Exception as e:
    print(f'CDP reload failed: {e}')
" >> /tmp/aionui_resume.log 2>&1
    echo "$(date): CDP reload attempted" >> /tmp/aionui_resume.log
    exit 0
  fi
fi

# Fallback: if CDP fails, use xdotool to send F5 to AionUI window
if command -v xdotool &>/dev/null; then
  WID=$(xdotool search --name "AionUi" 2>/dev/null | head -1)
  if [ -n "$WID" ]; then
    xdotool key --window "$WID" F5
    echo "$(date): xdotool F5 sent to window $WID" \
      >> /tmp/aionui_resume.log
    exit 0
  fi
fi

# Last resort: full restart
echo "$(date): falling back to full AionUI restart" \
  >> /tmp/aionui_resume.log
pkill -f "AionUi-main" 2>/dev/null
sleep 2
rm -f /home/boq/.config/AionUi-Dev/SingletonLock \
      /home/boq/.config/AionUi-Dev/SingletonCookie \
      /home/boq/.config/AionUi-Dev/SingletonSocket
rm -rf /home/boq/.config/AionUi-Dev/GPUCache/
DISPLAY=:0.0 ELECTRON_DISABLE_GPU=1 LIBGL_ALWAYS_SOFTWARE=1 \
  bash /home/boq/launch-aionui.sh > /tmp/aionui_resume_launch.log 2>&1 &
echo "$(date): AionUI restarted" >> /tmp/aionui_resume.log
