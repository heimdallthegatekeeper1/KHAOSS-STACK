#!/usr/bin/env bash
exec hermes --profile swarm16 acp --accept-hooks
