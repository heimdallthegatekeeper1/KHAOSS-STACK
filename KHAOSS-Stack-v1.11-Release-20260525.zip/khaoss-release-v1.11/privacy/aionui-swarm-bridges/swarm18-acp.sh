#!/usr/bin/env bash
exec hermes --profile swarm18 acp --accept-hooks
