#!/usr/bin/env bash
exec hermes --profile swarm14 acp --accept-hooks
