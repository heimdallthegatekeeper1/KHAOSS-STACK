#!/usr/bin/env bash
exec hermes --profile swarm17 acp --accept-hooks
