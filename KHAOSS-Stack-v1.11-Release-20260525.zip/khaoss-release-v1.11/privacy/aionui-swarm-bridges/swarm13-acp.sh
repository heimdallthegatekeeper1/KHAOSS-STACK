#!/usr/bin/env bash
exec hermes --profile swarm13 acp --accept-hooks
