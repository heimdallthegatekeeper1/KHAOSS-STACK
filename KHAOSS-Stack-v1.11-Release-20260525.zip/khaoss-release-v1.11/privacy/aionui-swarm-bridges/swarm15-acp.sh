#!/usr/bin/env bash
exec hermes --profile swarm15 acp --accept-hooks
