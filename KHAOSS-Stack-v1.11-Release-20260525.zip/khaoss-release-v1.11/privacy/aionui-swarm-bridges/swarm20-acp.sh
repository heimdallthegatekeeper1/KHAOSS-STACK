#!/usr/bin/env bash
exec hermes --profile swarm20 acp --accept-hooks
