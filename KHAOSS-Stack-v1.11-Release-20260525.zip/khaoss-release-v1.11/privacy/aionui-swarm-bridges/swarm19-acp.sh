#!/usr/bin/env bash
exec hermes --profile swarm19 acp --accept-hooks
