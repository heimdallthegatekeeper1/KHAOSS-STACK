// One-shot MCP TCP client → AionUI TeamMcpServer. Calls team_spawn_agent via the
// real in-process service path (handleSpawnAgent → spawnAgent → addAgent).
const net = require('node:net');

const PORT = Number(process.env.PORT || 42879);
const TOKEN = process.env.TOKEN || '7e92f33d-9e0d-405e-856f-7429eb16015c';
const LEADER_SLOT = process.env.LEADER_SLOT || 'slot-709023fa';

const request = {
  tool: 'team_spawn_agent',
  args: {
    name: process.env.AGENT_NAME || 'Technical Analyst',
    agent_type: process.env.AGENT_TYPE || 'codex',
    model: process.env.AGENT_MODEL || 'gpt-5.5/medium',
  },
  from_slot_id: LEADER_SLOT,
  auth_token: TOKEN,
};

function writeFrame(socket, data) {
  const body = Buffer.from(JSON.stringify(data), 'utf-8');
  const frame = Buffer.allocUnsafe(4 + body.length);
  frame.writeUInt32BE(body.length, 0);
  body.copy(frame, 4);
  socket.write(frame);
}

const chunks = [];
let total = 0;
const socket = net.createConnection({ host: '127.0.0.1', port: PORT }, () => {
  console.error(`[client] connected :${PORT}, sending team_spawn_agent ${JSON.stringify(request.args)}`);
  writeFrame(socket, request);
});

socket.on('data', (chunk) => {
  chunks.push(chunk);
  total += chunk.length;
  if (total < 4) return;
  const buf = Buffer.concat(chunks);
  const len = buf.readUInt32BE(0);
  if (buf.length < 4 + len) return;
  const body = buf.subarray(4, 4 + len).toString('utf-8');
  console.log(body);
  socket.destroy();
});

socket.on('error', (err) => {
  console.error('[client] socket error:', err.message);
  process.exit(1);
});
socket.setTimeout(60000);
socket.on('timeout', () => {
  console.error('[client] timeout');
  socket.destroy();
  process.exit(1);
});
