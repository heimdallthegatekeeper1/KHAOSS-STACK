---
name: khaoss_panel
description: Control the KHAOSS panel and services. All destructive
  actions require user confirmation before executing.
version: 1.0
author: KHAOSS Sonnet
---

# KHAOSS Panel Control Skill

## Available actions

### Check panel status
```bash
curl -s http://localhost:7842/snapshot | python3 -c "
import sys,json; d=json.load(sys.stdin)
for k,v in d['services'].items():
    print(k, v.get('display_state','?'))"
```

### Start a service (requires user confirmation)
```bash
# ASK USER: "Start [service_name]? (yes/no)"
# Only proceed if user confirms
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"service":"SERVICE_NAME"}' \
  http://localhost:7842/services/start
```

### Stop a service (requires user confirmation)
```bash
# ASK USER: "Stop [service_name]? This may affect running tasks. (yes/no)"  
# Only proceed if user confirms
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"service":"SERVICE_NAME"}' \
  http://localhost:7842/services/stop
```

### Add bridge path (requires user confirmation)
```bash
# ASK USER: "Add path [path] to bridge allowed list? (yes/no)"
# Get current paths first
CURRENT=$(curl -s http://localhost:7842/bridge/status | 
  python3 -c "import sys,json; print(json.load(sys.stdin)['allowed_paths'])")
# Only proceed if user confirms
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"allowed_paths":["NEW_PATH"]}' \
  http://localhost:7842/bridge/config
```

### Request permission (non-destructive — queues for user approval)
```bash
curl -s -X POST -H "Content-Type: application/json" \
  -d '{"action":"ACTION","params":{},"reason":"REASON"}' \
  http://localhost:7842/bridge/request
```

## Safety rules
1. ALWAYS ask user before starting or stopping services
2. NEVER add paths to bridge without explicit user confirmation
3. NEVER stop vault_watcher or sanitizer without user confirmation
4. NEVER modify bridge_config.json directly — use the API
5. Read-only status checks (GET requests) need no confirmation
