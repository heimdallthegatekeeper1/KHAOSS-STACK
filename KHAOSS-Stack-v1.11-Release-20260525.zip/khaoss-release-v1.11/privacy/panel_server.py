#!/usr/bin/env python3
"""
panel_server.py — local HTTP host + reverse proxy + SSE broadcaster for the
AionUI stack panel.

Why this exists
---------------
The panel HTML used to be opened as `file://…aionui-stack-panel.html`.  A
file:// origin cannot read PID files for most setups, and any fetch() to
http://localhost:3030 / :9119 is a cross-origin request that the browser will
block unless the target service emits the right CORS headers.

Serving the panel from http://localhost:7842 is necessary but **not
sufficient** to solve CORS: `localhost:7842 → localhost:3030` is still a
cross-origin pair (different ports = different origins). The robust fix is
to make this server a reverse proxy: the browser only ever fetches
same-origin URLs like `/api/screenpipe/health`, and this process proxies them
to the real service. Result: no CORS configuration on any backend.

Real-time status (SSE)
----------------------
The panel subscribes to GET /stream (SSE). A background poller thread
gathers status for every service every STREAM_INTERVAL_S seconds and
broadcasts one JSON event per tick to all subscribers. The panel applies
each event directly to the DOM — no setTimeout polling, no flicker.

Stdlib only — no Flask, no Starlette, no requests.

Security model
--------------
- Binds to 127.0.0.1 only — never reachable from the network.
- credential-check endpoint executes a fixed script path, no shell
  interpolation, no caller-supplied arguments.
- File-serving is locked to the single HTML file by path; no directory
  listing, no walks outside that file.
- screen_assistant lifecycle uses a fixed script path, never caller input.
"""

from __future__ import annotations

import argparse
import http.client
import json
import logging
import os
import queue
import re
import signal
import socket
import subprocess
import sys
import threading
import time
from datetime import datetime, timezone
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from typing import Any
from urllib.parse import parse_qs, urlsplit

# ── Paths / config ───────────────────────────────────────────────────────────

HOME = Path(os.path.expanduser("~"))
PANEL_HTML = HOME / "aionui-stack-panel.html"
PID_FILE = HOME / "beewid-privacy" / "panel_server.pid"
LOG_FILE = Path("/tmp/panel_server.log")

VAULT_PID_FILE     = HOME / "beewid-privacy" / "vault_watcher.pid"
SANITIZER_PID_FILE = HOME / "beewid-privacy" / "vault_import_sanitizer.pid"
SA_PID_FILE        = HOME / "beewid-privacy" / "screen_assistant.pid"
SA_SCRIPT          = HOME / "beewid-privacy" / "screen_assistant.py"
SA_LOG             = HOME / "beewid-privacy" / "screen_assistant.log"          # JSON suggestions only
SA_RUNTIME_LOG     = HOME / "beewid-privacy" / "screen_assistant_runtime.log"  # daemon stderr
SM_SCRIPT          = HOME / "beewid-privacy" / "session_memory.py"             # Tier-2 session synthesizer
SM_STATUS_DIR      = HOME / "beewid-privacy" / "_session_runs"                 # per-run status JSON
PR_SCRIPT          = HOME / "beewid-privacy" / "proactive_research.py"
PR_PID_FILE        = HOME / "beewid-privacy" / "proactive_research.pid"
PR_QUEUE           = HOME / "beewid-privacy" / "research_queue.jsonl"
VK_SCRIPT          = HOME / "beewid-privacy" / "voice_kanban.py"
VK_PID_FILE        = HOME / "beewid-privacy" / "voice_kanban.pid"
VK_RESULTS         = HOME / "beewid-privacy" / "voice_kanban_results.jsonl"
LL_SCRIPT          = HOME / "beewid-privacy" / "learning_loop.py"
LL_PID_FILE        = HOME / "beewid-privacy" / "learning_loop.pid"
LL_RUNS            = HOME / "beewid-privacy" / "learning_loop_runs.jsonl"
LL_STATUS_DIR      = HOME / "beewid-privacy" / "_learning_runs"
DEBATE_DIR         = HOME / "vault" / "workspace"                              # debate transcripts land in the workspace
DEBATE_STATUS_DIR  = HOME / "beewid-privacy" / "_debate_runs"                  # per-debate status JSON
OBSIDIAN_VAULT     = HOME / "obsidian-vault"
VAULT_WORKSPACE    = HOME / "vault" / "workspace"
VAULT_QUARANTINE   = HOME / "vault" / "quarantine"
MCP_LOG            = HOME / "beewid-privacy" / "mcp_access.log"
SECURITY_LOG       = HOME / "beewid-privacy" / "security.log"
SANITIZER_LOG      = HOME / "beewid-privacy" / "sanitizer.log"
WATCHER_LOG        = HOME / "beewid-privacy" / "watcher.log"
CREDENTIAL_CHECK   = HOME / "beewid-privacy" / "credential_check.sh"
LAUNCH_AIONUI      = HOME / "launch-aionui.sh"
LAUNCH_STACK       = HOME / "launch-stack.sh"
SPACE_AGENT_DIR    = HOME / "agents" / "space-agent"
HERMES_DASH_PORT   = 9119

# Service control — allowlisted definitions only; no caller input ever reaches argv.
# Each entry has:  start_argv (list or None for special cases),
#                  start_log  (stdout/stderr redirect path),
#                  stop_pattern (fixed pkill -f argument),
#                  pid_file   (optional Path — preferred kill target).
_SVC_DEFS: dict[str, dict] = {
    "screenpipe": {
        "start_argv":   [str(HOME / "Downloads" / "screenpipe-main" / "target" / "release" / "screenpipe"),
                         "record"],
        "start_env":    {"DISPLAY": ":0.0", "WAYLAND_DISPLAY": "", "XDG_SESSION_TYPE": "x11"},
        "start_log":    "/tmp/sp.log",
        "stop_pattern": "screenpipe",
        "pid_file":     None,
    },
    "hermes_dashboard": {
        "start_argv":   ["hermes", "dashboard"],
        "start_log":    "/tmp/hermes-dashboard.log",
        "stop_pattern": "hermes.*dashboard",
        "pid_file":     None,
    },
    "aionui": {
        "start_argv":   None,   # resolved at call-time: launch-aionui.sh or skip
        "start_log":    "/tmp/aionui.log",
        "stop_pattern": "electron",
        "pid_file":     None,
    },
    "vault_watcher": {
        "start_argv":   ["/usr/bin/env", "python3", str(HOME / "beewid-privacy" / "vault_watcher.py")],
        "start_log":    "/tmp/vw.log",
        "stop_pattern": "vault_watcher.py",
        "pid_file":     str(VAULT_PID_FILE),
    },
    "sanitizer": {
        "start_argv":   ["/usr/bin/env", "python3", str(HOME / "beewid-privacy" / "vault_import_sanitizer.py")],
        "start_log":    "/tmp/san.log",
        "stop_pattern": "vault_import_sanitizer.py",
        "pid_file":     str(SANITIZER_PID_FILE),
    },
    "screen_assistant": {
        "start_argv":   ["/usr/bin/env", "python3", str(HOME / "beewid-privacy" / "screen_assistant.py")],
        "start_log":    "/tmp/sa.log",
        "stop_pattern": "screen_assistant.py",
        "pid_file":     str(SA_PID_FILE),
    },
    "proactive_research": {
        "start_argv":   ["/usr/bin/env", "python3", str(HOME / "beewid-privacy" / "proactive_research.py")],
        "start_log":    "/tmp/pr.log",
        "stop_pattern": "proactive_research.py",
        "pid_file":     str(PR_PID_FILE),
    },
    "voice_kanban": {
        "start_argv":   ["/usr/bin/env", "python3", str(HOME / "beewid-privacy" / "voice_kanban.py")],
        "start_log":    "/tmp/vk.log",
        "stop_pattern": "voice_kanban.py",
        "pid_file":     str(VK_PID_FILE),
    },
    "space_agent": {
        "start_argv":   None,   # special: needs cwd + PORT=3000 env
        "start_log":    "/tmp/space.log",
        "stop_pattern": r"space-agent.*node|node.*space-agent",
        "pid_file":     None,
    },
}

# Launcher script discovery — first existing file wins.
# Listed so the new canonical name takes priority but legacy names still work.
LAUNCHER_CANDIDATES = [
    HOME / "launch-aionui-kanban-screenpipe.sh",
    HOME / "launch-stack.sh",
    HOME / "launch-beewid-stack.sh",
    HOME / "launch-ai-stack.sh",
]

# Reverse proxy targets — keyed by URL prefix
PROXY_TARGETS = {
    "screenpipe": ("localhost", 3030),
    "hermes":     ("127.0.0.1", 9119),   # kept for proxy fallback / future dashboard
    "aionui":     ("127.0.0.1", 3002),
    "space":      ("127.0.0.1", 3000),
}
# Hermes gateway API lives on 8642 (separate from the intended :9119 dashboard).
HERMES_GATEWAY_HOST = "127.0.0.1"
HERMES_GATEWAY_PORT = 8642

# Space agent install path — used as fallback when TCP :3000 is closed.
SPACE_AGENT_PACKAGE_JSON = HOME / "agents" / "space-agent" / "package.json"

# /logs endpoint — whitelist of log files under ~/beewid-privacy/ that the
# panel may tail. The whitelist + a fixed parent directory is the
# path-traversal defence; an attacker who somehow controls the `file` query
# parameter cannot escape this set even with ../ tricks because we ignore
# anything that contains a slash or isn't in the whitelist.
ALLOWED_LOG_FILES = {
    "mcp_access.log",
    "security.log",
    "sanitizer.log",
    "watcher.log",
    "screen_assistant.log",
    "proactive_research.log",
    "voice_kanban.log",
    "learning_loop.log",
}
LOG_DIR = HOME / "beewid-privacy"

# Backend log lives in /tmp — separate path constant since LOG_DIR is locked
# to ~/beewid-privacy/. The /logs?file=panel_server.log path resolves here.
BACKEND_LOG_NAME = "panel_server.log"

DEFAULT_BIND = "127.0.0.1"
DEFAULT_PORT = 7842

PROXY_TIMEOUT = 5.0
HOP_BY_HOP = {
    "connection", "keep-alive", "proxy-authenticate", "proxy-authorization",
    "te", "trailers", "transfer-encoding", "upgrade",
}

# SSE broadcast tick. 3s = fast enough that a service transition feels
# instant in the UI; slow enough that the poller doesn't hammer screenpipe.
STREAM_INTERVAL_S = 3.0

# ── Space Agent Bridge ─────────────────────────────────────────
BRIDGE_ENABLED = False
ALLOWED_PATHS: list[str] = []
BRIDGE_CONFIG_FILE = Path.home() / "beewid-privacy" / "bridge_config.json"

# ── AI Routing ─────────────────────────────────────────────────
AI_ROUTING_CONFIG_FILE = Path.home() / "beewid-privacy" / "ai_routing_config.json"
_AI_ROUTING_DEFAULT: dict = {
    "tier": "cloud",
    "local": {"url": "http://localhost:11434", "model": "llama3.2", "enabled": False},
    "private": {"url": "", "api_key": "", "model": "", "enabled": False},
    "cloud": {"profile": "swarm13", "enabled": True},
}

# Pending agent permission requests queued for operator review.
# Each entry: {id, action, params, reason, agent, ts, status}
BRIDGE_REQUESTS: list[dict] = []
BRIDGE_REQUESTS_LOCK = threading.Lock()


def _load_bridge_config() -> None:
    global BRIDGE_ENABLED, ALLOWED_PATHS
    try:
        if BRIDGE_CONFIG_FILE.exists():
            data = json.loads(BRIDGE_CONFIG_FILE.read_text())
            BRIDGE_ENABLED = bool(data.get("enabled", False))
            ALLOWED_PATHS = list(data.get("allowed_paths", []))
    except Exception:
        pass
    # Ensure ai_routing_config.json exists with safe defaults on first boot.
    if not AI_ROUTING_CONFIG_FILE.exists():
        try:
            AI_ROUTING_CONFIG_FILE.write_text(json.dumps(_AI_ROUTING_DEFAULT, indent=2))
        except Exception:
            pass


def _save_bridge_config() -> None:
    try:
        BRIDGE_CONFIG_FILE.write_text(
            json.dumps({"enabled": BRIDGE_ENABLED,
                        "allowed_paths": ALLOWED_PATHS}, indent=2))
    except Exception:
        pass


def _load_ai_routing_config() -> dict:
    try:
        if AI_ROUTING_CONFIG_FILE.exists():
            data = json.loads(AI_ROUTING_CONFIG_FILE.read_text())
            cfg = dict(_AI_ROUTING_DEFAULT)
            cfg.update(data)
            return cfg
    except Exception:
        pass
    return dict(_AI_ROUTING_DEFAULT)


def _save_ai_routing_config(cfg: dict) -> None:
    try:
        AI_ROUTING_CONFIG_FILE.write_text(json.dumps(cfg, indent=2))
    except Exception:
        pass


def _ai_routing_config_public(cfg: dict) -> dict:
    """Strip api_key from config before returning to clients."""
    out = {k: v for k, v in cfg.items() if k != "private"}
    priv = dict(cfg.get("private", {}))
    priv.pop("api_key", None)
    out["private"] = priv
    return out


def _check_local_available() -> bool:
    try:
        cfg = _load_ai_routing_config()
        url = cfg["local"]["url"].rstrip("/") + "/api/tags"
        import urllib.request as _ur
        req = _ur.urlopen(url, timeout=2)
        return req.status == 200
    except Exception:
        return False


def _check_private_available() -> bool:
    try:
        cfg = _load_ai_routing_config()
        url = cfg["private"].get("url", "")
        if not url:
            return False
        import urllib.request as _ur
        req = _ur.urlopen(url.rstrip("/") + "/health", timeout=2)
        return req.status == 200
    except Exception:
        return False


def _check_cloud_available() -> bool:
    r = _http_get(HERMES_GATEWAY_HOST, HERMES_GATEWAY_PORT, "/v1/models", timeout=2.0)
    if r is not None:
        return r[0] == 200
    r2 = _http_get(HERMES_GATEWAY_HOST, HERMES_GATEWAY_PORT, "/health", timeout=2.0)
    return r2 is not None and r2[0] == 200

# ── Logging ──────────────────────────────────────────────────────────────────

logger = logging.getLogger("panel_server")

def _setup_logging(foreground: bool) -> None:
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s %(levelname)-5s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    fh = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    # Only add stderr handler in foreground mode. In daemon mode, callers
    # commonly redirect stderr into the same log file (`nohup … 2>&1`), and
    # adding a StreamHandler would cause every line to be written twice.
    if foreground:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        logger.addHandler(sh)

# ── PID file ─────────────────────────────────────────────────────────────────

def _read_pid(path: Path) -> int | None:
    try:
        raw = path.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False

def write_pid_file() -> None:
    existing = _read_pid(PID_FILE)
    if existing and _alive(existing):
        logger.error("panel_server already running (PID %d) — refusing to start", existing)
        sys.exit(2)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n")

def remove_pid_file() -> None:
    try:
        current = _read_pid(PID_FILE)
        if current == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── Status pollers (server-side; same data the SSE stream emits) ─────────────

def _pid_status(pid_file: Path) -> dict[str, Any]:
    pid = _read_pid(pid_file)
    if pid is None:
        return {"pid": None, "running": False, "reason": "no pid file"}
    running = _alive(pid)
    started = None
    if running:
        try:
            started = os.stat(f"/proc/{pid}").st_mtime
        except OSError:
            pass
    return {"pid": pid, "running": running, "started": started}

def _pid_status_with_display(pid_file: Path) -> dict[str, Any]:
    info = _pid_status(pid_file)
    info["display_state"] = "running" if info.get("running") else "stopped"
    return info

def _http_get(host: str, port: int, path: str, timeout: float = 2.0) -> tuple[int, dict, str] | None:
    """Fetch a JSON endpoint. Returns (status, parsed_or_empty, raw_text) or None on failure."""
    try:
        conn = http.client.HTTPConnection(host, port, timeout=timeout)
        conn.request("GET", path)
        resp = conn.getresponse()
        body = resp.read().decode("utf-8", errors="replace")
        status = resp.status
        try: conn.close()
        except OSError: pass
        try:
            parsed = json.loads(body) if body else {}
            if not isinstance(parsed, dict):
                parsed = {"raw": parsed}
        except Exception:
            parsed = {}
        return status, parsed, body
    except (ConnectionRefusedError, socket.timeout, socket.gaierror, OSError):
        return None

def _tcp_reachable(host: str, port: int, timeout: float = 1.0) -> bool:
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return True
    except (ConnectionRefusedError, socket.timeout, OSError):
        return False

def _find_electron_pid() -> int | None:
    """Scan /proc for any electron / AionUI process. Returns PID or None."""
    try:
        for entry in os.listdir("/proc"):
            if not entry.isdigit():
                continue
            try:
                with open(f"/proc/{entry}/comm", "r") as fh:
                    comm = fh.read().strip().lower()
                if comm in ("electron", "aionui", "aion-ui"):
                    return int(entry)
                # comm may be truncated — also peek at cmdline for "aionui"
                with open(f"/proc/{entry}/cmdline", "rb") as fh:
                    cmd = fh.read().decode("utf-8", errors="replace").replace("\x00", " ").lower()
                if "aionui" in cmd or "/electron" in cmd:
                    return int(entry)
            except (OSError, ValueError):
                continue
    except OSError:
        pass
    return None

def _discover_launcher() -> dict[str, Any]:
    for cand in LAUNCHER_CANDIDATES:
        if cand.is_file():
            return {"path": str(cand), "exists": True, "name": cand.name, "status": "found"}
    return {"path": str(LAUNCHER_CANDIDATES[0]), "exists": False, "name": LAUNCHER_CANDIDATES[0].name, "status": "missing"}

def _vault_stats() -> dict[str, Any]:
    if not VAULT_WORKSPACE.is_dir():
        return {"file_count": 0, "last_scrub": None, "last_scrub_epoch": 0.0, "status": "ok (0 files)"}
    count = 0
    latest = 0.0
    try:
        for p in VAULT_WORKSPACE.iterdir():
            if p.is_file():
                count += 1
                m = p.stat().st_mtime
                if m > latest:
                    latest = m
    except OSError:
        pass
    return {
        "file_count": count,
        "last_scrub": (datetime.fromtimestamp(latest, tz=timezone.utc).isoformat() if latest else None),
        "last_scrub_epoch": latest,
        "status": f"ok ({count} files)",
    }

def _quarantine_stats() -> dict[str, Any]:
    if not VAULT_QUARANTINE.is_dir():
        return {"count": 0, "last": None, "status": "clear"}
    count = 0
    latest = 0.0
    try:
        for p in VAULT_QUARANTINE.iterdir():
            if p.is_file():
                count += 1
                m = p.stat().st_mtime
                if m > latest:
                    latest = m
    except OSError:
        pass
    return {
        "count": count,
        "last": (datetime.fromtimestamp(latest, tz=timezone.utc).isoformat() if latest else None),
        "status": f"quarantined ({count})" if count else "clear",
    }

def _tier3_pid_status(pid_file: Path, script: Path) -> dict[str, Any]:
    """Generic PID + install-check for Tier-3 daemons."""
    base = _pid_status(pid_file)
    base["script_exists"] = script.is_file()
    base["display_state"] = "running" if base.get("running") else "stopped"
    return base

def _space_agent_status(reachable: bool, installed: bool) -> dict[str, Any]:
    if reachable:
        state = "running"
    elif installed:
        state = "installed"
    else:
        state = "absent"
    if state == "running":
        display_state = "running"
    elif state == "installed":
        display_state = "installed"
    else:
        display_state = "offline"
    return {
        "reachable":     reachable,
        "installed":     installed,
        "state":         state,
        "display_state": display_state,
    }


def _screen_assistant_status() -> dict[str, Any]:
    pid_info = _pid_status(SA_PID_FILE)
    recent_suggestions = _read_screen_assistant_tail(3)
    return {
        **pid_info,
        "recent_suggestions": recent_suggestions,
        "log_exists": SA_LOG.is_file(),
        "display_state": "running" if pid_info.get("running") else "stopped",
    }

def _read_screen_assistant_tail(n: int) -> list[dict[str, Any]]:
    if not SA_LOG.is_file():
        return []
    try:
        with SA_LOG.open("r", encoding="utf-8", errors="replace") as fh:
            tail = fh.readlines()[-max(1, n):]
    except OSError:
        return []
    out = []
    for raw in tail:
        raw = raw.strip()
        if not raw:
            continue
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict):
                out.append(obj)
                continue
        except Exception:
            pass
        out.append({"ts": None, "suggestion": raw, "source_file": None})
    return out[-n:]

def _tail_log(path: Path, n: int = 20) -> list[str]:
    if not path.is_file():
        return []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            return [ln.rstrip("\n") for ln in fh.readlines()[-max(1, n):]]
    except OSError:
        return []

# ── Known fixes lookup for launch debug reports ───────────────────────────────
KNOWN_FIXES: dict[str, str] = {
    "screenpipe":       "Run with: DISPLAY=:0.0 WAYLAND_DISPLAY='' XDG_SESSION_TYPE=x11 screenpipe record",
    "aionui":           "Clean electron locks: rm -f ~/.config/AionUi-Dev/SingletonLock && ~/launch-aionui.sh",
    "hermes":           "Check: hermes doctor --fix --profile swarm13",
    "hermes_dashboard": "Restart: hermes dashboard > /tmp/hermes-dashboard.log 2>&1 &",
    "screen_assistant": "Check: python3 ~/beewid-privacy/screen_assistant.py",
    "proactive_research": "Check: python3 ~/beewid-privacy/proactive_research.py",
    "vault_watcher":    "Check: python3 ~/beewid-privacy/vault_watcher.py",
    "sanitizer":        "Check: python3 ~/beewid-privacy/vault_import_sanitizer.py",
}


def _log_tail(path_str: str, n: int = 20) -> str:
    """Return the last n lines of a log file as a string."""
    try:
        p = Path(path_str)
        if not p.exists():
            return "(log file not found)"
        lines = p.read_text(encoding="utf-8", errors="replace").splitlines()
        tail = lines[-n:] if len(lines) > n else lines
        return "\n".join(tail) if tail else "(empty log)"
    except OSError:
        return "(cannot read log)"


def _mem_free_mb() -> str:
    try:
        for line in Path("/proc/meminfo").read_text().splitlines():
            if line.startswith("MemFree:"):
                kb = int(line.split()[1])
                return f"{kb // 1024} MB"
    except Exception:
        pass
    return "unknown"


def _disk_free_gb() -> str:
    try:
        import shutil
        usage = shutil.disk_usage(str(HOME))
        return f"{usage.free // (1024 ** 3)} GB"
    except Exception:
        return "unknown"


def _build_debug_report(results: list, fixes: dict) -> str:
    import platform as _platform
    ts = datetime.now(timezone.utc).isoformat()
    hostname = _platform.node()
    sysinfo = f"{_platform.system()} {_platform.release()}"
    lines = [
        "# KHAOSS Launch Debug Report",
        f"Generated: {ts}",
        f"Machine: {hostname} ({sysinfo})",
        "",
    ]
    failures = [r for r in results if r.get("status") == "failed"]
    degraded = [r for r in results if r.get("status") == "degraded"]
    healthy  = [r for r in results if r.get("status") in ("healthy", "already_running", "skipped")]

    if failures:
        lines.append("## Failed Services")
        for r in failures:
            name = r.get("name", "?")
            lines.append(f"### {r.get('display', name)}")
            svc_defs_entry = _SVC_DEFS.get(r.get("svc_key", name), {})
            argv = svc_defs_entry.get("start_argv")
            if argv:
                lines.append(f"- Start command: {' '.join(str(a) for a in argv)}")
            lines.append(f"- Suggested fix: {fixes.get(name, 'No known fix — check service log manually')}")
            log_file = r.get("log_file", "")
            if log_file:
                lines.append(f"- Log file: {log_file}")
                tail = r.get("log_tail") or _log_tail(log_file)
                lines.append("- Last 20 log lines:")
                lines.append("```")
                lines.append(tail)
                lines.append("```")
            lines.append("")

    if degraded:
        lines.append("## Degraded Services")
        for r in degraded:
            lines.append(f"- {r.get('display', r.get('name', '?'))}: running but not fully healthy")
        lines.append("")

    if healthy:
        lines.append("## Healthy Services")
        lines.append("| Service | Status |")
        lines.append("|---|---|")
        for r in healthy:
            lines.append(f"| {r.get('display', r.get('name', '?'))} | {r.get('status', '?')} |")
        lines.append("")

    lines += [
        "## System State",
        f"- Display: {os.environ.get('DISPLAY', 'not set')}",
        f"- Memory free: {_mem_free_mb()}",
        f"- Disk free (home): {_disk_free_gb()}",
    ]
    return "\n".join(lines)


def _ai_routing_poll_status() -> dict[str, Any]:
    cfg = _load_ai_routing_config()
    tier = cfg.get("tier", "cloud")
    local_available = _check_local_available()
    return {
        "tier": tier,
        "display_state": tier,
        "status": tier,
        "local_available": local_available,
    }


def poll_all_services() -> dict[str, Any]:
    """Single snapshot of every service we monitor. Called every STREAM_INTERVAL_S."""

    # Screenpipe — /health returns {status, fps, frames_captured, ...}.
    # Fix B: treat HTTP-200 with status=="degraded" as amber, not red.
    sp = {"reachable": False, "status": "offline", "display_state": "offline"}
    r = _http_get(*PROXY_TARGETS["screenpipe"], "/health")
    if r is not None:
        http_status, parsed, _ = r
        if http_status == 200:
            svc_status = parsed.get("status") or parsed.get("frame_status") or "ok"
            sp["reachable"]      = True
            sp["http_status"]    = http_status
            sp["status"]         = svc_status
            sp["frames_captured"]= parsed.get("frames_captured") or parsed.get("frame_count")
            sp["fps"]            = parsed.get("fps")
            vis = parsed.get("vision_status") or parsed.get("vision")
            if vis is None:
                vis = "disabled" if (
                    parsed.get("is_vision_enabled") is False or
                    parsed.get("vision_enabled") is False
                ) else "enabled"
            sp["vision"] = vis
            # "degraded" = service is alive but some subsystem (e.g. Wayland
            # vision) is broken. Treat as amber, not red.
            sp["display_state"] = svc_status if svc_status in ("healthy", "degraded") else "ok"
        else:
            sp["http_status"] = http_status
            sp["display_state"] = "error"

    # Hermes dashboard — optional :9119 web UI (hermes dashboard process).
    hm_dash = {"reachable": False, "display_state": "offline"}
    r_dash = _http_get("127.0.0.1", HERMES_DASH_PORT, "/api/status")
    if r_dash is not None:
        hs, pd, _ = r_dash
        hm_dash["reachable"]     = (hs == 200)
        hm_dash["http_status"]   = hs
        hm_dash["display_state"] = "running" if hs == 200 else "error"
        if hs == 200:
            hm_dash["version"]       = pd.get("version")
            hm_dash["gateway_state"] = pd.get("gateway_state")
            hm_dash["active_sessions"] = pd.get("active_sessions")

    # Hermes — gateway API is on port 8642 (not the intended-but-absent :9119
    # dashboard). Fix A: use HERMES_GATEWAY_HOST/PORT and /health.
    # Mark online if HTTP 200 regardless of gateway_state value.
    hm = {"reachable": False, "display_state": "offline"}
    r = _http_get(HERMES_GATEWAY_HOST, HERMES_GATEWAY_PORT, "/health")
    if r is not None:
        http_status, parsed, raw_body = r
        hm["reachable"]      = (http_status == 200)
        hm["http_status"]    = http_status
        hm["gateway_port"]   = HERMES_GATEWAY_PORT
        # /health returns {"status":"ok","platform":"hermes-agent"} — no
        # version/sessions in this endpoint; surface what we have.
        hm["gateway_status"] = parsed.get("status") or "unknown"
        hm["platform"]       = parsed.get("platform")
        hm["display_state"]  = "online" if http_status == 200 else "error"
        # Try :9119 for extended status (version, gateway_state, sessions)
        # but don't fail if it's not there.
        r2 = _http_get(*PROXY_TARGETS["hermes"], "/api/status")
        if r2 is not None and r2[0] == 200:
            p2 = r2[1]
            hm["version"]       = p2.get("version") or p2.get("ver")
            hm["gateway_state"] = p2.get("gateway_state") or p2.get("gatewayState") or p2.get("state")
            hm["active_sessions"] = p2.get("active_sessions") or p2.get("activeSessions") or p2.get("sessions")

    # AionUI — Fix C: electron process scan is primary; TCP :3002 is secondary.
    ai_pid       = _find_electron_pid()
    ai_reachable = _tcp_reachable(*PROXY_TARGETS["aionui"]) if not ai_pid else False

    # CDP health check — port 9230. Blank white screen after suspend shows as
    # electron_pid present but CDP unresponsive (GPU process exited).
    cdp_ok = False
    if ai_pid:
        try:
            import urllib.request as _ur
            _cdp_resp = _ur.urlopen("http://127.0.0.1:9230/json/list", timeout=2)
            cdp_ok = _cdp_resp.status == 200
        except Exception:
            cdp_ok = False

    ai = {
        "reachable":      ai_reachable or bool(ai_pid),
        "port_open":      ai_reachable,
        "electron_pid":   ai_pid,
        "cdp_responsive": cdp_ok,
        "display_state":  (
            "running"   if ai_pid and cdp_ok else
            "blank"     if ai_pid and not cdp_ok else
            "reachable" if ai_reachable else
            "stopped"
        ),
    }

    # Space agent — Fix D: if TCP fails, check if installed on disk.
    sa_agent_reachable = _tcp_reachable(*PROXY_TARGETS["space"])
    sa_installed = SPACE_AGENT_PACKAGE_JSON.is_file()

    # BOHKSS TRANSITION — uncomment when Beewid Phase E ships
    # beewid_main = probe_http("http://localhost:8506/health", timeout=2)
    # beewid_watchdog = probe_http("http://localhost:8507/health", timeout=2)
    # beewid_autocode = probe_http("http://localhost:8509/health", timeout=2)

    return {
        "screenpipe":        sp,
        "hermes":            hm,
        "hermes_dashboard":  hm_dash,
        "aionui":            ai,
        "space_agent":   _space_agent_status(sa_agent_reachable, sa_installed),
        "vault_watcher": _pid_status_with_display(VAULT_PID_FILE),
        "sanitizer":     _pid_status_with_display(SANITIZER_PID_FILE),
        "screen_assistant":    _screen_assistant_status(),
        "proactive_research":  _tier3_pid_status(PR_PID_FILE, PR_SCRIPT),
        "voice_kanban":        _tier3_pid_status(VK_PID_FILE, VK_SCRIPT),
        "learning_loop":       _tier3_pid_status(LL_PID_FILE, LL_SCRIPT),
        "bridge": {
            "enabled": BRIDGE_ENABLED,
            "allowed_paths": ALLOWED_PATHS,
            "allowed_path_count": len(ALLOWED_PATHS),
            "display_state": "enabled" if BRIDGE_ENABLED else "disabled",
            "status": "enabled" if BRIDGE_ENABLED else "disabled",
        },
        "panel_server":  {"running": True, "pid": os.getpid(), "display_state": "running"},
        "ai_routing":    _ai_routing_poll_status(),
        "vault":         _vault_stats(),
        "quarantine":    _quarantine_stats(),
        "launcher":      _discover_launcher(),
        # BOHKSS pending — these surface as grey "pending BOHKSS transition"
        # cards on the panel until the real Beewid services come online.
        "beewid_main":      {"pending": True, "port": 8506, "status": "pending BOHKSS transition"},
        "beewid_watchdog":  {"pending": True, "port": 8507, "status": "pending BOHKSS transition"},
        "beewid_autocode":  {"pending": True, "port": 8509, "status": "pending BOHKSS transition"},
    }

def derive_alerts(snapshot: dict[str, Any]) -> list[dict[str, Any]]:
    alerts: list[dict[str, Any]] = []
    sp = snapshot.get("screenpipe", {})
    if not sp.get("reachable"):
        alerts.append({"tone": "amber", "text": "screenpipe offline (port 3030)"})
    elif sp.get("display_state") == "degraded":
        alerts.append({"tone": "amber", "text": "screenpipe degraded (vision broken, service alive)"})
    if not snapshot["hermes"].get("reachable"):
        alerts.append({"tone": "amber", "text": f"hermes gateway offline (port {HERMES_GATEWAY_PORT})"})
    if snapshot.get("aionui", {}).get("display_state") == "blank":
        alerts.append({"tone": "amber", "text": "AionUI renderer blank — may need reload after suspend"})
    if not snapshot["vault_watcher"].get("running"):
        alerts.append({"tone": "red", "text": "vault_watcher is not running"})
    if not snapshot["sanitizer"].get("running"):
        alerts.append({"tone": "red", "text": "vault_import_sanitizer is not running"})
    q = snapshot["quarantine"].get("count", 0)
    if q:
        alerts.append({"tone": "amber", "text": f"{q} file(s) in quarantine — review"})
    if not snapshot["launcher"].get("exists"):
        alerts.append({"tone": "amber", "text": f"launcher script missing: {snapshot['launcher']['path']}"})
    return alerts

# ── Small JSON state helpers (session-memory & debate runs) ──────────────────

def _write_json(path: Path, obj: dict) -> None:
    """Best-effort atomic write so a panel mid-poll never sees a half file."""
    tmp = path.with_suffix(path.suffix + ".tmp")
    path.parent.mkdir(parents=True, exist_ok=True)
    with tmp.open("w", encoding="utf-8") as fh:
        json.dump(obj, fh, indent=2, default=str)
    os.replace(tmp, path)

def _read_json(path: Path) -> dict:
    try:
        with path.open("r", encoding="utf-8") as fh:
            data = json.load(fh)
            return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

# ── Debate orchestration ─────────────────────────────────────────────────────

# Hermes profile names are restricted to a conservative shape so caller
# input can't be smuggled into the subprocess argv as an arbitrary string.
_PROFILE_RE = re.compile(r"^[A-Za-z0-9_-]{1,40}$")

def _safe_profile(value: Any, default: str) -> str:
    if isinstance(value, str) and _PROFILE_RE.match(value):
        return value
    return default

def _hermes_to_file(profile: str, prompt: str, out_file: Path, timeout: float = 180.0) -> tuple[int, str]:
    """Run hermes -z, capture stdout, write it to out_file. Returns (exit_code, stderr_tail)."""
    try:
        proc = subprocess.run(
            ["hermes", "--profile", profile, "-z", prompt],
            capture_output=True, text=True, timeout=timeout,
        )
    except FileNotFoundError:
        return -1, "hermes binary not on PATH"
    except subprocess.TimeoutExpired:
        return 124, f"hermes timed out after {timeout:.0f}s"
    out_file.parent.mkdir(parents=True, exist_ok=True)
    body = proc.stdout.strip() or "(empty response from hermes)"
    out_file.write_text(body + "\n", encoding="utf-8")
    return proc.returncode, (proc.stderr or "").strip()[-1000:]

def _run_debate_worker(
    debate_id: str, topic: str,
    profile_a: str, profile_b: str, judge: str,
    files: dict[str, Path], status_path: Path,
) -> None:
    """Run A and B in parallel; then ask `judge` to read both and rule."""
    def _update(**patch):
        cur = _read_json(status_path)
        cur.update(patch)
        _write_json(status_path, cur)

    prompt_a = (
        f"Argue FOR the following position: \"{topic}\". "
        "Be specific with evidence and concrete examples. "
        "3 paragraphs maximum. Markdown only — no preamble."
    )
    prompt_b = (
        f"Argue AGAINST the following position: \"{topic}\". "
        "Be specific with evidence and concrete examples. "
        "3 paragraphs maximum. Markdown only — no preamble."
    )

    _update(stage="arguing")

    results: dict[str, tuple[int, str]] = {}
    threads = []
    def _arg(side: str, profile: str, prompt: str, out: Path):
        code, err = _hermes_to_file(profile, prompt, out)
        results[side] = (code, err)
    for side, profile, prompt, out in [
        ("a", profile_a, prompt_a, files["a"]),
        ("b", profile_b, prompt_b, files["b"]),
    ]:
        t = threading.Thread(target=_arg, args=(side, profile, prompt, out),
                             name=f"debate-{debate_id}-{side}", daemon=True)
        t.start(); threads.append(t)
    for t in threads:
        t.join()

    cur = _read_json(status_path)
    cur["exit_codes"] = {side: results[side][0] for side in results}
    errors = []
    for side, (code, err) in results.items():
        if code != 0 and err:
            errors.append(f"{side}: {err}")
    cur["errors"] = errors
    _write_json(status_path, cur)

    if any(code != 0 for code, _ in results.values()) and not (files["a"].exists() and files["b"].exists()):
        _update(stage="failed", running=False,
                finished=datetime.now(tz=timezone.utc).isoformat())
        return

    # Judge stage. We hand the judge the actual transcripts so it doesn't
    # have to guess at the framing.
    try:
        body_a = files["a"].read_text(encoding="utf-8", errors="replace")
        body_b = files["b"].read_text(encoding="utf-8", errors="replace")
    except OSError as exc:
        _update(stage="failed", running=False, errors=errors + [f"read transcripts: {exc}"],
                finished=datetime.now(tz=timezone.utc).isoformat())
        return

    _update(stage="judging")
    verdict_prompt = (
        f"You are the impartial judge of a debate on the topic:\n\n"
        f"  \"{topic}\"\n\n"
        f"### Argument FOR (profile {profile_a})\n{body_a}\n\n"
        f"### Argument AGAINST (profile {profile_b})\n{body_b}\n\n"
        "Write your verdict as Markdown with these sections (use `##` headings):\n"
        "  - Summary of each side (one sentence each)\n"
        "  - Stronger argument and why\n"
        "  - Concessions the loser should make\n"
        "  - Your ruling (one paragraph)\n\n"
        "Be specific. Reference points raised in each transcript by quoting "
        "or paraphrasing. Keep the whole verdict under 400 words."
    )
    code, err = _hermes_to_file(judge, verdict_prompt, files["verdict"], timeout=240.0)
    final_errors = errors[:]
    if code != 0 and err:
        final_errors.append(f"judge: {err}")

    _update(
        stage="completed" if code == 0 else "judge_failed",
        running=False,
        finished=datetime.now(tz=timezone.utc).isoformat(),
        exit_codes={**(cur.get("exit_codes") or {}), "judge": code},
        errors=final_errors,
    )

# ── SSE broadcaster ──────────────────────────────────────────────────────────

class StatusBroadcaster:
    """One background thread polls; many client queues receive each tick."""

    def __init__(self, interval: float = STREAM_INTERVAL_S) -> None:
        self._interval = interval
        self._subs: list[queue.Queue[str]] = []
        self._lock = threading.Lock()
        self._stop = threading.Event()
        self._last_payload: str | None = None
        self._thread = threading.Thread(target=self._run, name="status-broadcaster", daemon=True)

    def start(self) -> None:
        self._thread.start()

    def stop(self) -> None:
        self._stop.set()

    def subscribe(self) -> queue.Queue[str]:
        q: queue.Queue[str] = queue.Queue(maxsize=8)
        with self._lock:
            self._subs.append(q)
            if self._last_payload is not None:
                try: q.put_nowait(self._last_payload)
                except queue.Full: pass
        return q

    def unsubscribe(self, q: queue.Queue[str]) -> None:
        with self._lock:
            try: self._subs.remove(q)
            except ValueError: pass

    def _run(self) -> None:
        while not self._stop.is_set():
            try:
                snapshot = poll_all_services()
                payload = json.dumps({
                    "ts": int(time.time() * 1000),
                    "services": snapshot,
                    "alerts": derive_alerts(snapshot),
                }, default=str)
            except Exception as exc:
                logger.warning("snapshot failed: %s", exc)
                payload = json.dumps({"ts": int(time.time() * 1000), "error": str(exc)})
            self._last_payload = payload
            with self._lock:
                dead: list[queue.Queue[str]] = []
                for q in list(self._subs):
                    try:
                        q.put_nowait(payload)
                    except queue.Full:
                        # Slow consumer — drop them so we don't memory-leak.
                        dead.append(q)
                for q in dead:
                    try: self._subs.remove(q)
                    except ValueError: pass
            self._stop.wait(self._interval)


BROADCASTER = StatusBroadcaster()

# ── Space Agent Bridge helpers ────────────────────────────────────────────────

def _bridge_path_allowed(path: str) -> bool:
    """Return True if path is under at least one ALLOWED_PATHS prefix."""
    p = os.path.realpath(os.path.expanduser(path))
    return any(p.startswith(os.path.realpath(os.path.expanduser(a)))
               for a in ALLOWED_PATHS)

def _bridge_headers() -> dict:
    return {
        "Access-Control-Allow-Origin": "*",
        "Access-Control-Allow-Methods": "GET, POST, OPTIONS",
        "Access-Control-Allow-Headers": "Content-Type, Authorization",
    }

# ── Handler ──────────────────────────────────────────────────────────────────

class PanelHandler(BaseHTTPRequestHandler):
    server_version = "PanelServer/2.0"

    # We log through `logger`, not stderr default
    def log_message(self, fmt: str, *args: Any) -> None:
        logger.info("%s - %s", self.address_string(), fmt % args)

    # ── helpers ──────────────────────────────────────────────────────────────

    def _cors(self) -> None:
        self.send_header("Access-Control-Allow-Origin", "*")
        self.send_header("Access-Control-Allow-Methods", "GET, POST, OPTIONS")
        self.send_header("Access-Control-Allow-Headers", "Content-Type")

    def _send_json(self, status: int, payload: Any) -> None:
        body = json.dumps(payload, indent=2, default=str).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json")
        self.send_header("Content-Length", str(len(body)))
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    def _send_text(self, status: int, body: str, ctype: str = "text/plain; charset=utf-8") -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        self._cors()
        self.end_headers()
        self.wfile.write(data)

    def _send(self, status: int, body: str, ctype: str, extra_headers: dict | None = None) -> None:
        data = body.encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(data)))
        if extra_headers:
            for k, v in extra_headers.items():
                self.send_header(k, v)
        self.end_headers()
        self.wfile.write(data)

    # ── routing ──────────────────────────────────────────────────────────────

    def do_OPTIONS(self) -> None:
        self._send(200, "", "text/plain", extra_headers=_bridge_headers())

    def do_GET(self) -> None:
        global BRIDGE_ENABLED, ALLOWED_PATHS
        path = urlsplit(self.path).path

        if path == "/" or path == "/index.html":
            return self._serve_panel()
        if path == "/favicon.ico":
            self.send_response(204); self.end_headers(); return

        # Real-time stream
        if path == "/stream":                  return self._sse_stream()
        if path == "/snapshot":                return self._snapshot_once()

        # Screen assistant
        if path == "/screen-assistant/status": return self._sa_status()

        # Tier-2: session memory + debate
        if path == "/session-memory/status":          return self._session_memory_status()
        if path.startswith("/debate/status/"):        return self._debate_status(path[len("/debate/status/"):])
        if path == "/debate/list":                    return self._debate_list()
        if path.startswith("/debate/transcript/"):
            rest = path[len("/debate/transcript/"):]
            parts = rest.split("/", 1)
            if len(parts) == 2:
                return self._debate_transcript(parts[0], parts[1])
            return self._send_json(400, {"error": "usage: /debate/transcript/<id>/<side>"})

        # Tier-3: proactive research
        if path == "/research/queue":          return self._research_queue()
        if path == "/research/status":         return self._research_status()

        # Tier-3: voice kanban
        if path == "/voice-kanban/status":     return self._vk_status()

        # Tier-3: learning loop
        if path == "/learning-loop/status":    return self._ll_status()

        if path == "/api/vault/pid":           return self._send_json(200, _pid_status(VAULT_PID_FILE))
        if path == "/api/vault/stats":         return self._api_vault_stats()
        if path == "/api/sanitizer/pid":       return self._send_json(200, _pid_status(SANITIZER_PID_FILE))
        if path == "/api/quarantine/stats":    return self._api_quarantine_stats()
        if path == "/api/mcp/log":             return self._api_mcp_log()
        if path == "/api/health":              return self._send_json(200, {"ok": True})
        if path == "/logs":                    return self._api_logs()
        if path == "/launch/all":              return self._launch_all()
        if path == "/blocklist":               return self._api_blocklist_get()
        if path == "/api/space-agent/ping":    return self._ping_target("space")

        # AI routing
        if path == "/ai-routing/status":       return self._ai_routing_status()
        if path == "/ai-routing/test":         return self._ai_routing_test()

        # GET form of credential-check kept for convenience curl-ability
        if path == "/run/credential-check":    return self._api_credential_check()

        # Exact ping matches MUST come before the prefix proxy below; otherwise
        # the proxy swallows them and tries to HTTP GET /ping on the target.
        if path == "/api/aionui/ping":          return self._ping_target("aionui")
        if path == "/api/screenpipe/ping":      return self._ping_target("screenpipe")
        if path == "/api/hermes/ping":          return self._ping_target("hermes")

        if path.startswith("/api/screenpipe/"): return self._proxy("screenpipe", path[len("/api/screenpipe"):])
        if path.startswith("/api/hermes/"):     return self._proxy("hermes",     path[len("/api/hermes"):])
        if path.startswith("/api/aionui/"):     return self._proxy("aionui",     path[len("/api/aionui"):])

        # GET /bridge/read?path=<absolute_path>
        if path.startswith("/bridge/read"):
            if not BRIDGE_ENABLED:
                self._send(503, json.dumps({"error": "bridge disabled"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            from urllib.parse import urlparse, parse_qs as _parse_qs
            qs = _parse_qs(urlparse(self.path).query)
            fpath = qs.get("path", [""])[0]
            if not fpath or not _bridge_path_allowed(fpath):
                self._send(403, json.dumps({"error": "path not allowed"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            try:
                full = os.path.realpath(os.path.expanduser(fpath))
                with open(full, "rb") as f:
                    raw = f.read()
                headers = {
                    **_bridge_headers(),
                    "Content-Type": "text/plain; charset=utf-8",
                    "Content-Length": str(len(raw)),
                    "X-Raw-Passthrough": "1",
                }
                self.send_response(200)
                for k, v in headers.items():
                    self.send_header(k, v)
                self.end_headers()
                self.wfile.write(raw)
            except FileNotFoundError:
                self._send(404, json.dumps({"error": "not found"}),
                           "application/json", extra_headers=_bridge_headers())
            except Exception as e:
                self._send(500, json.dumps({"error": str(e)}),
                           "application/json", extra_headers=_bridge_headers())
            return

        # GET /bridge/list?path=<absolute_path>
        if path.startswith("/bridge/list"):
            if not BRIDGE_ENABLED:
                self._send(503, json.dumps({"error": "bridge disabled"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            from urllib.parse import urlparse, parse_qs as _parse_qs
            qs = _parse_qs(urlparse(self.path).query)
            fpath = qs.get("path", [""])[0]
            if not fpath or not _bridge_path_allowed(fpath):
                self._send(403, json.dumps({"error": "path not allowed"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            try:
                full = os.path.realpath(os.path.expanduser(fpath))
                entries = os.listdir(full)
                self._send(200, json.dumps(sorted(entries)),
                           "application/json", extra_headers=_bridge_headers())
            except Exception as e:
                self._send(500, json.dumps({"error": str(e)}),
                           "application/json", extra_headers=_bridge_headers())
            return

        # GET /bridge/status
        if path == "/bridge/status":
            self._send(200, json.dumps({
                "enabled": BRIDGE_ENABLED,
                "allowed_paths": ALLOWED_PATHS,
                "allowed_path_count": len(ALLOWED_PATHS),
            }), "application/json", extra_headers=_bridge_headers())
            return

        # GET /bridge/requests — list pending agent permission requests
        if path == "/bridge/requests":
            with BRIDGE_REQUESTS_LOCK:
                requests_copy = list(BRIDGE_REQUESTS)
            self._send(200, json.dumps({"requests": requests_copy}),
                       "application/json", extra_headers=_bridge_headers())
            return

        self._send_json(404, {"error": "not found", "path": path})

    def do_POST(self) -> None:
        global BRIDGE_ENABLED, ALLOWED_PATHS
        path = urlsplit(self.path).path
        if path == "/api/credential-check" or path == "/run/credential-check":
            return self._api_credential_check()
        if path == "/ai-routing/config":
            return self._ai_routing_config_post()
        if path == "/screen-assistant/toggle":
            return self._sa_toggle()
        if path == "/session-memory/run":
            return self._session_memory_run()
        if path == "/debate/start":
            return self._debate_start()
        if path.startswith("/debate/continue/"):
            return self._debate_continue(path[len("/debate/continue/"):])
        if path == "/services/start":
            return self._svc_start()
        if path == "/services/stop":
            return self._svc_stop()
        if path == "/services/restart":
            return self._svc_restart()
        if path == "/services/restart-panel":
            return self._restart_panel()
        if path == "/voice-kanban/test":
            return self._vk_test()
        if path == "/voice-kanban/toggle":
            return self._vk_toggle()
        if path == "/learning-loop/run":
            return self._ll_run()
        if path == "/team/seed":
            return self._team_seed()
        if path == "/research/toggle":
            return self._research_toggle()
        if path == "/launch/all":              return self._launch_all()
        if path == "/blocklist":               return self._api_blocklist_post()
        if path.startswith("/api/screenpipe/"):
            return self._proxy("screenpipe", path[len("/api/screenpipe"):])
        if path.startswith("/api/hermes/"):
            return self._proxy("hermes",     path[len("/api/hermes"):])

        # POST /bridge/write  body: {path, content, backup:bool}
        if path == "/bridge/write":
            if not BRIDGE_ENABLED:
                self._send(503, json.dumps({"error": "bridge disabled"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            import shutil
            body = json.loads(self.rfile.read(
                int(self.headers.get("Content-Length", 0))))
            fpath = body.get("path", "")
            content = body.get("content", "")
            do_backup = body.get("backup", True)
            if not fpath or not _bridge_path_allowed(fpath):
                self._send(403, json.dumps({"error": "path not allowed"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            try:
                full = os.path.realpath(os.path.expanduser(fpath))
                backup_path = None
                if do_backup and os.path.exists(full):
                    backup_path = full + ".bak"
                    shutil.copy2(full, backup_path)
                os.makedirs(os.path.dirname(full), exist_ok=True)
                with open(full, "w") as f:
                    f.write(content)
                result = {"ok": True, "bytesWritten": len(content.encode()),
                          "backup": backup_path}
                self._send(200, json.dumps(result),
                           "application/json", extra_headers=_bridge_headers())
            except Exception as e:
                self._send(500, json.dumps({"error": str(e)}),
                           "application/json", extra_headers=_bridge_headers())
            return

        # POST /bridge/exec  body: {cmd, timeout}
        if path == "/bridge/exec":
            if not BRIDGE_ENABLED:
                self._send(503, json.dumps({"error": "bridge disabled"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            body = json.loads(self.rfile.read(
                int(self.headers.get("Content-Length", 0))))
            cmd = body.get("cmd", "")
            timeout = min(int(body.get("timeout", 30)), 120)
            if not cmd:
                self._send(400, json.dumps({"error": "cmd required"}),
                           "application/json", extra_headers=_bridge_headers())
                return
            try:
                result = subprocess.run(
                    cmd, shell=True, capture_output=True,
                    text=True, timeout=timeout)
                self._send(200, json.dumps({
                    "stdout": result.stdout,
                    "stderr": result.stderr,
                    "returncode": result.returncode,
                }), "application/json", extra_headers=_bridge_headers())
            except subprocess.TimeoutExpired:
                self._send(200, json.dumps({
                    "stdout": "", "stderr": f"timeout after {timeout}s",
                    "returncode": -1,
                }), "application/json", extra_headers=_bridge_headers())
            except Exception as e:
                self._send(500, json.dumps({"error": str(e)}),
                           "application/json", extra_headers=_bridge_headers())
            return

        # POST /bridge/request  body: {action, params, reason, agent}
        if path == "/bridge/request":
            try:
                body = json.loads(self.rfile.read(
                    int(self.headers.get("Content-Length", 0))) or b"{}")
            except Exception:
                body = {}
            req_id = f"req_{int(time.time()*1000)}_{os.urandom(3).hex()}"
            entry = {
                "id":     req_id,
                "action": str(body.get("action", "")),
                "params": body.get("params") or {},
                "reason": str(body.get("reason", "")),
                "agent":  str(body.get("agent", "unknown")),
                "ts":     int(time.time() * 1000),
                "status": "pending",
            }
            with BRIDGE_REQUESTS_LOCK:
                BRIDGE_REQUESTS.append(entry)
            self._send(200, json.dumps({
                "ok": True, "request_id": req_id, "status": "pending",
            }), "application/json", extra_headers=_bridge_headers())
            return

        # POST /bridge/request/<id>/approve | /deny
        if path.startswith("/bridge/request/") and (
            path.endswith("/approve") or path.endswith("/deny")
        ):
            parts = path.split("/")
            # ['', 'bridge', 'request', '<id>', '<approve|deny>']
            if len(parts) == 5:
                req_id = parts[3]
                op = parts[4]
                with BRIDGE_REQUESTS_LOCK:
                    target = next((r for r in BRIDGE_REQUESTS
                                   if r.get("id") == req_id), None)
                    if target is None:
                        self._send(404, json.dumps({"error": "not found"}),
                                   "application/json",
                                   extra_headers=_bridge_headers())
                        return
                    if op == "deny":
                        target["status"] = "denied"
                        self._send(200, json.dumps({"ok": True}),
                                   "application/json",
                                   extra_headers=_bridge_headers())
                        return
                    # approve
                    target["status"] = "approved"
                    action = target.get("action", "")
                    params = target.get("params") or {}
                executed = False
                exec_error = None
                try:
                    if action == "add_allowed_path":
                        new_paths = params.get("allowed_paths") or []
                        for p in new_paths:
                            real = os.path.realpath(os.path.expanduser(str(p)))
                            if real not in ALLOWED_PATHS:
                                ALLOWED_PATHS.append(real)
                        _save_bridge_config()
                        executed = True
                    elif action == "set_enabled":
                        BRIDGE_ENABLED = bool(params.get("enabled", False))
                        _save_bridge_config()
                        executed = True
                    else:
                        # Unknown actions are recorded approved but not executed.
                        executed = False
                except Exception as e:
                    exec_error = str(e)
                resp = {"ok": True, "executed": executed}
                if exec_error:
                    resp["error"] = exec_error
                self._send(200, json.dumps(resp),
                           "application/json",
                           extra_headers=_bridge_headers())
                return

        # POST /bridge/config  body: {enabled:bool, allowed_paths:[str]}
        if path == "/bridge/config":
            body = json.loads(self.rfile.read(
                int(self.headers.get("Content-Length", 0))))
            if "enabled" in body:
                BRIDGE_ENABLED = bool(body["enabled"])
            if "allowed_paths" in body:
                ALLOWED_PATHS = [os.path.realpath(os.path.expanduser(str(p)))
                                 for p in body["allowed_paths"]]
            _save_bridge_config()
            result = {"ok": True, "enabled": BRIDGE_ENABLED,
                      "allowed_paths": ALLOWED_PATHS}
            self._send(200, json.dumps(result),
                       "application/json", extra_headers=_bridge_headers())
            return

        self._send_json(404, {"error": "not found", "path": path})

    # ── /  → panel HTML ──────────────────────────────────────────────────────

    def _serve_panel(self) -> None:
        if not PANEL_HTML.is_file():
            self._send_text(500, f"panel HTML missing: {PANEL_HTML}")
            return
        body = PANEL_HTML.read_bytes()
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-cache")
        self._cors()
        self.end_headers()
        self.wfile.write(body)

    # ── /stream  (SSE) ───────────────────────────────────────────────────────

    def _sse_stream(self) -> None:
        # SSE headers. Streaming response — never close from server side
        # unless the client disconnects or the broadcaster stops.
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        # Disable any reverse-proxy buffering (defence in depth — we don't
        # actually expect a proxy in front of 127.0.0.1).
        self.send_header("X-Accel-Buffering", "no")
        self._cors()
        self.end_headers()

        q = BROADCASTER.subscribe()
        try:
            # Send a hello so the client knows the connection is live before
            # the first tick fires.
            self.wfile.write(b": connected\n\n")
            self.wfile.flush()
            while True:
                try:
                    payload = q.get(timeout=15.0)
                    chunk = f"data: {payload}\n\n".encode("utf-8")
                except queue.Empty:
                    # Heartbeat comment keeps stalled proxies / clients honest.
                    chunk = b": keepalive\n\n"
                try:
                    self.wfile.write(chunk)
                    self.wfile.flush()
                except (BrokenPipeError, ConnectionResetError, OSError):
                    return
        finally:
            BROADCASTER.unsubscribe(q)

    def _snapshot_once(self) -> None:
        snapshot = poll_all_services()
        return self._send_json(200, {
            "ts": int(time.time() * 1000),
            "services": snapshot,
            "alerts": derive_alerts(snapshot),
        })

    # ── /api/vault/stats ─────────────────────────────────────────────────────

    def _api_vault_stats(self) -> None:
        if not VAULT_WORKSPACE.is_dir():
            return self._send_json(200, {"file_count": 0, "last_scrub": None, "files": []})
        files = []
        latest = 0.0
        for p in VAULT_WORKSPACE.iterdir():
            if p.is_file():
                st = p.stat()
                files.append({"name": p.name, "size": st.st_size, "mtime": st.st_mtime})
                latest = max(latest, st.st_mtime)
        files.sort(key=lambda f: f["mtime"], reverse=True)
        last_iso = datetime.fromtimestamp(latest, tz=timezone.utc).isoformat() if latest else None
        return self._send_json(200, {
            "file_count": len(files),
            "last_scrub": last_iso,
            "last_scrub_epoch": latest,
            "files": files[:10],
        })

    def _api_quarantine_stats(self) -> None:
        if not VAULT_QUARANTINE.is_dir():
            return self._send_json(200, {"count": 0, "files": [], "last": None})
        files = []
        latest = 0.0
        for p in VAULT_QUARANTINE.iterdir():
            if p.is_file():
                st = p.stat()
                files.append({"name": p.name, "size": st.st_size, "mtime": st.st_mtime})
                latest = max(latest, st.st_mtime)
        files.sort(key=lambda f: f["mtime"], reverse=True)
        last_iso = datetime.fromtimestamp(latest, tz=timezone.utc).isoformat() if latest else None
        return self._send_json(200, {
            "count": len(files),
            "last": last_iso,
            "files": files[:10],
        })

    # ── /api/mcp/log?n=N ─────────────────────────────────────────────────────

    def _api_mcp_log(self) -> None:
        qs = parse_qs(urlsplit(self.path).query)
        try:
            n = int(qs.get("n", ["20"])[0])
        except ValueError:
            n = 20
        n = max(1, min(n, 500))
        if not MCP_LOG.is_file():
            return self._send_json(200, {"lines": [], "missing": True})
        with MCP_LOG.open("r", encoding="utf-8", errors="replace") as fh:
            tail = fh.readlines()[-n:]
        parsed = []
        for raw in tail:
            raw = raw.rstrip("\n")
            parts = raw.split("\t", 2)
            if len(parts) == 3:
                ts, tool, detail = parts
            elif len(parts) == 2:
                ts, tool = parts; detail = ""
            else:
                ts, tool, detail = "", "", raw
            parsed.append({"ts": ts, "tool": tool, "detail": detail, "raw": raw})
        return self._send_json(200, {"lines": parsed})

    # ── /logs?file=NAME&lines=N ──────────────────────────────────────────────
    # Generic tail-er for any file in the ALLOWED_LOG_FILES whitelist, plus
    # the backend's own /tmp/panel_server.log (special-cased because LOG_DIR
    # is locked to ~/beewid-privacy/).

    def _api_logs(self) -> None:
        qs = parse_qs(urlsplit(self.path).query)
        name = (qs.get("file") or [""])[0]
        try:
            n = int((qs.get("lines") or ["20"])[0])
        except ValueError:
            n = 20
        n = max(1, min(n, 500))

        # Path traversal defence: reject anything with separators or `..`
        # before doing any path math.
        if "/" in name or "\\" in name or ".." in name:
            return self._send_json(400, {"error": "invalid file name", "file": name})

        if name == BACKEND_LOG_NAME:
            path = LOG_FILE
        elif name in ALLOWED_LOG_FILES:
            path = LOG_DIR / name
        else:
            return self._send_json(400, {
                "error": "file not allowed",
                "file": name,
                "allowed": sorted(ALLOWED_LOG_FILES | {BACKEND_LOG_NAME}),
            })

        if not path.is_file():
            return self._send_json(200, {"file": name, "lines": [], "count": 0, "missing": True})

        try:
            with path.open("r", encoding="utf-8", errors="replace") as fh:
                tail = fh.readlines()[-n:]
        except OSError as exc:
            return self._send_json(500, {"error": "read failed", "reason": str(exc)})

        lines = [ln.rstrip("\n") for ln in tail]
        return self._send_json(200, {"file": name, "lines": lines, "count": len(lines)})

    # ── /api/credential-check ────────────────────────────────────────────────

    def _api_credential_check(self) -> None:
        if not CREDENTIAL_CHECK.is_file():
            return self._send_json(500, {"error": f"missing: {CREDENTIAL_CHECK}"})
        try:
            # Fixed path, no shell, no caller input. Safe.
            proc = subprocess.run(
                ["/bin/bash", str(CREDENTIAL_CHECK)],
                capture_output=True, text=True, timeout=30,
            )
        except subprocess.TimeoutExpired:
            return self._send_json(504, {"error": "credential_check.sh timed out after 30s"})
        return self._send_json(200, {
            "exit_code": proc.returncode,
            "exit":      proc.returncode,  # back-compat alias
            "passed":    proc.returncode == 0,
            "output":    proc.stdout,
            "stdout":    proc.stdout,      # back-compat alias
            "stderr":    proc.stderr,
            "timestamp": datetime.now(tz=timezone.utc).isoformat(),
        })

    # ── /ai-routing/* ────────────────────────────────────────────────────────

    def _ai_routing_status(self) -> None:
        cfg = _load_ai_routing_config()
        return self._send_json(200, _ai_routing_config_public(cfg))

    def _ai_routing_config_post(self) -> None:
        body = self._read_body_json()
        cfg = _load_ai_routing_config()
        # Merge top-level keys
        if "tier" in body:
            cfg["tier"] = str(body["tier"])
        for section in ("local", "private", "cloud"):
            if section in body and isinstance(body[section], dict):
                cfg.setdefault(section, {}).update(body[section])
        _save_ai_routing_config(cfg)
        return self._send_json(200, _ai_routing_config_public(cfg))

    def _ai_routing_test(self) -> None:
        qs = parse_qs(urlsplit(self.path).query)
        tier = (qs.get("tier") or ["cloud"])[0]
        if tier == "local":
            available = _check_local_available()
            msg = "Ollama reachable" if available else "Ollama not reachable at configured URL"
        elif tier == "private":
            available = _check_private_available()
            msg = "Private server reachable" if available else "Private server not reachable"
        else:
            available = _check_cloud_available()
            msg = "Hermes gateway reachable" if available else "Hermes gateway not reachable"
        return self._send_json(200, {"tier": tier, "available": available, "message": msg})

    # ── /screen-assistant/status ─────────────────────────────────────────────

    def _sa_status(self) -> None:
        return self._send_json(200, _screen_assistant_status())

    # ── /screen-assistant/toggle ────────────────────────────────────────────
    # Body: {"action": "start" | "stop"}.  Defaults to toggling current state.

    def _sa_toggle(self) -> None:
        body = b""
        content_length = self.headers.get("Content-Length")
        if content_length and content_length.isdigit():
            try:
                body = self.rfile.read(int(content_length))
            except OSError:
                body = b""
        action = None
        if body:
            try:
                obj = json.loads(body.decode("utf-8", errors="replace") or "{}")
                if isinstance(obj, dict):
                    raw_action = obj.get("action")
                    if isinstance(raw_action, str) and raw_action.lower() in ("start", "stop"):
                        action = raw_action.lower()
            except Exception:
                pass

        current = _pid_status(SA_PID_FILE)
        if action is None:
            action = "stop" if current.get("running") else "start"

        if action == "stop":
            if current.get("running") and current.get("pid"):
                try:
                    os.kill(int(current["pid"]), signal.SIGTERM)
                except (OSError, ValueError) as exc:
                    return self._send_json(500, {"error": f"kill failed: {exc}"})
                # Give the daemon a moment to clean up its PID file.
                for _ in range(20):
                    if not _alive(int(current["pid"])): break
                    time.sleep(0.1)
            try:
                if SA_PID_FILE.is_file():
                    SA_PID_FILE.unlink()
            except OSError:
                pass
            return self._send_json(200, {"action": "stop", "status": _screen_assistant_status()})

        # action == "start"
        if current.get("running"):
            return self._send_json(200, {"action": "noop", "reason": "already running", "status": current})
        if not SA_SCRIPT.is_file():
            return self._send_json(500, {"error": f"missing: {SA_SCRIPT}"})
        try:
            # Fully detached background process. stdout/stderr → runtime
            # log; the daemon writes its own JSON suggestions to SA_LOG so
            # we MUST NOT redirect stdout there or we'll contaminate the
            # JSON-lines file with python logging output.
            log_fh = open(SA_RUNTIME_LOG, "a", encoding="utf-8")
            proc = subprocess.Popen(
                ["/usr/bin/env", "python3", str(SA_SCRIPT)],
                stdout=log_fh, stderr=log_fh,
                start_new_session=True,
                close_fds=True,
            )
        except OSError as exc:
            return self._send_json(500, {"error": f"spawn failed: {exc}"})
        # The daemon writes its own PID file; give it a brief moment.
        for _ in range(15):
            if _read_pid(SA_PID_FILE): break
            time.sleep(0.1)
        return self._send_json(200, {
            "action": "start",
            "spawned_pid": proc.pid,
            "status": _screen_assistant_status(),
        })

    # ── Session memory (Tier-2) ─────────────────────────────────────────────
    # POST /session-memory/run  → spawns session_memory.py in the background,
    #                              returns a run_id immediately.
    # GET  /session-memory/status (optional ?id=…) → latest run, or named run.
    #
    # State for each run lives in SM_STATUS_DIR/<run_id>.json:
    #   {"id", "started", "finished", "exit_code", "output_path",
    #    "stdout_tail", "stderr_tail", "running"}

    def _session_memory_run(self) -> None:
        if not SM_SCRIPT.is_file():
            return self._send_json(500, {"error": f"missing: {SM_SCRIPT}"})
        SM_STATUS_DIR.mkdir(parents=True, exist_ok=True)
        run_id = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        status_path = SM_STATUS_DIR / f"{run_id}.json"
        _write_json(status_path, {
            "id": run_id,
            "started": datetime.now(tz=timezone.utc).isoformat(),
            "finished": None,
            "running": True,
            "exit_code": None,
            "output_path": None,
            "stdout_tail": "",
            "stderr_tail": "",
        })

        # Worker thread keeps us off the response path so the panel can
        # immediately render its "synthesizing…" spinner and start polling.
        def _worker():
            try:
                proc = subprocess.run(
                    ["/usr/bin/env", "python3", str(SM_SCRIPT)],
                    capture_output=True, text=True, timeout=180,
                )
                stdout = (proc.stdout or "").strip()
                stderr = (proc.stderr or "").strip()
                exit_code = proc.returncode
                output_path = stdout.splitlines()[-1] if stdout and exit_code == 0 else None
            except subprocess.TimeoutExpired:
                stdout, stderr, exit_code, output_path = "", "timed out after 180s", 124, None
            except Exception as exc:
                stdout, stderr, exit_code, output_path = "", f"worker crashed: {exc}", -1, None
            _write_json(status_path, {
                "id": run_id,
                "started": _read_json(status_path).get("started"),
                "finished": datetime.now(tz=timezone.utc).isoformat(),
                "running": False,
                "exit_code": exit_code,
                "output_path": output_path,
                "stdout_tail": stdout[-2000:],
                "stderr_tail": stderr[-2000:],
            })

        threading.Thread(target=_worker, name=f"session-mem-{run_id}", daemon=True).start()
        return self._send_json(202, {"run_id": run_id, "status": "running"})

    def _session_memory_status(self) -> None:
        qs = parse_qs(urlsplit(self.path).query)
        run_id = (qs.get("id") or [""])[0]
        if not SM_STATUS_DIR.is_dir():
            return self._send_json(200, {"runs": [], "latest": None})
        if run_id:
            if "/" in run_id or "\\" in run_id or ".." in run_id:
                return self._send_json(400, {"error": "invalid run_id"})
            path = SM_STATUS_DIR / f"{run_id}.json"
            if not path.is_file():
                return self._send_json(404, {"error": "no such run", "run_id": run_id})
            return self._send_json(200, _read_json(path))
        # No id → return latest run + a small index.
        # Also flatten latest fields at the top level so callers can read
        # exit_code / output_path directly without going through "latest".
        runs = sorted(SM_STATUS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        latest = _read_json(runs[0]) if runs else None
        return self._send_json(200, {
            **(latest or {}),
            "latest": latest,
            "runs": [p.stem for p in runs[:10]],
        })

    # ── Multi-agent debate (Tier-2) ─────────────────────────────────────────
    # POST /debate/start  body: {topic, profile_a, profile_b, judge}
    # GET  /debate/status/{id}
    # GET  /debate/list
    #
    # Each debate spawns A and B in parallel; once both finish, the judge
    # reads both transcripts and writes the verdict. Status lives at
    # DEBATE_STATUS_DIR/<debate_id>.json.

    def _debate_start(self) -> None:
        body = b""
        content_length = self.headers.get("Content-Length")
        if content_length and content_length.isdigit():
            try:
                body = self.rfile.read(int(content_length))
            except OSError:
                body = b""
        try:
            payload = json.loads(body.decode("utf-8", errors="replace") or "{}")
        except Exception:
            payload = {}
        if not isinstance(payload, dict):
            payload = {}

        topic = (payload.get("topic") or "").strip()
        if not topic:
            return self._send_json(400, {"error": "topic is required"})
        if len(topic) > 800:
            return self._send_json(400, {"error": "topic too long (max 800 chars)"})

        profile_a = _safe_profile(payload.get("profile_a"), default="swarm1")
        profile_b = _safe_profile(payload.get("profile_b"), default="swarm2")
        judge     = _safe_profile(payload.get("judge"),     default="swarm13")

        DEBATE_DIR.mkdir(parents=True, exist_ok=True)
        DEBATE_STATUS_DIR.mkdir(parents=True, exist_ok=True)

        debate_id = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        files = {
            "a":       DEBATE_DIR / f"debate_{debate_id}_a.md",
            "b":       DEBATE_DIR / f"debate_{debate_id}_b.md",
            "verdict": DEBATE_DIR / f"debate_{debate_id}_verdict.md",
        }
        status_path = DEBATE_STATUS_DIR / f"{debate_id}.json"
        _write_json(status_path, {
            "id": debate_id,
            "topic": topic,
            "profile_a": profile_a,
            "profile_b": profile_b,
            "judge": judge,
            "started": datetime.now(tz=timezone.utc).isoformat(),
            "finished": None,
            "running": True,
            "stage": "spawning",
            "files": {k: str(v) for k, v in files.items()},
            "exit_codes": {},
            "errors": [],
        })

        threading.Thread(
            target=_run_debate_worker,
            args=(debate_id, topic, profile_a, profile_b, judge, files, status_path),
            name=f"debate-{debate_id}",
            daemon=True,
        ).start()
        return self._send_json(202, {"debate_id": debate_id, "status": "running"})

    def _debate_status(self, debate_id: str) -> None:
        if not debate_id or "/" in debate_id or "\\" in debate_id or ".." in debate_id:
            return self._send_json(400, {"error": "invalid debate_id"})
        path = DEBATE_STATUS_DIR / f"{debate_id}.json"
        if not path.is_file():
            return self._send_json(404, {"error": "no such debate", "debate_id": debate_id})
        return self._send_json(200, _read_json(path))

    def _debate_list(self) -> None:
        if not DEBATE_STATUS_DIR.is_dir():
            return self._send_json(200, {"debates": []})
        files = sorted(DEBATE_STATUS_DIR.glob("*.json"), key=lambda p: p.stat().st_mtime, reverse=True)
        out = []
        for p in files[:20]:
            d = _read_json(p)
            out.append({
                "id": d.get("id"),
                "topic": d.get("topic"),
                "running": d.get("running"),
                "stage": d.get("stage"),
                "started": d.get("started"),
                "finished": d.get("finished"),
            })
        return self._send_json(200, {"debates": out})

    def _debate_transcript(self, debate_id: str, side: str) -> None:
        if not debate_id or "/" in debate_id or "\\" in debate_id or ".." in debate_id:
            return self._send_json(400, {"error": "invalid debate_id"})
        if side not in ("a", "b", "verdict"):
            return self._send_json(400, {"error": "side must be a, b, or verdict"})
        fpath = DEBATE_DIR / f"debate_{debate_id}_{side}.md"
        if not fpath.is_file():
            return self._send_json(200, {"content": "", "word_count": 0, "exists": False})
        try:
            content = fpath.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            return self._send_json(500, {"error": str(exc)})
        return self._send_json(200, {
            "content": content,
            "word_count": len(content.split()),
            "exists": True,
        })

    def _debate_continue(self, debate_id: str) -> None:
        if not debate_id or "/" in debate_id or "\\" in debate_id or ".." in debate_id:
            return self._send_json(400, {"error": "invalid debate_id"})
        body = b""
        content_length = self.headers.get("Content-Length")
        if content_length and content_length.isdigit():
            try:
                body = self.rfile.read(int(content_length))
            except OSError:
                body = b""
        try:
            payload = json.loads(body.decode("utf-8", errors="replace") or "{}")
        except Exception:
            payload = {}
        follow_up = (payload.get("follow_up") or "").strip()
        if not follow_up:
            return self._send_json(400, {"error": "follow_up is required"})
        if len(follow_up) > 800:
            return self._send_json(400, {"error": "follow_up too long (max 800 chars)"})

        status_path = DEBATE_STATUS_DIR / f"{debate_id}.json"
        if not status_path.is_file():
            return self._send_json(404, {"error": "original debate not found"})
        orig = _read_json(status_path)
        profile_a = _safe_profile(orig.get("profile_a"), "swarm1")
        profile_b = _safe_profile(orig.get("profile_b"), "swarm2")
        judge     = _safe_profile(orig.get("judge"),     "swarm13")
        orig_topic = (orig.get("topic") or "").strip()

        # Prepend prior verdict as context so agents know what was already argued.
        verdict_path = DEBATE_DIR / f"debate_{debate_id}_verdict.md"
        context = ""
        if verdict_path.is_file():
            try:
                context = verdict_path.read_text(encoding="utf-8", errors="replace")[:600]
            except OSError:
                pass
        new_topic = follow_up
        if orig_topic:
            new_topic = f"{follow_up} (continued from: {orig_topic[:120]})"
        if context:
            new_topic += f"\n\n[Prior verdict excerpt: {context}]"

        DEBATE_DIR.mkdir(parents=True, exist_ok=True)
        DEBATE_STATUS_DIR.mkdir(parents=True, exist_ok=True)
        new_id = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        files = {
            "a":       DEBATE_DIR / f"debate_{new_id}_a.md",
            "b":       DEBATE_DIR / f"debate_{new_id}_b.md",
            "verdict": DEBATE_DIR / f"debate_{new_id}_verdict.md",
        }
        new_status = DEBATE_STATUS_DIR / f"{new_id}.json"
        _write_json(new_status, {
            "id": new_id,
            "topic": follow_up,
            "orig_topic": orig_topic,
            "orig_debate_id": debate_id,
            "profile_a": profile_a,
            "profile_b": profile_b,
            "judge": judge,
            "started": datetime.now(tz=timezone.utc).isoformat(),
            "finished": None,
            "running": True,
            "stage": "spawning",
            "files": {k: str(v) for k, v in files.items()},
            "exit_codes": {},
            "errors": [],
        })
        threading.Thread(
            target=_run_debate_worker,
            args=(new_id, new_topic, profile_a, profile_b, judge, files, new_status),
            name=f"debate-{new_id}",
            daemon=True,
        ).start()
        return self._send_json(202, {"debate_id": new_id, "orig_id": debate_id, "status": "running"})

    # ── Service control (start / stop / restart) ─────────────────────────────

    def _read_body_json(self) -> dict:
        body = b""
        cl = self.headers.get("Content-Length")
        if cl and cl.isdigit():
            try: body = self.rfile.read(int(cl))
            except OSError: body = b""
        try:
            obj = json.loads(body.decode("utf-8", errors="replace") or "{}")
            return obj if isinstance(obj, dict) else {}
        except Exception:
            return {}

    def _svc_do_start(self, name: str) -> tuple[bool, str]:
        """Spawn the service. Returns (success, message)."""
        defn = _SVC_DEFS.get(name)
        if not defn:
            return False, f"unknown service: {name}"
        log_path = defn.get("start_log", "/tmp/svc.log")
        try:
            log_fh = open(log_path, "a", encoding="utf-8")
        except OSError as exc:
            return False, f"cannot open log {log_path}: {exc}"

        # Special case: aionui — run launch-aionui.sh if it exists
        if name == "aionui":
            if not LAUNCH_AIONUI.is_file():
                try: log_fh.close()
                except OSError: pass
                return False, f"launch script not found: {LAUNCH_AIONUI}"
            argv = ["/bin/bash", str(LAUNCH_AIONUI)]
        # Special case: space_agent — needs cwd + PORT env
        elif name == "space_agent":
            if not SPACE_AGENT_DIR.is_dir():
                try: log_fh.close()
                except OSError: pass
                return False, f"space-agent directory not found: {SPACE_AGENT_DIR}"
            env = {**os.environ, "PORT": "3000"}
            try:
                subprocess.Popen(
                    ["npm", "start"],
                    cwd=str(SPACE_AGENT_DIR),
                    env=env,
                    stdout=log_fh, stderr=log_fh,
                    start_new_session=True, close_fds=True,
                )
            except OSError as exc:
                try: log_fh.close()
                except OSError: pass
                return False, f"spawn failed: {exc}"
            try: log_fh.close()
            except OSError: pass
            return True, f"space_agent starting (log: {log_path})"
        else:
            argv = defn.get("start_argv")
            if not argv:
                try: log_fh.close()
                except OSError: pass
                return False, f"no start command defined for {name}"

        env_extra = defn.get("start_env")
        spawn_env = {**os.environ, **env_extra} if env_extra else None

        try:
            subprocess.Popen(
                argv, stdout=log_fh, stderr=log_fh,
                env=spawn_env,
                start_new_session=True, close_fds=True,
            )
        except OSError as exc:
            try: log_fh.close()
            except OSError: pass
            return False, f"spawn failed: {exc}"
        try: log_fh.close()
        except OSError: pass
        return True, f"{name} starting (log: {log_path})"

    def _svc_do_stop(self, name: str) -> tuple[bool, str]:
        """Stop the service. Returns (success, message)."""
        defn = _SVC_DEFS.get(name)
        if not defn:
            return False, f"unknown service: {name}"

        # Prefer PID file kill over pkill for cleaner shutdown.
        pid_file_str = defn.get("pid_file")
        if pid_file_str:
            pid = _read_pid(Path(pid_file_str))
            if pid and _alive(pid):
                try:
                    import signal as _sig
                    os.kill(pid, _sig.SIGTERM)
                    return True, f"{name} stopped (SIGTERM → PID {pid})"
                except OSError as exc:
                    logger.warning("SIGTERM %d failed: %s", pid, exc)

        # Fallback: pkill -f with fixed pattern (no caller input in pattern).
        pattern = defn.get("stop_pattern")
        if not pattern:
            return False, f"no stop method for {name}"
        try:
            result = subprocess.run(
                ["pkill", "-f", pattern],
                capture_output=True, timeout=5,
            )
            if result.returncode in (0, 1):   # 1 = no processes matched
                return True, f"{name} stopped (pkill -f '{pattern}')"
            return False, f"pkill returned {result.returncode}"
        except (OSError, subprocess.TimeoutExpired) as exc:
            return False, f"pkill failed: {exc}"

    def _svc_start(self) -> None:
        payload = self._read_body_json()
        name = (payload.get("service") or "").strip()
        if not name:
            return self._send_json(400, {"error": "service is required"})
        ok, msg = self._svc_do_start(name)
        logger.info("svc_start %s → %s %s", name, ok, msg)
        return self._send_json(200 if ok else 500, {"success": ok, "message": msg, "service": name})

    def _svc_stop(self) -> None:
        payload = self._read_body_json()
        name = (payload.get("service") or "").strip()
        if not name:
            return self._send_json(400, {"error": "service is required"})
        ok, msg = self._svc_do_stop(name)
        logger.info("svc_stop %s → %s %s", name, ok, msg)
        return self._send_json(200 if ok else 500, {"success": ok, "message": msg, "service": name})

    def _svc_restart(self) -> None:
        payload = self._read_body_json()
        name = (payload.get("service") or "").strip()
        if not name:
            return self._send_json(400, {"error": "service is required"})
        ok_stop, msg_stop = self._svc_do_stop(name)
        time.sleep(2)
        ok_start, msg_start = self._svc_do_start(name)
        ok = ok_start
        msg = f"stop: {msg_stop} | start: {msg_start}"
        logger.info("svc_restart %s → %s", name, msg)
        return self._send_json(200 if ok else 500, {"success": ok, "message": msg, "service": name})

    def _restart_panel(self) -> None:
        """Launch a background script that kills this process and relaunches it."""
        script = Path("/tmp/_panel_restart.sh")
        pid = os.getpid()
        panel_py = Path(__file__).resolve()
        script.write_text(
            "#!/bin/bash\n"
            "sleep 2\n"
            f"kill {pid} 2>/dev/null\n"
            "sleep 1\n"
            f"nohup python3 {panel_py} >> /tmp/panel_server.log 2>&1 &\n"
            "disown\n",
            encoding="utf-8",
        )
        script.chmod(0o700)
        subprocess.Popen(
            ["/bin/bash", str(script)],
            start_new_session=True, close_fds=True,
            stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
        )
        return self._send_json(200, {"message": "restarting panel in 2 s…", "pid": pid})

    # ── Proactive research (Tier-3) ──────────────────────────────────────────

    def _research_queue(self) -> None:
        pending = []
        completed = []
        if PR_QUEUE.is_file():
            try:
                with PR_QUEUE.open("r", encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        line = line.strip()
                        if not line:
                            continue
                        try:
                            obj = json.loads(line)
                            if isinstance(obj, dict):
                                if obj.get("status") == "pending":
                                    pending.append(obj)
                                else:
                                    completed.append(obj)
                        except Exception:
                            continue
            except OSError:
                pass
        return self._send_json(200, {
            "pending_count": len(pending),
            "completed_count": len(completed),
            "pending": pending[-10:],
            "last_completed": completed[-5:],
            "exa_key_set":      bool(os.environ.get("EXA_API_KEY")),
            "firecrawl_key_set": bool(os.environ.get("FIRECRAWL_API_KEY")),
        })

    def _research_status(self) -> None:
        pid_info = _tier3_pid_status(PR_PID_FILE, PR_SCRIPT)
        pending_count = 0
        if PR_QUEUE.is_file():
            try:
                with PR_QUEUE.open("r", encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        try:
                            if json.loads(line.strip()).get("status") == "pending":
                                pending_count += 1
                        except Exception:
                            pass
            except OSError:
                pass
        return self._send_json(200, {
            **pid_info,
            "pending_count":     pending_count,
            "exa_key_set":       bool(os.environ.get("EXA_API_KEY")),
            "firecrawl_key_set": bool(os.environ.get("FIRECRAWL_API_KEY")),
        })

    def _research_toggle(self) -> None:
        pid_info = _pid_status(PR_PID_FILE)
        if pid_info.get("running"):
            try:
                os.kill(int(pid_info["pid"]), signal.SIGTERM)
            except (OSError, ValueError) as exc:
                return self._send_json(500, {"error": str(exc)})
            return self._send_json(200, {"action": "stop"})
        if not PR_SCRIPT.is_file():
            return self._send_json(500, {"error": f"missing: {PR_SCRIPT}"})
        log_fh = open(HOME / "beewid-privacy" / "proactive_research.log", "a", encoding="utf-8")
        subprocess.Popen(
            ["/usr/bin/env", "python3", str(PR_SCRIPT)],
            stdout=log_fh, stderr=log_fh,
            start_new_session=True, close_fds=True,
        )
        time.sleep(0.5)
        return self._send_json(200, {"action": "start", "status": _tier3_pid_status(PR_PID_FILE, PR_SCRIPT)})

    # ── Voice Kanban (Tier-3) ────────────────────────────────────────────────

    def _vk_status(self) -> None:
        pid_info = _tier3_pid_status(VK_PID_FILE, VK_SCRIPT)
        results: list[dict] = []
        if VK_RESULTS.is_file():
            try:
                with VK_RESULTS.open("r", encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        try:
                            obj = json.loads(line.strip())
                            if isinstance(obj, dict):
                                results.append(obj)
                        except Exception:
                            continue
            except OSError:
                pass
        return self._send_json(200, {
            **pid_info,
            "last_results": results[-5:],
            "total_converted": len(results),
        })

    def _vk_toggle(self) -> None:
        pid_info = _pid_status(VK_PID_FILE)
        if pid_info.get("running"):
            try:
                os.kill(int(pid_info["pid"]), signal.SIGTERM)
            except (OSError, ValueError) as exc:
                return self._send_json(500, {"error": str(exc)})
            return self._send_json(200, {"action": "stop"})
        if not VK_SCRIPT.is_file():
            return self._send_json(500, {"error": f"missing: {VK_SCRIPT}"})
        log_fh = open(HOME / "beewid-privacy" / "voice_kanban.log", "a", encoding="utf-8")
        subprocess.Popen(
            ["/usr/bin/env", "python3", str(VK_SCRIPT)],
            stdout=log_fh, stderr=log_fh,
            start_new_session=True, close_fds=True,
        )
        time.sleep(0.5)
        return self._send_json(200, {"action": "start", "status": _tier3_pid_status(VK_PID_FILE, VK_SCRIPT)})

    def _vk_test(self) -> None:
        """Create a test OMI note in ~/obsidian-vault/ so voice_kanban picks it up."""
        ts = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        target = HOME / "obsidian-vault" / f"omi_test_{ts}.md"
        target.parent.mkdir(parents=True, exist_ok=True)
        target.write_text(
            f"# Voice Note — test {ts}\n\n"
            "Add grant research task for Pro Nara Q3 campaign. "
            "High priority, assign to swarm13, tenant khaoss.\n",
            encoding="utf-8",
        )
        return self._send_json(202, {"file": str(target), "message": "test note written; voice_kanban will pick it up within ~8s if running"})

    # ── Learning Loop (Tier-3) ───────────────────────────────────────────────

    def _ll_status(self) -> None:
        pid_info = _tier3_pid_status(LL_PID_FILE, LL_SCRIPT)
        runs: list[dict] = []
        if LL_RUNS.is_file():
            try:
                with LL_RUNS.open("r", encoding="utf-8", errors="replace") as fh:
                    for line in fh:
                        try:
                            obj = json.loads(line.strip())
                            if isinstance(obj, dict):
                                runs.append(obj)
                        except Exception:
                            continue
            except OSError:
                pass
        latest = runs[-1] if runs else None
        return self._send_json(200, {
            **pid_info,
            "last_run": latest,
            "total_runs": len(runs),
        })

    def _team_seed(self) -> None:
        """POST /team/seed  body: {"team": "<name>", "roles": ["Role", ...]}
        Spawns Hermes teammates into the named (open) AionUi team via
        seed_hermes_team.sh. Returns {ok, seeded[], output} or {error}."""
        import shlex
        SEED_SCRIPT = Path.home() / "beewid-privacy" / "seed_hermes_team.sh"
        try:
            body = json.loads(self.rfile.read(
                int(self.headers.get("Content-Length", 0))) or b"{}")
        except Exception:
            self._send(400, json.dumps({"error": "invalid JSON body"}), "application/json")
            return

        team = (body.get("team") or "").strip()
        roles_in = body.get("roles") or []

        # Validation: team name + roles must be plain, bounded strings.
        # No shell is used (we pass an argv list to subprocess), but we still
        # reject control chars / overlong values defensively.
        def _clean(s: str) -> str:
            s = str(s).strip()
            return s if (0 < len(s) <= 120 and all(ord(c) >= 32 for c in s)) else ""

        team = _clean(team)
        roles = [r for r in (_clean(x) for x in roles_in) if r][:12]  # cap at 12
        if not team:
            self._send(400, json.dumps({"error": "missing or invalid team name"}), "application/json")
            return
        if not roles:
            self._send(400, json.dumps({"error": "no valid roles provided"}), "application/json")
            return
        if not SEED_SCRIPT.exists():
            self._send(500, json.dumps({"error": f"seed script not found: {SEED_SCRIPT}"}), "application/json")
            return

        try:
            proc = subprocess.run(
                ["bash", str(SEED_SCRIPT), team, *roles],
                capture_output=True, text=True, timeout=180,
            )
        except subprocess.TimeoutExpired:
            self._send(504, json.dumps({"error": "seed timed out (is the team open in AionUi?)"}),
                       "application/json")
            return
        except Exception as e:
            self._send(500, json.dumps({"error": str(e)}), "application/json")
            return

        out = (proc.stdout or "") + (("\n" + proc.stderr) if proc.stderr else "")
        if proc.returncode == 0:
            self._send(200, json.dumps({"ok": True, "seeded": roles, "output": out.strip()}),
                       "application/json")
        else:
            # Common failure: team not found / session not open (port/token lookup fails).
            err = (proc.stderr or proc.stdout or "seed failed").strip().splitlines()
            self._send(200, json.dumps({"ok": False,
                       "error": (err[-1] if err else "seed failed"),
                       "output": out.strip()}), "application/json")
            return

    def _ll_run(self) -> None:
        if not LL_SCRIPT.is_file():
            return self._send_json(500, {"error": f"missing: {LL_SCRIPT}"})
        LL_STATUS_DIR.mkdir(parents=True, exist_ok=True)
        run_id = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
        status_path = LL_STATUS_DIR / f"{run_id}.json"
        _write_json(status_path, {
            "id": run_id,
            "started": datetime.now(tz=timezone.utc).isoformat(),
            "finished": None,
            "running": True,
            "exit_code": None,
            "output_path": None,
        })

        def _worker():
            try:
                log_fh = open(HOME / "beewid-privacy" / "learning_loop.log", "a", encoding="utf-8")
                proc = subprocess.run(
                    ["/usr/bin/env", "python3", str(LL_SCRIPT)],
                    capture_output=True, text=True, timeout=400,
                )
                stdout = (proc.stdout or "").strip()
                exit_code = proc.returncode
                output_path = stdout.splitlines()[-1] if stdout and exit_code == 0 else None
            except subprocess.TimeoutExpired:
                exit_code, output_path, stdout = 124, None, ""
            except Exception as exc:
                exit_code, output_path, stdout = -1, None, str(exc)
            _write_json(status_path, {
                "id": run_id,
                "started": _read_json(status_path).get("started"),
                "finished": datetime.now(tz=timezone.utc).isoformat(),
                "running": False,
                "exit_code": exit_code,
                "output_path": output_path,
            })

        threading.Thread(target=_worker, name=f"ll-{run_id}", daemon=True).start()
        return self._send_json(202, {"run_id": run_id, "status": "running"})

    # ── /blocklist ───────────────────────────────────────────────────────────

    def _api_blocklist_get(self) -> None:
        """Return current blocklist.txt as a list of non-comment lines."""
        bl_path = Path.home() / "beewid-privacy" / "blocklist.txt"
        if not bl_path.exists():
            return self._send_json(200, {"patterns": [], "raw": ""})
        raw = bl_path.read_text(encoding="utf-8")
        patterns = [
            ln.strip() for ln in raw.splitlines()
            if ln.strip() and not ln.strip().startswith("#")
        ]
        self._send_json(200, {"patterns": patterns, "raw": raw})

    def _api_blocklist_post(self) -> None:
        """Add, remove, or clear a pattern in blocklist.txt."""
        body = self._read_json_body()
        if body is None:
            return self._send_json(400, {"error": "invalid JSON body"})
        action  = body.get("action", "")
        pattern = body.get("pattern", "").strip()
        bl_path = Path.home() / "beewid-privacy" / "blocklist.txt"

        if action == "clear":
            bl_path.write_text(
                "# KHAOSS Privacy Scrubber — User Blocklist\n"
                "# One pattern per line. Lines starting with # are comments.\n"
                "# Plain word: CompanySecret    → redacted (case-insensitive)\n"
                "# Regex:      regex:SK-[a-z]{32}  → compiled and matched\n",
                encoding="utf-8",
            )
            self._reload_scrubber_blocklist()
            return self._send_json(200, {"ok": True, "action": "cleared"})

        if not pattern:
            return self._send_json(400, {"error": "pattern required"})

        existing = bl_path.read_text(encoding="utf-8") if bl_path.exists() else ""
        lines = existing.splitlines(keepends=True)

        if action == "add":
            # Avoid duplicate
            active = [ln.strip() for ln in lines if ln.strip() and not ln.strip().startswith("#")]
            if pattern not in active:
                lines.append(pattern + "\n")
                bl_path.write_text("".join(lines), encoding="utf-8")
            self._reload_scrubber_blocklist()
            return self._send_json(200, {"ok": True, "action": "added", "pattern": pattern})

        if action == "remove":
            new_lines = [ln for ln in lines if ln.strip() != pattern]
            bl_path.write_text("".join(new_lines), encoding="utf-8")
            self._reload_scrubber_blocklist()
            return self._send_json(200, {"ok": True, "action": "removed", "pattern": pattern})

        return self._send_json(400, {"error": f"unknown action: {action}"})

    # ── /launch/all ─────────────────────────────────────────────────────────────

    def _check_svc_health(self, spec: dict) -> str:
        """Return 'healthy', 'degraded', or 'stopped' for one launch spec entry."""
        check = spec.get("check")
        if check == "pid":
            pid_file = spec.get("pid_file")
            if pid_file:
                pid = _read_pid(Path(pid_file))
                if pid and _alive(pid):
                    return "healthy"
            return "stopped"
        if check == "http":
            host, port, path = spec["http"]
            r = _http_get(host, port, path, timeout=2.0)
            if r and r[0] == 200:
                parsed = r[1]
                svc_status = parsed.get("status", "ok")
                return "degraded" if svc_status == "degraded" else "healthy"
            return "stopped"
        if check == "tcp":
            host, port = spec["tcp"]
            return "healthy" if _tcp_reachable(host, port, timeout=1.0) else "stopped"
        if check == "electron":
            return "healthy" if _find_electron_pid() else "stopped"
        return "stopped"

    def _launch_all(self) -> None:
        """POST/GET /launch/all — streams SSE launch events then a final complete event."""
        self.send_response(200)
        self.send_header("Content-Type", "text/event-stream")
        self.send_header("Cache-Control", "no-cache, no-transform")
        self.send_header("Connection", "keep-alive")
        self._cors()
        self.end_headers()

        def emit(data: dict) -> bool:
            try:
                payload = json.dumps(data)
                self.wfile.write(f"data: {payload}\n\n".encode("utf-8"))
                self.wfile.flush()
                return True
            except (BrokenPipeError, OSError):
                return False

        # Full launch sequence — ordered by dependency
        _VW_LOG  = str(HOME / "beewid-privacy" / "watcher.log")
        _SAN_LOG = str(HOME / "beewid-privacy" / "sanitizer.log")
        _SA_LOG  = str(HOME / "beewid-privacy" / "screen_assistant_runtime.log")
        _PR_LOG  = str(HOME / "beewid-privacy" / "proactive_research.log")

        SEQUENCE: list[dict] = [
            {"name":"vault_watcher",     "display":"Vault Watcher",     "svc_key":"vault_watcher",
             "check":"pid",      "pid_file":VAULT_PID_FILE,     "timeout":5,  "log":_VW_LOG},
            {"name":"sanitizer",         "display":"Vault Sanitizer",   "svc_key":"sanitizer",
             "check":"pid",      "pid_file":SANITIZER_PID_FILE, "timeout":5,  "log":_SAN_LOG},
            {"name":"hermes",            "display":"Hermes Gateway",    "svc_key":"hermes_dashboard",
             "check":"http",     "http":(HERMES_GATEWAY_HOST, HERMES_GATEWAY_PORT, "/health"),
             "timeout":10, "log":"/tmp/hermes-dashboard.log", "port":f":{HERMES_GATEWAY_PORT}"},
            {"name":"hermes_dashboard",  "display":"Hermes Dashboard",  "svc_key":"hermes_dashboard",
             "check":"http",     "http":("127.0.0.1", HERMES_DASH_PORT, "/api/status"),
             "timeout":10, "log":"/tmp/hermes-dashboard.log", "port":f":{HERMES_DASH_PORT}",
             "no_start":True},
            {"name":"screenpipe",        "display":"Screenpipe",        "svc_key":"screenpipe",
             "check":"http",     "http":("127.0.0.1", 3030, "/health"),
             "timeout":15, "log":"/tmp/sp.log", "port":":3030"},
            {"name":"screen_assistant",  "display":"Screen Assistant",  "svc_key":"screen_assistant",
             "check":"pid",      "pid_file":SA_PID_FILE, "timeout":8, "log":_SA_LOG},
            {"name":"proactive_research","display":"Proactive Research","svc_key":"proactive_research",
             "check":"pid",      "pid_file":PR_PID_FILE, "timeout":8, "log":_PR_LOG},
            {"name":"aionui",            "display":"AionUI",            "svc_key":"aionui",
             "check":"electron", "timeout":20, "log":"/tmp/aionui.log"},
            {"name":"space_agent",       "display":"Space Agent",       "svc_key":"space_agent",
             "check":"tcp",      "tcp":("127.0.0.1", 3000),
             "timeout":15, "log":"/tmp/space.log", "optional":True},
            {"name":"panel_server",      "display":"Panel Server",      "svc_key":None,
             "check":"self",     "timeout":0, "log":str(LOG_FILE)},
        ]

        results: list[dict] = []

        for spec in SEQUENCE:
            name    = spec["name"]
            display = spec["display"]

            # Optional services: skip if not installed
            if spec.get("optional"):
                if name == "space_agent" and not SPACE_AGENT_PACKAGE_JSON.is_file():
                    emit({"service": name, "status": "skipped",
                          "msg": f"{display} — not installed (optional, skip)"})
                    results.append({"name": name, "display": display, "status": "skipped",
                                    "svc_key": spec.get("svc_key")})
                    continue

            # Panel server is always us
            if spec["check"] == "self":
                emit({"service": name, "status": "already_running",
                      "msg": f"{display} always running :7842"})
                results.append({"name": name, "display": display, "status": "already_running",
                                "svc_key": None})
                continue

            # Check current health
            current = self._check_svc_health(spec)
            if current in ("healthy", "degraded"):
                port_str = f" {spec['port']}" if spec.get("port") else ""
                emit({"service": name, "status": "already_running",
                      "msg": f"{display} already running{port_str}"})
                results.append({"name": name, "display": display, "status": current,
                                "svc_key": spec.get("svc_key")})
                continue

            # Not running — start it (unless flagged no_start, e.g. hermes_dashboard
            # which is covered by the hermes entry above)
            if not spec.get("no_start"):
                emit({"service": name, "status": "starting", "msg": f"Starting {display}..."})
                svc_key = spec.get("svc_key")
                if svc_key:
                    ok, start_msg = self._svc_do_start(svc_key)
                    if not ok:
                        log_tail = _log_tail(spec.get("log", ""))
                        emit({"service": name, "status": "failed",
                              "msg": f"{display} failed to start: {start_msg}",
                              "log_file": spec.get("log", "")})
                        results.append({"name": name, "display": display, "status": "failed",
                                        "svc_key": svc_key, "msg": start_msg,
                                        "log_file": spec.get("log", ""),
                                        "log_tail": log_tail})
                        continue
            else:
                emit({"service": name, "status": "starting",
                      "msg": f"Waiting for {display}..."})

            # Poll until healthy or timeout
            timeout    = spec.get("timeout", 10)
            final_state = "failed"
            for _ in range(timeout * 2):   # 0.5 s each iteration
                time.sleep(0.5)
                state = self._check_svc_health(spec)
                if state in ("healthy", "degraded"):
                    final_state = state
                    break

            if final_state == "healthy":
                port_str = f" {spec['port']}" if spec.get("port") else ""
                emit({"service": name, "status": "healthy",
                      "msg": f"{display} healthy{port_str}"})
                results.append({"name": name, "display": display, "status": "healthy",
                                "svc_key": spec.get("svc_key")})
            elif final_state == "degraded":
                emit({"service": name, "status": "degraded",
                      "msg": f"{display} degraded (running but not fully healthy)"})
                results.append({"name": name, "display": display, "status": "degraded",
                                "svc_key": spec.get("svc_key")})
            else:
                log_file = spec.get("log", "")
                log_tail = _log_tail(log_file)
                emit({"service": name, "status": "failed",
                      "msg": f"{display} did not become healthy — check {log_file or 'logs'}",
                      "log_file": log_file})
                results.append({"name": name, "display": display, "status": "failed",
                                "svc_key": spec.get("svc_key"),
                                "log_file": log_file, "log_tail": log_tail})

        # Final summary event
        n_healthy  = sum(1 for r in results if r["status"] in ("healthy", "already_running"))
        n_failed   = sum(1 for r in results if r["status"] == "failed")
        n_degraded = sum(1 for r in results if r["status"] == "degraded")

        debug_report = ""
        if n_failed > 0 or n_degraded > 0:
            debug_report = _build_debug_report(results, KNOWN_FIXES)

        emit({
            "type":         "complete",
            "healthy":      n_healthy,
            "failed":       n_failed,
            "degraded":     n_degraded,
            "debug_report": debug_report,
        })

    def _reload_scrubber_blocklist(self) -> None:
        try:
            sys.path.insert(0, str(Path.home() / "beewid-privacy"))
            import scrubber as _sc
            _sc.reload_blocklist()
        except Exception:
            pass

    def _read_json_body(self) -> dict | None:
        try:
            length = int(self.headers.get("Content-Length", 0))
            raw = self.rfile.read(length)
            return json.loads(raw)
        except (ValueError, json.JSONDecodeError):
            return None

    # ── Reverse proxy ────────────────────────────────────────────────────────

    def _proxy(self, target_key: str, target_path: str) -> None:
        host, port = PROXY_TARGETS[target_key]
        if not target_path.startswith("/"):
            target_path = "/" + target_path
        # Preserve query string from the original request
        query = urlsplit(self.path).query
        if query:
            target_path = f"{target_path}?{query}"

        # Forward body if any
        body = b""
        content_length = self.headers.get("Content-Length")
        if content_length and content_length.isdigit():
            try:
                body = self.rfile.read(int(content_length))
            except OSError:
                body = b""

        # Forward headers (minus hop-by-hop and host)
        fwd_headers: dict[str, str] = {}
        for name, value in self.headers.items():
            if name.lower() in HOP_BY_HOP or name.lower() == "host":
                continue
            fwd_headers[name] = value
        fwd_headers["Host"] = f"{host}:{port}"

        try:
            conn = http.client.HTTPConnection(host, port, timeout=PROXY_TIMEOUT)
            conn.request(self.command, target_path, body=body, headers=fwd_headers)
            upstream = conn.getresponse()
        except (ConnectionRefusedError, socket.timeout, socket.gaierror) as exc:
            return self._send_json(502, {
                "error": "upstream unreachable",
                "target": f"{host}:{port}{target_path}",
                "reason": str(exc),
            })
        except OSError as exc:
            return self._send_json(502, {
                "error": "proxy I/O error",
                "target": f"{host}:{port}{target_path}",
                "reason": str(exc),
            })

        try:
            data = upstream.read()
            self.send_response(upstream.status)
            for h, v in upstream.getheaders():
                if h.lower() in HOP_BY_HOP:
                    continue
                self.send_header(h, v)
            self._cors()
            self.end_headers()
            self.wfile.write(data)
        finally:
            try: conn.close()
            except OSError: pass

    # ── Ping target (used for AionUI :3002 reachability check) ──────────────

    def _ping_target(self, target_key: str) -> None:
        host, port = PROXY_TARGETS[target_key]
        try:
            with socket.create_connection((host, port), timeout=1.5):
                return self._send_json(200, {"reachable": True})
        except (ConnectionRefusedError, socket.timeout, OSError):
            return self._send_json(200, {"reachable": False})


# ── main ─────────────────────────────────────────────────────────────────────

def make_server(bind: str, port: int) -> ThreadingHTTPServer:
    return ThreadingHTTPServer((bind, port), PanelHandler)


def main() -> int:
    ap = argparse.ArgumentParser(description="AionUI stack panel HTTP server (with reverse proxy + SSE)")
    ap.add_argument("--bind", default=DEFAULT_BIND, help=f"bind address (default {DEFAULT_BIND})")
    ap.add_argument("--port", type=int, default=DEFAULT_PORT, help=f"port (default {DEFAULT_PORT})")
    ap.add_argument("--foreground", action="store_true", help="log to stderr only, no PID file")
    args = ap.parse_args()

    _setup_logging(foreground=args.foreground)
    _load_bridge_config()

    if not args.foreground:
        write_pid_file()

    try:
        httpd = make_server(args.bind, args.port)
    except OSError as exc:
        logger.error("could not bind %s:%d — %s", args.bind, args.port, exc)
        if not args.foreground:
            remove_pid_file()
        return 1

    BROADCASTER.start()

    stop_event = threading.Event()

    def _shutdown(signum: int, _frame: Any) -> None:
        logger.info("received signal %d, shutting down", signum)
        stop_event.set()
        BROADCASTER.stop()
        # server.shutdown() blocks if called from the same thread serving,
        # so run it in a background thread.
        threading.Thread(target=httpd.shutdown, daemon=True).start()

    signal.signal(signal.SIGINT, _shutdown)
    signal.signal(signal.SIGTERM, _shutdown)

    logger.info(
        "serving %s on http://%s:%d  (panel: %s, SSE every %.1fs)",
        PANEL_HTML.name, args.bind, args.port, PANEL_HTML, STREAM_INTERVAL_S,
    )
    try:
        httpd.serve_forever()
    finally:
        httpd.server_close()
        BROADCASTER.stop()
        if not args.foreground:
            remove_pid_file()
        logger.info("panel_server stopped cleanly")
    return 0


if __name__ == "__main__":
    sys.exit(main())
