#!/usr/bin/env bash
# seed_hermes_team.sh — spawn Hermes teammates into an AionUI team via the
# real addAgent service path (team MCP TCP server), not raw DB editing.
#
# Resolves a team by NAME -> teamId, reads the live MCP port/token from the
# leader conversation's teamMcpStdioConfig, then calls team_spawn_agent for
# each role with agent_type=hermes. addAgent runs in-process inside AionUI,
# atomically creating each teammate's conversation + slot + MCP config.
#
# Usage:   seed_hermes_team.sh "<team name>" "Role One" "Role Two" ...
# Env:     HERMES_MODEL  (default: openai-codex:gpt-5.5, cloned from the leader)
#          AIONUI_DB     (default: ~/.config/AionUi-Dev/aionui/aionui.db)
#
# Requires the team's AionUI session to be OPEN (TCP MCP server listening),
# because the port/token are session-scoped and only valid while it runs.

set -euo pipefail

DB="${AIONUI_DB:-$HOME/.config/AionUi-Dev/aionui/aionui.db}"
MODEL="${HERMES_MODEL:-openai-codex:gpt-5.5}"

TEAM_NAME="${1:-}"
if [ -z "$TEAM_NAME" ] || [ "$#" -lt 2 ]; then
  echo "usage: $(basename "$0") \"<team name>\" <role> [role...]" >&2
  exit 64
fi
shift

# Resolve teamId + leader slot + live MCP port/token from the DB (sqlite + WAL).
META="$(python3 - "$DB" "$TEAM_NAME" <<'PY'
import sys, json, sqlite3
db, name = sys.argv[1], sys.argv[2]
con = sqlite3.connect(db); con.row_factory = sqlite3.Row
row = con.execute("SELECT id, agents FROM teams WHERE name=?", (name,)).fetchone()
if not row:
    sys.stderr.write(f"team not found: {name!r}\n"); sys.exit(2)
agents = json.loads(row["agents"])
leader = next((a for a in agents if a.get("role") == "leader"), None)
if not leader:
    sys.stderr.write("team has no leader slot\n"); sys.exit(3)
conv = con.execute("SELECT extra FROM conversations WHERE id=?", (leader["conversationId"],)).fetchone()
cfg = (json.loads(conv["extra"]).get("teamMcpStdioConfig") or {}) if conv else {}
env = {e["name"]: e["value"] for e in cfg.get("env", [])}
port, token = env.get("TEAM_MCP_PORT"), env.get("TEAM_MCP_TOKEN")
if not port or not token:
    sys.stderr.write("no live MCP port/token in leader extra — is the team session open?\n"); sys.exit(4)
print(row["id"], leader["slotId"], port, token)
PY
)" || { echo "failed to resolve team '$TEAM_NAME'" >&2; exit 1; }

read -r TEAM_ID LEADER_SLOT PORT TOKEN <<<"$META"
echo "team='$TEAM_NAME' id=$TEAM_ID leader=$LEADER_SLOT port=$PORT model=$MODEL"

if command -v ss >/dev/null 2>&1 && ! ss -tlnp 2>/dev/null | grep -q "127.0.0.1:$PORT"; then
  echo "ERROR: port $PORT is not listening — open '$TEAM_NAME' in AionUI first." >&2
  exit 5
fi

rc=0
for ROLE in "$@"; do
  echo "--- spawning: '$ROLE' (agent_type=hermes, model=$MODEL) ---"
  PORT="$PORT" TOKEN="$TOKEN" LEADER_SLOT="$LEADER_SLOT" ROLE="$ROLE" MODEL="$MODEL" node - <<'NODE' || rc=1
const net = require('node:net');
const { PORT, TOKEN, LEADER_SLOT, ROLE, MODEL } = process.env;
const req = {
  tool: 'team_spawn_agent',
  args: { name: ROLE, agent_type: 'hermes', model: MODEL },
  from_slot_id: LEADER_SLOT,
  auth_token: TOKEN,
};
function frame(sock, data) {
  const body = Buffer.from(JSON.stringify(data), 'utf-8');
  const f = Buffer.allocUnsafe(4 + body.length);
  f.writeUInt32BE(body.length, 0); body.copy(f, 4); sock.write(f);
}
const chunks = []; let total = 0;
const s = net.createConnection({ host: '127.0.0.1', port: Number(PORT) }, () => frame(s, req));
s.on('data', (c) => {
  chunks.push(c); total += c.length;
  if (total < 4) return;
  const buf = Buffer.concat(chunks); const len = buf.readUInt32BE(0);
  if (buf.length < 4 + len) return;
  console.log(buf.subarray(4, 4 + len).toString('utf-8'));
  s.destroy();
});
s.on('error', (e) => { console.error('socket error:', e.message); process.exit(1); });
s.setTimeout(60000); s.on('timeout', () => { console.error('timeout'); s.destroy(); process.exit(1); });
NODE
done
exit $rc
