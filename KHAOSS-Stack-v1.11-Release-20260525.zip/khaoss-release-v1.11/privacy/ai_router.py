#!/usr/bin/env python3
"""
ai_router.py — KHAOSS Three-Tier AI Routing
Shared module: import only, never fork.
Maintained by KHAOSS Sonnet at ~/beewid-privacy/ai_router.py

Tiers:
  1. local   — Ollama at localhost:11434 (recommended, 🍪 cookie tier)
  2. private — Self-hosted endpoint (configurable URL + key)
  3. cloud   — Hermes CLI / cloud providers (current default)
"""
import json
import os
import subprocess
import urllib.request
from pathlib import Path

ROUTING_CONFIG_FILE = Path.home() / "beewid-privacy" / "ai_routing_config.json"

DEFAULT_CONFIG = {
    "tier": "cloud",
    "local": {
        "url": "http://localhost:11434",
        "model": "llama3.2",
        "enabled": False
    },
    "private": {
        "url": "",
        "api_key": "",
        "model": "",
        "enabled": False
    },
    "cloud": {
        "profile": "swarm13",
        "enabled": True
    }
}

def load_config() -> dict:
    try:
        if ROUTING_CONFIG_FILE.exists():
            return {**DEFAULT_CONFIG, **json.loads(ROUTING_CONFIG_FILE.read_text())}
    except Exception:
        pass
    return DEFAULT_CONFIG.copy()

def save_config(config: dict):
    try:
        ROUTING_CONFIG_FILE.write_text(json.dumps(config, indent=2))
    except Exception:
        pass

def get_tier() -> str:
    return load_config().get("tier", "cloud")

def is_local_available() -> bool:
    """Check if Ollama is running at configured URL."""
    try:
        cfg = load_config()
        url = cfg["local"]["url"].rstrip("/") + "/api/tags"
        req = urllib.request.urlopen(url, timeout=3)
        return req.status == 200
    except Exception:
        return False

def is_private_available() -> bool:
    """Check if private server endpoint is reachable."""
    try:
        cfg = load_config()
        url = cfg["private"]["url"]
        if not url:
            return False
        req = urllib.request.urlopen(url.rstrip("/") + "/health", timeout=3)
        return req.status == 200
    except Exception:
        return False

def get_ollama_models() -> list:
    """Return list of available Ollama models."""
    try:
        cfg = load_config()
        url = cfg["local"]["url"].rstrip("/") + "/api/tags"
        resp = urllib.request.urlopen(url, timeout=3)
        data = json.loads(resp.read())
        return [m["name"] for m in data.get("models", [])]
    except Exception:
        return []

def call_ai(prompt: str, context: str = "", timeout: int = 60) -> str:
    """
    Route an AI call through the configured tier.
    Returns the AI response as a string, or raises RuntimeError.
    """
    cfg = load_config()
    tier = cfg.get("tier", "cloud")

    if tier == "local":
        return _call_ollama(prompt, context, cfg, timeout)
    elif tier == "private":
        return _call_private(prompt, context, cfg, timeout)
    else:
        return _call_cloud(prompt, context, cfg, timeout)

def _call_ollama(prompt: str, context: str, cfg: dict, timeout: int) -> str:
    """Call local Ollama instance."""
    local_cfg = cfg.get("local", {})
    url = local_cfg.get("url", "http://localhost:11434").rstrip("/")
    model = local_cfg.get("model", "llama3.2")
    full_prompt = f"{context}\n\n{prompt}".strip() if context else prompt

    payload = json.dumps({
        "model": model,
        "prompt": full_prompt,
        "stream": False
    }).encode()

    req = urllib.request.Request(
        f"{url}/api/generate",
        data=payload,
        headers={"Content-Type": "application/json"},
        method="POST"
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read())
        return data.get("response", "").strip()
    except Exception as e:
        raise RuntimeError(f"Ollama call failed: {e}")

def _call_private(prompt: str, context: str, cfg: dict, timeout: int) -> str:
    """Call private server (OpenAI-compatible endpoint)."""
    private_cfg = cfg.get("private", {})
    url = private_cfg.get("url", "").rstrip("/")
    api_key = private_cfg.get("api_key", "")
    model = private_cfg.get("model", "")

    if not url:
        raise RuntimeError("Private server URL not configured")

    full_prompt = f"{context}\n\n{prompt}".strip() if context else prompt
    payload = json.dumps({
        "model": model,
        "messages": [{"role": "user", "content": full_prompt}],
        "max_tokens": 1000
    }).encode()

    req = urllib.request.Request(
        f"{url}/v1/chat/completions",
        data=payload,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}"
        },
        method="POST"
    )
    try:
        resp = urllib.request.urlopen(req, timeout=timeout)
        data = json.loads(resp.read())
        return data["choices"][0]["message"]["content"].strip()
    except Exception as e:
        raise RuntimeError(f"Private server call failed: {e}")

def _call_cloud(prompt: str, context: str, cfg: dict, timeout: int) -> str:
    """Call cloud via Hermes CLI (current default)."""
    cloud_cfg = cfg.get("cloud", {})
    profile = cloud_cfg.get("profile", "swarm13")
    full_prompt = f"{context}\n\n{prompt}".strip() if context else prompt

    result = subprocess.run(
        ["hermes", "--profile", profile, "-z", full_prompt],
        capture_output=True, text=True, timeout=timeout
    )
    if result.returncode != 0:
        raise RuntimeError(f"Hermes call failed: {result.stderr}")
    return result.stdout.strip()
