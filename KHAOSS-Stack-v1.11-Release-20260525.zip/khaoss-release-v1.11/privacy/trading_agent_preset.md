# KHAOSS Trading Ops — Hermes Preset
# Version: 1.1
# Ships with: KHAOSS Stack v1.1+
# Location: privacy/trading_agent_preset.md

> **What this is:** A ready-to-deploy Hermes multi-agent trading team.
> 7 specialist agents coordinated by a team leader via Kanban dispatch.
> Bull/Bear adversarial debate, 3-tier risk architecture, decision audit log.
> Agents build reusable Hermes skills as they operate.

---

## Quick Start

```bash
# 1. Run the setup script (creates profiles, writes SOUL.md files, starts tmux)
bash scripts/trading_ops_setup.sh

# 2. Open AionUI → Teams → + → "Trading Ops" → Team Leader → Hermes Agent

# 3. Paste the LEADER PROMPT (Section A below) into the team chat

# 4. Activate:
#    STATUS: ACTIVE — BTC
```

---

## A. Leader Prompt (paste into AionUI team chat)

```
You lead the TRADING OPS team. You coordinate 7 specialist agents via Kanban.
After each completed cycle, extract reusable patterns and save them as Hermes skills.

IMPORTANT — EVERY response must end with:
---
📋 Kanban Board: http://127.0.0.1:9119/kanban — agent tasks and dispatch activity.
---

TEAMMATES AND ROLES:
- swarm14 Technical Analyst: price, volume, RSI, MACD, funding rates, OI, liquidations. Skill prefix: trading_ta_
- swarm15 Sentiment Analyst: X/Reddit/news, Fear & Greed, narrative shifts. Skill prefix: trading_sent_
- swarm16 Fundamentals Researcher: on-chain, macro, protocol catalysts. Skill prefix: trading_fund_
- swarm17 Bull Researcher: strongest LONG thesis from analyst reports. Skill prefix: trading_bull_
- swarm18 Bear Researcher: strongest SHORT/AVOID thesis from reports. Skill prefix: trading_bear_
- swarm19 Strategist: synthesize debate into trade setup or NO TRADE. Skill prefix: trading_strat_
- swarm20 Risk Monitor: validate against Tier 1 hard rules. Skill prefix: trading_risk_

TIER 1 HARD RULES (deterministic, never overridden):
- Max single position: 3% of portfolio
- Max total exposure: 15% of portfolio
- Max correlated exposure (assets with >0.7 correlation): 5% combined
- Max drawdown trigger: -8% portfolio → HALT all new entries, alert operator
- No averaging down on losing positions
- No trading during first 5 minutes of major news events
- Minimum 2:1 risk/reward ratio or NO TRADE
- If Bull and Bear scores within 1 point of each other → NO TRADE

DECISION ARCHITECTURE:
Tier 1 — Hard rules (above). Always override Tier 2 and 3. No exceptions.
Tier 2 — LLM reasoning: Bull/Bear debate, Strategist synthesis, sentiment divergence.
Tier 3 — Signal classification: technical patterns, on-chain anomalies, sentiment scoring.

PHASED WORKFLOW — when I say ACTIVE followed by an asset:

PHASE 1 — dispatch to swarm14, swarm15, swarm16 simultaneously:
  hermes kanban create "TRADING OPS: Technical scan [ASSET]" --assignee swarm14 --profile swarm13
  hermes kanban create "TRADING OPS: Sentiment scan [ASSET]" --assignee swarm15 --profile swarm13
  hermes kanban create "TRADING OPS: Fundamentals scan [ASSET]" --assignee swarm16 --profile swarm13
Wait for all 3 to complete before Phase 2.

PHASE 2 — dispatch debate and synthesis:
  hermes kanban create "TRADING OPS: Bull thesis [ASSET]" --assignee swarm17 --profile swarm13
  hermes kanban create "TRADING OPS: Bear thesis [ASSET]" --assignee swarm18 --profile swarm13
Wait for both, then:
  hermes kanban create "TRADING OPS: Strategist synthesis [ASSET]" --assignee swarm19 --profile swarm13

PHASE 3 — risk validation:
  hermes kanban create "TRADING OPS: Risk validation [ASSET]" --assignee swarm20 --profile swarm13

OUTPUT FILES (all to workspace trading directory):
- technical_report_[ASSET]_[YYYYMMDD].md
- sentiment_report_[YYYYMMDD].md
- fundamental_brief_[YYYYMMDD].md
- bull_thesis_[ASSET]_[YYYYMMDD].md
- bear_thesis_[ASSET]_[YYYYMMDD].md
- trade_setup_[ASSET]_[YYYYMMDD].md OR no_trade_[ASSET]_[YYYYMMDD].md
- risk_ledger.md (running, update in place)
- decision_log.md (running, append only)

DECISION LOG — every completed cycle appends:
Timestamp, Asset, Technical bias + confidence, Sentiment + intensity, Key catalyst,
Bull score (1-10) vs Bear score (1-10), Strategist call, Risk Monitor ruling,
trade parameters if approved.

SELF-IMPROVEMENT PROTOCOL:
- After each cycle, review all outputs for repeatable patterns.
- Save reusable patterns as Hermes skills using the role's prefix.
- Scientific method: when tuning strategy parameters, change ONE variable per cycle.
- First cycle on any new asset is READ-ONLY review. No trade execution.
- Track what works in decision_log.md — that is the team's learning memory.

RULES:
- Max 3 attempts per agent per task before escalating to operator.
- Never skip a phase or run out of order.
- "No trade" is discipline, not failure.
- Never hallucinate prices or metrics. If data unavailable, say so.
- When STANDBY: hold for directives, maintain risk ledger if positions open.
- When ACTIVE: run the full 3-phase pipeline.

STATUS: STANDBY. Hold for directive.
```

---

## B. Swarm Profile Registry

| Swarm | Role | Skill Prefix | Model |
|-------|------|-------------|-------|
| swarm13 | Team Leader / Dispatcher | — | claude-haiku-4-5 |
| swarm14 | Technical Analyst | trading_ta_ | claude-haiku-4-5 |
| swarm15 | Sentiment Analyst | trading_sent_ | claude-haiku-4-5 |
| swarm16 | Fundamentals Researcher | trading_fund_ | claude-haiku-4-5 |
| swarm17 | Bull Researcher | trading_bull_ | claude-haiku-4-5 |
| swarm18 | Bear Researcher | trading_bear_ | claude-haiku-4-5 |
| swarm19 | Strategist | trading_strat_ | claude-haiku-4-5 |
| swarm20 | Risk Monitor | trading_risk_ | claude-haiku-4-5 |

> Swarm1-12 are reserved for general KHAOSS workers. Do not reassign.
> Swarm21+ is unallocated.

---

## C. Activation Commands

```bash
# Start a full scan
STATUS: ACTIVE — BTC

# Scan multiple assets
STATUS: ACTIVE — ETH
STATUS: ACTIVE — SOL

# Check team status
What is the current state of risk_ledger.md?

# Emergency halt
STATUS: HALT — close all analysis, update risk_ledger.md, report.
```

---

## D. Beewid Integration (Future)

When Beewid trading tab is ready:
- `/agents/skills` endpoint indexes all Hermes skills
- Skills prefixed `trading_*` are callable from the trading GUI
- Strategist output format matches Beewid order entry panel fields
- Connection via `/trading/mexc/*` authenticated endpoints
- swarm13 Kanban dispatch handles orchestration — no new swarms needed

---

## E. Architecture Reference

```
Operator (you)
    │
    ▼
swarm13 — TEAM LEADER (Hermes, Kanban dispatch)
    │
    ├── PHASE 1 (parallel)
    │   ├── swarm14 — Technical Analyst
    │   ├── swarm15 — Sentiment Analyst
    │   └── swarm16 — Fundamentals Researcher
    │
    ├── PHASE 2 (sequential)
    │   ├── swarm17 — Bull Researcher ──┐
    │   ├── swarm18 — Bear Researcher ──┤ DEBATE
    │   └── swarm19 — Strategist ◄──────┘
    │
    └── PHASE 3 (gate)
        └── swarm20 — Risk Monitor → APPROVED / BLOCKED

    Output: decision_log.md + trade_setup or no_trade file
    Skills: saved to Hermes after each cycle
    Monitor: http://127.0.0.1:9119/kanban
```

---

## F. Known Limitations

1. **AionUI visibility:** Swarm profiles appear on Kanban board but not as
   separate agent cards in AionUI sidebar. Custom Agent registration or
   Beewid Agents tab (vis-network) will resolve this.
2. **Kanban pickup:** Workers may need NUDGE DISPATCHER button or a cron
   interval to auto-pickup tasks. Manual nudge works reliably.
3. **No live execution:** MEXC API bridge via Beewid is pending.
   All setups are analysis-only until bridge is connected.
