# KHAOSS Installation Help

## Quick debug

```bash
bash scripts/khaoss_debug.sh
# Paste /tmp/khaoss_debug_*.md into any AI:
# "Fix my KHAOSS installation — here is my debug report:"
```

---

## Common fixes

### Hermes won't connect
```bash
hermes doctor --fix --profile swarm13
hermes auth login openai-codex --profile swarm13
```

### AionUI blank white screen after suspend
```bash
sudo systemctl status aionui-resume.service
# If not installed:
sudo bash privacy/install_aionui_resume.sh
```

### Panel not loading (:7842)
```bash
pkill -f panel_server.py
sleep 2
nohup python3 ~/beewid-privacy/panel_server.py > /tmp/panel_server.log 2>&1 &
```

### AionUI won't start (Electron crash)
```bash
pkill -9 -f electron 2>/dev/null
rm -f ~/.config/AionUi-Dev/SingletonLock \
      ~/.config/AionUi-Dev/SingletonCookie \
      ~/.config/AionUi-Dev/SingletonSocket
rm -rf ~/.config/AionUi-Dev/GPUCache/
bash ~/launch-aionui.sh
```

### `hermes profile create` fails with `--provider` flag
`hermes profile create` does NOT accept `--provider` or `--model` flags. Create first, then set:
```bash
hermes profile create myprofile
hermes config set model.provider openai-codex --profile myprofile
hermes config set model.name gpt-5.5 --profile myprofile
```

### Screenpipe shows degraded (amber)
Normal on Linux/Wayland. Vision + audio still work.

### Autocode engine-lost warning
Normal if it self-recovers. Only a problem if run never completes.

---

## Installation time

- **Total:** 5-10 minutes
- If any step hangs >2 minutes: `Ctrl+C` and run `khaoss_debug.sh`
