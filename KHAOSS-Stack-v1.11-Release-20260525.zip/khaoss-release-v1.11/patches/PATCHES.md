# KHAOSS v1.11 — shipping patches

These patches live in files **outside** this repo (the AionUi source tree and the
Hermes ACP adapter). They are not tracked here, so a dependency reinstall, a fresh
checkout, or a Hermes update can silently revert them.

**Reapply them all (idempotent, safe to re-run):**

```bash
~/beewid-privacy/khaoss_reapply_patches.sh
```

Every step is check-then-patch: already-patched files are skipped; reverted files
are re-patched after a timestamped backup (`<file>.bak_khaoss_v111_<epoch>`).
After it runs it tells you whether an AionUi rebuild (dev-server restart) and/or a
Hermes restart is needed.

---

## What each patch does

### 1. Stable team MCP server name
- **File:** `~/Downloads/AIonUi/AionUi-main/src/process/team/mcp/team/TeamMcpServer.ts`
- **Change:** `getStdioConfig()` returns `name: 'aionui-team'` instead of
  `name: \`aionui-team-${this.params.teamId}\``.
- **Why:** the per-team UUID made Hermes prefix the tools as
  `mcp_aionui_team_<uuid>_team_*`, so the leader never matched the `team_*` names in
  its prompt and reported "no team tools". A stable name yields `mcp_aionui_team_team_*`.
- **Wiped by:** fresh AionUi checkout / `git checkout` / reinstall of the tree.

### 2. Team-MCP name matching (gemini path)
- **Files:**
  - `src/process/task/GeminiAgentManager.ts` (auto-approve team MCP tool confirmations)
  - `src/process/agent/gemini/cli/config.ts` (keep team MCP servers past allow/exclude lists)
- **Change:** broaden the match from `startsWith('aionui-team-')` to
  `=== 'aionui-team' || startsWith('aionui-team-')` so it still recognizes the new
  UUID-free name (and the `aionui-team-guide` / legacy forms).
- **Why:** patch 1 renamed the server; without this, gemini-backed teams would stop
  auto-approving / keeping the team MCP server.
- **Wiped by:** same as patch 1.

### 3. Leader-prompt suffix guidance
- **File:** `src/process/team/prompts/leadPrompt.ts`
- **Change:** add a paragraph telling the leader its team tools appear under the
  `mcp_aionui_team_` prefix (e.g. `mcp_aionui_team_team_spawn_agent`) and to **match by
  suffix**.
- **Why:** the prompt body uses short `team_*` names; this paragraph bridges the gap so
  the model invokes the namespaced tools it actually sees.
- **Wiped by:** same as patch 1.

### 4. Hermes advertises MCP stdio capability
- **File:** `~/.hermes/hermes-agent/acp_adapter/server.py`
- **Change:** import `McpCapabilities` and add
  `mcp_capabilities=McpCapabilities(stdio=True)` to the `AgentCapabilities(...)` block in
  `initialize()`.
- **Why:** without advertising `mcpCapabilities.stdio`, AionUi won't inject the team MCP
  stdio server into Hermes sessions, so no team tools register at all.
- **Wiped by:** a Hermes Agent update / reinstall of `~/.hermes/hermes-agent`.

### 5. Dead-code cleanup (revert, not a patch)
- **File:** `~/Downloads/AIonUi/AionUi-main/src/process/agent/acp/index.ts`
- **Change:** **removes** an inert `teamId` edit (a `teamId?: string` field added to two
  inline `extra` types + two `this.extra.teamId` substitutions) left over from debugging.
- **Why:** that file is the LEGACY `AcpAgent` — imported only as a *type* and tree-shaken
  out of the bundle (the live ACP class is `AcpAgentV2`). The edit does nothing at runtime;
  reverting it keeps the AionUi diff clean. The script restores the upstream form only if the
  edit is still present (idempotent — skips once reverted), and does **not** flag a rebuild
  (dead file → byte-identical bundle).
- **Wiped by:** n/a — this step *undoes* a local edit. After a fresh checkout the file is
  already upstream and the step simply skips.

---

## After reapplying
- **AionUi files changed** → restart the dev server (it builds the main process only at
  startup; it does **not** hot-rebuild on save):
  `pkill -9 -f '[e]lectron'` then relaunch `electron-vite dev`.
- **server.py changed** → restart the Hermes ACP adapter / reopen the team so the agent
  re-initializes and re-advertises the capability.

## Related tooling
- `~/beewid-privacy/seed_hermes_team.sh` — spawn Hermes teammates into an open team.
- The panel's "⚡ Build Hermes Team" button → `POST /team/seed` in `panel_server.py` →
  `seed_hermes_team.sh`.
