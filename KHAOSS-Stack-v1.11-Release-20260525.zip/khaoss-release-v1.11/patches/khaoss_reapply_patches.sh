#!/usr/bin/env bash
# khaoss_reapply_patches.sh — idempotently reapply the KHAOSS v1.11 shipping patches.
#
# Safe to run repeatedly: every step is check-then-patch. If a file is already
# patched, the step is skipped (no backup, no write). If a file was reset to its
# upstream form (e.g. by `npm install` / a fresh AionUi checkout, or a Hermes
# update), the step reapplies the patch after backing the file up (.bak_khaoss_*).
#
# Patches:
#   1  AionUi TeamMcpServer.ts          — team MCP server name -> 'aionui-team'
#   2a AionUi GeminiAgentManager.ts     — team MCP auto-approve name match
#   2b AionUi gemini/cli/config.ts      — team MCP keep/exclude name match (2 spots)
#   3  AionUi leadPrompt.ts             — mcp_aionui_team_ suffix guidance paragraph
#   4  Hermes acp_adapter/server.py     — advertise McpCapabilities(stdio=True)
#
# See ~/beewid-privacy/PATCHES.md for what each patch does and what wipes it.

python3 - <<'PYEOF'
import os, time, shutil

HOME   = os.path.expanduser("~")
AIONUI = os.path.join(HOME, "Downloads/AIonUi/AionUi-main")
HERMES = os.path.join(HOME, ".hermes/hermes-agent/acp_adapter/server.py")
EPOCH  = int(time.time())
BAK    = ".bak_khaoss_v111_%d" % EPOCH

aionui_changed = False
hermes_changed = False
deadcode_changed = False
n_skip = n_patch = n_warn = n_revert = 0
backups = []

def do_patch(label, path, already, transforms, kind):
    """already: marker that means 'already patched' -> SKIP.
       transforms: list of (find, replace); each applied once if found."""
    global aionui_changed, hermes_changed, n_skip, n_patch, n_warn
    if not os.path.exists(path):
        n_warn += 1
        print("  [WARN] %s: file not found: %s" % (label, path))
        return
    s = open(path, encoding="utf-8").read()
    if already in s:
        n_skip += 1
        print("  [SKIP] %s: already patched" % label)
        return
    new = s
    applied = 0
    missing = 0
    for find, repl in transforms:
        if find in new:
            new = new.replace(find, repl, 1)
            applied += 1
        else:
            missing += 1
    if applied == 0:
        n_warn += 1
        print("  [WARN] %s: not patched and no known anchor found — upstream may have "
              "changed; review manually (NOT modified)" % label)
        return
    dst = path + BAK
    shutil.copy2(path, dst)
    backups.append(dst)
    open(path, "w", encoding="utf-8").write(new)
    n_patch += 1
    if kind == "aionui":
        aionui_changed = True
    elif kind == "hermes":
        hermes_changed = True
    extra = "" if missing == 0 else "  (note: %d expected anchor(s) absent)" % missing
    print("  [PATCH] %s: applied %d change(s); backup %s%s"
          % (label, applied, os.path.basename(dst), extra))

def do_revert(label, path, present_marker, transforms):
    """Reverse an inert edit back to upstream. If present_marker is ABSENT -> SKIP
       (already upstream). Else replace each (edited -> upstream) for ALL
       occurrences, backing up first. Does NOT set aionui_changed: the target is
       dead/tree-shaken code, so no rebuild is needed."""
    global deadcode_changed, n_skip, n_revert, n_warn
    if not os.path.exists(path):
        n_warn += 1
        print("  [WARN] %s: file not found: %s" % (label, path))
        return
    s = open(path, encoding="utf-8").read()
    if present_marker not in s:
        n_skip += 1
        print("  [SKIP] %s: already reverted (upstream form)" % label)
        return
    new = s
    spans = 0
    for find, repl in transforms:
        if find in new:
            spans += new.count(find)
            new = new.replace(find, repl)
    if new == s:
        n_warn += 1
        print("  [WARN] %s: marker present but no revert anchor matched — review manually (NOT modified)" % label)
        return
    dst = path + BAK
    shutil.copy2(path, dst)
    backups.append(dst)
    open(path, "w", encoding="utf-8").write(new)
    n_revert += 1
    deadcode_changed = True
    print("  [REVERT] %s: removed inert edit (%d span(s)); backup %s" % (label, spans, os.path.basename(dst)))

print("KHAOSS v1.11 — reapply shipping patches")
print("  AionUi tree : %s" % AIONUI)
print("  Hermes file : %s" % HERMES)
print("  Backup tag  : %s" % BAK)
print()

# ── 1. TeamMcpServer.ts — stable, team-independent MCP server name ───────────
print("[1] AionUi TeamMcpServer.ts — getStdioConfig() name -> 'aionui-team'")
do_patch(
    "TeamMcpServer.name",
    os.path.join(AIONUI, "src/process/team/mcp/team/TeamMcpServer.ts"),
    already="name: 'aionui-team'",
    transforms=[("name: `aionui-team-${this.params.teamId}`,", "name: 'aionui-team',")],
    kind="aionui",
)

# ── 2a. GeminiAgentManager.ts — team MCP auto-approve name match ─────────────
print("[2a] AionUi GeminiAgentManager.ts — team MCP name match (auto-approve)")
do_patch(
    "GeminiAgentManager.match",
    os.path.join(AIONUI, "src/process/task/GeminiAgentManager.ts"),
    already="serverName === 'aionui-team' ||",
    transforms=[("if (serverName.startsWith('aionui-team-')) {",
                 "if (serverName === 'aionui-team' || serverName.startsWith('aionui-team-')) {")],
    kind="aionui",
)

# ── 2b. gemini/cli/config.ts — team MCP keep/exclude name match (2 spots) ────
print("[2b] AionUi gemini/cli/config.ts — team MCP name match (keep/exclude)")
do_patch(
    "config.match",
    os.path.join(AIONUI, "src/process/agent/gemini/cli/config.ts"),
    already="key === 'aionui-team'",
    transforms=[
        ("([key]) => key.startsWith('aionui-team-') || allowedNames.has(key)",
         "([key]) => key === 'aionui-team' || key.startsWith('aionui-team-') || allowedNames.has(key)"),
        ("([key]) => key.startsWith('aionui-team-') || !excludedNames.has(key)",
         "([key]) => key === 'aionui-team' || key.startsWith('aionui-team-') || !excludedNames.has(key)"),
    ],
    kind="aionui",
)

# ── 3. leadPrompt.ts — mcp_aionui_team_ suffix guidance paragraph ────────────
# NOTE: leadPrompt.ts is a TS template literal, so backticks are escaped (\`).
print("[3] AionUi leadPrompt.ts — mcp_aionui_team_ suffix guidance")
LP_ANCHOR = r"system and will break team coordination. Always use the \`team_*\` versions."
LP_PARA = "\n\n" + r"""These tools are registered via an MCP server, so your tool list may show them
with a namespace prefix: \`team_spawn_agent\` typically appears as
\`mcp_aionui_team_team_spawn_agent\`, \`team_send_message\` as
\`mcp_aionui_team_team_send_message\`, and so on. **Match team tools by suffix**:
any tool whose name ends in \`team_spawn_agent\`, \`team_send_message\`,
\`team_members\`, \`team_task_create\`, \`team_task_update\`, \`team_task_list\`,
\`team_rename_agent\`, \`team_shutdown_agent\`, \`team_describe_assistant\`, or
\`team_list_models\` is the correct tool to call — invoke it by its full name as
listed, regardless of the prefix."""
do_patch(
    "leadPrompt.suffix",
    os.path.join(AIONUI, "src/process/team/prompts/leadPrompt.ts"),
    already="mcp_aionui_team_team_spawn_agent",
    transforms=[(LP_ANCHOR, LP_ANCHOR + LP_PARA)],
    kind="aionui",
)

# ── 4. Hermes server.py — advertise McpCapabilities(stdio=True) ──────────────
print("[4a] Hermes server.py — import McpCapabilities")
do_patch(
    "server.import",
    HERMES,
    already="    McpCapabilities,",
    transforms=[("    McpServerStdio,", "    McpCapabilities,\n    McpServerStdio,")],
    kind="hermes",
)
print("[4b] Hermes server.py — mcp_capabilities in initialize() AgentCapabilities")
do_patch(
    "server.capabilities",
    HERMES,
    already="mcp_capabilities=McpCapabilities(stdio=True)",
    transforms=[("                prompt_capabilities=PromptCapabilities(image=True),\n",
                 "                prompt_capabilities=PromptCapabilities(image=True),\n"
                 "                mcp_capabilities=McpCapabilities(stdio=True),\n")],
    kind="hermes",
)

# ── 5. Dead-code cleanup — revert the inert teamId edit in acp/index.ts ──────
# src/process/agent/acp/index.ts is the LEGACY AcpAgent: imported only as a type
# and tree-shaken out of the bundle (the live ACP class is AcpAgentV2). An earlier
# session left an inert teamId edit there; revert it to upstream so the AionUi diff
# stays clean. No rebuild needed (dead file).
print("[5] AionUi acp/index.ts — revert inert teamId edit (dead file) if present")
_DC_TYPE_EDITED = (
    "    /** Team MCP server stdio config injected by TeamSessionService */\n"
    "    teamMcpStdioConfig?: { name: string; command: string; args: string[]; env: Array<{ name: string; value: string }> };\n"
    "    /** Team ID for emitting MCP status events (set on team conversations) */\n"
    "    teamId?: string;\n"
    "    /** Pending config option selections from Guid page (applied after session creation) */\n"
)
_DC_TYPE_UPSTREAM = (
    "    /** Team MCP server stdio config injected by TeamSessionService */\n"
    "    teamMcpStdioConfig?: { name: string; command: string; args: string[]; env: Array<{ name: string; value: string }> };\n"
    "    /** Pending config option selections from Guid page (applied after session creation) */\n"
)
_DC_A_EDITED = (
    "    // Only emit MCP status events when running inside a team session.\n"
    "    const teamId = this.extra.teamId;\n"
)
_DC_A_UPSTREAM = (
    "    // Derive teamId from injected team MCP server name (format: aionui-team-<teamId>)\n"
    "    // Only emit MCP status events when running inside a team session.\n"
    "    const teamMcpName = this.extra.teamMcpStdioConfig?.name;\n"
    "    const teamId = teamMcpName?.startsWith('aionui-team-') ? teamMcpName.slice('aionui-team-'.length) : undefined;\n"
)
_DC_B_EDITED = (
    "      const tId = this.extra.teamId;\n"
    "      if (tId) {\n"
)
_DC_B_UPSTREAM = (
    "      const mcpName = this.extra.teamMcpStdioConfig?.name;\n"
    "      const tId =\n"
    "        typeof mcpName === 'string' && mcpName.startsWith('aionui-team-')\n"
    "          ? mcpName.slice('aionui-team-'.length)\n"
    "          : undefined;\n"
    "      if (tId) {\n"
)
do_revert(
    "acp.deadcode-teamId",
    os.path.join(AIONUI, "src/process/agent/acp/index.ts"),
    present_marker="Team ID for emitting MCP status events",
    transforms=[
        (_DC_TYPE_EDITED, _DC_TYPE_UPSTREAM),
        (_DC_A_EDITED, _DC_A_UPSTREAM),
        (_DC_B_EDITED, _DC_B_UPSTREAM),
    ],
)

# ── Summary ──────────────────────────────────────────────────────────────────
print()
print("Summary: %d patched, %d reverted, %d skipped, %d warning(s)" % (n_patch, n_revert, n_skip, n_warn))
if backups:
    print("Backups written:")
    for b in backups:
        print("  - %s" % b)
else:
    print("No files changed (all patches already present).")

print()
if aionui_changed:
    print("⚠ AionUi rebuild REQUIRED — main-process files changed.")
    print("  This project's `electron-vite dev` builds the main process only at startup;")
    print("  it does NOT hot-rebuild on save. Restart the dev server:")
    print("    pkill -9 -f '[e]lectron'; (cd %s && nohup node_modules/.bin/electron-vite dev >/tmp/aionui-dev.log 2>&1 &)" % AIONUI)
else:
    print("AionUi rebuild: not needed (no AionUi files changed).")
if hermes_changed:
    print("⚠ Hermes restart REQUIRED — server.py changed. Restart the Hermes ACP adapter /")
    print("  reopen the team in AionUi so the agent re-initializes with the new capability.")
if deadcode_changed:
    print("Note: reverted the inert teamId edit in acp/index.ts (dead/tree-shaken file — no rebuild needed).")

print()
print("Reminder: re-run this script after a fresh AionUi `npm install`/checkout or a Hermes")
print("update — both can restore upstream files and silently drop these patches.")
PYEOF
