#!/usr/bin/env bash
# KHAOSS Stack v1.1 — Linux Installer (double-click or run in terminal)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bash "$SCRIPT_DIR/install.sh"
