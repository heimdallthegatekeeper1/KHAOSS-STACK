@echo off
REM KHAOSS Stack v1.1 — Windows Installer (double-click)
cd /d "%~dp0"
powershell -ExecutionPolicy Bypass -File "install.ps1"
pause
