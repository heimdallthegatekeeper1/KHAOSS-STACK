#!/usr/bin/env bash
# KHAOSS Stack v1.1 — macOS Installer (double-click in Finder)
set -euo pipefail
SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
bash "$SCRIPT_DIR/install_macos.sh"
