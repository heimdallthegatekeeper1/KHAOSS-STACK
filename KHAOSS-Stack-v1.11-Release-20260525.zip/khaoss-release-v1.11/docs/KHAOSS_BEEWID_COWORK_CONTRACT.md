# KHAOSS ↔ Beewid Co-Work Contract
**Anti-Interference + Integration Agreements**
**Version:** 2 (consolidated)
**Date:** 2026-05-18
**Authors:** KHAOSS Sonnet (this session) + Beewid Opus 9th instance
**Status:** Canonical — both stacks must respect this document

---

## TL;DR for any new instance

- KHAOSS lives in `~/beewid-privacy/` and `~/aionui-stack-panel.html`
- Beewid lives in `~/Downloads/beewid/`
- Neither touches the other's directory — ever
- Shared modules live in `~/beewid-privacy/` and are **imported, never forked**
- Vault paths are permanent territorial contracts (see §3)
- swarm13 = KHAOSS · swarm14 = Beewid (reserved)
- BOHKSS transition happens when Beewid Phase E ships — not before

---

## §1 — Directory Ownership (hard boundary)

| Path | Owner | Rule |
|------|-------|------|
| `~/Downloads/beewid/` | **Beewid Opus** | KHAOSS never reads, writes, or scans this |
| `~/beewid-privacy/` | **KHAOSS Sonnet** | Beewid imports from here, never modifies |
| `~/aionui-stack-panel.html` | **KHAOSS Sonnet** | Beewid does not touch this file |
| `~/launch-stack.sh` | **KHAOSS Sonnet** | Beewid does not modify |
| `~/launch-aionui.sh` | **KHAOSS Sonnet** | Beewid does not modify |
| `~/agents/space-agent/` | **Shared / opt-in** | Either can start it; neither owns it |
| `~/obsidian-vault/` | **Shared read** | Both write here; KHAOSS writes session_*.md; Beewid writes its own notes |
| `~/vault/` | **KHAOSS-owned** | See §3 for permanent vault contract |
| `~/Downloads/beewid/vault/` | **Beewid-owned** | See §3 |

**Enforcement:** Any CC or Opus instance that receives a task must
check the target path before writing. If the path is in the other
stack's territory, refuse and flag it.

---

## §2 — Shared Modules (import-only, never fork)

These files live in `~/beewid-privacy/` and are maintained by
KHAOSS Sonnet. Beewid uses them by importing — it never copies,
forks, or reimplements them.

| Module | What it does | When Beewid imports it |
|--------|-------------|----------------------|
| `scrubber.py` | PII scrubbing (59 tests, v2) | Beewid §20 — replaces `privacy_scrub` skill |
| `ring_interface.py` | Ring 0-4 context gating | Beewid §18 — vault context rings |
| `vault_mcp_readonly.py` | 7 read-only MCP tools | Beewid §20 — MCP config reference |
| `vault_import_sanitizer.py` | Quarantine gate | Beewid §20 — when Obsidian routing via KHAOSS ships |

**Import pin rule:** When Beewid imports these, pin the absolute
path in a code comment so future Opus instances don't accidentally
fork them:
```python
# KHAOSS shared module — import only, never fork
# Maintained by KHAOSS Sonnet at ~/beewid-privacy/scrubber.py
import sys; sys.path.insert(0, os.path.expanduser('~/beewid-privacy'))
import scrubber
```

---

## §3 — Vault Paths (permanent territorial contract)

This is contractual and survives the BOHKSS transition.

| Vault | Owner | Contents |
|-------|-------|----------|
| `~/vault/` | **KHAOSS permanently** | raw/ private/ workspace/ public/ quarantine/ |
| `~/Downloads/beewid/vault/` | **Beewid permanently** | autocode_reports/ autocode_problems/ diagnostics/ future secrets |

**Unification rule (§20):** When Beewid §20 "unified vault" ships,
unification happens **via `vault_mcp_readonly.py`** as a read-only
MCP bridge — NOT by relocating files from either vault. Both
projects keep their vault roots permanently. Neither project uses
`~/vault/` as a generic root — always full absolute paths in code.

**Scanning rule:** Neither project scans the other's vault. KHAOSS
`EXCLUDED_PATHS` in `screen_assistant.py` explicitly excludes
`~/Downloads/beewid/vault/`. Beewid must do the equivalent.

---

## §4 — Hermes Swarm Profile Assignment

| Profile | Owner | Purpose |
|---------|-------|---------|
| swarm13 | **KHAOSS** | Primary leader, screen assistant, panel judge, KHAOSS tasks |
| swarm14 | **Beewid §29** | Beewid engine backend default (reserved, not yet configured) |
| swarm1 | KHAOSS | Strategic analysis (Claude Sonnet via OpenRouter) |
| swarm2 | KHAOSS | Operations/writing (GPT-4o via OpenRouter) |
| swarm3 | KHAOSS | Bulk research (Claude Haiku via OpenRouter) |
| swarm4-12 | Unassigned | Available for either stack |

**Contention rule:** swarm13 is KHAOSS-owned. Beewid §29 defaults
to swarm14 to avoid run-state contention. Configurable per-dispatch
but swarm14 is the no-thought default for Beewid. When swarm14 is
created, use the Hermes API server proxy at `:8642`.

---

## §5 — Hermes API Server Proxy Contract

The Hermes v0.14.0 OpenAI-compatible proxy at `:8642` is how both
stacks communicate with Hermes without MCP conflicts.

```
URL: http://localhost:8642/v1
Key: change-me-local-dev (change for production)
```

- **KHAOSS** uses it via AionUI's custom model provider entry
- **Beewid §29** uses it via OpenAI SDK:
  ```python
  from openai import AsyncOpenAI
  hermes_client = AsyncOpenAI(
      base_url="http://localhost:8642/v1",
      api_key=os.environ.get("HERMES_API_KEY", "change-me-local-dev")
  )
  # Use model="swarm14" for Beewid, "swarm13" for KHAOSS
  ```

Full contract: `~/beewid-privacy/HERMES_V014_PROXY_CONTRACT.md`

---

## §6 — Phase B Scope Clarification

From Beewid Opus 9th instance reply (2026-05-17):

**Phase B (active)** = autocode run-state liveness fix. Touches
`_ACTIVE_RUNS` registry in `beewid_autocode_engine.py`. Adds
`last_event_at`, `terminal_state`, `owner_tab_token`, `pid_alive`.
**Zero relationship to vault context rings.**

**Beewid Vault Context Rings (§18, separate)** = Ring 0-4 RAG
context scoping. Scheduled v0.84. This is when `ring_interface.py`
gets imported.

KHAOSS Phase B dispatch was clear of this — no rework needed.

---

## §7 — BOHKSS Transition Trigger and Checklist

BOHKSS = Beewid + Obsidian + Hermes + Kanban + Screenpipe + Space Agent

**Transition happens when:** Beewid Phase E ships (watchdog :8507
confirmed serving, autocode :8509 confirmed serving, main :8506
health endpoint live).

**What KHAOSS Sonnet does at transition:**

- [ ] Uncomment Beewid health stubs in `panel_server.py` (ports 8506/8507/8509)
- [ ] Update `EXCLUDED_PATHS` in `screen_assistant.py` for unified vault
- [ ] Switch `screen_assistant.py` `TRANSPORT` to `"beewid_autocode"`
- [ ] Rename `~/aionui-stack-panel.html` → `~/bohkss-panel.html`
- [ ] Update `~/launch-stack.sh` to launch Beewid instead of AionUI
- [ ] Wire `scrubber.py` import into Beewid `privacy_scrub` skill
- [ ] Wire `ring_interface.py` import into `beewid_api.py` context gating

**What does NOT change at transition:**
- `~/vault/` stays KHAOSS-owned
- `~/beewid-privacy/` stays the shared module home
- Hermes, Kanban, Screenpipe, Obsidian, Space Agent all continue unchanged
- swarm profile assignments stay the same
- The Hermes API proxy contract stays the same

**BOHKSS panel is the KHAOSS panel renamed** — same features,
same SSE, same service cards. Three BOHKSS pending service cards
are already in the panel waiting to be uncommented.

---

## §8 — Screen Assistant Transport Swap

`screen_assistant.py` has a swappable transport layer for when
Beewid autocode replaces the Hermes CLI dispatch:

```python
TRANSPORT = "hermes_cli"   # current
# TRANSPORT = "beewid_autocode"  # after BOHKSS transition
```

`call_suggestion_backend()` already handles both. At transition,
change the constant and the screen assistant routes to Beewid
Autocode at `:8509` instead of shelling out to `hermes -z`.

---

## §9 — Port Assignments (no conflicts)

| Port | Service | Owner |
|------|---------|-------|
| :3030 | Screenpipe | Shared |
| :7842 | KHAOSS Panel | KHAOSS |
| :8506 | Beewid main | Beewid (pending Phase E) |
| :8507 | Beewid watchdog | Beewid (pending Phase E) |
| :8509 | Beewid autocode | Beewid (pending Phase E) |
| :8642 | Hermes gateway | Shared |
| :9119 | Hermes dashboard | Shared |
| :3000 | Space Agent | Shared (opt-in) |
| :5173 | AionUI dev server | KHAOSS (AionUI era only) |

**Note:** :8508 is NOT the Beewid autocode port. The correct port
is :8509 (confirmed in Phase E verification per Beewid Opus reply).

---

## §10 — What Each Stack Tells New Instances

### What KHAOSS Sonnet must tell new instances:
1. Never touch `~/Downloads/beewid/`
2. Shared modules in `~/beewid-privacy/` are import-only
3. Vault paths are permanent (§3)
4. swarm13 is KHAOSS, swarm14 is Beewid
5. BOHKSS transition checklist (§7) — don't trigger early
6. The `</script>` inside template literal bug — always use `\u003c/script\u003e`

### What Beewid Opus must tell new instances:
1. Never touch `~/beewid-privacy/` (only import from it)
2. Never touch `~/aionui-stack-panel.html`
3. Use swarm14 not swarm13
4. Phase B is autocode run-state only — not rings
5. §18 is when ring_interface.py gets imported (v0.84)
6. §29 is the Hermes proxy integration (post-beta)

---

## §11 — Interference Analysis Resolutions (from original doc)

Original conflicts found in `KHAOSS_BEEWID_INTERFERENCE_ANALYSIS.md`
and Beewid Opus 9th reply — all resolved:

| Conflict | Resolution |
|----------|-----------|
| #1: Panel port collision | KHAOSS :7842 · Beewid :8506/:8507/:8509 — no overlap |
| #2: ring_interface.py ownership | KHAOSS owns it · Beewid imports at §18 (Phase B has zero ring involvement — confirmed by Opus 9) |
| #3: vault path ambiguity | Permanent territorial split (§3) · unification via MCP bridge only |
| #4: swarm profile contention | swarm13=KHAOSS · swarm14=Beewid (§4) |
| #5: AionUI MCP team_* gap | Hermes v0.14.0 proxy at :8642 solves it · Beewid §29 uses same proxy |
| #6: screen_assistant transport | Swappable TRANSPORT constant (§8) · swap at BOHKSS transition |

---

## §12 — NAMING LOCKED

From Beewid Opus 9th reply (2026-05-17):

```
KHAOSS = Kanban + Hermes + AionUI + Obsidian + Screenpipe + Space Agent
BOHKSS = Beewid + Obsidian + Hermes + Kanban + Screenpipe + Space Agent
```

Pronounceable. Distinctive from "Chaos". Both names are canonical
and must survive handoffs in both projects.

Beewid slogan: **"If-Need-Bee"**

---

## §13 — Pro Nara Shared Context

Pro Nara AI Team uses KHAOSS infrastructure:
- Team profiles: swarm13 (leader), swarm1-3 (workers)
- Tenant: `[pronara]`
- Vault workspace: `/home/boq/vault/workspace/pronara_*.md`
- Kanban: BLOCKED tasks await Phase 2 (Gmail/Drive — needs phone/2SV)

Beewid has no Pro Nara involvement until BOHKSS transition.
Privacy remediation complete: all "Bobby" placeholders replaced
with `[ORG LEAD]` across workspace files.

---

*KHAOSS Sonnet · Beewid Opus 9 · 2026-05-18*
*This document supersedes all previous interference analysis versions.*
*Copy to: ~/beewid-privacy/KHAOSS_BEEWID_COWORK_CONTRACT.md*
*Copy to: ~/Downloads/beewid/KHAOSS_BEEWID_COWORK_CONTRACT.md*

---

## §14 — Bridge ALLOWED_PATHS Policy (added 2026-05-18)

ALLOWED_PATHS is configured by the human operator via the panel UI only.
Beewid MUST NOT call POST /bridge/config to modify ALLOWED_PATHS autonomously.

When Beewid needs a new path accessible to Space Agent:
1. Beewid requests it via POST /bridge/request
2. Operator approves via panel card
3. Operator confirms before Space Agent can access

Violation = one stack silently expanding the other's security surface.

## §15 — Space Agent L2 Mount (added 2026-05-18)

L2/user/ is the ONLY user-visible sandbox mount in Space Agent v0.36.
CUSTOMWARE_PATH=/home/boq relocates the L2 root but does not add mounts.
Beewid Agents tab should document this when surfacing Space Agent skills.

## §16 — Space Agent Hermes Profile (added 2026-05-20)

The `space-agent` Hermes profile is permanently reserved:
- Owner: Space Agent integration
- Model: gpt-5.5 via openai-codex
- Created: 2026-05-20
- Skills: 87 bundled (auto-synced on creation)
- Neither KHAOSS nor Beewid may reassign this profile

Reference: ~/beewid-privacy/HERMES_SWARM_REGISTRY.md

## §17 — Space Agent Bridge Write Rule (added 2026-05-20)

When Space Agent edits files via POST /bridge/write:
- HTML and CSS changes: bridge write is safe
- JavaScript changes: MUST go via Terminal CC, not bridge write
- Reason: bridge write can corrupt JS even with raw passthrough
  due to Space Agent's internal content handling

This applies to all files: aionui-stack-panel.html, beewid_*.html,
panel_server.py, and any other code files.

Deploy to both stacks:
cp ~/beewid-privacy/KHAOSS_BEEWID_COWORK_CONTRACT.md \
  ~/Downloads/beewid/KHAOSS_BEEWID_COWORK_CONTRACT.md
