KHAOSS v1.11 — "Build Hermes Team" panel button + endpoint
============================================================
Two edits. HTML/CSS goes in via the bridge (contract §17).
The Python endpoint + JS go in via Terminal CC (§17: JS via terminal, not bridge).

────────────────────────────────────────────────────────────────────────
EDIT 1 — HTML/CSS: the button block
File: ~/aionui-stack-panel.html
Insert IMMEDIATELY AFTER the closing </div> of the topbar (after line ~411,
the `</div>` that closes <div class="topbar">), and BEFORE
<div class="alerts-bar" ...>. This puts it at the very top, impossible to miss.
────────────────────────────────────────────────────────────────────────

<!-- ── Build Hermes Team (top-of-panel, primary action) ───────────── -->
<style>
.bht-bar{
  background:linear-gradient(90deg,#001f0a,var(--panel));
  border-bottom:1px solid var(--accent);
  padding:14px 20px;display:flex;align-items:center;gap:16px;flex-wrap:wrap;
}
.bht-main{display:flex;align-items:center;gap:14px;flex:1;min-width:280px}
.bht-btn{
  background:#001f0a;border:1px solid var(--accent);color:var(--accent);
  font-family:inherit;font-size:14px;font-weight:bold;letter-spacing:1px;
  padding:10px 20px;border-radius:3px;cursor:pointer;white-space:nowrap;
  transition:background .12s,box-shadow .12s;
}
.bht-btn:hover{background:#003314;box-shadow:0 0 12px var(--green-soft)}
.bht-btn:disabled{opacity:.5;cursor:not-allowed;box-shadow:none}
.bht-help{font-size:10px;color:var(--fg-faint);line-height:1.5;max-width:520px}
.bht-help b{color:var(--fg-dim)}
.bht-form{display:none;width:100%;margin-top:10px;gap:8px;flex-direction:column}
.bht-form.open{display:flex}
.bht-row{display:flex;align-items:center;gap:8px;flex-wrap:wrap}
.bht-row label{font-size:10px;color:var(--fg-faint);min-width:88px}
.bht-input,.bht-select{
  background:var(--card);border:1px solid var(--border2);color:var(--fg);
  font-family:inherit;font-size:11px;padding:5px 9px;border-radius:2px;outline:none;flex:1;min-width:180px;
}
.bht-roles{min-height:54px;resize:vertical;width:100%}
.bht-status{font-size:10px;letter-spacing:.3px;margin-top:4px}
.bht-status.ok{color:var(--green)} .bht-status.err{color:var(--red)} .bht-status.run{color:var(--amber)}
</style>

<div class="bht-bar" id="bht-bar">
  <div class="bht-main">
    <button class="bht-btn" id="bht-btn" onclick="bhtToggleForm()">⚡ BUILD HERMES TEAM</button>
    <div class="bht-help">
      Spawns <b>Hermes-harnessed teammate agents</b> into your team and makes them
      appear as clickable cards in the AionUi chat. Each teammate is its own Hermes
      session you can talk to directly.
      <br><b>First open the team in AionUi</b> (its session must be live), then click Build.
    </div>
  </div>
  <div class="bht-form" id="bht-form">
    <div class="bht-row">
      <label for="bht-team">Team name</label>
      <input class="bht-input" id="bht-team" placeholder="exact AionUi team name, e.g. Crypto trading 2.">
    </div>
    <div class="bht-row">
      <label for="bht-preset">Preset</label>
      <select class="bht-select" id="bht-preset" onchange="bhtPreset()">
        <option value="trading">Trading Ops (7 roles)</option>
        <option value="research">Research (4 roles)</option>
        <option value="custom">Custom…</option>
      </select>
    </div>
    <div class="bht-row" style="align-items:flex-start">
      <label for="bht-roles">Roles</label>
      <textarea class="bht-input bht-roles" id="bht-roles" placeholder="one role per line"></textarea>
    </div>
    <div class="bht-row">
      <button class="btn-action" id="bht-go" onclick="bhtSeed()">Build team →</button>
      <span class="bht-status" id="bht-status"></span>
    </div>
  </div>
</div>

────────────────────────────────────────────────────────────────────────
EDIT 2 — JS: add to the panel's <script> (via Terminal CC, §17)
File: ~/aionui-stack-panel.html  (inside the main <script> block)
────────────────────────────────────────────────────────────────────────

const BHT_PRESETS = {
  trading: ["Technical Analyst","Sentiment Analyst","Fundamentals Researcher",
            "Bull Researcher","Bear Researcher","Strategist","Risk Monitor"],
  research: ["Lead Researcher","Source Scout","Fact Checker","Synthesizer"],
  custom: [],
};
function bhtToggleForm(){
  const f=document.getElementById('bht-form');
  f.classList.toggle('open');
  if(f.classList.contains('open')) bhtPreset();
}
function bhtPreset(){
  const p=document.getElementById('bht-preset').value;
  document.getElementById('bht-roles').value=(BHT_PRESETS[p]||[]).join('\n');
}
async function bhtSeed(){
  const team=document.getElementById('bht-team').value.trim();
  const roles=document.getElementById('bht-roles').value
    .split('\n').map(r=>r.trim()).filter(Boolean);
  const st=document.getElementById('bht-status');
  const go=document.getElementById('bht-go');
  if(!team){ st.className='bht-status err'; st.textContent='Enter the team name.'; return; }
  if(roles.length===0){ st.className='bht-status err'; st.textContent='Add at least one role.'; return; }
  go.disabled=true; st.className='bht-status run'; st.textContent='Spawning '+roles.length+' Hermes teammate(s)…';
  try{
    const r=await fetch('/team/seed',{method:'POST',headers:{'Content-Type':'application/json'},
      body:JSON.stringify({team,roles})});
    const d=await r.json();
    if(d.ok){ st.className='bht-status ok';
      st.textContent='✓ '+(d.seeded?d.seeded.length:roles.length)+' Hermes teammate(s) built into "'+team+'". Switch to AionUi to see the cards.'; }
    else { st.className='bht-status err'; st.textContent='✗ '+(d.error||'Failed. Is the team open in AionUi?'); }
  }catch(e){ st.className='bht-status err'; st.textContent='✗ '+e.message; }
  finally{ go.disabled=false; }
}

────────────────────────────────────────────────────────────────────────
EDIT 3 — Python endpoint: in panel_server.py
File: ~/beewid-privacy/panel_server.py
────────────────────────────────────────────────────────────────────────

(a) In do_POST(), add this route line alongside the other `if path == ...` checks
    (e.g. right after the `/learning-loop/run` line):

        if path == "/team/seed":
            return self._team_seed()

(b) Add this handler method to the same handler class (place it near the other
    _xxx POST handlers, e.g. after _ll_run). SEED_SCRIPT path matches the
    documented location; adjust if yours differs.

    def _team_seed(self) -> None:
        """POST /team/seed  body: {"team": "<name>", "roles": ["Role", ...]}
        Spawns Hermes teammates into the named (open) AionUi team via
        seed_hermes_team.sh. Returns {ok, seeded[], output} or {error}."""
        import shlex
        SEED_SCRIPT = Path.home() / "beewid-privacy" / "seed_hermes_team.sh"
        try:
            body = json.loads(self.rfile.read(
                int(self.headers.get("Content-Length", 0))) or b"{}")
        except Exception:
            self._send(400, json.dumps({"error": "invalid JSON body"}), "application/json")
            return

        team = (body.get("team") or "").strip()
        roles_in = body.get("roles") or []

        # Validation: team name + roles must be plain, bounded strings.
        # No shell is used (we pass an argv list to subprocess), but we still
        # reject control chars / overlong values defensively.
        def _clean(s: str) -> str:
            s = str(s).strip()
            return s if (0 < len(s) <= 120 and all(ord(c) >= 32 for c in s)) else ""

        team = _clean(team)
        roles = [r for r in (_clean(x) for x in roles_in) if r][:12]  # cap at 12
        if not team:
            self._send(400, json.dumps({"error": "missing or invalid team name"}), "application/json")
            return
        if not roles:
            self._send(400, json.dumps({"error": "no valid roles provided"}), "application/json")
            return
        if not SEED_SCRIPT.exists():
            self._send(500, json.dumps({"error": f"seed script not found: {SEED_SCRIPT}"}), "application/json")
            return

        try:
            proc = subprocess.run(
                ["bash", str(SEED_SCRIPT), team, *roles],
                capture_output=True, text=True, timeout=180,
            )
        except subprocess.TimeoutExpired:
            self._send(504, json.dumps({"error": "seed timed out (is the team open in AionUi?)"}),
                       "application/json")
            return
        except Exception as e:
            self._send(500, json.dumps({"error": str(e)}), "application/json")
            return

        out = (proc.stdout or "") + (("\n" + proc.stderr) if proc.stderr else "")
        if proc.returncode == 0:
            self._send(200, json.dumps({"ok": True, "seeded": roles, "output": out.strip()}),
                       "application/json")
        else:
            # Common failure: team not found / session not open (port/token lookup fails).
            err = (proc.stderr or proc.stdout or "seed failed").strip().splitlines()
            self._send(200, json.dumps({"ok": False,
                       "error": (err[-1] if err else "seed failed"),
                       "output": out.strip()}), "application/json")
            return

NOTES
- subprocess is called with an argv LIST (no shell), so role/team strings cannot
  inject commands even before the _clean() guard. Matches the file's existing
  subprocess usage (_hermes_to_file at line 867).
- The endpoint returns ok:false (HTTP 200) for "team not open / not found" so the
  button can show a friendly message rather than a generic 500.
- After applying: restart the panel (POST /services/restart-panel or your usual
  way) so the new route is live.
