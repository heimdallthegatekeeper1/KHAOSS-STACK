# KHAOSS Stack — Opus Handoff v7
**Date:** 2026-05-25 · **Supersedes:** v6 (2026-05-24)
**Machine:** Cornholio · Kali · user boq · X11
**Status:** v1.11 — Hermes team display WORKING (provisioned via panel button / seed script)

---

## HEADLINE

A team of **all-Hermes agents** now renders horizontally in the AionUi panel,
each individually engageable, no GUI conflicts. Reference team "Crypto trading 2."
= 1 Hermes leader + 7 Hermes teammates (swarm21–27 lineup), all
`agentType: hermes`, all "Active session with Hermes Agent", verified live.

Provisioning is via the new **⚡ Build Hermes Team** panel button (or the
`seed_hermes_team.sh` script it wraps). **Leader-driven prompt-spawn is NOT yet
working** — it's the documented fast-follow (see below).

---

## CORRECTED ROOT CAUSES (v6 had several of these wrong)

The "Hermes leader has no team_* tools / teammates don't display" problem was a
STACK of issues, peeled one at a time. For the next chat, the truth:

1. **NOT a capability-flag problem.** `hermes` was already in
   `KNOWN_TEAM_CAPABLE_BACKENDS` (patched 2026-05-17). Team creation with a Hermes
   leader was always allowed.

2. **Hermes didn't advertise `mcpCapabilities`.** Its ACP `initialize()` omitted
   `mcp_capabilities`, so AionUi's injection gate (`if (mcpCapabilities)`) skipped
   the builtin-MCP path. FIXED in `server.py` — `mcp_capabilities=McpCapabilities(stdio=True)`.
   (Note: that acp build's `McpCapabilities` has no `stdio` field — it has
   `http`/`sse`; stdio is implied by the object's presence. AionUi parses
   `stdio: mcp !== null`. So emitting the object — even `{}` — is the correct
   spec-compliant signal. The patch is still correct/keep.)

3. **The MCP server name carried the team UUID** → tools surfaced to the model as
   `mcp_aionui_team_<uuid>_team_spawn_agent`, but `leadPrompt.ts` told the leader
   to call `team_spawn_agent`. Name mismatch. FIXED: `TeamMcpServer.ts`
   `getStdioConfig()` → `name: 'aionui-team'` (no UUID) + companion name-match
   fixes in `GeminiAgentManager.ts`, `gemini/cli/config.ts` + `leadPrompt.ts`
   suffix guidance.

4. **THE LIVE ACP PATH IS `AcpAgentV2`, NOT `acp/index.ts`.** We burned hours
   reading/patching `src/process/agent/acp/index.ts` — it is **dead code**,
   imported only as a type, tree-shaken out of the bundle. The live class is
   `AcpAgentV2` (`src/process/acp/compat/AcpAgentV2.ts`); the session client is
   `ProcessAcpClient`. **Patch/instrument those.** (The patcher reverts the inert
   `acp/index.ts` edit to keep the diff clean.)

5. **Leader sessions resume (`loadSession`), not recreate.** A leader with a
   stored `acpSessionId` resumes its ACP session. Clearing `acpSessionId` forces a
   fresh `session/new`. We confirmed via instrumentation that the team MCP server
   **IS** injected into the leader's session
   (`loadSession(RESUME) mcpServers=[aionui-team]`).

6. **THE REMAINING BUG (fast-follow): Hermes receives the injected MCP but does
   not surface its tools to the model on the resume path.** Verified end to end:
   AionUi injects `[aionui-team]`, but the leader's verbatim tool list still has
   zero `team_*`/`mcp_aionui_team_*`. So the leader can't self-spawn. Teammates
   created via the service path DO work and render. → We ship via the seed/button;
   leader-driven spawn is v1.22.

---

## WHAT SHIPPED (v1.11)

- **4 source patches** (see PATCHES.md): `TeamMcpServer.ts` rename,
  `GeminiAgentManager.ts` + `gemini/cli/config.ts` name-match, `leadPrompt.ts`
  suffix guidance, `server.py` mcpCapabilities.
- **⚡ Build Hermes Team button** — top of the control panel.
  `POST /team/seed {team, roles}` → `seed_hermes_team.sh` → TCP `team_spawn_agent`
  (service path, agent_type hermes). Verified end-to-end; leaves no residue.
- **`seed_hermes_team.sh`** + **`team_spawn_client.js`** — deterministic Hermes
  team provisioner. Domain-agnostic (trading, research, anything).
- **`khaoss_reapply_patches.sh`** + **PATCHES.md** — idempotent durability layer;
  reapplies the 4 patches after `npm install`/`hermes update`, reverts the
  dead-code edit. Verified all-skip on a clean tree.
- **README.md** — install, the button flow, Hermes-harness clarification,
  no-conflict swarm operation, quirks.

---

## HERMES SWARM REGISTRY (v1.11 — supersedes v6's 14–20)

Trading renumbered to swarm21–27 (Option A; swarm14 stays Beewid §29 reserved).

| Profile | Role | Status |
|---------|------|--------|
| swarm13 | KHAOSS primary + Trading Leader | LOCKED |
| swarm14 | Beewid §29 RESERVED | do not touch |
| swarm15–20 | FREE | available |
| swarm21 | Technical Analyst | active |
| swarm22 | Sentiment Analyst | active |
| swarm23 | Fundamentals Researcher | active |
| swarm24 | Bull Researcher | active |
| swarm25 | Bear Researcher | active |
| swarm26 | Strategist | active |
| swarm27 | Risk Monitor | active |

Note: teammates currently run `agentType: hermes` on model
`openai-codex:gpt-5.5` (cloned from leader). The Hermes *harness* is what matters;
the model behind it is swappable per profile.

---

## CRITICAL OPERATIONAL NOTES

- **Two AionUi builds:** `~/launch-aionui.sh` = dev (patched). Desktop launcher =
  packaged (NOT patched unless installer applied there). Test the build you patched.
- **Blank window causes:** (a) `pkill -9 -f electron` kills its own shell — use
  `pkill -9 -f "[e]lectron"`; (b) electron launched before dev-server compiles main
  → wait for "renderer did-finish-load".
- **Main-process edits don't hot-reload** — full dev restart needed; confirm with
  `grep -c <marker> out/main/index.js`.
- **Seed needs the team OPEN in AionUi** (MCP port/token are session-scoped).
- **Provision via service path, never raw DB** (dangling conversationId breaks slot).
- **Back up `aionui.db` before any DB op.**
- **Team data is SQLite** (`~/.config/AionUi-Dev/aionui/aionui.db`), NOT leveldb.

---

## FAST-FOLLOW (v1.22)

1. **Fix Hermes tool-surfacing** so the leader sees `mcp_aionui_team_team_*` and
   can self-spawn. The fix is in the Hermes adapter: register the injected MCP into
   the **model-visible tool surface** on `load_session`/`resume`, not just
   `new_session`. `_register_session_mcp_servers` is called on all paths, but the
   resume path apparently doesn't refresh the model's exposed toolset. Investigate
   there.
2. **Leader skill** that auto-proposes + spawns a standard lineup → true
   "spawn leader, prompt, go".
3. **Packaged-build patching** — ensure the 4 patches land in the build users
   actually run (installer applies patcher to the packaged tree, or ship a
   pre-patched build).

---

## OPEN / UNRELATED

- **Analyst Kanban workers** (swarm21–23) still fail on `claude-haiku-4-5` credit
  balance. Independent of team display. Fund Anthropic or repoint profiles to a
  working provider (the leader's codex/gpt-5.5 works).

---

*KHAOSS Opus 1 · Handoff v7 · 2026-05-25 · 🐝 If-Need-Bee*
