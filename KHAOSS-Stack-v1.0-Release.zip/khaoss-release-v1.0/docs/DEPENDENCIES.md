# KHAOSS Dependencies — Download Guide

This document is the canonical source for every external download
the installer expects. The installers print warnings when these are
missing; this page explains where to get each one and any post-
install steps that the script does not perform automatically.

## Required Downloads

### 1. Hermes Agent (required)
- Download: https://hermes.sh
- Linux/macOS: `curl -fsSL https://hermes.sh/install | bash`
- Windows: Download installer from website
- After install: `hermes auth login --provider openai-codex`
- Create profile: `hermes profile create swarm13 --provider openai-codex --model gpt-5.5`

### 2. Screenpipe (required for vision/audio)
- Download: https://screenpipe.com
- Linux: Binary at `~/Downloads/screenpipe-main/target/release/screenpipe`
  OR: `cargo install screenpipe` (requires Rust)
- macOS: DMG installer from website
- Windows: EXE installer from website
- After install: `screenpipe doctor`

### 3. AionUI (required for agent teams)
- GitHub: https://github.com/aionui/aionui
- Download the latest release zip
- Extract to `~/Downloads/AIonUi/AionUi-main`
- Run: `cd ~/Downloads/AIonUi/AionUi-main && npm install`
- CRITICAL: Apply Hermes patches after install
  See: `docs/AIONUI_HERMES_LEADER_FIX.md`

### 4. Codex CLI (required for swarm profiles)
- Install: `npm install -g @openai/codex`
- Authenticate: `codex auth login`
- Verify: `codex --version`

### 5. Python 3.10+ (required)
- https://python.org/downloads
- Required packages: `pip3 install watchdog requests pytest`

### 6. Node.js 18+ LTS (required)
- https://nodejs.org
- Includes npm

### 7. Git (required)
- https://git-scm.com
- Linux: `sudo apt install git`
- macOS: `xcode-select --install`
- Windows: Git for Windows from website

### 8. Obsidian (optional but recommended)
- https://obsidian.md
- Point vault to `~/obsidian-vault/`
- Session memory and weekly learning notes appear here

## Optional

### 9. Space Agent (opt-in)
- Clone: `git clone https://github.com/space-agent/space-agent ~/agents/space-agent`
- Install: `cd ~/agents/space-agent && npm install`
- Start: `PORT=3000 npm start` (via panel toggle)

### 10. OpenRouter API (for swarm1-3 multi-provider)
- https://openrouter.ai/keys
- Add to `~/.hermes/.env`: `OPENROUTER_API_KEY=your_key`
- Configure swarm1 (Claude Sonnet), swarm2 (GPT-4o), swarm3 (Claude Haiku)

### 11. EXA or Firecrawl (for proactive research)
- EXA: https://exa.ai → API keys
- Firecrawl: https://firecrawl.dev → API keys
- Add to `~/.hermes/.env`
- Proactive Research auto-activates when key present
