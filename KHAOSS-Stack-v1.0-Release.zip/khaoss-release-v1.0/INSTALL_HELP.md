# KHAOSS Installation Help

## If the installer hangs or fails

### Step 1 — Run the debug report

**Linux/macOS:**
```bash
bash scripts/khaoss_debug.sh
```

**Windows (in WSL2):**
```bash
bash scripts/khaoss_debug.sh
```

This generates `/tmp/khaoss_debug_TIMESTAMP.md`

---

### Step 2 — Get AI help (fastest option)

Paste the debug report into any of these:

**Option A: Terminal CC (Claude Code)**
```bash
cd ~
claude
# Then paste the debug report contents
# Ask: "Fix my KHAOSS installation — here is my debug report:"
```

**Option B: Claude.ai**
Go to https://claude.ai → New chat → paste the debug file contents

**Option C: ChatGPT**
Go to https://chatgpt.com → paste the debug file contents

**Option D: Any AI coding assistant**
The debug report is self-contained — any AI can read it and give
exact fix commands.

---

### Step 3 — Manual fixes for common problems

#### "hermes: command not found"
```bash
curl -fsSL https://hermes.sh/install | bash
source ~/.bashrc
hermes --version
```

#### "screenpipe not found"
Download the binary from https://screenpipe.com
Place it at: `~/Downloads/screenpipe-main/target/release/screenpipe`
Or add to PATH.

#### "AionUI won't start" / Electron crash
```bash
pkill -9 -f electron 2>/dev/null
rm -f ~/.config/AionUi-Dev/SingletonLock
rm -f ~/.config/AionUi-Dev/SingletonCookie
rm -f ~/.config/AionUi-Dev/SingletonSocket
rm -rf ~/.config/AionUi-Dev/GPUCache/
bash ~/launch-aionui.sh
```

#### "Panel not loading" (http://localhost:7842 blank)
```bash
pkill -f panel_server.py
sleep 2
python3 ~/beewid-privacy/panel_server.py &
sleep 3
curl http://localhost:7842/
```

#### "Hermes team not connecting in AionUI"
The Hermes source patches may be missing. Check:
```bash
grep -c "LOCAL PATCH" \
  ~/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts
# Must return 1 — if 0, see docs/AIONUI_HERMES_LEADER_FIX.md
```

#### "Screenpipe shows degraded (amber dot)"
This is NORMAL on Linux/Wayland. Vision + audio still work.
Only `input_monitoring` is unavailable — not required for KHAOSS.

#### "Kanban board won't open"
```bash
hermes dashboard &
sleep 4
# Then open http://127.0.0.1:9119/kanban
```

#### Python package errors
```bash
pip3 install watchdog requests --break-system-packages
# or
pip3 install watchdog requests
```

#### Port already in use
```bash
# Find what's on port 7842
lsof -i :7842
# Kill it
pkill -f panel_server.py
```

---

### Step 4 — Full reinstall (nuclear option)

```bash
# Stop everything
pkill -f panel_server.py vault_watcher sanitizer screen_assistant
pkill -f proactive_research learning_loop voice_kanban

# Re-run installer
bash installers/install.sh
```

---

### Step 5 — Ask for help with the debug report

If nothing works, the debug report at `/tmp/khaoss_debug_*.md`
contains everything an AI needs to fix your installation.

**What to say:**
> "I'm installing KHAOSS and getting errors. Here is my debug report.
> Please give me the exact bash commands to fix each issue."

Then paste the entire debug file.

The AI will give you copy-pasteable fix commands. This works with
Claude, ChatGPT, Gemini, Copilot, or any AI assistant.

---

## Installation time expectations

| Step | Expected time |
|---|---|
| Prerequisite check | < 30 seconds |
| Python packages | 30-60 seconds |
| Hermes install (if needed) | 1-2 minutes |
| Codex CLI install | 1-2 minutes |
| AionUI npm install | 2-5 minutes |
| Stack first boot | 30-60 seconds |
| **Total** | **5-10 minutes** |

If any single step takes > 2 minutes without progress output,
it may be stuck — press Ctrl+C and run the debug script.
