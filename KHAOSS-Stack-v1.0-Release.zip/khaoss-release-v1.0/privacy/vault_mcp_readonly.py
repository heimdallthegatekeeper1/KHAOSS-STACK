#!/usr/bin/env python3
"""
Read-only MCP filesystem server for the Beewid vault-workspace.

Replaces @modelcontextprotocol/server-filesystem to enforce that Hermes
(and any other MCP client) can ONLY read from ~/vault/workspace/.

Security guarantees:
  - Exposes only read tools (no write_file, edit_file, create_directory,
    move_file, or delete_file). Write tools are not registered; calls to
    them return JSON-RPC -32601 (method not found).
  - Every path argument is resolved through realpath and verified to live
    inside the allowed root. Symlink escapes are rejected.
  - Every successful tool call is appended to ~/beewid-privacy/mcp_access.log
    with UTC timestamp, tool name, and resolved path(s).
  - No external dependencies — pure stdlib.

Protocol:
  JSON-RPC 2.0 over stdio, newline-delimited (one JSON object per line).
  Implements: initialize, tools/list, tools/call, notifications/initialized.
"""

from __future__ import annotations

import fnmatch
import json
import os
import stat
import sys
import threading
from datetime import datetime, timezone
from pathlib import Path
from typing import Any, Iterable

# ── Configuration ────────────────────────────────────────────────────────────

ALLOWED_ROOTS: list[Path] = [
    Path(os.path.expanduser("~/vault/workspace")).resolve(),
]
LOG_PATH = Path(os.path.expanduser("~/beewid-privacy/mcp_access.log"))
MAX_READ_BYTES = 2 * 1024 * 1024          # 2 MiB per read_file call
MAX_TREE_ENTRIES = 5000                    # cap recursive listings
MAX_SEARCH_RESULTS = 1000

PROTOCOL_VERSION = "2024-11-05"
SERVER_NAME = "beewid-vault-readonly"
SERVER_VERSION = "1.0.0"

_log_lock = threading.Lock()

# ── Logging ──────────────────────────────────────────────────────────────────

def _log(tool: str, detail: str) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    line = f"{ts}\t{tool}\t{detail}\n"
    try:
        with _log_lock:
            LOG_PATH.parent.mkdir(parents=True, exist_ok=True)
            with LOG_PATH.open("a", encoding="utf-8") as fh:
                fh.write(line)
    except OSError:
        # Logging must never block tool execution.
        pass

# ── Path safety ──────────────────────────────────────────────────────────────

class PathDenied(Exception):
    """Raised when a path resolves outside the allowed root or is malformed."""

def _resolve_inside_root(raw: str) -> Path:
    """
    Resolve `raw` to an absolute path and verify it lives inside one of
    ALLOWED_ROOTS. Symlinks are followed via realpath so an attacker cannot
    point a symlink to /etc/passwd.

    Accepts both absolute paths and paths relative to the first allowed root.
    """
    if not isinstance(raw, str) or not raw:
        raise PathDenied("path must be a non-empty string")

    candidate = Path(raw)
    if not candidate.is_absolute():
        candidate = ALLOWED_ROOTS[0] / candidate

    try:
        resolved = candidate.resolve(strict=False)
    except (OSError, RuntimeError) as exc:
        raise PathDenied(f"could not resolve path: {exc}") from exc

    for root in ALLOWED_ROOTS:
        try:
            resolved.relative_to(root)
            return resolved
        except ValueError:
            continue
    raise PathDenied(f"path escapes allowed root: {raw}")

# ── Tool implementations (read-only) ─────────────────────────────────────────

def _tool_read_file(args: dict[str, Any]) -> dict[str, Any]:
    path = _resolve_inside_root(args.get("path", ""))
    if not path.is_file():
        raise PathDenied(f"not a regular file: {path}")
    if path.stat().st_size > MAX_READ_BYTES:
        raise PathDenied(
            f"file exceeds {MAX_READ_BYTES} byte limit ({path.stat().st_size} bytes)"
        )
    text = path.read_text(encoding="utf-8", errors="replace")
    _log("read_file", str(path))
    return {"content": [{"type": "text", "text": text}]}


def _tool_read_multiple_files(args: dict[str, Any]) -> dict[str, Any]:
    raw_paths = args.get("paths", [])
    if not isinstance(raw_paths, list):
        raise PathDenied("paths must be an array of strings")

    sections: list[str] = []
    for raw in raw_paths:
        try:
            p = _resolve_inside_root(raw)
            if not p.is_file():
                sections.append(f"# {raw}\nERROR: not a regular file\n")
                continue
            if p.stat().st_size > MAX_READ_BYTES:
                sections.append(f"# {p}\nERROR: file too large\n")
                continue
            body = p.read_text(encoding="utf-8", errors="replace")
            sections.append(f"# {p}\n{body}")
            _log("read_multiple_files", str(p))
        except PathDenied as exc:
            sections.append(f"# {raw}\nERROR: {exc}\n")
    return {"content": [{"type": "text", "text": "\n---\n".join(sections)}]}


def _tool_list_directory(args: dict[str, Any]) -> dict[str, Any]:
    path = _resolve_inside_root(args.get("path", ""))
    if not path.is_dir():
        raise PathDenied(f"not a directory: {path}")
    lines: list[str] = []
    for entry in sorted(path.iterdir(), key=lambda e: e.name):
        kind = "[DIR]" if entry.is_dir() else "[FILE]"
        lines.append(f"{kind} {entry.name}")
    _log("list_directory", str(path))
    return {"content": [{"type": "text", "text": "\n".join(lines) or "(empty)"}]}


def _tool_directory_tree(args: dict[str, Any]) -> dict[str, Any]:
    path = _resolve_inside_root(args.get("path", ""))
    if not path.is_dir():
        raise PathDenied(f"not a directory: {path}")

    def walk(node: Path) -> dict[str, Any]:
        entry: dict[str, Any] = {"name": node.name, "type": "directory", "children": []}
        try:
            children = sorted(node.iterdir(), key=lambda e: e.name)
        except OSError:
            return entry
        for child in children:
            if len(collected) >= MAX_TREE_ENTRIES:
                return entry
            if child.is_dir() and not child.is_symlink():
                entry["children"].append(walk(child))
            else:
                entry["children"].append({"name": child.name, "type": "file"})
            collected.append(child)
        return entry

    collected: list[Path] = []
    tree = walk(path)
    _log("directory_tree", f"{path} entries={len(collected)}")
    return {"content": [{"type": "text", "text": json.dumps(tree, indent=2)}]}


def _tool_get_file_info(args: dict[str, Any]) -> dict[str, Any]:
    path = _resolve_inside_root(args.get("path", ""))
    if not path.exists():
        raise PathDenied(f"path does not exist: {path}")
    st = path.stat()
    info = {
        "path": str(path),
        "size": st.st_size,
        "type": "directory" if path.is_dir() else "file",
        "mode": stat.filemode(st.st_mode),
        "modified": datetime.fromtimestamp(st.st_mtime, tz=timezone.utc).isoformat(),
        "created":  datetime.fromtimestamp(st.st_ctime, tz=timezone.utc).isoformat(),
    }
    _log("get_file_info", str(path))
    return {"content": [{"type": "text", "text": json.dumps(info, indent=2)}]}


def _tool_list_allowed_directories(_args: dict[str, Any]) -> dict[str, Any]:
    body = "\n".join(str(r) for r in ALLOWED_ROOTS)
    _log("list_allowed_directories", body.replace("\n", ","))
    return {"content": [{"type": "text", "text": body}]}


def _tool_search_files(args: dict[str, Any]) -> dict[str, Any]:
    root = _resolve_inside_root(args.get("path", ""))
    pattern = args.get("pattern", "*")
    if not isinstance(pattern, str) or not pattern:
        raise PathDenied("pattern must be a non-empty string")
    if not root.is_dir():
        raise PathDenied(f"not a directory: {root}")

    hits: list[str] = []
    for dirpath, dirnames, filenames in os.walk(root, followlinks=False):
        # Stay inside allowed root even after os.walk dereferences something odd.
        try:
            _resolve_inside_root(dirpath)
        except PathDenied:
            dirnames[:] = []
            continue
        for name in filenames:
            if fnmatch.fnmatch(name, pattern):
                hits.append(os.path.join(dirpath, name))
                if len(hits) >= MAX_SEARCH_RESULTS:
                    break
        if len(hits) >= MAX_SEARCH_RESULTS:
            break
    _log("search_files", f"root={root} pattern={pattern} hits={len(hits)}")
    body = "\n".join(hits) if hits else "(no matches)"
    return {"content": [{"type": "text", "text": body}]}


# ── Tool registry — names match the official filesystem server's read tools.
# Write tools (write_file, edit_file, create_directory, move_file, delete_file)
# are intentionally absent. tools/call on any unregistered name returns -32601.

TOOLS: dict[str, dict[str, Any]] = {
    "read_file": {
        "description": "Read the complete contents of a file as UTF-8 text. Path must be inside the allowed vault-workspace root.",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string", "description": "Absolute or relative path to read."}},
            "required": ["path"],
            "additionalProperties": False,
        },
        "handler": _tool_read_file,
    },
    "read_multiple_files": {
        "description": "Read multiple files in one call. Returns sections separated by '---'.",
        "inputSchema": {
            "type": "object",
            "properties": {"paths": {"type": "array", "items": {"type": "string"}}},
            "required": ["paths"],
            "additionalProperties": False,
        },
        "handler": _tool_read_multiple_files,
    },
    "list_directory": {
        "description": "List the immediate contents of a directory. Returns [DIR]/[FILE] prefixed names.",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
        "handler": _tool_list_directory,
    },
    "directory_tree": {
        "description": "Return a JSON tree of files and directories rooted at the given path.",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
        "handler": _tool_directory_tree,
    },
    "get_file_info": {
        "description": "Return metadata for a file or directory: size, type, mode, mtime, ctime.",
        "inputSchema": {
            "type": "object",
            "properties": {"path": {"type": "string"}},
            "required": ["path"],
            "additionalProperties": False,
        },
        "handler": _tool_get_file_info,
    },
    "list_allowed_directories": {
        "description": "Return the list of root directories this server is permitted to read.",
        "inputSchema": {"type": "object", "properties": {}, "additionalProperties": False},
        "handler": _tool_list_allowed_directories,
    },
    "search_files": {
        "description": "Recursively search for files whose name matches a glob pattern (fnmatch).",
        "inputSchema": {
            "type": "object",
            "properties": {
                "path": {"type": "string"},
                "pattern": {"type": "string", "description": "Glob pattern, e.g. '*.md'"},
            },
            "required": ["path", "pattern"],
            "additionalProperties": False,
        },
        "handler": _tool_search_files,
    },
}

# ── JSON-RPC dispatch ────────────────────────────────────────────────────────

def _make_result(rpc_id: Any, result: Any) -> dict[str, Any]:
    return {"jsonrpc": "2.0", "id": rpc_id, "result": result}

def _make_error(rpc_id: Any, code: int, message: str, data: Any = None) -> dict[str, Any]:
    err: dict[str, Any] = {"code": code, "message": message}
    if data is not None:
        err["data"] = data
    return {"jsonrpc": "2.0", "id": rpc_id, "error": err}

def _handle_initialize(_params: dict[str, Any]) -> dict[str, Any]:
    return {
        "protocolVersion": PROTOCOL_VERSION,
        "serverInfo": {"name": SERVER_NAME, "version": SERVER_VERSION},
        "capabilities": {"tools": {"listChanged": False}},
    }

def _handle_tools_list(_params: dict[str, Any]) -> dict[str, Any]:
    return {
        "tools": [
            {
                "name": name,
                "description": spec["description"],
                "inputSchema": spec["inputSchema"],
            }
            for name, spec in TOOLS.items()
        ]
    }

def _handle_tools_call(params: dict[str, Any]) -> dict[str, Any]:
    name = params.get("name")
    args = params.get("arguments", {}) or {}
    spec = TOOLS.get(name)
    if spec is None:
        # Treat as application error (not JSON-RPC) so the client sees a
        # structured "tool not allowed" message rather than a transport error.
        _log("DENIED", f"unknown_or_blocked_tool={name}")
        return {
            "content": [{"type": "text", "text": f"Tool '{name}' is not available on this read-only server."}],
            "isError": True,
        }
    try:
        return spec["handler"](args)
    except PathDenied as exc:
        _log("DENIED", f"{name} {exc}")
        return {"content": [{"type": "text", "text": f"DENIED: {exc}"}], "isError": True}
    except OSError as exc:
        _log("ERROR", f"{name} {exc}")
        return {"content": [{"type": "text", "text": f"ERROR: {exc}"}], "isError": True}

def _dispatch(message: dict[str, Any]) -> dict[str, Any] | None:
    method = message.get("method")
    rpc_id = message.get("id")
    params = message.get("params") or {}

    # Notifications (no id) get no response per JSON-RPC 2.0
    is_notification = "id" not in message

    if method == "initialize":
        return _make_result(rpc_id, _handle_initialize(params))
    if method == "tools/list":
        return _make_result(rpc_id, _handle_tools_list(params))
    if method == "tools/call":
        return _make_result(rpc_id, _handle_tools_call(params))
    if method == "notifications/initialized" or method == "initialized":
        return None  # notification — no response
    if method == "ping":
        return _make_result(rpc_id, {})
    if is_notification:
        return None
    return _make_error(rpc_id, -32601, f"Method not found: {method}")

# ── stdio main loop ──────────────────────────────────────────────────────────

def _emit(obj: dict[str, Any]) -> None:
    sys.stdout.write(json.dumps(obj, separators=(",", ":")) + "\n")
    sys.stdout.flush()

def main() -> int:
    _log("BOOT", f"pid={os.getpid()} roots={[str(r) for r in ALLOWED_ROOTS]}")
    for raw_line in sys.stdin:
        line = raw_line.strip()
        if not line:
            continue
        try:
            message = json.loads(line)
        except json.JSONDecodeError as exc:
            _emit(_make_error(None, -32700, f"Parse error: {exc}"))
            continue
        if not isinstance(message, dict):
            _emit(_make_error(None, -32600, "Invalid Request: not an object"))
            continue
        response = _dispatch(message)
        if response is not None:
            _emit(response)
    _log("SHUTDOWN", f"pid={os.getpid()}")
    return 0


if __name__ == "__main__":
    sys.exit(main())
