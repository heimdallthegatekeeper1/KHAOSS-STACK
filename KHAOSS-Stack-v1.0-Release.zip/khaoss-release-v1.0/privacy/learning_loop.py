#!/usr/bin/env python3
"""
learning_loop.py — Weekly learning synthesis daemon for the KHAOSS stack.

Reads past screen-assistant suggestions and Obsidian session summaries, then
asks Hermes (profile swarm13) to analyse recurring patterns and create or
improve skills accordingly. Writes a weekly_learning_YYYY-WW.md to
~/obsidian-vault/.

Run manually:  python3 learning_loop.py
Schedule:      python3 learning_loop.py --schedule

PID file is written for the duration of execution and removed on exit,
since this is a one-shot run (not a persistent daemon).
"""

from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# ── Constants ─────────────────────────────────────────────────────────────────

HOME         = Path(os.path.expanduser("~"))
VAULT_DIR    = HOME / "obsidian-vault"
PRIVACY_DIR  = HOME / "beewid-privacy"
LOG_FILE     = PRIVACY_DIR / "learning_loop.log"
PID_FILE     = PRIVACY_DIR / "learning_loop.pid"
RUNS_FILE    = PRIVACY_DIR / "learning_loop_runs.jsonl"

SCREEN_LOG   = PRIVACY_DIR / "screen_assistant.log"

HERMES_BIN      = "/home/boq/.local/bin/hermes"
HERMES_PROFILE  = "swarm13"
HERMES_TIMEOUT  = 300   # /goal calls can take a while
SKILLS_TIMEOUT  = 30

MAX_SESSION_CHARS = 5000

# ── Logging ───────────────────────────────────────────────────────────────────

log = logging.getLogger("learning_loop")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%Y-%m-%dT%H:%M:%S")
_fh = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
_fh.setFormatter(_fmt)
log.addHandler(_fh)
_sh = logging.StreamHandler(sys.stderr)
_sh.setFormatter(_fmt)
log.addHandler(_sh)

# ── PID management ────────────────────────────────────────────────────────────

def _read_pid(path: Path) -> int | None:
    try:
        raw = path.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def write_pid_file() -> None:
    existing = _read_pid(PID_FILE)
    if existing and _alive(existing):
        log.error("learning_loop already running (PID %d) — refusing to start", existing)
        sys.exit(2)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n")


def remove_pid_file() -> None:
    try:
        current = _read_pid(PID_FILE)
        if current == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── Data gathering ────────────────────────────────────────────────────────────

def read_screen_suggestions() -> list[str]:
    """Parse all JSON suggestion lines from screen_assistant.log."""
    suggestions: list[str] = []
    if not SCREEN_LOG.is_file():
        log.info("screen_assistant.log not found, skipping")
        return suggestions
    try:
        with SCREEN_LOG.open(encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    record = json.loads(line)
                    suggestion = record.get("suggestion", "")
                    if suggestion:
                        suggestions.append(suggestion)
                except json.JSONDecodeError:
                    pass
    except OSError as exc:
        log.warning("could not read screen log: %s", exc)
    log.info("read %d suggestions from screen_assistant.log", len(suggestions))
    return suggestions


def read_session_files() -> tuple[str, list[str]]:
    """Read session_*.md files from the vault, up to MAX_SESSION_CHARS total.

    Returns (combined_text, list_of_filenames_read).
    """
    if not VAULT_DIR.is_dir():
        log.warning("vault directory not found: %s", VAULT_DIR)
        return "", []

    session_files: list[Path] = []
    try:
        for p in VAULT_DIR.iterdir():
            if p.is_file() and p.name.startswith("session_") and p.suffix == ".md":
                session_files.append(p)
    except OSError as exc:
        log.warning("vault scan failed: %s", exc)
        return "", []

    session_files.sort(key=lambda p: p.stat().st_mtime, reverse=True)

    chunks: list[str] = []
    total = 0
    read_names: list[str] = []

    for p in session_files:
        if total >= MAX_SESSION_CHARS:
            break
        try:
            text = p.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            log.warning("could not read %s: %s", p.name, exc)
            continue
        remaining = MAX_SESSION_CHARS - total
        chunk = text[:remaining]
        chunks.append(f"### {p.name}\n{chunk}")
        total += len(chunk)
        read_names.append(p.name)

    combined = "\n\n".join(chunks)
    log.info("read %d session file(s) (%d chars total)", len(read_names), total)
    return combined, read_names


def get_hermes_skills() -> str:
    """Fetch the current hermes skills list and return as a string."""
    try:
        result = subprocess.run(
            [HERMES_BIN, "skills", "list", "--profile", HERMES_PROFILE],
            capture_output=True, text=True, timeout=SKILLS_TIMEOUT,
        )
        if result.returncode != 0:
            log.warning(
                "skills list exited %d: %s",
                result.returncode, result.stderr.strip()[:300],
            )
            return "(skills list unavailable)"
        return result.stdout.strip() or "(no skills found)"
    except FileNotFoundError:
        log.error("hermes binary not found at %s", HERMES_BIN)
        return "(hermes not found)"
    except subprocess.TimeoutExpired:
        log.warning("hermes skills list timed out after %ds", SKILLS_TIMEOUT)
        return "(skills list timed out)"

# ── Hermes synthesis call ─────────────────────────────────────────────────────

def build_goal_prompt(
    session_text: str,
    suggestions: list[str],
    skills_text: str,
) -> str:
    suggestions_block = "\n".join(f"- {s}" for s in suggestions) or "(none)"
    return (
        "/goal Analyze the past week of work patterns from these session summaries "
        "and screen suggestions. Create or improve Hermes skills based on recurring "
        "patterns. For each pattern found: "
        "1. Check if a skill exists: hermes skills list --profile swarm13 "
        "2. If not: create a new skill with hermes skills create --profile swarm13 "
        "3. If yes: improve the existing skill. "
        "Goal criteria: at least 1 skill created or improved, "
        "weekly_learning_YYYY-WW.md written to ~/obsidian-vault/. "
        "Max turns: 15.\n\n"
        f"Session summaries:\n{session_text or '(none)'}\n\n"
        f"Screen suggestions:\n{suggestions_block}\n\n"
        f"Existing skills:\n{skills_text}"
    )


def call_hermes_goal(prompt: str) -> tuple[str | None, int]:
    """Send the /goal prompt to hermes. Returns (stdout, exit_code)."""
    try:
        result = subprocess.run(
            [HERMES_BIN, "--profile", HERMES_PROFILE, "-z", prompt],
            capture_output=True, text=True, timeout=HERMES_TIMEOUT,
        )
        output = result.stdout.strip()
        if result.returncode != 0:
            log.warning(
                "hermes /goal exited %d: %s",
                result.returncode, result.stderr.strip()[:300],
            )
        return output or None, result.returncode
    except FileNotFoundError:
        log.error("hermes binary not found at %s", HERMES_BIN)
        return None, 127
    except subprocess.TimeoutExpired:
        log.warning("hermes /goal timed out after %ds", HERMES_TIMEOUT)
        return None, 124

# ── Output writing ────────────────────────────────────────────────────────────

def week_label() -> str:
    """Return ISO year-week label like 2026-W20."""
    now = datetime.now(tz=timezone.utc)
    iso = now.isocalendar()
    return f"{iso[0]}-W{iso[1]:02d}"


def write_weekly_md(
    synthesis: str,
    session_names: list[str],
    suggestion_count: int,
) -> Path:
    """Write the weekly learning markdown file and return its path."""
    label = week_label()
    out_path = VAULT_DIR / f"weekly_learning_{label}.md"

    ts = datetime.now(tz=timezone.utc).isoformat()
    meta_lines = [
        "## Run metadata",
        f"- **Timestamp:** {ts}",
        f"- **Session files read:** {', '.join(session_names) or 'none'}",
        f"- **Screen suggestions processed:** {suggestion_count}",
    ]
    meta_block = "\n".join(meta_lines)

    content = (
        f"# Weekly Learning — {label}\n\n"
        f"{synthesis}\n\n"
        f"{meta_block}\n"
    )

    try:
        VAULT_DIR.mkdir(parents=True, exist_ok=True)
        out_path.write_text(content, encoding="utf-8")
        log.info("wrote weekly learning file: %s", out_path)
    except OSError as exc:
        log.error("could not write %s: %s", out_path, exc)

    return out_path


def append_run_record(
    exit_code: int,
    output_path: Path,
    suggestions_read: int,
    sessions_read: int,
) -> None:
    """Append a JSON run record to the runs JSONL file."""
    record = {
        "ts": datetime.now(tz=timezone.utc).isoformat(),
        "exit_code": exit_code,
        "output_path": str(output_path),
        "suggestions_read": suggestions_read,
        "sessions_read": sessions_read,
    }
    try:
        RUNS_FILE.parent.mkdir(parents=True, exist_ok=True)
        with RUNS_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")
    except OSError as exc:
        log.warning("could not write runs record: %s", exc)

# ── Signal handling ───────────────────────────────────────────────────────────

def _on_signal(signum: int, _frame) -> None:
    log.info("received signal %d — one-shot run, continuing to completion", signum)

# ── Main entry point ──────────────────────────────────────────────────────────

def run() -> int:
    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT,  _on_signal)

    PRIVACY_DIR.mkdir(parents=True, exist_ok=True)
    write_pid_file()

    exit_code = 0
    output_path = VAULT_DIR / f"weekly_learning_{week_label()}.md"

    try:
        log.info("learning_loop started")

        # Gather inputs
        suggestions = read_screen_suggestions()
        session_text, session_names = read_session_files()
        skills_text = get_hermes_skills()

        # Build and send the /goal prompt
        prompt = build_goal_prompt(session_text, suggestions, skills_text)
        log.info(
            "calling hermes /goal (timeout %ds, %d suggestions, %d session files)",
            HERMES_TIMEOUT, len(suggestions), len(session_names),
        )
        synthesis, exit_code = call_hermes_goal(prompt)

        # Write outputs
        if synthesis:
            output_path = write_weekly_md(synthesis, session_names, len(suggestions))
        else:
            log.warning("no synthesis from hermes; writing stub weekly file")
            output_path = write_weekly_md(
                "(Hermes did not return output — check learning_loop.log for details.)",
                session_names,
                len(suggestions),
            )

        append_run_record(exit_code, output_path, len(suggestions), len(session_names))
        log.info("learning_loop complete (exit_code=%d)", exit_code)
        return exit_code

    except Exception as exc:  # noqa: BLE001
        log.exception("unexpected error: %s", exc)
        append_run_record(1, output_path, 0, 0)
        return 1
    finally:
        remove_pid_file()
        log.info("learning_loop PID file removed")


# ── Cron scheduling helper ────────────────────────────────────────────────────

def schedule_cron():
    """Register a weekly cron job with hermes swarm13. Safe to call multiple times."""
    import subprocess
    # hermes cron add syntax: hermes cron add "CRON_EXPR" "COMMAND" [--name NAME] [--profile PROFILE]
    cmd = "python3 /home/boq/beewid-privacy/learning_loop.py"
    result = subprocess.run(
        ["hermes", "cron", "add", "0 3 * * 0", cmd, "--profile", "swarm13"],
        capture_output=True, text=True, timeout=30,
    )
    return result.returncode == 0, result.stdout + result.stderr


if __name__ == "__main__":
    import sys
    if len(sys.argv) > 1 and sys.argv[1] == "--schedule":
        ok, out = schedule_cron()
        print(out)
        sys.exit(0 if ok else 1)
    sys.exit(run())
