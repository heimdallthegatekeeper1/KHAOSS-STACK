#!/usr/bin/env python3
"""
vault_watcher.py — Watches ~/.screenpipe/data/ for new files and scrubs them
into ~/vault/private/ and ~/vault/workspace/ using scrubber.py.

Standalone process; does not depend on Hermes or AionUI.
Run directly:  python3 vault_watcher.py
Stop:          kill $(cat vault_watcher.pid)
"""

import json
import os
import sys
import time
import signal
import logging
import hashlib
from pathlib import Path

from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler

# ---------------------------------------------------------------------------
# Paths
# ---------------------------------------------------------------------------

BASE = Path(__file__).parent
WATCH_DIR = Path.home() / ".screenpipe" / "data"
VAULT_PRIVATE = Path.home() / "vault" / "private"
VAULT_WORKSPACE = Path.home() / "vault" / "workspace"
LOG_FILE = BASE / "watcher.log"
PID_FILE = BASE / "vault_watcher.pid"

# ---------------------------------------------------------------------------
# File classification
# ---------------------------------------------------------------------------

TEXT_EXTENSIONS = {
    ".txt", ".json", ".md", ".csv", ".log",
    ".yaml", ".yml", ".toml", ".xml", ".html",
    ".srt", ".vtt",  # subtitle/caption files screenpipe may produce
}

SKIP_EXTENSIONS = {
    ".jpg", ".jpeg", ".png", ".gif", ".webp",
    ".mp4", ".mkv", ".webm", ".avi",
    ".db", ".sqlite", ".db-wal", ".db-shm",  # handled separately if needed
    ".opus", ".mp3", ".wav", ".ogg",
    ".zip", ".tar", ".gz",
}

# ---------------------------------------------------------------------------
# Logging
# ---------------------------------------------------------------------------

def _setup_logging() -> logging.Logger:
    fmt = "%(asctime)s %(levelname)-8s %(message)s"
    datefmt = "%Y-%m-%dT%H:%M:%S"
    logger = logging.getLogger("vault_watcher")
    logger.setLevel(logging.DEBUG)
    fh = logging.FileHandler(LOG_FILE, encoding="utf-8")
    fh.setLevel(logging.DEBUG)
    fh.setFormatter(logging.Formatter(fmt, datefmt))
    sh = logging.StreamHandler(sys.stdout)
    sh.setLevel(logging.INFO)
    sh.setFormatter(logging.Formatter(fmt, datefmt))
    logger.addHandler(fh)
    logger.addHandler(sh)
    return logger


log = _setup_logging()

# ---------------------------------------------------------------------------
# Scrubber import (sibling module)
# ---------------------------------------------------------------------------

sys.path.insert(0, str(BASE))
import scrubber
from scrubber import Level

SCRUB_LEVELS = [
    (Level.PRIVATE,   VAULT_PRIVATE),
    (Level.WORKSPACE, VAULT_WORKSPACE),
]

# ---------------------------------------------------------------------------
# Event handler
# ---------------------------------------------------------------------------

class VaultHandler(FileSystemEventHandler):
    def __init__(self, config: dict):
        self.config = config
        self._seen: set[str] = set()

    def on_created(self, event):
        if not event.is_directory:
            self._enqueue(Path(event.src_path))

    def on_moved(self, event):
        if not event.is_directory:
            self._enqueue(Path(event.dest_path))

    def _enqueue(self, path: Path):
        key = str(path)
        if key in self._seen:
            return
        self._seen.add(key)
        self._process(path)

    def _process(self, path: Path):
        suffix = path.suffix.lower()

        if suffix in SKIP_EXTENSIONS:
            log.debug("skip binary: %s", path.name)
            return

        if suffix not in TEXT_EXTENSIONS:
            log.debug("unknown extension %s — attempting text: %s", suffix, path.name)

        # Brief wait for the writer to flush
        time.sleep(0.3)

        if not path.exists():
            log.warning("file vanished before processing: %s", path)
            return

        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except Exception as exc:
            log.warning("cannot read %s: %s", path, exc)
            return

        # Screen zone exclusion: JSON files with frame coordinate metadata
        if path.suffix.lower() == ".json":
            try:
                frame_data = json.loads(text)
                fx = int(frame_data.get("x", frame_data.get("frame_x", 0)))
                fy = int(frame_data.get("y", frame_data.get("frame_y", 0)))
                fw = int(frame_data.get("width", frame_data.get("w", 0)))
                fh = int(frame_data.get("height", frame_data.get("h", 0)))
                if scrubber.is_in_excluded_zone(fx, fy, fw, fh):
                    log.info("zone_excluded: %s (frame %d,%d %dx%d)",
                             path.name, fx, fy, fw, fh)
                    return
                # Extract and OCR-scrub text content within the JSON
                for key in ("text", "content", "ocr_text"):
                    if key in frame_data and isinstance(frame_data[key], str):
                        original = frame_data[key]
                        scrubbed = scrubber.scrub_ocr_text(
                            original, scrubber.Level.WORKSPACE, self.config
                        )
                        n_removed = scrubbed.count("[REDACTED_") - original.count("[REDACTED_")
                        if n_removed > 0:
                            log.info("ocr_scrubbed: %d patterns removed from %s[%s]",
                                     n_removed, path.name, key)
                        frame_data[key] = scrubbed
                text = json.dumps(frame_data, ensure_ascii=False)
            except (json.JSONDecodeError, TypeError, ValueError):
                pass  # not parseable JSON — treat as plain text

        # Preserve relative path inside the vault
        try:
            rel = path.relative_to(WATCH_DIR)
        except ValueError:
            rel = Path(path.name)

        src_hash = hashlib.sha256(text.encode()).hexdigest()[:12]
        log.info("new file  %s  sha256=...%s  size=%d", path.name, src_hash, len(text))

        for level, vault_dir in SCRUB_LEVELS:
            out = vault_dir / rel
            out.parent.mkdir(parents=True, exist_ok=True)
            try:
                result = scrubber.process(text, level, self.config)
                out.write_text(result, encoding="utf-8")
                log.info("  → [%s] %s", level.value, out)
            except Exception as exc:
                log.error("scrub error [%s] %s: %s", level.value, path, exc)


# ---------------------------------------------------------------------------
# PID management
# ---------------------------------------------------------------------------

def _write_pid() -> None:
    PID_FILE.write_text(str(os.getpid()), encoding="utf-8")


def _read_pid() -> int | None:
    if not PID_FILE.exists():
        return None
    try:
        return int(PID_FILE.read_text().strip())
    except ValueError:
        return None


def _is_running(pid: int | None) -> bool:
    if pid is None:
        return False
    try:
        os.kill(pid, 0)
        return True
    except (ProcessLookupError, PermissionError):
        return False


# ---------------------------------------------------------------------------
# Signal / shutdown
# ---------------------------------------------------------------------------

_observer: Observer | None = None


def _shutdown(signum=None, frame=None) -> None:
    log.info("shutdown signal received")
    if _observer is not None:
        _observer.stop()
    if PID_FILE.exists():
        PID_FILE.unlink(missing_ok=True)
    log.info("vault_watcher stopped")
    sys.exit(0)


# ---------------------------------------------------------------------------
# Main
# ---------------------------------------------------------------------------

def main() -> None:
    global _observer

    existing = _read_pid()
    if _is_running(existing):
        print(f"vault_watcher already running (PID {existing})", flush=True)
        sys.exit(0)

    _write_pid()
    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT, _shutdown)

    VAULT_PRIVATE.mkdir(parents=True, exist_ok=True)
    VAULT_WORKSPACE.mkdir(parents=True, exist_ok=True)
    WATCH_DIR.mkdir(parents=True, exist_ok=True)

    config = {
        "username": os.environ.get("USER", ""),
        "allowed_ips": [],
        "allowed_hostnames": [],
    }

    log.info("vault_watcher started  PID=%d", os.getpid())
    log.info("watching  : %s", WATCH_DIR)
    log.info("→ private : %s", VAULT_PRIVATE)
    log.info("→ workspace: %s", VAULT_WORKSPACE)
    log.info("log file  : %s", LOG_FILE)

    handler = VaultHandler(config=config)
    _observer = Observer()
    _observer.schedule(handler, str(WATCH_DIR), recursive=True)
    _observer.start()

    try:
        while True:
            time.sleep(2)
            if not _observer.is_alive():
                log.error("observer thread died — restarting")
                _observer.stop()
                _observer = Observer()
                _observer.schedule(handler, str(WATCH_DIR), recursive=True)
                _observer.start()
    except Exception as exc:
        log.error("fatal: %s", exc)
    finally:
        _shutdown()


if __name__ == "__main__":
    main()
