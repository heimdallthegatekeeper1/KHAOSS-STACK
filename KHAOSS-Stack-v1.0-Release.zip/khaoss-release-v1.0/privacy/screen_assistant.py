#!/usr/bin/env python3
"""
screen_assistant.py — Tier-1 active screen assistant for the KHAOSS stack.

Watches ~/vault/workspace/ for new or modified files. When fresh content
appears it asks Hermes (profile swarm13) for one actionable suggestion for
the user. Suggestions are appended as JSON lines to
~/beewid-privacy/screen_assistant.log so the panel can tail them.

Stdlib only (polls the directory; no watchdog dependency) so this script
can be started/stopped by panel_server.py without dragging in extra venv
state.

Rate limit
----------
At most one suggestion per RATE_LIMIT_S seconds (default: 120). If many
files change inside the window we still pick only the most-recently
modified file when the window finally elapses — there's no point
suggesting against stale content.

Stop with: kill $(cat ~/beewid-privacy/screen_assistant.pid)
"""

from __future__ import annotations

import json
import logging
import os
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

HOME            = Path(os.path.expanduser("~"))
WATCH_DIR       = HOME / "vault" / "workspace"
LOG_FILE        = HOME / "beewid-privacy" / "screen_assistant.log"
RUNTIME_LOG     = HOME / "beewid-privacy" / "screen_assistant_runtime.log"
PID_FILE        = HOME / "beewid-privacy" / "screen_assistant.pid"

# Files under these prefixes are skipped before any content is read.
# Used to keep the assistant out of the Beewid vault (separate trust
# domain) and to ignore re-firing on quarantined content.
EXCLUDED_PATHS = [
    os.path.expanduser("~/Downloads/beewid/vault/"),
    os.path.expanduser("~/vault/quarantine/"),
]

# Suggestion backend transport. Today: shell out to the hermes CLI.
# When Beewid Phase E ships, switch to "beewid_autocode" and route
# through the Beewid Autocode dispatcher (:8509) instead.
TRANSPORT       = "hermes_cli"   # future: "beewid_autocode"

HERMES_BIN      = "hermes"
HERMES_PROFILE  = "swarm13"

POLL_INTERVAL_S = 5.0
RATE_LIMIT_S    = 120.0          # max 1 suggestion / 2 min
MAX_READ_BYTES  = 4096           # truncate file content before sending
HERMES_TIMEOUT  = 60.0
SKIP_TOKEN      = "SKIP"

# Files larger than this are summarised by tail only — avoids dumping a
# 10 MB log into a prompt.
TAIL_THRESHOLD  = 16 * 1024

# File extensions worth reading. Anything else we treat as a non-text
# artefact and skip (matches the convention used by vault_watcher.py).
TEXT_EXTS = {
    ".txt", ".md", ".json", ".csv", ".log",
    ".yaml", ".yml", ".toml", ".xml", ".html",
    ".srt", ".vtt", ".py", ".js", ".ts",
}

# ── Logging ──────────────────────────────────────────────────────────────────

log = logging.getLogger("screen_assistant")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%Y-%m-%dT%H:%M:%S")
_fh = logging.FileHandler(RUNTIME_LOG, mode="a", encoding="utf-8")
_fh.setFormatter(_fmt)
log.addHandler(_fh)
_sh = logging.StreamHandler(sys.stderr)
_sh.setFormatter(_fmt)
log.addHandler(_sh)

# ── PID management ───────────────────────────────────────────────────────────

def _read_pid(path: Path) -> int | None:
    try:
        raw = path.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False

def write_pid_file() -> None:
    existing = _read_pid(PID_FILE)
    if existing and _alive(existing):
        log.error("screen_assistant already running (PID %d) — refusing to start", existing)
        sys.exit(2)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n")

def remove_pid_file() -> None:
    try:
        current = _read_pid(PID_FILE)
        if current == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── Filesystem helpers ───────────────────────────────────────────────────────

def is_excluded(path: Path) -> bool:
    """True if `path` lives under any EXCLUDED_PATHS prefix."""
    try:
        resolved = str(path.resolve())
    except OSError:
        resolved = str(path)
    return any(resolved.startswith(prefix) for prefix in EXCLUDED_PATHS)

def newest_changed(since: float) -> Path | None:
    """Return the most-recently modified file in WATCH_DIR newer than `since`."""
    if not WATCH_DIR.is_dir():
        return None
    best: tuple[float, Path] | None = None
    try:
        for p in WATCH_DIR.iterdir():
            if not p.is_file():
                continue
            if is_excluded(p):
                continue
            try:
                m = p.stat().st_mtime
            except OSError:
                continue
            if m <= since:
                continue
            if best is None or m > best[0]:
                best = (m, p)
    except OSError as exc:
        log.warning("scan failed: %s", exc)
    return best[1] if best else None

def summarise_file(path: Path) -> str:
    """Return up to MAX_READ_BYTES of context from `path` for the prompt."""
    try:
        size = path.stat().st_size
    except OSError as exc:
        return f"<unreadable: {exc}>"

    ext = path.suffix.lower()
    if ext and ext not in TEXT_EXTS:
        return f"<non-text file ({ext}, {size} bytes) — skipped>"

    try:
        with path.open("rb") as fh:
            if size > TAIL_THRESHOLD:
                # Read first chunk + last chunk; cheap on small files and
                # safe on large ones.
                head = fh.read(MAX_READ_BYTES // 2)
                fh.seek(max(0, size - MAX_READ_BYTES // 2))
                tail = fh.read()
                blob = head + b"\n...\n" + tail
            else:
                blob = fh.read(MAX_READ_BYTES)
    except OSError as exc:
        return f"<read failed: {exc}>"

    text = blob.decode("utf-8", errors="replace").strip()
    if not text:
        return "<empty>"
    return text

# ── Hermes ───────────────────────────────────────────────────────────────────

def call_suggestion_backend(context: str) -> str:
    """Swappable transport. Today: hermes CLI. Future: beewid autocode dispatch."""
    if TRANSPORT == "hermes_cli":
        result = subprocess.run(
            [HERMES_BIN, "--profile", HERMES_PROFILE, "-z", context],
            capture_output=True, text=True, timeout=HERMES_TIMEOUT,
        )
        if result.returncode != 0:
            # Surface the failure to ask_hermes by raising — keeps the
            # contract simple: return value is the assistant text or
            # nothing.
            raise RuntimeError(
                f"hermes exit {result.returncode}: {result.stderr.strip()[:300]}"
            )
        return result.stdout.strip()
    raise NotImplementedError(f"Transport {TRANSPORT} not implemented")

def ask_hermes(prompt: str) -> str | None:
    """Thin wrapper around the swappable transport.

    Returns stripped text on success, None on any failure (so the caller
    can simply skip the suggestion rather than wrap try/except).
    """
    try:
        reply = call_suggestion_backend(prompt)
    except FileNotFoundError:
        log.error("hermes binary not on PATH (looked for %r)", HERMES_BIN)
        return None
    except subprocess.TimeoutExpired:
        log.warning("hermes timed out after %.1fs", HERMES_TIMEOUT)
        return None
    except NotImplementedError as exc:
        log.error("%s", exc)
        return None
    except RuntimeError as exc:
        log.warning("%s", exc)
        return None
    return reply or None

def build_prompt(path: Path, content: str) -> str:
    return (
        f"New screen context available from {path.name}:\n"
        f"---\n{content}\n---\n"
        "In one sentence, what is the most helpful suggestion for the user right now? "
        f"Be specific and actionable. If nothing helpful, respond {SKIP_TOKEN}."
    )

def emit_suggestion(suggestion: str, source: Path) -> None:
    record = {
        "ts": datetime.now(tz=timezone.utc).isoformat(),
        "suggestion": suggestion,
        "source_file": str(source),
    }
    LOG_FILE.parent.mkdir(parents=True, exist_ok=True)
    with LOG_FILE.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(record) + "\n")
    log.info("suggestion logged: %s …", suggestion[:80].replace("\n", " "))

# ── Main loop ────────────────────────────────────────────────────────────────

_STOP = False

def _on_signal(signum: int, _frame) -> None:
    global _STOP
    log.info("received signal %d, stopping", signum)
    _STOP = True

def run() -> int:
    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT,  _on_signal)
    write_pid_file()
    try:
        WATCH_DIR.mkdir(parents=True, exist_ok=True)
        LOG_FILE.parent.mkdir(parents=True, exist_ok=True)

        # Seed last_seen with the current latest mtime so we don't immediately
        # fire on every file in the directory at startup.
        last_seen = 0.0
        try:
            for p in WATCH_DIR.iterdir():
                if p.is_file() and not is_excluded(p):
                    last_seen = max(last_seen, p.stat().st_mtime)
        except OSError:
            pass

        next_allowed = 0.0
        log.info("watching %s (poll %.1fs, rate-limit %.0fs)",
                 WATCH_DIR, POLL_INTERVAL_S, RATE_LIMIT_S)

        while not _STOP:
            now = time.time()
            target = newest_changed(last_seen)
            if target is None:
                time.sleep(POLL_INTERVAL_S)
                continue

            if now < next_allowed:
                # Hold this file as the candidate but wait for the window.
                time.sleep(min(POLL_INTERVAL_S, next_allowed - now))
                continue

            # Re-pick the newest changed file (it may have moved on while we
            # waited for the rate-limit window).
            target = newest_changed(last_seen) or target
            try:
                m = target.stat().st_mtime
            except OSError:
                time.sleep(POLL_INTERVAL_S)
                continue
            last_seen = m

            content = summarise_file(target)
            prompt = build_prompt(target, content)
            log.info("asking hermes about %s (%d bytes context)", target.name, len(content))
            reply = ask_hermes(prompt)
            next_allowed = time.time() + RATE_LIMIT_S

            if not reply:
                log.info("no reply from hermes; skipping")
                continue
            if reply.strip().upper().startswith(SKIP_TOKEN):
                log.info("hermes said SKIP for %s", target.name)
                continue
            emit_suggestion(reply, target)

        return 0
    finally:
        remove_pid_file()
        log.info("screen_assistant stopped")


if __name__ == "__main__":
    sys.exit(run())
