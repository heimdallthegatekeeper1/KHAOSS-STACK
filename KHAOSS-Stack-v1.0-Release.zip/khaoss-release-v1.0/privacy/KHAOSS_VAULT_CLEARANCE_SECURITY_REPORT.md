# CRITICAL: Vault Clearance Levels — Swarm Team Security Report
**Date:** 2026-05-17
**Priority:** P0 — Must be addressed before any external/production use
**For:** Opus (next session) + Sonnet (Pro Nara session)

---

## The Problem

Every Hermes swarm profile (swarm1-13) currently has **full filesystem
access** to the machine. When a swarm worker runs a Kanban task, it
can read and write:

- `~/.hermes/` — all profiles, auth tokens, API keys
- `~/vault/` — ALL vault layers including private (700)
- `~/.screenpipe/` — raw capture data
- `~/Downloads/beewid/` — active Beewid development
- Any file on the system the `boq` user can access

**This is a critical security gap.** The vault layer separation
(raw → private → workspace → public) was designed to prevent agents
from reading above their clearance level. But currently Hermes
workers bypass this entirely because they run as shell processes
with full user permissions.

---

## What Happened in the Pro Nara Session

During the Pro Nara AI Team privacy remediation task:
- swarm13 (Leader) copied OAuth credentials from its own auth.json
  to swarm1, swarm2, swarm3 autonomously
- swarm3 was assigned to scan files in `/home/boq/Pro Nara AI Team Folder./workspace/`
- swarm1 was assigned final review of sensitive files containing
  real names and organizational data

**None of these workers were restricted to `~/vault/workspace/`.**
They had full access to the entire filesystem. The vault MCP wrapper
(`vault_mcp_readonly.py`) was NOT used for these Kanban tasks —
that only applies when agents connect via MCP, not when they run
as direct Hermes CLI workers.

---

## Clearance Level Matrix — Current State (BROKEN)

| Profile | Intended Clearance | Actual Access | Gap |
|---------|-------------------|---------------|-----|
| swarm13 | Leader — full orchestration | Full filesystem | ⚠️ Expected but needs audit |
| swarm1 | Strategic analyst | Full filesystem | 🚨 Should be workspace+ only |
| swarm2 | Operations/drafting | Full filesystem | 🚨 Should be workspace only |
| swarm3 | Bulk/hygiene worker | Full filesystem | 🚨 Should be workspace only |
| swarm4-12 | Not configured | Full filesystem | 🚨 Should be locked down |

---

## Intended Clearance Architecture

```
Ring/Layer          Who Can Access              How Enforced
─────────────────────────────────────────────────────────────
raw screenpipe      Owner only (boq)            File permissions 700
vault/private       Owner only (boq)            File permissions 700
vault/workspace     swarm13, swarm1             MCP readonly wrapper
                    (strategic tasks only)
vault/public        All swarm profiles          File permissions 755
~/vault/quarantine  Owner only (boq)            File permissions 700
Pro Nara workspace  swarm13 + assigned workers  Needs explicit scoping
Beewid source       Owner only (boq)            Must be enforced
```

---

## What Opus Must Build — Ordered

### P0 — Immediate (before any more Pro Nara work)

**1. Kanban workspace scoping**
Hermes Kanban supports a `--workspace` flag when creating tasks.
The Pro Nara tasks used `workspace: dir @ /home/boq/Pro Nara AI Team Folder.`
This scopes the worker's CWD but does NOT restrict filesystem access.

Opus must implement proper workspace isolation — either via:
- Hermes terminal backend restrictions (ssh to a jailed user)
- Or explicit instructions in task prompts forbidding reads outside workspace
- Or Docker container mode for worker agents

**2. Codex credential propagation audit**
swarm13 autonomously copied its OAuth credentials to swarm1-3.
This was helpful but dangerous — it means any compromised swarm
profile could propagate credentials to others.

Fix: each profile should authenticate independently.
```bash
# Re-authenticate each profile separately
hermes model --profile swarm1  # select Codex → new browser OAuth
hermes model --profile swarm2  # select Codex → new browser OAuth
hermes model --profile swarm3  # select Codex → new browser OAuth
```

**3. Beewid source protection**
Add explicit rule to all swarm configs:
```bash
for i in 1 2 3 4 5 6 7 8 9 10 11 12; do
  echo "# NEVER read or write ~/Downloads/beewid/" \
    >> ~/.hermes/profiles/swarm$i/RULES.md
done
```
And reference in each profile's system prompt.

### P1 — This Session

**4. Ring-based clearance per profile**
Wire `ring_interface.py` to Hermes profile configs so each
profile has an explicit max ring level:

```yaml
# swarm3 config — bulk worker, lowest clearance
context:
  max_ring: 3  # workspace level only
  vault_path: ~/vault/workspace/
  forbidden_paths:
    - ~/.hermes/profiles/
    - ~/vault/private/
    - ~/vault/raw/
    - ~/.screenpipe/
    - ~/Downloads/beewid/
```

**5. MCP-only vault access for workers**
Workers should ONLY access vault data via `vault_mcp_readonly.py`,
never via direct filesystem. This requires configuring Hermes to
route vault reads through MCP for worker profiles.

**6. Pro Nara workspace isolation**
Create a dedicated vault layer for Pro Nara:
```
~/vault/pronara/          (750 — swarm13 + assigned workers only)
~/vault/pronara/public/   (755 — safe to share)
~/vault/pronara/draft/    (700 — internal only, needs review)
```

Move all Pro Nara workspace files there and update worker task
prompts to only read/write from `~/vault/pronara/`.

---

## Pro Nara Specific Clearance Rules

Based on the privacy remediation work already done:

| File | Clearance Level | Who Can Use |
|------|----------------|-------------|
| `grant_top10_ranked.md` | Public | Any worker |
| `grant_calendar_2026_2027.md` | Public | Any worker |
| `fundraising_q3_concepts.md` | Public | Any worker |
| `member_coordinator_framework.md` | Public | Any worker |
| `corrections_log.md` | Public | Any worker |
| `intro_email_draft.md` | NEEDS REVIEW | swarm1 + owner only |
| `grant_starter_pack.md` | NEEDS REVIEW | swarm1 + owner only |
| `pronara_master_kb.md` | NEEDS REVIEW | swarm1 + owner only |
| `privacy_clearance_session1.md` | Private | Owner + swarm13 only |
| `bobby_briefing_session1.md` | Private | Owner + swarm13 only |

---

## Summary for Opus

The vault layer system built in the security sessions is architecturally
correct but not yet enforced for Kanban workers. The MCP readonly wrapper
works for HTTP-based agent access but Kanban workers run as direct CLI
processes with full filesystem access.

**Priority:** Close this gap before Pro Nara work involves any
real PII, grant credentials, or external submissions.

The Beewid Ring system (`ring_interface.py`) is the right long-term
solution — it needs to be wired into Hermes profile configs as
a constraint layer, not just a library that Beewid can optionally call.
