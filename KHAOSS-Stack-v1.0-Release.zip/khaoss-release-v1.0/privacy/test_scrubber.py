"""
Tests for scrubber.py — at least 10 cases covering all PII categories and levels.
"""

import re
import sys
import tempfile
import unittest
from pathlib import Path

sys.path.insert(0, str(Path(__file__).parent))

import scrubber
from scrubber import Level, scrub, process, process_file


class TestAPIKeys(unittest.TestCase):
    def test_sk_prefix_redacted(self):
        text = "Use key sk-abcdefghij1234567890 for auth"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("sk-abcdefghij", result)
        self.assertIn("[REDACTED_API_KEY]", result)

    def test_bearer_token_redacted(self):
        text = "Authorization: Bearer eyJhbGciOiJSUzI1NiIsInR5cCI6IkpXVCJ9"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("eyJhbGciOi", result)
        self.assertIn("[REDACTED_API_KEY]", result)

    def test_anthropic_env_var_redacted(self):
        text = "ANTHROPIC_API_KEY=sk-ant-abcdefghijklmnop"
        result = scrub(text, Level.PRIVATE)
        self.assertIn("[REDACTED_API_KEY]", result)
        self.assertNotIn("sk-ant-abc", result)

    def test_openai_env_var_redacted(self):
        text = "OPENAI_API_KEY='sk-openai-testkey12345678'"
        result = scrub(text, Level.PRIVATE)
        self.assertIn("[REDACTED_API_KEY]", result)

    def test_aws_access_key_redacted(self):
        text = "AWS key: AKIAIOSFODNN7EXAMPLE"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("AKIAIOSFODNN7EXAMPLE", result)
        self.assertIn("[REDACTED_API_KEY]", result)


class TestPasswords(unittest.TestCase):
    def test_password_equals_redacted(self):
        text = "password=mysecretpassword123"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("mysecretpassword123", result)
        self.assertIn("[REDACTED_PASSWORD]", result)

    def test_login_colon_redacted(self):
        text = "login: admin, auth=superSecretPass!"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("superSecretPass!", result)
        self.assertIn("[REDACTED_PASSWORD]", result)


class TestEmails(unittest.TestCase):
    def test_email_redacted(self):
        text = "Contact us at support@example.com for help."
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("support@example.com", result)
        self.assertIn("[REDACTED_EMAIL]", result)

    def test_email_raw_unchanged(self):
        text = "Contact us at support@example.com for help."
        result = scrub(text, Level.RAW)
        self.assertEqual(result, text)

    def test_multiple_emails(self):
        text = "From: alice@foo.com To: bob@bar.org"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("alice@foo.com", result)
        self.assertNotIn("bob@bar.org", result)
        self.assertEqual(result.count("[REDACTED_EMAIL]"), 2)


class TestPhones(unittest.TestCase):
    def test_us_phone_redacted(self):
        text = "Call us at (555) 867-5309"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("867-5309", result)
        self.assertIn("[REDACTED_PHONE]", result)

    def test_international_phone_redacted(self):
        text = "Reach the London office at +44 20 7946 0958"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("7946 0958", result)
        self.assertIn("[REDACTED_PHONE]", result)

    def test_dotted_phone_redacted(self):
        text = "Mobile: 555.123.4567"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("555.123.4567", result)
        self.assertIn("[REDACTED_PHONE]", result)


class TestSSN(unittest.TestCase):
    def test_ssn_with_dashes_redacted(self):
        text = "SSN: 123-45-6789"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("123-45-6789", result)
        self.assertIn("[REDACTED_SSN]", result)

    def test_ssn_no_separator_redacted(self):
        text = "Social: 123456789"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("123456789", result)


class TestCreditCards(unittest.TestCase):
    def test_visa_luhn_redacted(self):
        # Valid Luhn: 4532015112830366
        text = "Card: 4532015112830366"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("4532015112830366", result)
        self.assertIn("[REDACTED_CC]", result)

    def test_mastercard_with_spaces_redacted(self):
        # Valid Luhn: 5425233430109903
        text = "Payment: 5425 2334 3010 9903"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("5425 2334", result)
        self.assertIn("[REDACTED_CC]", result)

    def test_non_luhn_not_redacted(self):
        # Random digits that fail Luhn
        text = "ID: 1234567890123456"
        result = scrub(text, Level.PRIVATE)
        # Should not be replaced as CC since it fails Luhn
        self.assertNotIn("[REDACTED_CC]", result)


class TestIPAddresses(unittest.TestCase):
    def test_ip_redacted(self):
        text = "Server at 192.168.1.100"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("192.168.1.100", result)
        self.assertIn("[REDACTED_IP]", result)

    def test_allowed_ip_preserved(self):
        text = "Loopback: 127.0.0.1"
        result = scrub(text, Level.PRIVATE, config={"allowed_ips": ["127.0.0.1"]})
        self.assertIn("127.0.0.1", result)
        self.assertNotIn("[REDACTED_IP]", result)

    def test_multiple_ips(self):
        text = "From 10.0.0.1 to 10.0.0.2"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("10.0.0.1", result)
        self.assertNotIn("10.0.0.2", result)


class TestFilePaths(unittest.TestCase):
    def test_home_path_redacted(self):
        text = "Config at /home/boq/.config/app/settings.yaml"
        result = scrub(text, Level.PRIVATE, config={"username": "boq"})
        self.assertNotIn("/home/boq/", result)
        self.assertIn("[REDACTED_PATH]", result)

    def test_macos_users_path_redacted(self):
        text = "File: /Users/boq/Documents/secret.pdf"
        result = scrub(text, Level.PRIVATE, config={"username": "boq"})
        self.assertNotIn("/Users/boq/", result)
        self.assertIn("[REDACTED_PATH]", result)


class TestURLTokens(unittest.TestCase):
    def test_url_with_api_key_param_redacted(self):
        text = "GET https://api.example.com/v1/data?api_key=abc123secret&format=json"
        result = scrub(text, Level.PRIVATE)
        self.assertNotIn("abc123secret", result)
        self.assertIn("[REDACTED_PARAMS]", result)

    def test_url_without_sensitive_params_preserved(self):
        text = "See https://example.com/page?foo=bar&baz=qux"
        result = scrub(text, Level.PRIVATE)
        # No token params → URL should not be mangled
        self.assertIn("foo=bar", result)


class TestHostnames(unittest.TestCase):
    def test_internal_hostname_redacted_at_workspace(self):
        text = "Connect to db.internal.company.com for queries"
        result = scrub(text, Level.WORKSPACE)
        self.assertNotIn("db.internal.company.com", result)
        self.assertIn("[REDACTED_HOST]", result)

    def test_hostname_preserved_at_private(self):
        text = "Connect to db.internal.company.com"
        result = scrub(text, Level.PRIVATE)
        # Hostnames are not redacted at private level
        self.assertIn("db.internal.company.com", result)

    def test_allowed_hostname_preserved(self):
        text = "Use api.allowed-partner.io for calls"
        result = scrub(
            text, Level.WORKSPACE,
            config={"allowed_hostnames": ["api.allowed-partner.io"]}
        )
        self.assertIn("api.allowed-partner.io", result)


class TestPublicLevel(unittest.TestCase):
    def test_financial_figure_redacted(self):
        text = "Revenue reached $4,500,000 last quarter."
        result = scrub(text, Level.PUBLIC)
        self.assertNotIn("$4,500,000", result)
        self.assertIn("[REDACTED_FINANCIAL]", result)

    def test_medical_term_redacted(self):
        text = "Patient received a prescription for hypertension."
        result = scrub(text, Level.PUBLIC)
        self.assertNotIn("prescription", result)
        self.assertIn("[REDACTED_MEDICAL]", result)

    def test_proper_nouns_redacted(self):
        text = "Alice Johnson submitted the report yesterday."
        result = scrub(text, Level.PUBLIC)
        self.assertNotIn("Alice Johnson", result)

    def test_zip_code_redacted(self):
        text = "Located in 94103 San Francisco."
        result = scrub(text, Level.PUBLIC)
        self.assertNotIn("94103", result)
        self.assertIn("[REDACTED_ZIP]", result)

    def test_public_also_covers_private_rules(self):
        text = "Email: ceo@corp.com, SSN 111-22-3333"
        result = scrub(text, Level.PUBLIC)
        self.assertNotIn("ceo@corp.com", result)
        self.assertNotIn("111-22-3333", result)


class TestMetadataHeader(unittest.TestCase):
    def test_header_present(self):
        result = process("Hello world", Level.PRIVATE)
        self.assertTrue(result.startswith("---\n"))
        self.assertIn("scrub_level: private", result)
        self.assertIn("scrub_date:", result)
        self.assertIn("source_hash:", result)
        self.assertIn("ai_processed: false", result)

    def test_source_hash_is_sha256(self):
        import hashlib
        text = "test content"
        result = process(text, Level.PRIVATE)
        expected_hash = hashlib.sha256(text.encode()).hexdigest()
        self.assertIn(expected_hash, result)

    def test_raw_level_has_header_unchanged_body(self):
        text = "password=secret123"
        result = process(text, Level.RAW)
        self.assertIn("scrub_level: raw", result)
        # Body unchanged
        self.assertIn("password=secret123", result)

    def test_workspace_level_in_header(self):
        result = process("hello", Level.WORKSPACE)
        self.assertIn("scrub_level: workspace", result)

    def test_public_level_in_header(self):
        result = process("hello", Level.PUBLIC)
        self.assertIn("scrub_level: public", result)


class TestProcessFile(unittest.TestCase):
    def test_file_roundtrip(self):
        text = "Token: sk-testkey1234567890, email: user@example.com"
        with tempfile.TemporaryDirectory() as d:
            inp = Path(d) / "input.txt"
            out = Path(d) / "output.txt"
            inp.write_text(text)
            process_file(inp, out, Level.PRIVATE)
            result = out.read_text()
        self.assertIn("[REDACTED_API_KEY]", result)
        self.assertIn("[REDACTED_EMAIL]", result)
        self.assertIn("scrub_level: private", result)

    def test_output_to_directory(self):
        text = "ip: 192.168.0.1"
        with tempfile.TemporaryDirectory() as d:
            inp = Path(d) / "data.txt"
            inp.write_text(text)
            process_file(inp, Path(d) / "data.txt", Level.WORKSPACE)
            result = (Path(d) / "data.txt").read_text()
        self.assertIn("[REDACTED_IP]", result)


class TestLevelEnum(unittest.TestCase):
    def test_accepts_string_level(self):
        result = scrub("email: foo@bar.com", "private")
        self.assertIn("[REDACTED_EMAIL]", result)

    def test_invalid_level_raises(self):
        with self.assertRaises(ValueError):
            scrub("text", "ultra")


class TestConfigOverride(unittest.TestCase):
    def test_custom_username_in_path(self):
        text = "See /home/alice/notes.txt for details"
        result = scrub(text, Level.PRIVATE, config={"username": "alice"})
        self.assertIn("[REDACTED_PATH]", result)
        self.assertNotIn("/home/alice/", result)

    def test_empty_username_skips_path_scrub(self):
        text = "See /home/alice/notes.txt for details"
        # With no username configured, path should NOT be redacted
        result = scrub(text, Level.PRIVATE, config={"username": ""})
        self.assertIn("/home/alice/notes.txt", result)


# ---------------------------------------------------------------------------
# Ring interface tests — bridge between Beewid's Ring 0-4 system and scrubber
# ---------------------------------------------------------------------------

import ring_interface
from ring_interface import RING_LEVELS, RingConfig, RingFilter, to_scrubber_level


class TestRingInterface(unittest.TestCase):

    def test_ring_levels_dict_has_five_entries_with_expected_names(self):
        self.assertEqual(
            RING_LEVELS,
            {
                0: "current_turn",
                1: "session_vault",
                2: "project_vault",
                3: "global_vault",
                4: "history_rag",
            },
        )

    def test_ringconfig_defaults_are_privacy_first(self):
        cfg = RingConfig()
        self.assertEqual(cfg.rings_enabled, [0])
        self.assertTrue(cfg.privacy_mode)
        self.assertTrue(cfg.cloud_safe)
        self.assertEqual(cfg.vault_tags_filter, [])

    def test_to_scrubber_level_maps_each_ring(self):
        self.assertEqual(to_scrubber_level(0), Level.RAW)
        self.assertEqual(to_scrubber_level(1), Level.PRIVATE)
        self.assertEqual(to_scrubber_level(2), Level.PRIVATE)
        self.assertEqual(to_scrubber_level(3), Level.WORKSPACE)
        self.assertEqual(to_scrubber_level(4), Level.PUBLIC)

    def test_to_scrubber_level_from_config_uses_highest_enabled_ring(self):
        cfg = RingConfig(rings_enabled=[0, 2, 4], privacy_mode=False, cloud_safe=False)
        # max([0,2,4]) = 4 → PUBLIC
        self.assertEqual(to_scrubber_level(cfg), Level.PUBLIC)
        cfg2 = RingConfig(rings_enabled=[0, 1], privacy_mode=False, cloud_safe=False)
        self.assertEqual(to_scrubber_level(cfg2), Level.PRIVATE)

    def test_to_scrubber_level_empty_rings_defaults_to_public(self):
        # No rings enabled = unknown policy = defensive maximum stripping
        cfg = RingConfig(rings_enabled=[], privacy_mode=False, cloud_safe=False)
        self.assertEqual(to_scrubber_level(cfg), Level.PUBLIC)

    def test_filter_strips_above_ring0_when_privacy_and_cloudsafe(self):
        rf = RingFilter()
        cfg = RingConfig()  # defaults: privacy + cloud_safe
        # Content from any ring > 0 must be stripped to empty string
        for ring in (1, 2, 3, 4):
            self.assertEqual(rf.filter("anything", max_ring=ring, config=cfg), "",
                             msg=f"ring {ring} should be stripped")

    def test_filter_passes_ring0_when_privacy_and_cloudsafe(self):
        rf = RingFilter()
        cfg = RingConfig()
        # Ring 0 = current turn → passes through unmodified (RAW)
        out = rf.filter("hello sk-abc12345678", max_ring=0, config=cfg)
        self.assertEqual(out, "hello sk-abc12345678")

    def test_filter_cloud_unsafe_whitelist_passes_allowed_ring(self):
        rf = RingFilter()
        cfg = RingConfig(rings_enabled=[0, 2], privacy_mode=False, cloud_safe=False)
        # Ring 2 is on the whitelist → passes, scrubbed at PRIVATE
        out = rf.filter("call me at alice@x.com", max_ring=2, config=cfg)
        self.assertIn("[REDACTED_EMAIL]", out)
        self.assertNotIn("alice@x.com", out)

    def test_filter_cloud_unsafe_whitelist_blocks_disallowed_ring(self):
        rf = RingFilter()
        cfg = RingConfig(rings_enabled=[0, 2], privacy_mode=False, cloud_safe=False)
        # Ring 3 not on whitelist → stripped
        self.assertEqual(rf.filter("secret", max_ring=3, config=cfg), "")
        # Ring 4 not on whitelist → stripped
        self.assertEqual(rf.filter("history", max_ring=4, config=cfg), "")

    def test_filter_ring4_applies_public_level_scrubbing(self):
        rf = RingFilter()
        # cloud_safe=False so Ring 4 actually passes (gated by whitelist).
        # privacy_mode irrelevant when cloud_safe=False.
        cfg = RingConfig(rings_enabled=[4], privacy_mode=False, cloud_safe=False)
        # Public level strips emails AND medical terms AND proper nouns
        text = "Alice Johnson got a prescription, email bob@x.com"
        out = rf.filter(text, max_ring=4, config=cfg)
        self.assertNotIn("Alice Johnson", out)
        self.assertNotIn("prescription", out)
        self.assertNotIn("bob@x.com", out)


# ---------------------------------------------------------------------------
# New tests: OCR scrubbing and blocklist (scrubber v2)
# ---------------------------------------------------------------------------

import tempfile
from scrubber import scrub_ocr_text, load_blocklist, reload_blocklist, BLOCKLIST_PATH
from scrubber import is_in_excluded_zone, load_screen_zones


class TestOCRScrubbing(unittest.TestCase):
    def test_ocr_password_label_redacted(self):
        # Screenpipe OCR reads "Password    myS3cret!" from a form on screen
        text = "Password    myS3cret!"
        result = scrub_ocr_text(text, Level.PRIVATE)
        self.assertNotIn("myS3cret!", result)
        self.assertIn("[REDACTED", result)

    def test_session_token_phpsessid_redacted(self):
        text = "Cookie: PHPSESSID=abc123def456ghi789"
        result = scrub_ocr_text(text, Level.PRIVATE)
        self.assertNotIn("abc123def456ghi789", result)
        self.assertIn("[REDACTED_SESSION]", result)

    def test_cc_partial_midentry_redacted(self):
        # 8 digits in two groups — partial card entry, can't Luhn-validate yet
        text = "Card: 4532 0151 still typing..."
        result = scrub_ocr_text(text, Level.PRIVATE)
        self.assertNotIn("4532 0151", result)
        self.assertIn("[REDACTED_CC_PARTIAL]", result)

    def test_ocr_inherits_standard_patterns(self):
        # scrub_ocr_text must still redact emails (standard pattern)
        text = "Contact: user@example.com"
        result = scrub_ocr_text(text, Level.PRIVATE)
        self.assertNotIn("user@example.com", result)
        self.assertIn("[REDACTED_EMAIL]", result)


class TestBlocklist(unittest.TestCase):
    def test_blocklist_plain_word_redacted(self):
        with tempfile.NamedTemporaryFile(
            mode="w", suffix=".txt", delete=False, dir=str(BLOCKLIST_PATH.parent)
        ) as tmp:
            tmp.write("CompanySecret\n")
            tmp_path = tmp.name
        import scrubber as _sc
        orig_path = _sc.BLOCKLIST_PATH
        _sc.BLOCKLIST_PATH = Path(tmp_path)
        _sc.reload_blocklist()
        try:
            result = scrub("The password is CompanySecret123", Level.PRIVATE)
            self.assertIn("[REDACTED_BLOCKLIST]", result)
            self.assertNotIn("CompanySecret123", result)
        finally:
            _sc.BLOCKLIST_PATH = orig_path
            _sc.reload_blocklist()
            Path(tmp_path).unlink(missing_ok=True)


if __name__ == "__main__":
    unittest.main(verbosity=2)
