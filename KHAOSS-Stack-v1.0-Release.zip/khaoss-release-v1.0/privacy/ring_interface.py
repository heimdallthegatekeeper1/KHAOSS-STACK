"""
ring_interface.py — bridge between Beewid's Ring 0-4 context isolation system
and `scrubber.py`'s RAW/PRIVATE/WORKSPACE/PUBLIC levels.

The Ring system describes WHERE a piece of context lives (current turn,
session vault, project vault, global vault, history RAG). The scrubber's
levels describe HOW MUCH PII to strip. This module maps between the two so
callers can configure privacy policy in Ring terms and have the scrubber do
the right thing.

Pure stdlib + `scrubber.py`. No network, no AI.
"""

from __future__ import annotations

from dataclasses import dataclass, field
from typing import List, Optional, Union

import scrubber
from scrubber import Level, scrub


# ── Ring registry ────────────────────────────────────────────────────────────

RING_LEVELS: dict[int, str] = {
    0: "current_turn",
    1: "session_vault",
    2: "project_vault",
    3: "global_vault",
    4: "history_rag",
}

# Ring → scrubber Level mapping (per Beewid spec).
_RING_TO_LEVEL: dict[int, Level] = {
    0: Level.RAW,
    1: Level.PRIVATE,
    2: Level.PRIVATE,
    3: Level.WORKSPACE,
    4: Level.PUBLIC,
}


# ── Config dataclass ─────────────────────────────────────────────────────────

@dataclass
class RingConfig:
    """
    Policy describing which rings may pass through the filter and how strictly
    they must be scrubbed.

    Attributes
    ----------
    rings_enabled
        Whitelist of ring IDs that may pass when ``cloud_safe`` is False.
        Defaults to [0] (only the current turn).
    privacy_mode
        When True together with ``cloud_safe``, only Ring 0 content passes.
    cloud_safe
        When True the policy is "exporting to a cloud model"; combine with
        ``privacy_mode`` to enforce maximum lockdown.
    vault_tags_filter
        Optional vault-tag whitelist. Stored as metadata; downstream code may
        consult it to gate content that carries Beewid vault tags.
    """
    rings_enabled: List[int] = field(default_factory=lambda: [0])
    privacy_mode: bool = True
    cloud_safe: bool = True
    vault_tags_filter: List[str] = field(default_factory=list)


# ── Ring → scrubber level ────────────────────────────────────────────────────

def to_scrubber_level(ring_config: Union["RingConfig", int]) -> Level:
    """
    Map a RingConfig (or a single ring id) to the scrubber Level that should
    be applied to its highest enabled ring.

    For an ``int``: return the level mapped to that ring.
    For a ``RingConfig``: return the level for ``max(rings_enabled)``. If
    ``rings_enabled`` is empty, return :data:`Level.PUBLIC` defensively (most
    stripping).
    """
    if isinstance(ring_config, RingConfig):
        if not ring_config.rings_enabled:
            return Level.PUBLIC
        highest = max(ring_config.rings_enabled)
        if highest not in _RING_TO_LEVEL:
            raise ValueError(f"unknown ring id in rings_enabled: {highest}")
        return _RING_TO_LEVEL[highest]

    if isinstance(ring_config, int):
        if ring_config not in _RING_TO_LEVEL:
            raise ValueError(f"unknown ring id: {ring_config}")
        return _RING_TO_LEVEL[ring_config]

    raise TypeError(
        f"to_scrubber_level expected RingConfig or int, got {type(ring_config).__name__}"
    )


# ── Filter ───────────────────────────────────────────────────────────────────

class RingFilter:
    """
    Strip or scrub content based on its ring of origin.

    Usage::

        rf = RingFilter()
        safe_text = rf.filter(raw_text, max_ring=2, config=RingConfig(...))

    ``max_ring`` is the ring the content comes from. If the active policy
    forbids that ring, the filter returns an empty string. Otherwise the
    content is scrubbed at the level mapped to that ring.
    """

    def filter(
        self,
        content: str,
        max_ring: int,
        config: Optional[RingConfig] = None,
    ) -> str:
        if not isinstance(content, str):
            raise TypeError(f"content must be str, got {type(content).__name__}")
        if max_ring not in RING_LEVELS:
            raise ValueError(f"max_ring must be in {sorted(RING_LEVELS)}, got {max_ring}")

        cfg = config if config is not None else RingConfig()

        # Maximum lockdown: cloud-safe + privacy mode — only Ring 0 passes.
        # Higher rings are stripped entirely (return empty string).
        if cfg.privacy_mode and cfg.cloud_safe:
            if max_ring > 0:
                return ""
            # Ring 0 content (current turn) passes unmodified — its mapped
            # scrubber Level is RAW, which is a no-op.
            return content

        # Cloud-unsafe mode: rings_enabled is the gate. A ring not on the
        # whitelist is stripped; allowed rings are scrubbed at their mapped
        # level so downstream consumers still don't see raw secrets.
        if not cfg.cloud_safe:
            if max_ring not in cfg.rings_enabled:
                return ""

        # Default path: scrub at the level matched to this ring.
        return scrub(content, _RING_TO_LEVEL[max_ring])
