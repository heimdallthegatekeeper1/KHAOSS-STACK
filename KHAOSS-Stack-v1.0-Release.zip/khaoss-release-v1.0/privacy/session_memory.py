#!/usr/bin/env python3
"""
session_memory.py — Tier-2 daily-session synthesizer.

Run once. Pulls together:
  • files modified in ~/vault/workspace/ in the last 8 hours
  • the last 20 entries from screen_assistant.log
  • the last 50 lines from watcher.log

…then asks Hermes (profile swarm13) to synthesize a session note. The
Markdown reply is written to ~/obsidian-vault/session_YYYY-MM-DD.md. If
the file already exists (e.g. you ran it twice in one day) the new
synthesis is appended under a fresh "## run @ HH:MM:SS UTC" header.

Why this script writes the file (instead of asking Hermes to write it)
----------------------------------------------------------------------
`hermes -z` is non-interactive and the swarm13 profile's tool set
varies; relying on it to do a filesystem write would couple our
robustness to which tools happen to be wired up today. Doing the write
in Python keeps the script honest: if Hermes returns markdown, the file
appears, period.

Exit codes
----------
  0   wrote (or appended to) the session file
  1   Hermes returned an empty / unusable reply
  2   Hermes call failed (timeout, non-zero exit, missing binary)
  3   nothing to synthesize (no recent activity at all)
"""

from __future__ import annotations

import json
import os
import subprocess
import sys
import time
from datetime import datetime, timedelta, timezone
from pathlib import Path

HOME             = Path(os.path.expanduser("~"))
WORKSPACE        = HOME / "vault" / "workspace"
SA_LOG           = HOME / "beewid-privacy" / "screen_assistant.log"
WATCHER_LOG      = HOME / "beewid-privacy" / "watcher.log"
OBSIDIAN_VAULT   = HOME / "obsidian-vault"

HERMES_BIN       = "hermes"
HERMES_PROFILE   = "swarm13"
HERMES_TIMEOUT   = 120.0     # synthesis is bigger than a single-suggestion prompt

LOOKBACK_HOURS   = 8
SA_TAIL          = 20
WATCHER_TAIL     = 50
MAX_FILE_BYTES   = 1500      # snippet per file included in the prompt

EXCLUDE_PREFIXES = [
    str(HOME / "Downloads" / "beewid" / "vault"),
    str(HOME / "vault" / "quarantine"),
]

# ── data collection ─────────────────────────────────────────────────────────

def _is_excluded(path: Path) -> bool:
    try:
        resolved = str(path.resolve())
    except OSError:
        resolved = str(path)
    return any(resolved.startswith(pfx) for pfx in EXCLUDE_PREFIXES)

def recent_workspace_files(hours: int) -> list[Path]:
    if not WORKSPACE.is_dir():
        return []
    cutoff = time.time() - hours * 3600
    out: list[tuple[float, Path]] = []
    for p in WORKSPACE.iterdir():
        if not p.is_file() or _is_excluded(p):
            continue
        try:
            m = p.stat().st_mtime
        except OSError:
            continue
        if m >= cutoff:
            out.append((m, p))
    out.sort(reverse=True)
    return [p for _, p in out]

def file_snippet(path: Path) -> str:
    try:
        with path.open("rb") as fh:
            blob = fh.read(MAX_FILE_BYTES)
        text = blob.decode("utf-8", errors="replace").strip()
    except OSError as exc:
        return f"<unreadable: {exc}>"
    return text or "<empty>"

def tail_log(path: Path, n: int) -> list[str]:
    if not path.is_file():
        return []
    try:
        with path.open("r", encoding="utf-8", errors="replace") as fh:
            return [ln.rstrip("\n") for ln in fh.readlines()[-n:]]
    except OSError:
        return []

def recent_suggestions(n: int) -> list[dict]:
    # screen_assistant writes JSON lines; tolerate non-JSON entries
    # (older format / startup chatter) by skipping them quietly.
    out: list[dict] = []
    for raw in tail_log(SA_LOG, max(n * 3, 60)):  # over-fetch in case of noise
        raw = raw.strip()
        if not raw:
            continue
        try:
            obj = json.loads(raw)
            if isinstance(obj, dict) and "suggestion" in obj:
                out.append(obj)
        except Exception:
            continue
    return out[-n:]

# ── prompt building ─────────────────────────────────────────────────────────

def build_prompt(files: list[Path], suggestions: list[dict], watcher: list[str], target_md: Path) -> str:
    file_section = []
    for p in files[:12]:  # cap so the prompt doesn't explode
        try:
            stamp = datetime.fromtimestamp(p.stat().st_mtime, tz=timezone.utc).strftime("%H:%M:%SZ")
        except OSError:
            stamp = "?"
        file_section.append(
            f"### {p.name}  (modified {stamp})\n"
            f"```\n{file_snippet(p)}\n```\n"
        )
    files_block = "\n".join(file_section) if file_section else "(none in the last 8 hours)"

    sugg_section = []
    for s in suggestions:
        ts = s.get("ts") or "?"
        src = (s.get("source_file") or "").split("/")[-1] or "?"
        sugg_section.append(f"- [{ts}] ({src}) {s.get('suggestion','').strip()}")
    sugg_block = "\n".join(sugg_section) if sugg_section else "(no screen-assistant suggestions)"

    watcher_block = "\n".join(watcher) if watcher else "(no watcher log entries)"

    today = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")

    return (
        f"Synthesize today's work session ({today}).\n\n"
        f"## Files modified in the last {LOOKBACK_HOURS}h\n{files_block}\n\n"
        f"## Recent screen-assistant suggestions (last {SA_TAIL})\n{sugg_block}\n\n"
        f"## Recent vault watcher entries (last {WATCHER_TAIL})\n{watcher_block}\n\n"
        "Write a Markdown session note (the body only — no preamble, no\n"
        "code fences around the whole thing) suitable for "
        f"`{target_md.name}` in an Obsidian vault. Include these sections,\n"
        "in this order, each as a `##` heading:\n"
        "  - Work summary (what was accomplished)\n"
        "  - Key decisions made\n"
        "  - Files created/modified\n"
        "  - Suggested next session starting point\n\n"
        "Keep the whole note under 500 words. Be specific — name actual\n"
        "files and concrete decisions, not vague themes. If the inputs above\n"
        "show nothing meaningful, say so plainly in one sentence under each\n"
        "heading rather than inventing activity."
    )

# ── hermes call ─────────────────────────────────────────────────────────────

def call_hermes(prompt: str) -> str:
    """Call hermes -z. Returns the stdout body; raises on hard failure."""
    proc = subprocess.run(
        [HERMES_BIN, "--profile", HERMES_PROFILE, "-z", prompt],
        capture_output=True, text=True, timeout=HERMES_TIMEOUT,
    )
    if proc.returncode != 0:
        raise RuntimeError(
            f"hermes exit {proc.returncode}: {proc.stderr.strip()[:500]}"
        )
    return proc.stdout.strip()

# ── output ──────────────────────────────────────────────────────────────────

def write_session_note(body: str) -> Path:
    OBSIDIAN_VAULT.mkdir(parents=True, exist_ok=True)
    today = datetime.now(tz=timezone.utc).strftime("%Y-%m-%d")
    now   = datetime.now(tz=timezone.utc).strftime("%H:%M:%S UTC")
    target = OBSIDIAN_VAULT / f"session_{today}.md"

    if target.exists():
        # Append under a fresh header so multiple runs in one day stack.
        with target.open("a", encoding="utf-8") as fh:
            fh.write(f"\n\n---\n\n## run @ {now}\n\n{body}\n")
    else:
        with target.open("w", encoding="utf-8") as fh:
            fh.write(f"# Session — {today}\n\n## run @ {now}\n\n{body}\n")
    return target

# ── main ────────────────────────────────────────────────────────────────────

def main() -> int:
    files       = recent_workspace_files(LOOKBACK_HOURS)
    suggestions = recent_suggestions(SA_TAIL)
    watcher     = tail_log(WATCHER_LOG, WATCHER_TAIL)

    if not files and not suggestions and not watcher:
        print("nothing to synthesize — no recent activity", file=sys.stderr)
        return 3

    prompt = build_prompt(files, suggestions, watcher, OBSIDIAN_VAULT / "session_PLACEHOLDER.md")

    try:
        body = call_hermes(prompt)
    except FileNotFoundError:
        print(f"error: {HERMES_BIN} not on PATH", file=sys.stderr)
        return 2
    except subprocess.TimeoutExpired:
        print(f"error: hermes timed out after {HERMES_TIMEOUT:.0f}s", file=sys.stderr)
        return 2
    except RuntimeError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 2

    if not body:
        print("error: hermes returned an empty reply", file=sys.stderr)
        return 1

    target = write_session_note(body)
    print(str(target))
    return 0


if __name__ == "__main__":
    sys.exit(main())
