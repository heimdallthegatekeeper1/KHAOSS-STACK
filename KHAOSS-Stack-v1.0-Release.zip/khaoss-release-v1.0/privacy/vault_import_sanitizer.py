#!/usr/bin/env python3
"""
vault_import_sanitizer.py — gate untrusted markdown imports for prompt injection.

Watches ~/obsidian-vault/ for new .md / .markdown / .txt files (OMI exports,
manual notes, anything else that lands in the vault from outside agents). On
each new file:

  1. Scan content for prompt-injection patterns.
  2. If any pattern matches → MOVE the file to ~/vault/quarantine/, append an
     entry to ~/beewid-privacy/security.log, and never let it reach
     ~/vault/workspace/.
  3. If clean → leave the file in place; downstream tooling (Obsidian, OMI
     pipelines) can pick it up.

Does NOT compete with vault_watcher.py — that one watches
~/.screenpipe/data/, a disjoint tree.

Pure stdlib + watchdog (already a dependency of vault_watcher.py).
"""

from __future__ import annotations

import logging
import os
import re
import shutil
import signal
import sys
import time
from datetime import datetime, timezone
from pathlib import Path
from typing import Iterable

from watchdog.events import FileSystemEventHandler
from watchdog.observers import Observer

# ── Paths ────────────────────────────────────────────────────────────────────

HOME = Path.home()
WATCH_DIR      = HOME / "obsidian-vault"
QUARANTINE_DIR = HOME / "vault" / "quarantine"
SECURITY_LOG   = HOME / "beewid-privacy" / "security.log"
PID_FILE       = HOME / "beewid-privacy" / "vault_import_sanitizer.pid"
RUNTIME_LOG    = HOME / "beewid-privacy" / "sanitizer.log"

WATCH_EXTENSIONS = {".md", ".markdown", ".txt"}
PROCESS_DEBOUNCE = 0.4  # seconds — let writer flush before we read

# ── Injection pattern library ────────────────────────────────────────────────
# Each entry is (short_name, compiled_regex). Names appear verbatim in the
# security log so an analyst can grep for incidents by pattern class.

INJECTION_PATTERNS: list[tuple[str, re.Pattern]] = [
    ("ignore_previous",
     re.compile(r"ignore\s+(?:all\s+|the\s+|your\s+|prior\s+|earlier\s+)?previous\s+instructions?", re.I)),
    ("disregard_forget",
     re.compile(r"\b(?:disregard|forget)\s+(?:your|the|all|previous|prior|above)\b", re.I)),
    ("new_instructions",
     re.compile(r"\bnew\s+(?:instructions?|system\s+prompt|rules?)\s*[:\-]", re.I)),
    ("role_hijack",
     re.compile(
         r"\b(?:you\s+are\s+now|act\s+as(?:\s+if)?|pretend\s+(?:to\s+be|you(?:'re|\s+are))"
         r"|roleplay\s+as|simulate\s+(?:being|a))\b",
         re.I,
     )),
    ("inst_tag",
     re.compile(r"\[\s*/?INST\s*\]", re.I)),
    ("system_tag",
     re.compile(r"<\s*\|?\s*/?\s*system\s*\|?\s*>", re.I)),
    ("chatml_system",
     re.compile(r"<\|im_start\|>\s*system\b", re.I)),
    # Base-64-looking blocks: either ≥2 consecutive 60+ char lines of
    # base64 alphabet, OR a single contiguous run ≥200 chars.
    ("base64_multiline",
     re.compile(r"(?:[A-Za-z0-9+/]{60,}={0,2}\s*\n){2,}")),
    ("base64_long_run",
     re.compile(r"(?<![A-Za-z0-9+/])[A-Za-z0-9+/]{200,}={0,2}(?![A-Za-z0-9+/])")),
]

# ── Logging ──────────────────────────────────────────────────────────────────

logger = logging.getLogger("vault_import_sanitizer")

def _setup_logging(foreground: bool) -> None:
    logger.setLevel(logging.INFO)
    fmt = logging.Formatter(
        "%(asctime)s %(levelname)-5s %(message)s",
        datefmt="%Y-%m-%dT%H:%M:%S",
    )
    fh = logging.FileHandler(RUNTIME_LOG, mode="a", encoding="utf-8")
    fh.setFormatter(fmt)
    logger.addHandler(fh)
    if foreground:
        sh = logging.StreamHandler(sys.stderr)
        sh.setFormatter(fmt)
        logger.addHandler(sh)

# ── PID management ───────────────────────────────────────────────────────────

def _read_pid() -> int | None:
    try:
        raw = PID_FILE.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0); return True
    except (OSError, ProcessLookupError):
        return False

def _write_pid_file() -> None:
    existing = _read_pid()
    if existing and _alive(existing):
        print(f"vault_import_sanitizer already running (PID {existing})", flush=True)
        sys.exit(0)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n", encoding="utf-8")

def _remove_pid_file() -> None:
    try:
        if PID_FILE.exists() and _read_pid() == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── Scanning ─────────────────────────────────────────────────────────────────

def scan(text: str) -> list[tuple[str, str]]:
    """Return list of (pattern_name, matched_excerpt_<=80_chars) for every hit."""
    hits: list[tuple[str, str]] = []
    for name, pat in INJECTION_PATTERNS:
        m = pat.search(text)
        if m:
            excerpt = m.group(0).replace("\n", " ")[:80]
            hits.append((name, excerpt))
    return hits

# ── Security log ─────────────────────────────────────────────────────────────

def _append_security_log(event: str, original: Path, dest: Path | None, hits: Iterable[tuple[str, str]]) -> None:
    ts = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%S.%fZ")
    patterns = "; ".join(f"{n}={excerpt!r}" for n, excerpt in hits) or "-"
    dest_str = str(dest) if dest else "-"
    line = f"{ts}\t{event}\t{original}\t→ {dest_str}\tpatterns: {patterns}\n"
    try:
        SECURITY_LOG.parent.mkdir(parents=True, exist_ok=True)
        with SECURITY_LOG.open("a", encoding="utf-8") as fh:
            fh.write(line)
    except OSError as exc:
        logger.error("could not write security.log: %s", exc)

# ── Handler ──────────────────────────────────────────────────────────────────

class SanitizerHandler(FileSystemEventHandler):
    def __init__(self) -> None:
        self._seen: set[str] = set()  # dedup repeated events on the same path

    def on_created(self, event):
        if event.is_directory:
            return
        self._enqueue(Path(event.src_path))

    def on_moved(self, event):
        if event.is_directory:
            return
        self._enqueue(Path(event.dest_path))

    def _enqueue(self, path: Path) -> None:
        if path.suffix.lower() not in WATCH_EXTENSIONS:
            return
        key = str(path)
        if key in self._seen:
            return
        self._seen.add(key)
        # let the writer finish flushing
        time.sleep(PROCESS_DEBOUNCE)
        if not path.exists():
            logger.info("vanished before scan: %s", path)
            return
        self._inspect(path)

    def _inspect(self, path: Path) -> None:
        try:
            text = path.read_text(encoding="utf-8", errors="replace")
        except OSError as exc:
            logger.warning("cannot read %s: %s", path, exc)
            return

        hits = scan(text)
        if not hits:
            logger.info("clean: %s (%d bytes)", path.name, len(text))
            _append_security_log("CLEAN", path, path, hits)
            return

        QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)
        dest = QUARANTINE_DIR / path.name
        if dest.exists():
            stamp = datetime.now(timezone.utc).strftime("%Y%m%d_%H%M%S")
            dest = QUARANTINE_DIR / f"{path.stem}.{stamp}{path.suffix}"

        try:
            shutil.move(str(path), str(dest))
        except OSError as exc:
            logger.error("FAILED to quarantine %s: %s", path, exc)
            _append_security_log("QUARANTINE_FAIL", path, None, hits)
            return

        # Lock down the quarantined file so nothing reads it casually.
        try:
            os.chmod(dest, 0o600)
        except OSError:
            pass

        logger.warning(
            "QUARANTINED %s → %s | %d pattern(s): %s",
            path.name, dest, len(hits),
            ", ".join(n for n, _ in hits),
        )
        _append_security_log("QUARANTINE", path, dest, hits)


# ── Main loop ────────────────────────────────────────────────────────────────

_observer: Observer | None = None

def _shutdown(signum=None, _frame=None) -> None:
    logger.info("shutdown signal=%s received", signum)
    if _observer is not None:
        _observer.stop()
    _remove_pid_file()
    logger.info("vault_import_sanitizer stopped")
    sys.exit(0)

def main() -> int:
    import argparse
    ap = argparse.ArgumentParser(description="Vault import sanitizer — prompt-injection gate")
    ap.add_argument("--foreground", action="store_true", help="log to stderr, skip PID file")
    args = ap.parse_args()

    _setup_logging(foreground=args.foreground)

    if not args.foreground:
        _write_pid_file()

    WATCH_DIR.mkdir(parents=True, exist_ok=True)
    QUARANTINE_DIR.mkdir(parents=True, exist_ok=True)

    signal.signal(signal.SIGTERM, _shutdown)
    signal.signal(signal.SIGINT,  _shutdown)

    logger.info("vault_import_sanitizer started  PID=%d", os.getpid())
    logger.info("watching   : %s", WATCH_DIR)
    logger.info("quarantine : %s", QUARANTINE_DIR)
    logger.info("security log: %s", SECURITY_LOG)
    logger.info("patterns   : %d", len(INJECTION_PATTERNS))

    global _observer
    handler = SanitizerHandler()
    _observer = Observer()
    _observer.schedule(handler, str(WATCH_DIR), recursive=True)
    _observer.start()

    try:
        while True:
            time.sleep(2)
            if not _observer.is_alive():
                logger.error("observer thread died — restarting")
                _observer.stop()
                _observer = Observer()
                _observer.schedule(handler, str(WATCH_DIR), recursive=True)
                _observer.start()
    except Exception as exc:
        logger.error("fatal: %s", exc)
        _shutdown()
    return 0


if __name__ == "__main__":
    sys.exit(main())
