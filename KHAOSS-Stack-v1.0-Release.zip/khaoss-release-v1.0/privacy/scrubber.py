"""
Privacy scrubber module for Beewid.
Pure Python, no AI dependency, works offline.
"""

import re
import json
import hashlib
import argparse
import os
import sys
from datetime import datetime, timezone
from pathlib import Path
from enum import Enum
from typing import Optional


class Level(str, Enum):
    RAW = "raw"
    PRIVATE = "private"
    WORKSPACE = "workspace"
    PUBLIC = "public"


# ---------------------------------------------------------------------------
# Configuration
# ---------------------------------------------------------------------------

DEFAULT_CONFIG = {
    # IPs in this list are NOT redacted even at private/workspace level
    "allowed_ips": [],
    # Hostnames in this list are NOT redacted
    "allowed_hostnames": [],
    # Username to redact in paths (defaults to current user)
    "username": os.environ.get("USER", ""),
}


# ---------------------------------------------------------------------------
# Regex patterns
# ---------------------------------------------------------------------------

# API keys / tokens
_API_KEY_PATTERNS = [
    # Generic secret-key prefixes (min 8 chars after sk- to avoid false positives
    # while still catching short test/dev keys; real keys are 20-100+ chars)
    re.compile(r'\bsk-[A-Za-z0-9_\-]{8,}', re.IGNORECASE),
    re.compile(r'\bBearer\s+[A-Za-z0-9_\-\.]{10,}', re.IGNORECASE),
    # Anthropic
    re.compile(r'\bANTHROPIC_[A-Z_]*\s*[=:]\s*[\'\"]?[A-Za-z0-9_\-]{10,}[\'\"]?', re.IGNORECASE),
    # OpenAI
    re.compile(r'\bOPENAI_[A-Z_]*\s*[=:]\s*[\'\"]?[A-Za-z0-9_\-]{10,}[\'\"]?', re.IGNORECASE),
    # Generic API_KEY / TOKEN patterns
    re.compile(r'\b(?:api[_\-]?key|api[_\-]?token|access[_\-]?token|secret[_\-]?key)\s*[=:]\s*[\'\"]?[A-Za-z0-9_\-\.]{10,}[\'\"]?', re.IGNORECASE),
    # GitHub tokens
    re.compile(r'\bgh[ps]_[A-Za-z0-9]{36,}'),
    # AWS keys
    re.compile(r'\bAKIA[0-9A-Z]{16}\b'),
    re.compile(r'\b(?:aws[_\-]secret[_\-]access[_\-]key|aws[_\-]access[_\-]key[_\-]id)\s*[=:]\s*[\'\"]?[A-Za-z0-9/+=]{20,}[\'\"]?', re.IGNORECASE),
]

# Passwords
_PASSWORD_PATTERNS = [
    re.compile(r'(?:password|passwd|pass|pwd|login|auth)\s*[=:]\s*[\'\"]?([^\s\'\"&,;]{4,})[\'\"]?', re.IGNORECASE),
]

# Email addresses
_EMAIL_PATTERN = re.compile(
    r'\b[A-Za-z0-9._%+\-]+@[A-Za-z0-9.\-]+\.[A-Za-z]{2,}\b'
)

# Phone numbers (US and international)
_PHONE_PATTERN = re.compile(
    r'(?<!\d)(?:'
    r'\+?1?\s*[\(\-\.]?\s*\d{3}\s*[\)\-\.]?\s*\d{3}\s*[\-\.]\s*\d{4}'  # US: +1 (555) 555-5555
    r'|'
    r'\+[1-9]\d{1,3}[\s\-\.]?\d{1,4}[\s\-\.]?\d{1,4}[\s\-\.]?\d{1,9}'  # International: +44 20 7946 0958
    r')(?!\d)'
)

# SSN
_SSN_PATTERN = re.compile(r'\b\d{3}[-\s]?\d{2}[-\s]?\d{4}\b')

# Credit card numbers (Luhn-candidate patterns, 13-19 digits with optional separators)
_CC_PATTERN = re.compile(
    r'\b(?:\d[ \-]?){13,19}\b'
)

# OCR-specific: password field lines (label + whitespace + value, as seen on screen)
_OCR_PASSWORD_PATTERNS = [
    # "Password    myP@ss" style (label then whitespace then value)
    re.compile(r'(?:password|passphrase|pwd)\s{1,20}\S{4,}', re.IGNORECASE),
    # "secret: value" and "token: value" not already caught by _PASSWORD_PATTERNS
    re.compile(r'(?:passphrase|secret|token)\s*[=:]\s*[\'\"]?([^\s\'\"&,;]{4,})[\'\"]?', re.IGNORECASE),
]

# Session token patterns (OCR from browser dev tools / headers visible on screen)
_SESSION_TOKEN_PATTERNS = [
    re.compile(r'\bPHPSESSID\s*=\s*[A-Za-z0-9]{10,}', re.IGNORECASE),
    re.compile(r'\bsessionid\s*=\s*[A-Za-z0-9_\-]{10,}', re.IGNORECASE),
    re.compile(r'\bauth_token\s*=\s*[A-Za-z0-9_\-\.]{10,}', re.IGNORECASE),
    re.compile(r'\bX-Auth-Token\s*:\s*[A-Za-z0-9_\-\.]{10,}', re.IGNORECASE),
]

# Credit card mid-entry: 2-4 groups of 4 digits separated by spaces/dashes
# (catches partial entry like "4532 0151 128" before the number is complete)
_CC_MIDENTRY_PATTERN = re.compile(r'\b\d{4}[ \-]\d{4}(?:[ \-]\d{1,4}){0,2}\b')

# IP addresses
_IP_PATTERN = re.compile(
    r'\b(?:(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\.){3}(?:25[0-5]|2[0-4]\d|[01]?\d\d?)\b'
)

# File paths containing usernames
def _build_path_pattern(username: str) -> Optional[re.Pattern]:
    if not username:
        return None
    escaped = re.escape(username)
    return re.compile(
        r'(?:/home/' + escaped + r'|/Users/' + escaped + r')[^\s\'\"]*',
        re.IGNORECASE
    )

# ---------------------------------------------------------------------------
# Blocklist (user-configurable, ~/beewid-privacy/blocklist.txt)
# ---------------------------------------------------------------------------

BLOCKLIST_PATH = Path.home() / "beewid-privacy" / "blocklist.txt"


def load_blocklist() -> list[re.Pattern]:
    """Load ~/beewid-privacy/blocklist.txt and return compiled patterns.

    File format — one entry per line:
      plain word     → case-insensitive literal match
      regex:<expr>   → compiled as-is
      # comment      → ignored
    """
    if not BLOCKLIST_PATH.exists():
        return []
    patterns: list[re.Pattern] = []
    for raw in BLOCKLIST_PATH.read_text(encoding="utf-8").splitlines():
        line = raw.strip()
        if not line or line.startswith("#"):
            continue
        if line.lower().startswith("regex:"):
            expr = line[6:]
            try:
                patterns.append(re.compile(expr))
            except re.error:
                pass  # silently skip invalid regex
        else:
            patterns.append(re.compile(re.escape(line), re.IGNORECASE))
    return patterns


_BLOCKLIST_PATTERNS: list[re.Pattern] = load_blocklist()


def reload_blocklist() -> None:
    """Refresh the in-memory blocklist from disk. Call after editing the file."""
    global _BLOCKLIST_PATTERNS
    _BLOCKLIST_PATTERNS = load_blocklist()


# ---------------------------------------------------------------------------
# Screen zones exclusion (~/beewid-privacy/screen_zones.json)
# ---------------------------------------------------------------------------

SCREEN_ZONES_PATH = Path.home() / "beewid-privacy" / "screen_zones.json"

_DEFAULT_ZONES: dict = {
    "excluded_zones": [
        {"name": "password manager", "x": 0, "y": 0, "w": 400, "h": 100},
        {"name": "private chat", "x": 0, "y": 800, "w": 600, "h": 200},
    ],
    "enabled": False,
}


def load_screen_zones() -> dict:
    """Load screen_zones.json. Returns default (zones disabled) if missing."""
    if not SCREEN_ZONES_PATH.exists():
        return _DEFAULT_ZONES
    try:
        data = json.loads(SCREEN_ZONES_PATH.read_text(encoding="utf-8"))
        if "excluded_zones" not in data:
            data["excluded_zones"] = []
        if "enabled" not in data:
            data["enabled"] = False
        return data
    except (json.JSONDecodeError, OSError):
        return _DEFAULT_ZONES


def is_in_excluded_zone(x: int, y: int, w: int, h: int) -> bool:
    """Return True if the rectangle (x,y,w,h) overlaps any enabled excluded zone."""
    zones = load_screen_zones()
    if not zones.get("enabled", False):
        return False
    for zone in zones.get("excluded_zones", []):
        zx, zy = zone.get("x", 0), zone.get("y", 0)
        zw, zh = zone.get("w", 0), zone.get("h", 0)
        # Rectangle overlap check
        if x < zx + zw and x + w > zx and y < zy + zh and y + h > zy:
            return True
    return False


# URLs with tokens/keys in query params
_URL_TOKEN_PATTERN = re.compile(
    r'(https?://[^\s\'\"]*?[?&])(?:[^=&\s\'\"]*(?:key|token|secret|auth|pass|password|api)[^=&\s\'\"]*=[^\s\'\"&]+(&?))+',
    re.IGNORECASE
)

# Hostnames (simple heuristic: word.word.tld patterns that aren't plain domains)
_HOSTNAME_PATTERN = re.compile(
    r'\b(?:[a-z0-9](?:[a-z0-9\-]*[a-z0-9])?\.){2,}[a-z]{2,}\b',
    re.IGNORECASE
)

# --- PUBLIC level additional patterns ---

# Financial figures
_FINANCIAL_PATTERN = re.compile(
    r'\$\s*\d[\d,\.]*(?:\s*(?:million|billion|thousand|k|m|b))?\b'
    r'|\b\d[\d,\.]*\s*(?:USD|EUR|GBP|JPY|CAD|AUD)\b',
    re.IGNORECASE
)

# Location data (simple heuristics)
_LOCATION_PATTERN = re.compile(
    r'\b(?:at|in|near|from|located\s+(?:at|in))\s+[A-Z][a-zA-Z\s,]{2,40}(?:,\s*[A-Z]{2})?\b'
)

# US ZIP codes
_ZIP_PATTERN = re.compile(r'\b\d{5}(?:-\d{4})?\b')

# Health/medical terms (small curated list)
_MEDICAL_TERMS = re.compile(
    r'\b(?:diagnosis|diagnoses|prescription|medication|dosage|symptom|syndrome|disorder|'
    r'therapy|treatment|patient|clinical|hypertension|diabetes|cancer|anxiety|depression|'
    r'surgery|physician|doctor|hospital|clinic|pharmaceutical|vaccine|chronic|acute|'
    r'allergy|allergies|ADHD|PTSD|HIV|AIDS|COVID|influenza)\b',
    re.IGNORECASE
)

# Proper nouns: naive approach — capitalized words not at sentence start
# (We'll do a sentence-aware pass)
_PROPER_NOUN_PATTERN = re.compile(
    r'(?<=[.!?]\s)(?![A-Z][a-z]+\s+[a-z])'  # after sentence end
    r'|(?<=\s)(?=[A-Z][a-z]{2,}(?:\s+[A-Z][a-z]{2,})*)'  # mid-sentence caps
)

# Two or more consecutive Title-Case words → treated as a proper noun
_PROPER_NOUN_SEQUENCE = re.compile(
    r'\b([A-Z][a-z]{1,}(?:\s+[A-Z][a-z]{1,}){1,3})\b'
)


# ---------------------------------------------------------------------------
# Luhn check (to reduce false positives on credit cards)
# ---------------------------------------------------------------------------

def _luhn(number: str) -> bool:
    digits = [int(c) for c in number if c.isdigit()]
    if len(digits) < 13:
        return False
    odd = digits[-1::-2]
    even = [sum(divmod(d * 2, 10)) for d in digits[-2::-2]]
    return (sum(odd) + sum(even)) % 10 == 0


# ---------------------------------------------------------------------------
# Core scrubbing functions
# ---------------------------------------------------------------------------

def _redact(text: str, pattern: re.Pattern, replacement: str) -> str:
    return pattern.sub(replacement, text)


def _scrub_api_keys(text: str) -> str:
    for pat in _API_KEY_PATTERNS:
        text = pat.sub("[REDACTED_API_KEY]", text)
    return text


def _scrub_passwords(text: str) -> str:
    def _replace_pw(m: re.Match) -> str:
        full = m.group(0)
        val = m.group(1)
        return full.replace(val, "[REDACTED_PASSWORD]")
    for pat in _PASSWORD_PATTERNS:
        text = pat.sub(_replace_pw, text)
    return text


def _scrub_emails(text: str) -> str:
    return _EMAIL_PATTERN.sub("[REDACTED_EMAIL]", text)


def _scrub_phones(text: str) -> str:
    return _PHONE_PATTERN.sub("[REDACTED_PHONE]", text)


def _scrub_ssn(text: str) -> str:
    return _SSN_PATTERN.sub("[REDACTED_SSN]", text)


def _scrub_credit_cards(text: str) -> str:
    def _replace_cc(m: re.Match) -> str:
        raw = m.group(0)
        digits_only = re.sub(r'[ \-]', '', raw)
        if _luhn(digits_only):
            return "[REDACTED_CC]"
        return raw
    return _CC_PATTERN.sub(_replace_cc, text)


def _scrub_ips(text: str, allowed: list[str]) -> str:
    def _replace_ip(m: re.Match) -> str:
        ip = m.group(0)
        if ip in allowed:
            return ip
        return "[REDACTED_IP]"
    return _IP_PATTERN.sub(_replace_ip, text)


def _scrub_paths(text: str, username: str) -> str:
    pat = _build_path_pattern(username)
    if pat:
        text = pat.sub("[REDACTED_PATH]", text)
    return text


def _scrub_url_tokens(text: str) -> str:
    def _replace_url(m: re.Match) -> str:
        base = m.group(1)
        return base + "[REDACTED_PARAMS]"
    return _URL_TOKEN_PATTERN.sub(_replace_url, text)


def _scrub_hostnames(text: str, allowed: list[str]) -> str:
    def _replace_host(m: re.Match) -> str:
        host = m.group(0)
        if host in allowed:
            return host
        return "[REDACTED_HOST]"
    return _HOSTNAME_PATTERN.sub(_replace_host, text)


def _scrub_financial(text: str) -> str:
    return _FINANCIAL_PATTERN.sub("[REDACTED_FINANCIAL]", text)


def _scrub_location(text: str) -> str:
    text = _LOCATION_PATTERN.sub("[REDACTED_LOCATION]", text)
    text = _ZIP_PATTERN.sub("[REDACTED_ZIP]", text)
    return text


def _scrub_medical(text: str) -> str:
    return _MEDICAL_TERMS.sub("[REDACTED_MEDICAL]", text)


def _scrub_proper_nouns(text: str) -> str:
    return _PROPER_NOUN_SEQUENCE.sub("[REDACTED_NAME]", text)


def _scrub_ocr_passwords(text: str) -> str:
    for pat in _OCR_PASSWORD_PATTERNS:
        text = pat.sub("[REDACTED_PASSWORD]", text)
    return text


def _scrub_session_tokens(text: str) -> str:
    for pat in _SESSION_TOKEN_PATTERNS:
        text = pat.sub("[REDACTED_SESSION]", text)
    return text


def _scrub_cc_midentry(text: str) -> str:
    """Redact partial credit-card numbers (mid-entry, may not pass Luhn yet)."""
    def _check(m: re.Match) -> str:
        raw = m.group(0)
        digits_only = re.sub(r'[ \-]', '', raw)
        # Full card (Luhn-validatable length): handled by _scrub_credit_cards.
        # Here we catch short partial entries (8-11 digits after stripping separators).
        if 8 <= len(digits_only) <= 11:
            return "[REDACTED_CC_PARTIAL]"
        return raw
    return _CC_MIDENTRY_PATTERN.sub(_check, text)


def _scrub_blocklist(text: str) -> str:
    for pat in _BLOCKLIST_PATTERNS:
        text = pat.sub("[REDACTED_BLOCKLIST]", text)
    return text


# ---------------------------------------------------------------------------
# Public API
# ---------------------------------------------------------------------------

def scrub(
    text: str,
    level: Level | str,
    config: Optional[dict] = None,
) -> str:
    """
    Scrub *text* at the given *level*.

    Returns the scrubbed string (without the metadata header).
    Use :func:`process` to get a full document with header.
    """
    level = Level(level)
    if level == Level.RAW:
        return text

    cfg = {**DEFAULT_CONFIG, **(config or {})}
    allowed_ips: list[str] = cfg.get("allowed_ips", [])
    allowed_hosts: list[str] = cfg.get("allowed_hostnames", [])
    username: str = cfg.get("username", "") or os.environ.get("USER", "")

    out = text

    # Applied at PRIVATE, WORKSPACE, PUBLIC
    # URL tokens must run first so query-param values aren't consumed by the
    # API-key patterns before the URL context is available.
    out = _scrub_url_tokens(out)
    out = _scrub_api_keys(out)
    out = _scrub_passwords(out)
    out = _scrub_emails(out)
    out = _scrub_phones(out)
    out = _scrub_ssn(out)
    out = _scrub_credit_cards(out)
    out = _scrub_ips(out, allowed_ips)
    out = _scrub_paths(out, username)

    # WORKSPACE + PUBLIC also redact hostnames
    if level in (Level.WORKSPACE, Level.PUBLIC):
        out = _scrub_hostnames(out, allowed_hosts)

    # PUBLIC additionally strips higher-level identifiers
    if level == Level.PUBLIC:
        out = _scrub_proper_nouns(out)
        out = _scrub_financial(out)
        out = _scrub_location(out)
        out = _scrub_medical(out)

    # Apply user blocklist (last, so custom patterns catch anything the above missed)
    out = _scrub_blocklist(out)

    return out


def scrub_ocr_text(
    text: str,
    level: "Level | str",
    config: Optional[dict] = None,
) -> str:
    """Scrub raw OCR text from Screenpipe frames.

    Applies all standard ``scrub()`` patterns plus OCR-specific ones:
    password field labels, session tokens, partial credit-card numbers,
    and the user blocklist.
    """
    # First apply the standard scrubber pipeline
    out = scrub(text, level, config)
    # Then apply OCR-specific additions
    out = _scrub_ocr_passwords(out)
    out = _scrub_session_tokens(out)
    out = _scrub_cc_midentry(out)
    out = _scrub_blocklist(out)
    return out


def _make_header(level: Level, source_hash: str) -> str:
    iso_date = datetime.now(timezone.utc).strftime("%Y-%m-%dT%H:%M:%SZ")
    return (
        "---\n"
        f"scrub_level: {level.value}\n"
        f"scrub_date: {iso_date}\n"
        f"source_hash: {source_hash}\n"
        "ai_processed: false\n"
        "---\n"
    )


def process(
    input_text: str,
    level: Level | str,
    config: Optional[dict] = None,
) -> str:
    """
    Scrub *input_text* and return a document with a YAML metadata header.

    Parameters
    ----------
    input_text : str
        Raw text to process.
    level : Level | str
        One of 'raw', 'private', 'workspace', 'public'.
    config : dict, optional
        Override default config keys: allowed_ips, allowed_hostnames, username.

    Returns
    -------
    str
        Metadata header + scrubbed text.
    """
    level = Level(level)
    source_hash = hashlib.sha256(input_text.encode()).hexdigest()
    header = _make_header(level, source_hash)
    body = scrub(input_text, level, config)
    return header + body


def process_file(
    input_path: str | Path,
    output_path: str | Path,
    level: Level | str,
    config: Optional[dict] = None,
) -> None:
    """
    Read *input_path*, scrub it, and write result to *output_path*.
    """
    input_path = Path(input_path)
    output_path = Path(output_path)
    text = input_path.read_text(encoding="utf-8", errors="replace")
    result = process(text, level, config)
    output_path.write_text(result, encoding="utf-8")


# ---------------------------------------------------------------------------
# CLI
# ---------------------------------------------------------------------------

def _cli() -> None:
    parser = argparse.ArgumentParser(
        description="Privacy scrubber — rule-based PII removal",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog="""
Levels:
  raw        No changes; only attaches metadata header.
  private    Removes API keys, passwords, emails, phones, SSN, CC, IPs, paths, URL tokens.
  workspace  private + hostname redaction.
  public     workspace + proper nouns, financial figures, locations, medical terms.
        """,
    )
    parser.add_argument("--input", required=True, help="Input file path")
    parser.add_argument(
        "--level",
        required=True,
        choices=[l.value for l in Level],
        help="Scrub level",
    )
    parser.add_argument(
        "--output",
        required=True,
        help="Output file path or directory",
    )
    parser.add_argument(
        "--allowed-ips",
        nargs="*",
        default=[],
        metavar="IP",
        help="IP addresses to leave unredacted",
    )
    parser.add_argument(
        "--allowed-hostnames",
        nargs="*",
        default=[],
        metavar="HOST",
        help="Hostnames to leave unredacted",
    )
    parser.add_argument(
        "--username",
        default=os.environ.get("USER", ""),
        help="Username to redact from file paths (default: $USER)",
    )
    args = parser.parse_args()

    input_path = Path(args.input)
    if not input_path.exists():
        print(f"Error: input file not found: {input_path}", file=sys.stderr)
        sys.exit(1)

    output_path = Path(args.output)
    if output_path.is_dir():
        output_path = output_path / input_path.name

    config = {
        "allowed_ips": args.allowed_ips,
        "allowed_hostnames": args.allowed_hostnames,
        "username": args.username,
    }

    process_file(input_path, output_path, args.level, config)
    print(f"Scrubbed ({args.level}) → {output_path}")


if __name__ == "__main__":
    _cli()
