#!/usr/bin/env python3
"""
proactive_research.py — Tier-3 credential-gated proactive web research.

Watches ~/vault/workspace/ for new/modified .md files.
When one appears, asks Hermes swarm13 to extract 1-3 search queries from
the first 500 chars.  If FIRECRAWL_API_KEY or EXA_API_KEY is set, runs the
search; otherwise logs to research_queue.jsonl and retries when a key appears.

Results are written to ~/vault/workspace/research_[timestamp]_[slug].md.
Rate limit: max 3 research tasks per 10 minutes.

PID:  ~/beewid-privacy/proactive_research.pid
Log:  ~/beewid-privacy/proactive_research.log
Queue: ~/beewid-privacy/research_queue.jsonl
"""

from __future__ import annotations

import json
import logging
import os
import re
import signal
import subprocess
import sys
import time
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime, timezone
from pathlib import Path

# ── paths & config ───────────────────────────────────────────────────────────

HOME           = Path(os.path.expanduser("~"))
WATCH_DIR      = HOME / "vault" / "workspace"
RESULTS_DIR    = HOME / "vault" / "workspace"
QUEUE_FILE     = HOME / "beewid-privacy" / "research_queue.jsonl"
LOG_FILE       = HOME / "beewid-privacy" / "proactive_research.log"
PID_FILE       = HOME / "beewid-privacy" / "proactive_research.pid"

HERMES_BIN     = "hermes"
HERMES_PROFILE = "swarm13"

POLL_INTERVAL_S   = 10.0
RATE_LIMIT_WINDOW = 600   # seconds (10 min)
RATE_LIMIT_COUNT  = 3     # max tasks per window
HERMES_TIMEOUT    = 60.0
SEARCH_TIMEOUT    = 20.0
SNIPPET_CHARS     = 500   # chars sent to hermes for query extraction
MAX_SLUG_LEN      = 40

EXCLUDED_PREFIXES = [
    str(HOME / "Downloads" / "beewid" / "vault"),
    str(HOME / "vault" / "quarantine"),
]

# ── logging ──────────────────────────────────────────────────────────────────

log = logging.getLogger("proactive_research")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%Y-%m-%dT%H:%M:%S")
_fh = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
_fh.setFormatter(_fmt)
log.addHandler(_fh)
_sh = logging.StreamHandler(sys.stderr)
_sh.setFormatter(_fmt)
log.addHandler(_sh)

# ── PID management ───────────────────────────────────────────────────────────

def _read_pid(path: Path) -> int | None:
    try:
        raw = path.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None

def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False

def write_pid() -> None:
    existing = _read_pid(PID_FILE)
    if existing and _alive(existing):
        log.error("already running (PID %d)", existing)
        sys.exit(2)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n")

def remove_pid() -> None:
    try:
        if _read_pid(PID_FILE) == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── credential detection ─────────────────────────────────────────────────────

def active_provider() -> str | None:
    """Return 'exa', 'firecrawl', or None."""
    if os.environ.get("EXA_API_KEY"):
        return "exa"
    if os.environ.get("FIRECRAWL_API_KEY"):
        return "firecrawl"
    return None

# ── file helpers ─────────────────────────────────────────────────────────────

def is_excluded(path: Path) -> bool:
    try:
        resolved = str(path.resolve())
    except OSError:
        resolved = str(path)
    return any(resolved.startswith(pfx) for pfx in EXCLUDED_PREFIXES)

def slugify(text: str) -> str:
    slug = re.sub(r"[^a-z0-9]+", "_", text.lower().strip())[:MAX_SLUG_LEN]
    return slug.strip("_") or "research"

# ── queue helpers ─────────────────────────────────────────────────────────────

def queue_pending() -> list[dict]:
    if not QUEUE_FILE.is_file():
        return []
    out = []
    try:
        with QUEUE_FILE.open("r", encoding="utf-8", errors="replace") as fh:
            for line in fh:
                line = line.strip()
                if not line:
                    continue
                try:
                    obj = json.loads(line)
                    if isinstance(obj, dict):
                        out.append(obj)
                except Exception:
                    continue
    except OSError:
        pass
    return out

def queue_all() -> list[dict]:
    return queue_pending()

def enqueue(entry: dict) -> None:
    QUEUE_FILE.parent.mkdir(parents=True, exist_ok=True)
    with QUEUE_FILE.open("a", encoding="utf-8") as fh:
        fh.write(json.dumps(entry) + "\n")

def rewrite_queue(entries: list[dict]) -> None:
    """Overwrite the queue file with the given entries."""
    tmp = QUEUE_FILE.with_suffix(".jsonl.tmp")
    with tmp.open("w", encoding="utf-8") as fh:
        for e in entries:
            fh.write(json.dumps(e) + "\n")
    os.replace(tmp, QUEUE_FILE)

# ── hermes query extraction ──────────────────────────────────────────────────

def extract_queries(snippet: str) -> list[str]:
    prompt = (
        'Extract 1-3 search queries from this content. '
        'Return ONLY a JSON array of strings like ["query 1", "query 2"]. '
        f'If no useful queries, return []. Content: {snippet}'
    )
    try:
        proc = subprocess.run(
            [HERMES_BIN, "--profile", HERMES_PROFILE, "-z", prompt],
            capture_output=True, text=True, timeout=HERMES_TIMEOUT,
        )
    except (FileNotFoundError, subprocess.TimeoutExpired) as exc:
        log.warning("hermes extract failed: %s", exc)
        return []

    raw = proc.stdout.strip()
    # tolerate text before/after the JSON array
    m = re.search(r'\[.*?\]', raw, re.DOTALL)
    if not m:
        return []
    try:
        result = json.loads(m.group(0))
        if isinstance(result, list):
            return [str(q).strip() for q in result if str(q).strip()][:3]
    except Exception:
        pass
    return []

# ── search execution ─────────────────────────────────────────────────────────

def search_exa(query: str, api_key: str) -> str:
    """Call Exa search API; return markdown-formatted results."""
    url = "https://api.exa.ai/search"
    payload = json.dumps({"query": query, "numResults": 5, "useAutoprompt": True})
    req = urllib.request.Request(
        url,
        data=payload.encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "x-api-key": api_key,
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=SEARCH_TIMEOUT) as resp:
            d = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError) as exc:
        return f"(exa search failed: {exc})"
    results = d.get("results") or []
    lines = [f"# Exa search: {query}\n"]
    for r in results[:5]:
        title = r.get("title") or "(no title)"
        url_r = r.get("url") or ""
        text  = (r.get("text") or r.get("highlights") or [""])[0][:500]
        lines.append(f"## {title}\n{url_r}\n\n{text}\n")
    return "\n".join(lines)

def search_firecrawl(query: str, api_key: str) -> str:
    """Call Firecrawl search endpoint; return markdown-formatted results."""
    url = "https://api.firecrawl.dev/v1/search"
    payload = json.dumps({"query": query, "limit": 5})
    req = urllib.request.Request(
        url,
        data=payload.encode("utf-8"),
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Bearer {api_key}",
        },
        method="POST",
    )
    try:
        with urllib.request.urlopen(req, timeout=SEARCH_TIMEOUT) as resp:
            d = json.loads(resp.read().decode("utf-8", errors="replace"))
    except (urllib.error.URLError, json.JSONDecodeError) as exc:
        return f"(firecrawl search failed: {exc})"
    results = d.get("data") or d.get("results") or []
    lines = [f"# Firecrawl search: {query}\n"]
    for r in results[:5]:
        title = r.get("title") or r.get("metadata", {}).get("title") or "(no title)"
        url_r = r.get("url") or r.get("metadata", {}).get("sourceURL") or ""
        text  = (r.get("markdown") or r.get("content") or "")[:500]
        lines.append(f"## {title}\n{url_r}\n\n{text}\n")
    return "\n".join(lines)

def run_search(query: str, provider: str) -> str:
    if provider == "exa":
        return search_exa(query, os.environ["EXA_API_KEY"])
    if provider == "firecrawl":
        return search_firecrawl(query, os.environ["FIRECRAWL_API_KEY"])
    return f"(no search provider active for: {query})"

def write_result(query: str, content: str, source_file: str) -> Path:
    ts = datetime.now(tz=timezone.utc).strftime("%Y%m%dT%H%M%SZ")
    slug = slugify(query)
    out = RESULTS_DIR / f"research_{ts}_{slug}.md"
    RESULTS_DIR.mkdir(parents=True, exist_ok=True)
    header = (
        f"---\nsource_file: {source_file}\nquery: {query}\n"
        f"generated: {datetime.now(tz=timezone.utc).isoformat()}\n---\n\n"
    )
    out.write_text(header + content + "\n", encoding="utf-8")
    return out

# ── rate limiter ─────────────────────────────────────────────────────────────

class RateLimiter:
    def __init__(self, max_count: int, window_s: float) -> None:
        self._max = max_count
        self._window = window_s
        self._times: list[float] = []

    def allowed(self) -> bool:
        now = time.time()
        self._times = [t for t in self._times if now - t < self._window]
        return len(self._times) < self._max

    def record(self) -> None:
        self._times.append(time.time())

# ── main watcher loop ─────────────────────────────────────────────────────────

_STOP = False

def _on_signal(signum: int, _frame) -> None:
    global _STOP
    log.info("signal %d — stopping", signum)
    _STOP = True

def process_file(path: Path, provider: str | None, rate: RateLimiter, seen: set[str]) -> None:
    key = str(path)
    try:
        snippet = path.read_text(encoding="utf-8", errors="replace")[:SNIPPET_CHARS]
    except OSError as exc:
        log.warning("read failed for %s: %s", path.name, exc)
        seen.add(key)
        return

    queries = extract_queries(snippet)
    if not queries:
        log.info("%s: no queries extracted", path.name)
        seen.add(key)
        return

    for q in queries:
        if not rate.allowed():
            log.info("rate limited — queuing: %s", q)
            enqueue({
                "ts": datetime.now(tz=timezone.utc).isoformat(),
                "query": q,
                "source_file": str(path),
                "status": "pending",
                "reason": "rate_limited",
            })
            continue
        if provider is None:
            log.info("no API key — queuing: %s", q)
            enqueue({
                "ts": datetime.now(tz=timezone.utc).isoformat(),
                "query": q,
                "source_file": str(path),
                "status": "pending",
                "reason": "no_api_key",
            })
            continue
        rate.record()
        log.info("searching (%s): %s", provider, q)
        content = run_search(q, provider)
        out = write_result(q, content, str(path))
        log.info("result written: %s", out.name)
    seen.add(key)

def process_backlog(provider: str, rate: RateLimiter) -> None:
    """Re-run pending queue entries when a key becomes available."""
    entries = queue_all()
    pending = [e for e in entries if e.get("status") == "pending"]
    if not pending:
        return
    log.info("processing %d backlog entries with provider=%s", len(pending), provider)
    updated = list(entries)  # copy
    for entry in pending:
        if not rate.allowed():
            break
        q    = entry.get("query", "")
        src  = entry.get("source_file", "")
        if not q:
            entry["status"] = "skipped"
            continue
        rate.record()
        content = run_search(q, provider)
        out = write_result(q, content, src)
        entry["status"] = "completed"
        entry["result_file"] = str(out)
        log.info("backlog result: %s", out.name)
    rewrite_queue(updated)

def scan(watch_dir: Path, since_mtime: float, seen: set[str]) -> list[Path]:
    """Files modified after `since_mtime`, not excluded, not already seen."""
    new = []
    if not watch_dir.is_dir():
        return new
    try:
        for p in watch_dir.iterdir():
            if not p.is_file() or p.suffix.lower() != ".md":
                continue
            if is_excluded(p) or str(p) in seen:
                continue
            try:
                if p.stat().st_mtime > since_mtime:
                    new.append(p)
            except OSError:
                continue
    except OSError:
        pass
    return new

def run() -> int:
    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT, _on_signal)
    write_pid()
    try:
        WATCH_DIR.mkdir(parents=True, exist_ok=True)
        rate = RateLimiter(RATE_LIMIT_COUNT, RATE_LIMIT_WINDOW)
        seen: set[str] = set()

        # Seed seen from existing files so we don't process them on startup.
        last_mtime = 0.0
        try:
            for p in WATCH_DIR.iterdir():
                if p.is_file() and p.suffix.lower() == ".md" and not is_excluded(p):
                    m = p.stat().st_mtime
                    seen.add(str(p))
                    if m > last_mtime:
                        last_mtime = m
        except OSError:
            pass

        provider = active_provider()
        log.info(
            "started (watch=%s poll=%.0fs rate=%d/%ds provider=%s)",
            WATCH_DIR, POLL_INTERVAL_S, RATE_LIMIT_COUNT, RATE_LIMIT_WINDOW,
            provider or "none (credential-pending)",
        )

        # Process backlog if credentials already present at startup.
        if provider:
            process_backlog(provider, rate)

        while not _STOP:
            # Re-check credentials each tick in case keys were added.
            new_provider = active_provider()
            if new_provider and new_provider != provider:
                log.info("API key detected (%s) — processing backlog", new_provider)
                provider = new_provider
                process_backlog(provider, rate)
            elif new_provider:
                provider = new_provider
            else:
                provider = None

            new_files = scan(WATCH_DIR, last_mtime, seen)
            for p in sorted(new_files, key=lambda f: f.stat().st_mtime):
                if _STOP:
                    break
                process_file(p, provider, rate, seen)
                try:
                    m = p.stat().st_mtime
                    if m > last_mtime:
                        last_mtime = m
                except OSError:
                    pass

            time.sleep(POLL_INTERVAL_S)

        return 0
    finally:
        remove_pid()
        log.info("stopped")


if __name__ == "__main__":
    sys.exit(run())
