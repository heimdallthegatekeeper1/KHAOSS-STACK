# Hermes v0.14.0 — OpenAI-Compatible Local Proxy Contract
**For:** Beewid §29 (Hermes engine backend integration)
**Date:** 2026-05-17
**Maintained by:** KHAOSS Sonnet

---

## What It Is

Hermes v0.14.0 introduces an OpenAI-compatible local proxy that turns
any OAuth-authed Hermes provider (Claude Pro, ChatGPT Pro, SuperGrok)
into an endpoint that Codex / Aider / Cline / Continue / AionUI can hit.

This solves two problems simultaneously:
1. AionUI MCP team_* tools not registered with Hermes (the gap found
   in the Pro Nara session)
2. Beewid §29 needing a clean transport for Hermes ↔ Beewid integration

---

## Current State on Cornholio

Hermes API server is running at:
- http://localhost:8642/v1 (OpenAI-compatible)
- API key: change-me-local-dev
- Model: swarm13 (maps to gpt-5.5 via Codex OAuth)

Verified working:
```bash
curl http://localhost:8642/v1/chat/completions \
  -H "Authorization: Bearer change-me-local-dev" \
  -H "Content-Type: application/json" \
  -d '{"model":"swarm13","messages":[{"role":"user","content":"hello"}]}'
# Returns: {"choices": [{"message": {"content": "Hello"}}], ...}
```

---

## For Beewid §29 Integration

When Beewid §29 ships, use this transport config:

```python
# beewid_api.py — Hermes engine backend (§29)
HERMES_PROXY_URL = "http://localhost:8642/v1"
HERMES_PROXY_KEY = os.environ.get("HERMES_API_KEY", "change-me-local-dev")
HERMES_DEFAULT_PROFILE = "swarm14"  # Beewid's reserved slot per QUIRKS

# OpenAI SDK compatible — drop-in replacement
from openai import AsyncOpenAI
hermes_client = AsyncOpenAI(
    base_url=HERMES_PROXY_URL,
    api_key=HERMES_PROXY_KEY
)
```

## Profile Assignments (contractual)

| Profile | Owner | Purpose |
|---------|-------|---------|
| swarm13 | KHAOSS | Screen assistant, panel, primary leader |
| swarm14 | Beewid §29 | Beewid engine backend default |
| swarm1 | KHAOSS | Strategic analysis (Claude Sonnet via OpenRouter) |
| swarm2 | KHAOSS | Operations/writing (GPT-4o via OpenRouter) |
| swarm3 | KHAOSS | Bulk research (Claude Haiku via OpenRouter) |

---

## AionUI MCP team_* Gap — Resolution Path

The v0.14.0 proxy means AionUI can be configured to call
`http://localhost:8642/v1` as a model provider, which routes through
Hermes' full tool chain including Kanban and skills.

This was the fix implemented via `AIONUI_HERMES_LEADER_FIX.md` —
the aionrs preset now routes through the Hermes API server.

When Beewid replaces AionUI (BOHKSS transition), the same proxy
URL works — Beewid just uses the OpenAI client above.

---

## API Server Config in swarm13

```yaml
# ~/.hermes/profiles/swarm13/config.yaml
api_server:
  enabled: true
  key: change-me-local-dev
```

**Change the key for any production/shared deployment:**
```bash
hermes config set api_server.key your_secure_key --profile swarm13
# Then update AionUI model config to match
```

---

*KHAOSS Sonnet · 2026-05-17 · For Beewid §29*
