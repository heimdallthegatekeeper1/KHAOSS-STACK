# KHAOSS Stack Status
**K**anban · **H**ermes · **A**ionUI · **O**bsidian · **S**creenpipe · **S**pace Agent

_KHAOSS v1.0 — verified 2026-05-18 · Panel: http://localhost:7842_
_SSE real-time — status updates push every 3 s, no page refresh needed_

---

## 1. Service Status (verified 2026-05-18)

| Service | Status | Notes |
|---|---|---|
| **Screenpipe** | ✅ healthy :3030 | Vision enabled · degraded = amber (Wayland), not red |
| **Hermes gateway** | ✅ online :8642 | v0.14.0 · `hermes doctor` clean · swarm13 active |
| **Hermes dashboard** | ✅ running :9119 | `/api/status` returns version · `/goal` verified working |
| **AionUI** | ✅ running (electron PID 1511392) | Port :3002 closed — normal for electron window |
| **Vault Watcher** | ✅ running PID 290137 | Scrubs `~/.screenpipe/data/` → `~/vault/{private,workspace,public}/` |
| **Vault Import Sanitizer** | ✅ running PID 405592 | Quarantine gate for `~/obsidian-vault/` |
| **Screen Assistant** | ✅ running | Fires suggestions within ~2 min of new workspace file |
| **Proactive Research** | ✅ running (credential-pending) | Queue-mode until `EXA_API_KEY` or `FIRECRAWL_API_KEY` set |
| **Panel Server** | ✅ running :7842 | SSE broadcaster + reverse proxy · PID in `panel_server.pid` |
| **Space Agent** | ⚠️ installed, not running | `~/agents/space-agent/` · opt-in; start: `cd ~/agents/space-agent && PORT=3000 npm start` |
| **Voice → Kanban** | ⬜ stopped by design | Phone-pending — waiting for OMI device setup |
| **Learning Loop** | ⬜ idle by design | Manual trigger: `python3 ~/beewid-privacy/learning_loop.py` |
| **Beewid Main** | 🔲 pending BOHKSS | :8506 — Phase E transition |
| **Beewid Watchdog** | 🔲 pending BOHKSS | :8507 — Phase E transition |
| **Beewid Autocode** | 🔲 pending BOHKSS | :8509 — Phase E transition |

**Quarantine:** 1 file (`test_inject.md` — old injection test, safe to ignore or delete)

---

## 2. Verified Features

| Feature | Status | Detail |
|---|---|---|
| Screen Assistant suggestions | ✅ | Fires within ~2 min of new `~/vault/workspace/` file · `recent_suggestions` key confirmed |
| Session Memory synthesis | ✅ | Writes `~/obsidian-vault/session_YYYY-MM-DD.md` · exit_code + output_path return correctly |
| Debate Mode | ✅ | "Claude vs GPT-5.5" debate completed to verdict file in ~42 s · all exit codes 0 |
| Proactive Research | ✅ | Running in credential-pending mode · queue drains automatically on key arrival |
| Credential Check | ✅ | 53 PASS / 0 FAIL |
| MCP servers | ✅ | `screenpipe` (23 tools) + `vault-workspace` (7 read-only tools) |
| Hermes /goal | ✅ | Verified working with judge model (swarm13) |
| Hermes v0.14.0 | ✅ | Updated · `hermes doctor` clean |
| SSE real-time push | ✅ | `/stream` event-source · all cards update live, no setTimeout polling |
| Snapshot endpoint | ✅ | All 14 services return `display_state` or `status` (? fields fixed) |
| Launch script | ✅ | `~/launch-stack.sh` · idempotent · hermes dashboard block added with running-check |

---

## 3. Pending (not blockers)

| Item | Unblocks |
|---|---|
| `EXA_API_KEY` or `FIRECRAWL_API_KEY` | Proactive research goes live (auto-drains queue) |
| OMI phone + 2SV | Voice → Kanban goes live |
| Learning loop first run | `python3 ~/beewid-privacy/learning_loop.py` — needs a few session files to be useful |
| Pro Nara Phase 2 | Blocked on phone / 2SV for Gmail/Drive |
| swarm4-12 provider config | Profiles exist, provider credentials unconfigured |

Set API keys in `~/.hermes/.env` or your shell profile. The proactive_research daemon checks on every poll tick and auto-processes `research_queue.jsonl` backlog when a key appears.

---

## 4. BOHKSS Transition Checklist

_Beewid replaces AionUI · stack renames to BOHKSS (Beewid · Obsidian · Hermes · Kanban · Screenpipe · Space Agent)_

- [ ] Uncomment Beewid health stubs in `panel_server.py` (ports 8506/8507/8509)
- [ ] Update `EXCLUDED_PATHS` in `screen_assistant.py` for unified vault
- [ ] Switch `screen_assistant.py` `TRANSPORT` to `"beewid_autocode"`
- [ ] Rename `~/aionui-stack-panel.html` → `~/bohkss-panel.html`
- [ ] Update `~/launch-stack.sh` to launch Beewid instead of AionUI
- [ ] Wire `scrubber.py` into Beewid `privacy_scrub` skill
- [ ] Wire `ring_interface.py` into `beewid_api.py` context gating

---

## 5. Beta Tester Quick-Start (5 steps)

**Prerequisites:** Hermes v0.14.0 at `~/.local/bin/hermes` · `swarm13` profile configured · `hermes doctor` clean.

```bash
# Step 1 — Boot the full stack
bash ~/launch-stack.sh

# Step 2 — Open the panel
xdg-open http://localhost:7842
# (or: firefox http://localhost:7842)

# Step 3 — Verify services
# Panel topbar shows "N/M healthy" — aim for 5+/9
# Green: screenpipe, hermes :8642, hermes dashboard :9119, vault_watcher, sanitizer
# Expected running: screen_assistant, proactive_research, panel_server
# Amber/expected off: voice_kanban (phone-pending), learning_loop (manual)

# Step 4 — Enable screen assistant (already running after launch-stack)
# SCREEN ASSISTANT card — dot is green; drop a .md file into ~/vault/workspace/
# Suggestion appears in card within ~2 min

# Step 5 — Run session synthesis
# Click "⏏ End Session" in the topbar
# Wait ~30 s → "✓ Session saved to Obsidian — session_YYYY-MM-DD.md"

# Bonus: test the debate engine
# DEBATE card → type topic → Start Debate
# Verdict in ~/vault/workspace/debate_<id>_verdict.md in ~1 min
```

**Logs if something breaks:**

| Service | Log |
|---|---|
| Panel server | `tail -f /tmp/panel_server.log` |
| Screenpipe | `tail -f ~/.screenpipe/screenpipe.log` |
| Vault watcher | `tail -f ~/beewid-privacy/watcher.log` |
| Screen assistant | `tail -f ~/beewid-privacy/screen_assistant_runtime.log` |
| Hermes gateway | `journalctl --user -u hermes-gateway-swarm13 -f` |
| Hermes dashboard | `tail -f /tmp/hermes-dashboard.log` |

---

## 6. Privacy Warning — Screenpipe + Cloud AI

### What beta testers must know

```
WHAT SCREENPIPE CURRENTLY SCRUBS (working):
✓ API keys (sk-, ghp_, AKIA..., sp-, etc.)
✓ Email addresses
✓ Phone numbers (US + international)
✓ Social Security Numbers
✓ Credit card numbers (Luhn-validated)
✓ File paths containing your username
✓ URL tokens and query parameters
✓ IP addresses and hostnames (workspace level)

WHAT MAY STILL REACH CLOUD AI (known gaps):
✗ Passwords typed into browser forms
✗ Names in conversation text
✗ Credit card numbers mid-entry (before complete)
✗ Session tokens in browser dev tools
✗ Private chat content (WhatsApp, Signal visible on screen)
✗ Context-specific sensitive words not in standard patterns

SAFE USAGE RULES:
1. Disable Screenpipe in panel during sensitive work
2. Use local AI (Ollama) when handling PII
3. Never type API keys/passwords while Screenpipe runs
4. Check ~/vault/workspace/ to see what agents can read
5. Add sensitive words to ~/beewid-privacy/blocklist.txt
```

Screenpipe captures your screen continuously. Before reaching any AI:
- `scrubber.py` strips: API keys, emails, phones, SSNs, credit cards,
  file paths, IPs, hostnames (at workspace level)
- `scrub_ocr_text()` applies additional OCR-aware patterns (password fields,
  session tokens, partial card numbers)
- `vault_import_sanitizer.py` blocks prompt injection attempts
- Agents read only from `~/vault/workspace/` (pre-scrubbed)
- `~/beewid-privacy/blocklist.txt` — add custom words/patterns to block

**Roadmap to close the gap:**
- Browser form field detection (password fields always redacted)
- Screen zone exclusions (`screen_zones.json` — draw rectangles over sensitive areas)
- Automated scrubber regression tests on every deploy

---

_For BOHKSS transition and Beewid integration details see `~/beewid-privacy/README.md` and the BOHKSS checklist above._
_Do NOT touch `~/Downloads/beewid/` — active Beewid development, Opus territory._
