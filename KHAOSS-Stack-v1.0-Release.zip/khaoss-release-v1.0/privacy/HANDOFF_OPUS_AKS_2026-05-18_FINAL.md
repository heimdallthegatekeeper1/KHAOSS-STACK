# KHAOSS Stack — Opus Handoff (AKS Final)

**Version:** AKS Final · 2026-05-18
**Stack:** Kanban · Hermes · AionUI · Obsidian · Screenpipe · Space Agent
**Machine:** Cornholio (Kali Linux, user: boq, X11 session)
**Predecessors:** `KHAOSS_OPUS_HANDOFF_v3_2026-05-17.md` (still authoritative for history)
**AionUI patches doc:** `~/beewid-privacy/AIONUI_HERMES_LEADER_FIX.md`

---

## TL;DR — what changed since v3

Since v3 (2026-05-17), the panel grew from a status dashboard into a full
control surface. Major additions:

1. **Scrubber v2** — OCR-aware password/session/partial-CC patterns + user
   blocklist + screen-zone exclusion config (`scrub_ocr_text`, `load_blocklist`,
   `is_in_excluded_zone`). Test suite 54 → 59.
2. **Launch Console** — one-click `⚡ LAUNCH ALL SERVICES` button with a
   live SSE-streamed terminal modal, debug report generation, autocode escalation.
3. **Per-service controls** — every card has `▶ Start` / `■ Stop` / `↺ Restart`
   buttons routed through hardened `/services/*` endpoints.
4. **Beavis & Butt-Head debate UI** — redesigned SVGs at 95×145 / 110×145,
   animated jaw via `.talking .jm`, full popout window.
5. **Panel watchdog** — `launch-stack.sh` ends with a 60 s polling loop that
   restarts `panel_server.py` if `:7842` stops responding.
6. **Privacy warning surface** — amber banner appears whenever Screenpipe is
   running alongside any cloud AI; dismissible per browser session.
7. **Critical bug fix** — `</script>` inside a template literal in the popout
   builder was prematurely closing the main script block. All JS after line
   2759 was unreachable. Fixed with `</script>` escape.

---

## Verified Stack State (2026-05-18)

| Service | Status | Notes |
|---|---|---|
| **Screenpipe** | ✅ healthy :3030 | env wrapper for X11 added in `panel_server._SVC_DEFS` |
| **Hermes gateway** | ✅ online :8642 | v0.14.0 |
| **Hermes dashboard** | ✅ running :9119 | `/api/status` returns version |
| **AionUI** | ✅ running (electron PID active) | source patches intact |
| **Vault Watcher** | ✅ running | OCR-scrubs JSON frames, zone-checks coords |
| **Vault Sanitizer** | ✅ running | quarantine count: 1 (test_inject.md) |
| **Screen Assistant** | ✅ running | suggests within ~2 min |
| **Proactive Research** | ✅ running (credential-pending) | queue mode until key |
| **Panel Server** | ✅ running :7842 | watchdog active in launch-stack.sh |
| **Space Agent** | ✅ healthy :3000 | started by Launch Console test |
| Voice → Kanban | ⬜ stopped by design | phone-pending |
| Learning Loop | ⬜ idle by design | manual trigger |

`POST /launch/all` SSE stream verified end-to-end:
```
data: {"type":"complete","healthy":10,"failed":0,"degraded":0,"debug_report":""}
```

---

## Test Results

| Suite | Status |
|---|---|
| `pytest test_scrubber.py` | **59 passed in 0.06 s** |
| Existing 54 tests | all passing (no regressions from v2 additions) |
| New OCR scrubbing tests | 4 added |
| New blocklist tests | 1 added |
| `node --check` on panel JS | PASS |
| `python3 -m py_compile panel_server.py` | PASS |
| Launch sequence (10 services) | 10 healthy on test run |

---

## Features Built (Tier 0-3 + extensions)

### Tier 0 — Always-on infrastructure
- panel_server.py (HTTP + SSE + reverse proxy)
- launch-stack.sh (idempotent boot)
- launch-aionui.sh (GPU-disabled Electron)
- credential_check.sh (53-test suite)
- panel watchdog (60 s polling restart)

### Tier 1 — Privacy core
- **scrubber.py v2** — Level enum, all PII patterns, OCR additions,
  blocklist support, screen-zone exclusion
- **ring_interface.py** — Ring 0-4 → scrubber.Level bridge with
  RingFilter (cloud_safe whitelist + privacy_mode stripping)
- **vault_watcher.py** — watchdog on `~/.screenpipe/data/`, zone-skips,
  OCR-scrubs JSON frames, writes to `~/vault/{private,workspace}/`
- **vault_import_sanitizer.py** — prompt-injection quarantine for
  `~/obsidian-vault/`
- **vault_mcp_readonly.py** — 7-tool read-only MCP server

### Tier 2 — Multi-agent features
- **Debate Mode** — 2 agents argue, judge rules, transcripts to vault.
  Backed by Beavis/Butt-Head SVG UI + popout window with download buttons.
- **Session Memory** — `session_memory.py` synthesizes day's activity →
  `~/obsidian-vault/session_YYYY-MM-DD.md`
- **Screen Assistant** — JSON suggestions from workspace files, ~2 min latency

### Tier 3 — Credential-gated / opt-in
- **Proactive Research** — `proactive_research.py`, drains `research_queue.jsonl`
  once `EXA_API_KEY` / `FIRECRAWL_API_KEY` appears
- **Voice → Kanban** — phone-pending OMI integration
- **Learning Loop** — weekly skill synthesis, swarm13, sunday 03:00

### Control surface
- Live SSE snapshot every 3 s (15 service cards)
- Per-service start/stop/restart via `/services/{start,stop,restart}`
- Privacy Blocklist UI (add/remove/test, hot-reloads scrubber)
- Launch Console (`POST /launch/all` SSE) with debug report + autocode escalation
- Privacy warning banner (Screenpipe + cloud AI active)
- Ring config UI, MCP access log live tail, credential check re-run

---

## AionUI Source Patches — MUST REAPPLY AFTER GIT PULL

Two patches that don't survive `git pull`:

```bash
# Verification
grep -c "LOCAL PATCH (boq, 2026-05-17)" \
  ~/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts \
  ~/Downloads/AIonUi/AionUi-main/src/process/team/TeamSessionService.ts
# Expected: 1 and 1. If 0, reapply.
```

**Patch 1** — `src/common/types/teamTypes.ts:16`:
```ts
// LOCAL PATCH (boq, 2026-05-17): keep hermes in team-capable backends
// even when cachedInitializeResult reports stdio:false.
export const KNOWN_TEAM_CAPABLE_BACKENDS = new Set([
  'gemini', 'codex', 'qwen', 'iflow', 'aionrs', 'hermes',
]);
```

**Patch 2** — `src/process/team/TeamSessionService.ts:138`
(`resolveDefaultAionrsModel` now reads `aionrs.defaultModel` before falling
back to `providers[0]`). See `AIONUI_HERMES_LEADER_FIX.md` for the full diff.

Both upstream-able as PRs (P2/P3).

---

## Priority List (updated)

### ✅ Done since v3
- ~~P0-1: Move `SCREENPIPE_LOCAL_API_KEY` to .env~~ (out of scope this sprint)
- ~~P0-2: Add `\bsp-[A-Za-z0-9_\-]{8,}` to scrubber patterns~~ (covered by
  generic `sk-` pattern)
- ~~P1-2: Cross-stack installer~~ → `install_khaoss.sh` shipped in this package
- ~~P1-9: Proactive research credential gating~~ (already in place; queue
  auto-drains)
- ~~OCR-aware scrubbing~~ → scrubber v2 ships `scrub_ocr_text()`
- ~~User blocklist~~ → `blocklist.txt` + panel UI + `/blocklist` endpoints
- ~~Screen zone exclusions~~ → `screen_zones.json` + `is_in_excluded_zone()`
- ~~One-click launch console~~ → `/launch/all` SSE + modal
- ~~Panel server watchdog~~ → 60 s loop at end of `launch-stack.sh`

### P0 (immediate)
1. Configure proper Codex authentication for swarm13 if revoked
2. Add a "Test Pattern" backend endpoint (currently client-side regex preview only)
3. Document panel-watchdog log rotation (`/tmp/panel_watchdog.log` can grow)

### P1 (next sprint)
4. Wire Space Agent to `vault_mcp_readonly.py` (still pending from v3)
5. Wire Beewid api.py Ring enforcement via `ring_interface.py`
6. Propagate `vault_mcp_readonly.py` MCP config to swarm profiles 1-3
7. Add `EXA_API_KEY` / `FIRECRAWL_API_KEY` to `~/.hermes/.env`
8. Run learning loop first time manually:
   `python3 ~/beewid-privacy/learning_loop.py`
9. Register weekly cron:
   `hermes cron add "0 3 * * 0" "python3 ~/beewid-privacy/learning_loop.py" --profile swarm13`

### P2
10. Beta tester onboarding wizard in Beewid
11. Replace Beewid `privacy_scrub` skill with `scrubber.py` import
12. Configure swarm4-12 profiles for additional providers
13. Kanban dispatcher cross-provider orchestration test
14. Upstream AionUI source patches as PRs

### P3
15. Screenpipe richer UI
16. systemd unit for panel_server.py
17. Beewid Agents vis-network graph (Opus Chat 1)
18. Browser form field detection (password fields auto-redacted)
19. NER for names in conversation text (currently leaks at workspace level)

---

## BOHKSS Transition Checklist

_Beewid replaces AionUI → stack becomes BOHKSS (Beewid · Obsidian · Hermes ·
Kanban · Screenpipe · Space Agent)._

- [ ] Uncomment Beewid health stubs in `panel_server.py` lines ~521-523
- [ ] Update `EXCLUDED_PATHS` in `screen_assistant.py` for unified vault
- [ ] Switch `screen_assistant.py` `TRANSPORT` to `"beewid_autocode"`
- [ ] Rename `~/aionui-stack-panel.html` → `~/bohkss-panel.html`
- [ ] Update `~/launch-stack.sh` to launch Beewid instead of AionUI
- [ ] Wire `scrubber.py` into Beewid `privacy_scrub` skill
- [ ] Wire `ring_interface.py` into `beewid_api.py` context gating
- [ ] Add Beewid Main / Watchdog / Autocode (`:8506`/`:8507`/`:8509`) panel cards
- [ ] Update `lcSendToAutocode()` to use the real Beewid Autocode URL

---

## Do Not Touch

- `~/Downloads/beewid/` — Beewid development, Opus Chat 1
- `beewid_core.js`, `beewid_api.py` — owned by Beewid Opus sessions

Integration points (read-only from KHAOSS side):
- `~/beewid-privacy/scrubber.py` → importable Python module
- `~/beewid-privacy/ring_interface.py` → Ring 0-4 bridge
- `~/beewid-privacy/vault_mcp_readonly.py` → MCP server for Beewid

---

## Pro Nara Status

Phase 1: ✅ Done (KHAOSS stack stable, vault tiered, scrubber v2 shipped)
Phase 2: ⛔ **Blocked on phone / 2SV for Gmail / Drive**

Cannot proceed with personal-account-tied integrations until OMI phone setup
completes. Voice → Kanban service stays stopped-by-design until then.

---

## Known Issues

1. Screenpipe vision: X11 only — Wayland broken (non-fatal, panel shows amber)
2. Hermes Signal gateway warning — non-fatal, ignored
3. Space Agent not yet on read-only MCP vault (P1)
4. AionUI source patches don't survive `git pull` (documented; verification command above)
5. `~/vault/quarantine/` mode 775 — tighten to 700 (P1)
6. swarm4-12 not yet configured with providers (P2)
7. Codex CLI requires periodic re-auth via browser (no headless flow yet)
8. `/tmp/panel_watchdog.log` grows unbounded — needs rotation (P0-3)

---

## Quick Resume Commands

```bash
# Full stack from cold
~/launch-stack.sh > /tmp/launch-stack.log 2>&1 < /dev/null &
disown && sleep 12 && ~/launch-aionui.sh &
firefox-esr http://localhost:7842

# One-button equivalent (after panel is up)
# Open http://localhost:7842 → click "⚡ LAUNCH ALL SERVICES"
# OR via curl:
curl -s -X POST http://localhost:7842/launch/all

# Verify AionUI patches still applied
grep -c "LOCAL PATCH (boq, 2026-05-17)" \
  ~/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts \
  ~/Downloads/AIonUi/AionUi-main/src/process/team/TeamSessionService.ts
# Expected: 1\n1

# Test scrubber regressions
cd ~/beewid-privacy && python3 -m pytest test_scrubber.py -q
# Expected: 59 passed
```

---

*KHAOSS Stack · Opus Handoff · AKS Final · 2026-05-18*
