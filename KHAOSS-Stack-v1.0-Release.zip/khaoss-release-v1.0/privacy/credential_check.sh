#!/usr/bin/env bash
# credential_check.sh — verify Beewid credential isolation.
#
# Checks:
#   1. Every ~/.hermes/profiles/*/.env is mode 0600 (or absent)
#   2. Every ~/.hermes/profiles/*/config.yaml is mode 0600 (or absent)
#   3. Every ~/.hermes/profiles/*/ directory is mode 0700
#   4. ~/vault/ contains no strings matching the scrubber's API-key patterns
#
# Output: PASS/FAIL per check with details. Exit 0 if all pass, 1 otherwise.

set -u

PROFILES="$HOME/.hermes/profiles"
VAULT="$HOME/vault"
SCRUBBER_DIR="$HOME/beewid-privacy"

PASS=0
FAIL=0
pass() { echo "  ✓ PASS  $1"; PASS=$((PASS+1)); }
fail() { echo "  ✗ FAIL  $1"; FAIL=$((FAIL+1)); }
hdr()  { echo ""; echo "── $1 ──"; }

hdr "1. Hermes profile .env files (expect mode 600)"
if [ -d "$PROFILES" ]; then
    found=0
    while IFS= read -r -d '' f; do
        found=$((found+1))
        perm=$(stat -c '%a' "$f")
        [ "$perm" = "600" ] && pass "$f ($perm)" || fail "$f has perm $perm (expected 600)"
    done < <(find "$PROFILES" -name ".env" -type f -print0)
    [ $found -eq 0 ] && echo "  (no .env files found)"
else
    fail "$PROFILES does not exist"
fi

hdr "2. Hermes profile config.yaml files (expect mode 600)"
if [ -d "$PROFILES" ]; then
    found=0
    while IFS= read -r -d '' f; do
        found=$((found+1))
        perm=$(stat -c '%a' "$f")
        [ "$perm" = "600" ] && pass "$f ($perm)" || fail "$f has perm $perm (expected 600)"
    done < <(find "$PROFILES" -name "config.yaml" -type f -print0)
    [ $found -eq 0 ] && echo "  (no config.yaml files found)"
fi

hdr "3. Hermes profile directories (expect mode 700)"
if [ -d "$PROFILES" ]; then
    while IFS= read -r -d '' d; do
        perm=$(stat -c '%a' "$d")
        [ "$perm" = "700" ] && pass "$d ($perm)" || fail "$d has perm $perm (expected 700)"
    done < <(find "$PROFILES" -maxdepth 1 -mindepth 1 -type d -print0)
fi

hdr "4. Vault scan for committed API keys (scrubber patterns)"
if [ ! -d "$VAULT" ]; then
    fail "$VAULT does not exist"
elif [ ! -f "$SCRUBBER_DIR/scrubber.py" ]; then
    fail "$SCRUBBER_DIR/scrubber.py missing — cannot import patterns"
else
    # Use the scrubber's actual patterns so this check stays in sync with what
    # the scrubber will redact. Reports up to the first 20 hits.
    RESULT=$(VAULT="$VAULT" SCRUBBER_DIR="$SCRUBBER_DIR" python3 <<'PYEOF'
import os, sys
sys.path.insert(0, os.environ["SCRUBBER_DIR"])
from scrubber import _API_KEY_PATTERNS

vault = os.environ["VAULT"]
hits = []
SCANNED_EXT = (".md", ".txt", ".json", ".yaml", ".yml", ".env", ".ini", ".cfg", ".py", ".sh")
for root, _, files in os.walk(vault):
    for name in files:
        path = os.path.join(root, name)
        if not name.lower().endswith(SCANNED_EXT):
            continue
        try:
            size = os.path.getsize(path)
        except OSError:
            continue
        if size > 2_000_000:
            continue
        try:
            with open(path, "r", encoding="utf-8", errors="replace") as fh:
                content = fh.read()
        except OSError:
            continue
        for pat in _API_KEY_PATTERNS:
            for m in pat.finditer(content):
                hits.append((path, m.group(0)[:80]))
                if len(hits) >= 20:
                    break
            if len(hits) >= 20:
                break
        if len(hits) >= 20:
            break
    if len(hits) >= 20:
        break

print(len(hits))
for path, sample in hits:
    print(f"  {path}: {sample}")
PYEOF
)
    NUM=$(printf '%s\n' "$RESULT" | head -n1)
    DETAIL=$(printf '%s\n' "$RESULT" | tail -n +2)
    if [ "$NUM" = "0" ]; then
        pass "no API key matches in $VAULT"
    else
        fail "$NUM API key match(es) found in $VAULT:"
        printf '%s\n' "$DETAIL"
    fi
fi

echo ""
echo "════════════════════════════════════════"
echo "  Summary: $PASS PASS / $FAIL FAIL"
echo "════════════════════════════════════════"
[ $FAIL -eq 0 ] && exit 0 || exit 1
