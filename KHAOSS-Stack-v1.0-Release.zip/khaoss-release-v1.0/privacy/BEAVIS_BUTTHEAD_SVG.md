# Beavis & Butt-Head SVG — Approved Versions

_Approved 2026-05-18. Used in `~/aionui-stack-panel.html` debate card._

## Usage

Both SVGs are returned by `getBeavisSVG()` and `getButtHeadSVG()` in the panel HTML.
Jaw animation: add class `talking` to the `<svg>` element — the `.jm` group inside
animates via `.talking .jm { animation: jdrop 0.13s steps(2) infinite }`.

Wrapper div style:
```
display:flex;align-items:flex-end;justify-content:center;gap:40px;padding:20px 0 8px;min-height:160px;overflow:visible
```

---

## Beavis SVG

```xml
<svg id="beavis" width="95" height="145" viewBox="0 0 95 145" xmlns="http://www.w3.org/2000/svg" style="overflow:visible;flex-shrink:0">
  <rect x="12" y="106" width="56" height="36" rx="3" fill="#bf1a1a"/>
  <path d="M22 106 Q26 96 38 94 Q50 96 52 106Z" fill="#dba840"/>
  <path d="M16 90 Q12 70 14 52 Q16 32 26 20 Q36 10 50 12 Q64 14 70 28 Q76 42 72 60 Q68 76 60 86 Q50 94 36 94 Q24 94 16 90Z" fill="#e8b848"/>
  <ellipse cx="52" cy="30" rx="16" ry="14" fill="#f0c050"/>
  <path d="M14 58 Q10 30 18 12 Q32 4 50 8 Q62 10 68 22 Q56 14 40 14 Q24 16 16 32 Q12 44 14 58Z" fill="#e8c040"/>
  <path d="M13 56 Q6 38 10 20 Q16 36 18 52Z" fill="#f4d050"/>
  <path d="M16 48 Q8 26 14 8 Q22 26 22 46Z" fill="#f0c848"/>
  <path d="M22 42 Q16 18 24 2 Q32 20 30 40Z" fill="#f4d050"/>
  <path d="M30 36 Q26 10 36 0 Q42 18 40 36Z" fill="#f0c848"/>
  <path d="M40 32 Q38 6 48 -2 Q52 16 50 32Z" fill="#f4d050"/>
  <path d="M50 30 Q50 6 60 0 Q62 18 60 30Z" fill="#f0c848"/>
  <path d="M60 30 Q62 10 70 8 Q70 22 68 32Z" fill="#f4d050"/>
  <path d="M18 54 Q12 44 15 32 Q19 42 20 52Z" fill="#f8d858"/>
  <path d="M36 34 Q32 16 40 8 Q44 22 42 34Z" fill="#f8d858"/>
  <ellipse cx="62" cy="54" rx="5" ry="4.5" fill="white"/>
  <circle cx="64" cy="55" r="3" fill="#111"/>
  <circle cx="63" cy="54" r="0.9" fill="white"/>
  <path d="M57 51 Q62 48 68 51 Q66 55 62 55 Q57 55 57 51Z" fill="#e8b848"/>
  <path d="M57 48 Q63 45 69 49" fill="none" stroke="#b8880a" stroke-width="2.5" stroke-linecap="round"/>
  <path d="M70 65 Q78 62 80 68 Q80 74 74 75 Q68 74 68 69 Q68 64 70 65Z" fill="#d4a030"/>
  <ellipse cx="74" cy="73" rx="2.2" ry="1.6" fill="#a07820" opacity="0.8"/>
  <path d="M64 78 Q72 74 80 79 Q78 83 72 84 Q66 83 64 78Z" fill="#c89030"/>
  <path d="M52 80 Q66 76 80 81 L78 86 Q66 84 52 86Z" fill="#d8a840"/>
  <path d="M53 86 Q66 89 78 86 Q77 93 66 94 Q55 93 53 86Z" fill="#1a0808"/>
  <g class="jm" id="bv-jaw">
    <path d="M53 86 Q66 91 78 86 Q77 99 68 103 Q57 103 53 86Z" fill="#d0a038"/>
    <ellipse cx="65" cy="97" rx="7" ry="3" fill="#cc3333" opacity="0.9"/>
  </g>
  <ellipse cx="64" cy="102" rx="10" ry="5" fill="#cca038"/>
</svg>
```

---

## Butt-Head SVG

```xml
<svg id="butthead" width="110" height="145" viewBox="0 0 110 145" xmlns="http://www.w3.org/2000/svg" style="overflow:visible;flex-shrink:0">
  <rect x="22" y="106" width="68" height="36" rx="3" fill="#111"/>
  <path d="M32 106 Q36 94 54 92 Q70 94 74 106Z" fill="#b08838"/>
  <path d="M90 92 Q98 72 96 50 Q92 28 78 16 Q64 6 48 8 Q32 10 24 26 Q16 42 20 64 Q24 84 34 94 Q46 102 62 100 Q78 98 90 92Z" fill="#c09040"/>
  <ellipse cx="56" cy="30" rx="22" ry="18" fill="#cca048"/>
  <path d="M90 58 Q90 18 66 8 Q44 4 26 20 Q16 34 18 54 Q24 28 46 18 Q70 12 88 34Z" fill="#1c1c1c"/>
  <path d="M30 22 Q42 8 64 8 Q84 10 92 30 Q84 18 64 14 Q44 14 30 28Z" fill="#222"/>
  <path d="M88 42 Q96 56 96 70 Q92 60 88 52Z" fill="#1c1c1c"/>
  <path d="M86 55 Q94 68 92 80 Q88 70 84 62Z" fill="#222"/>
  <path d="M20 38 Q26 16 46 10 Q32 16 24 30 Q20 34 18 42Z" fill="#1a1a1a"/>
  <path d="M18 48 Q22 32 30 22 Q22 30 18 42Z" fill="#252525"/>
  <path d="M30 20 Q50 10 70 12" fill="none" stroke="#252525" stroke-width="2.5"/>
  <path d="M26 32 Q44 18 66 16" fill="none" stroke="#222" stroke-width="2"/>
  <path d="M22 44 Q36 26 58 20" fill="none" stroke="#222" stroke-width="1.5"/>
  <path d="M88 58 Q93 68 92 78 Q90 68 86 60Z" fill="#1a1a1a"/>
  <ellipse cx="24" cy="70" rx="6" ry="8" fill="#a07830"/>
  <ellipse cx="25" cy="70" rx="3.5" ry="5.5" fill="#906820"/>
  <ellipse cx="34" cy="58" rx="5.5" ry="5" fill="white"/>
  <circle cx="32" cy="59" r="3.2" fill="#080808"/>
  <circle cx="33" cy="58" r="0.9" fill="white"/>
  <path d="M28 55 Q34 50 40 55 Q38 60 34 60 Q28 60 28 55Z" fill="#c09040"/>
  <path d="M27 51 Q34 45 42 51" fill="none" stroke="#181818" stroke-width="5.5" stroke-linecap="round"/>
  <path d="M18 74 Q10 70 8 78 Q8 88 18 90 Q28 90 30 84 Q32 78 26 74 Q22 72 18 74Z" fill="#9a7020"/>
  <ellipse cx="14" cy="87" rx="3.5" ry="2.5" fill="#7a5518" opacity="0.9"/>
  <ellipse cx="22" cy="88" rx="3" ry="2.2" fill="#7a5518" opacity="0.7"/>
  <path d="M18 92 Q28 88 40 94 Q38 99 28 100 Q18 99 18 92Z" fill="#a88030"/>
  <path d="M28 96 Q46 92 60 97 L58 102 Q46 100 28 102Z" fill="#b89040"/>
  <path d="M29 102 Q46 106 58 102 Q57 110 44 111 Q30 110 29 102Z" fill="#1a0808"/>
  <g class="jm" id="bh-jaw">
    <path d="M29 102 Q46 108 58 102 Q57 118 46 122 Q32 122 29 102Z" fill="#a88030"/>
    <ellipse cx="43" cy="115" rx="9" ry="3.5" fill="#bb2222" opacity="0.9"/>
  </g>
  <ellipse cx="42" cy="120" rx="13" ry="6" fill="#a08030"/>
</svg>
```

---

## CSS Animation

```css
.talking .jm{animation:jdrop 0.13s steps(2) infinite}
@keyframes jdrop{0%{transform:translateY(0)}50%{transform:translateY(5px)}100%{transform:translateY(0)}}
```

## setDebateTalking

```javascript
function setDebateTalking(on){
  var b=document.getElementById('beavis');
  var bh=document.getElementById('butthead');
  if(!b||!bh)return;
  if(on){b.classList.add('talking');bh.classList.add('talking');}
  else{b.classList.remove('talking');bh.classList.remove('talking');}
}
```
