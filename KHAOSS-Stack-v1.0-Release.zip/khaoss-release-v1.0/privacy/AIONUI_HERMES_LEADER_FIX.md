# AionUI: Hermes Agent as Team Leader — durable fix

**Status**: working as of 2026-05-17 09:28 PDT
**Author**: Opus 4.7 (terminal CC), driven by Robert (boq)
**Scope**: makes Hermes Agent appear in the AionUI Team Leader dropdown reliably
across new team creations, regardless of `cachedInitializeResult` regressions, and
makes the `aionrs` preset path resolve to Hermes regardless of provider list
ordering.

---

## TL;DR

Two source patches + three config keys. With these in place, the Hermes Agent
preset assistant is permanently selectable as a Team Leader and the aionrs
backend (which it routes through) reliably spawns the aionrs CLI with
`--provider openai --base-url http://localhost:8642 --model swarm13`, hitting
the local Hermes `/v1/chat/completions` endpoint.

| Piece | What | Why |
|---|---|---|
| Source patch 1 | Add `'hermes'` to `KNOWN_TEAM_CAPABLE_BACKENDS` in `src/common/types/teamTypes.ts:16` | The CLI Hermes Agent stays in the dropdown even when its real `cachedInitializeResult` reports `mcpCapabilities.stdio: false` (Hermes 0.13.0 does) |
| Source patch 2 | Make `resolveDefaultAionrsModel` consult `aionrs.defaultModel` first in `src/process/team/TeamSessionService.ts:138` | Eliminates the `providers[0]` fragility — adding/reordering providers no longer drops Hermes out of the aionrs path |
| Config — provider | `model.config[*]` entry: `{platform:'custom', name:'Hermes Agent', baseUrl:'http://localhost:8642/v1', apiKey:'change-me-local-dev', model:['swarm13'], enabled:true, useModel:'swarm13'}` | The provider AionUI hands to the aionrs CLI |
| Config — preset | `assistants[*]` entry: `{id:'custom-hermes-agent', name:'Hermes Agent', presetAgentType:'aionrs', isPreset:true, enabled:true, models:['swarm13']}` | Visible "Hermes Agent" entry in the Team Leader dropdown's Preset Assistants section. `aionrs` is hardcoded team-capable, so this entry never disappears regardless of cached init results. |
| Config — pointer | `aionrs.defaultModel: {id:'<hermes provider id>', useModel:'swarm13'}` | Tells the patched `resolveDefaultAionrsModel` which provider to use, independent of list order |

---

## What broke last time (root cause)

1. The `aionrs` preset path calls `TeamSessionService.resolveDefaultAionrsModel()`.
2. Original code blindly returned `providers[0]` — the first enabled provider in
   `model.config`. With OpenAI entries earlier in the list, aionrs got
   `--provider openai --model gpt-5.5-pro`, which OpenAI rejects with
   "404: This is not a chat model and thus not supported in the v1/chat/completions endpoint".
3. Reordering Hermes to index 0 was a workaround, but **adding or re-adding a
   provider** could move it back, silently re-breaking the team leader.

Independently, when the preset path was switched to `presetAgentType: 'hermes'`
(direct ACP route), Hermes ran fine — but the first real session caused AionUI
to **overwrite the synthetic `acp.cachedInitializeResult['hermes']`** with the
real one from Hermes 0.13.0, which reports `mcpCapabilities.stdio: false`. That
made `isTeamCapableBackend('hermes', cachedInitResults)` return false, and
Hermes vanished from the Team Leader dropdown for any newly-created team.

Both regression vectors are now closed.

---

## The exact changes

### 1. Source patch — `src/common/types/teamTypes.ts:16`

```diff
-const KNOWN_TEAM_CAPABLE_BACKENDS = new Set(['gemini', 'claude', 'codex', 'aionrs']);
+// LOCAL PATCH (boq, 2026-05-17): added 'hermes'. Hermes 0.13.0 reports
+// mcpCapabilities.stdio=false in its ACP init result, which would otherwise
+// hide it from the Team Leader dropdown after the first conversation
+// overwrites the synthetic cache. Hermes ACP works fine in practice (proven
+// in production team sessions), so we treat it as known-capable.
+const KNOWN_TEAM_CAPABLE_BACKENDS = new Set(['gemini', 'claude', 'codex', 'aionrs', 'hermes']);
```

### 2. Source patch — `src/process/team/TeamSessionService.ts:138`

Insert a `savedAionrsModel` lookup before the `providers[0]` fallback:

```ts
// LOCAL PATCH (boq, 2026-05-17): honor `aionrs.defaultModel` instead of
// blindly returning providers[0]. Matches the pattern resolveDefaultGeminiModel
// already uses for `gemini.defaultModel`. Prevents the failure mode where
// adding any other provider drops Hermes out of providers[0] and the aionrs
// CLI ends up spawned with --provider openai --model gpt-5.5-pro (the
// "not a chat model" 404 from OpenAI).
const savedAionrsModel = await ProcessConfig.get('aionrs.defaultModel');
if (
  savedAionrsModel &&
  typeof savedAionrsModel === 'object' &&
  'id' in savedAionrsModel &&
  'useModel' in savedAionrsModel
) {
  const matched = providers.find(
    (p) => p.id === (savedAionrsModel as { id: string }).id
  );
  if (matched) {
    return {
      ...matched,
      useModel: (savedAionrsModel as { useModel: string }).useModel,
    } as TProviderWithModel;
  }
}
```

`bunx tsc --noEmit` reports **0 errors** with both patches applied.

### 3. Config — `~/.config/AionUi-Dev/config/aionui-config.txt`

(Format: `base64(URL-encode(JSON))`.) After decoding, the durable shape:

```jsonc
{
  "model.config": [
    {
      "id": "hermes-agent-668e280a",     // any stable id is fine
      "platform": "custom",
      "name": "Hermes Agent",
      "baseUrl": "http://localhost:8642/v1",
      "apiKey": "change-me-local-dev",
      "model": ["swarm13"],
      "modelEnabled": {"swarm13": true},
      "enabled": true,
      "useModel": "swarm13"
    },
    // ... other providers can follow in any order ...
  ],
  "assistants": [
    {
      "id": "custom-hermes-agent",
      "name": "Hermes Agent",
      "description": "...",
      "avatar": "🤖",
      "enabled": true,
      "isPreset": true,
      "isBuiltin": false,
      "presetAgentType": "aionrs",       // ← KEY: aionrs is hardcoded team-capable
      "models": ["swarm13"]
    },
    // ... other assistants ...
  ],
  "aionrs.defaultModel": {
    "id": "hermes-agent-668e280a",       // matches model.config[].id
    "useModel": "swarm13"
  },
  // acp.cachedInitializeResult is irrelevant for this path — aionrs is
  // team-capable via the hardcoded set, not via the cache.
}
```

---

## Backups taken (this session)

- `src/common/types/teamTypes.ts.bak_pre_hermes_durable_20260517_092618`
- `src/process/team/TeamSessionService.ts.bak_pre_hermes_durable_20260517_092618`
- `~/.config/AionUi-Dev/config/aionui-config.txt.bak_pre_durable_20260517_092618`

Earlier session backups (pre-aionrs, pre-hermes, pre-reorder, pre-hermesacp)
remain in the same directory for staircase rollback.

---

## How to verify it's working

1. AionUI logs: open `~/.config/AionUi-Dev/logs/2026-05-17.log` (or current date).
   - `[AgentRegistry] Completed in ...ms, found 5 agents: Aion CLI, Gemini CLI, Claude Code, Codex, Hermes Agent`
2. Quick chat endpoint sanity check:
   ```bash
   curl -s --max-time 10 http://localhost:8642/v1/chat/completions \
     -H "Authorization: Bearer change-me-local-dev" \
     -H "Content-Type: application/json" \
     -d '{"model":"swarm13","messages":[{"role":"user","content":"reply pong"}]}'
   ```
   Expect a JSON `chat.completion` with assistant content `pong` (or similar
   one-word). 200 OK.
3. Create a new team in AionUI → Team Leader dropdown:
   - CLI Agents → **Hermes Agent** (source patch 1 keeps this entry)
   - Preset Assistants → **Hermes Agent** (preset `presetAgentType='aionrs'`)
4. Send a test message. The aionrs CLI spawn (visible in stderr via the
   AionUI process log if you `tail -F /tmp/aionui_launch.log`) should include
   `--provider openai --base-url http://localhost:8642 --model swarm13`.

---

## If it breaks again — diagnostic checklist (in order)

1. **Is AionUI source still patched?**
   ```bash
   grep -c "LOCAL PATCH (boq, 2026-05-17)" \
     ~/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts \
     ~/Downloads/AIonUi/AionUi-main/src/process/team/TeamSessionService.ts
   ```
   Both should report `1`. If `0`, a `git pull` or AionUI update wiped the
   patches — reapply from this doc.

2. **Is the Hermes provider in `model.config` and `enabled: true`?**
   ```bash
   python3 -c "
   import base64, urllib.parse, json
   o = json.loads(urllib.parse.unquote(base64.b64decode(open('/home/boq/.config/AionUi-Dev/config/aionui-config.txt').read().strip()).decode()))
   for p in o['model.config']:
       if 'localhost:8642' in (p.get('baseUrl') or ''):
           print(p)
   "
   ```

3. **Is `aionrs.defaultModel` pointed at Hermes?** Same python decode, check
   `o['aionrs.defaultModel']`. If wrong, re-run the script at
   `/tmp/_aionui_durable_hermes.py` (or rewrite it from this doc).

4. **Is the preset's `presetAgentType` still `'aionrs'`?** Check via decode.
   If it drifted to `'gemini'`, `'codex'`, or anything else, the dropdown
   may still show Hermes (aionrs is team-capable) but the spawn will go
   elsewhere.

5. **Is Hermes' chat endpoint healthy?** Run the curl sanity check above.
   If Hermes returns "Unknown provider 'openai'", Hermes' own config
   (`~/.hermes/profiles/swarm13/config.yaml`) has a model provider it can't
   reach — that's a Hermes issue, not an AionUI issue.

6. **Did electron pick up source changes?**
   ```bash
   pkill -9 -f electron 2>/dev/null
   sleep 2
   rm -f ~/.config/AionUi-Dev/SingletonLock \
         ~/.config/AionUi-Dev/SingletonCookie \
         ~/.config/AionUi-Dev/SingletonSocket
   rm -rf ~/.config/AionUi-Dev/GPUCache/
   nohup ~/launch-aionui.sh > /tmp/aionui_launch.log 2>&1 &
   ```
   `electron-vite dev` rebuilds on file change, but a full restart is safer
   after source edits.

---

## Caveats

- **Source patches don't survive `git pull`.** If you update AionUI from
  upstream, both patches will be reverted silently. After any update, re-run
  the verification in step 1 and re-apply from this doc if needed. Consider
  upstreaming as a PR — both changes are small, well-motivated, and
  backward-compatible.
- **The `acp.cachedInitializeResult['hermes']` entry is now ignored by the
  team-capability check** (because of source patch 1). It still gets
  overwritten by AionUI on each Hermes ACP session, but that no longer
  affects dropdown visibility. The aionrs preset path doesn't read it at all.
- **If you delete the Hermes provider entry from Settings → Model and re-add
  it**, the new entry will get a fresh random `id`. The preset's
  `aionrs.defaultModel.id` will then be stale. Either update
  `aionrs.defaultModel.id` to match the new entry, or move the new entry to
  index 0 in `model.config` (the patched code falls back to `providers[0]`
  if `aionrs.defaultModel.id` doesn't match anything).
- **The `custom-hermes-agent` preset stores `presetAgentType: 'aionrs'`.
  Don't change it via the UI** — AionUI may not expose this field cleanly in
  the assistant editor, and editing the assistant in Settings could lose this
  field. If that happens, re-run `/tmp/_aionui_durable_hermes.py`.
- **Teams created BEFORE this fix have their leader agentType frozen** in
  the sqlite `teams` row (`~/.config/AionUi-Dev/aionui/aionui.db`). The
  preset edit only affects newly-created teams. To migrate an old team,
  update the `agents` JSON in the teams row directly, or just recreate the
  team in the UI.
