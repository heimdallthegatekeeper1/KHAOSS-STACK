#!/usr/bin/env python3
"""
voice_kanban.py — Voice-note-to-Kanban daemon for the KHAOSS stack.

Watches ~/obsidian-vault/ for new .md files whose filename contains "voice"
or "omi" (case-insensitive). When found, sends the file content to Hermes
(profile swarm13) to extract a structured Kanban task, then creates the task
via the Hermes Kanban API.

Processed files are tracked in ~/beewid-privacy/voice_kanban_seen.json so
we never re-process a file across restarts.

Stop with: kill $(cat ~/beewid-privacy/voice_kanban.pid)
"""

from __future__ import annotations

import json
import logging
import os
import re
import signal
import subprocess
import sys
import time
from datetime import datetime, timezone
from pathlib import Path

# ── Constants ─────────────────────────────────────────────────────────────────

HOME          = Path(os.path.expanduser("~"))
VAULT_DIR     = HOME / "obsidian-vault"
PRIVACY_DIR   = HOME / "beewid-privacy"
LOG_FILE      = PRIVACY_DIR / "voice_kanban.log"
PID_FILE      = PRIVACY_DIR / "voice_kanban.pid"
SEEN_FILE     = PRIVACY_DIR / "voice_kanban_seen.json"
RESULTS_FILE  = PRIVACY_DIR / "voice_kanban_results.jsonl"

HERMES_BIN      = "/home/boq/.local/bin/hermes"
HERMES_PROFILE  = "swarm13"
HERMES_TIMEOUT  = 60
POLL_INTERVAL   = 8
MAX_READ_CHARS  = 2000

VALID_ASSIGNEES = {"swarm1", "swarm2", "swarm3", "swarm13"}

# ── Logging ───────────────────────────────────────────────────────────────────

log = logging.getLogger("voice_kanban")
log.setLevel(logging.INFO)
_fmt = logging.Formatter("%(asctime)s %(levelname)-5s %(message)s", "%Y-%m-%dT%H:%M:%S")
_fh = logging.FileHandler(LOG_FILE, mode="a", encoding="utf-8")
_fh.setFormatter(_fmt)
log.addHandler(_fh)
_sh = logging.StreamHandler(sys.stderr)
_sh.setFormatter(_fmt)
log.addHandler(_sh)

# ── PID management ────────────────────────────────────────────────────────────

def _read_pid(path: Path) -> int | None:
    try:
        raw = path.read_text().strip()
        return int(raw) if raw.isdigit() else None
    except (OSError, ValueError):
        return None


def _alive(pid: int) -> bool:
    try:
        os.kill(pid, 0)
        return True
    except (OSError, ProcessLookupError):
        return False


def write_pid_file() -> None:
    existing = _read_pid(PID_FILE)
    if existing and _alive(existing):
        log.error("voice_kanban already running (PID %d) — refusing to start", existing)
        sys.exit(2)
    PID_FILE.parent.mkdir(parents=True, exist_ok=True)
    PID_FILE.write_text(f"{os.getpid()}\n")


def remove_pid_file() -> None:
    try:
        current = _read_pid(PID_FILE)
        if current == os.getpid():
            PID_FILE.unlink()
    except OSError:
        pass

# ── Seen-file persistence ─────────────────────────────────────────────────────

def load_seen() -> set[str]:
    """Load the set of already-processed file paths from disk."""
    try:
        data = json.loads(SEEN_FILE.read_text(encoding="utf-8"))
        if isinstance(data, list):
            return set(data)
    except (OSError, json.JSONDecodeError):
        pass
    return set()


def save_seen(seen: set[str]) -> None:
    """Persist the seen set to disk atomically."""
    tmp = SEEN_FILE.with_suffix(".tmp")
    try:
        tmp.write_text(json.dumps(sorted(seen), indent=2), encoding="utf-8")
        tmp.replace(SEEN_FILE)
    except OSError as exc:
        log.warning("could not save seen file: %s", exc)

# ── File scanning ─────────────────────────────────────────────────────────────

def is_voice_file(path: Path) -> bool:
    """Return True if the filename contains 'voice' or 'omi' (case-insensitive)."""
    name = path.name.lower()
    return "voice" in name or "omi" in name


def scan_vault(seen: set[str]) -> list[Path]:
    """Return new voice/omi .md files in VAULT_DIR not yet in seen."""
    new_files: list[Path] = []
    if not VAULT_DIR.is_dir():
        log.warning("vault directory not found: %s", VAULT_DIR)
        return new_files
    try:
        for p in VAULT_DIR.iterdir():
            if not p.is_file():
                continue
            if p.suffix.lower() != ".md":
                continue
            if not is_voice_file(p):
                continue
            if str(p) in seen:
                continue
            new_files.append(p)
    except OSError as exc:
        log.warning("vault scan failed: %s", exc)
    return new_files


def read_voice_file(path: Path) -> str:
    """Read up to MAX_READ_CHARS characters from the voice note."""
    try:
        text = path.read_text(encoding="utf-8", errors="replace")
        return text[:MAX_READ_CHARS]
    except OSError as exc:
        log.warning("could not read %s: %s", path, exc)
        return ""

# ── Hermes interaction ────────────────────────────────────────────────────────

def ask_hermes_for_task(content: str) -> str | None:
    """Send voice note content to hermes and return the raw response."""
    prompt = (
        'Convert this voice note to a structured Kanban task. '
        'Return JSON only: {"title": str, "assignee": str '
        '(one of: swarm1/swarm2/swarm3/swarm13), "priority": str '
        '(high/medium/low), "tenant": str, "notes": str} '
        f'Voice note: {content}'
    )
    try:
        result = subprocess.run(
            [HERMES_BIN, "--profile", HERMES_PROFILE, "-z", prompt],
            capture_output=True, text=True, timeout=HERMES_TIMEOUT,
        )
        if result.returncode != 0:
            log.warning(
                "hermes exited %d: %s",
                result.returncode, result.stderr.strip()[:300],
            )
            return None
        return result.stdout.strip() or None
    except FileNotFoundError:
        log.error("hermes binary not found at %s", HERMES_BIN)
        return None
    except subprocess.TimeoutExpired:
        log.warning("hermes timed out after %ds", HERMES_TIMEOUT)
        return None


def parse_task_json(raw: str) -> dict | None:
    """Extract and parse a JSON object from hermes output (tolerates markdown fences)."""
    # Strip markdown code fences if present
    text = raw.strip()
    fence_match = re.search(r"```(?:json)?\s*([\s\S]*?)```", text)
    if fence_match:
        text = fence_match.group(1).strip()

    # Find the first {...} block in case there's preamble text
    brace_match = re.search(r"\{[\s\S]*\}", text)
    if brace_match:
        text = brace_match.group(0)

    try:
        data = json.loads(text)
    except json.JSONDecodeError as exc:
        log.warning("JSON parse failed: %s — raw: %s", exc, raw[:200])
        return None

    if not isinstance(data, dict):
        log.warning("expected a JSON object, got %s", type(data).__name__)
        return None

    return data


def create_kanban_task(title: str, assignee: str, tenant: str) -> int:
    """Call hermes kanban create and return the exit code."""
    # Normalise assignee to a known value; fall back to swarm13
    if assignee not in VALID_ASSIGNEES:
        log.warning("unknown assignee %r — falling back to swarm13", assignee)
        assignee = "swarm13"

    try:
        result = subprocess.run(
            [
                HERMES_BIN, "kanban", "create", title,
                "--assignee", assignee,
                "--tenant", tenant,
                "--profile", HERMES_PROFILE,
            ],
            capture_output=True, text=True, timeout=HERMES_TIMEOUT,
        )
        if result.returncode != 0:
            log.warning(
                "kanban create exited %d: %s",
                result.returncode, result.stderr.strip()[:300],
            )
        else:
            log.info("kanban task created: %r → %s/%s", title, tenant, assignee)
        return result.returncode
    except FileNotFoundError:
        log.error("hermes binary not found at %s", HERMES_BIN)
        return 127
    except subprocess.TimeoutExpired:
        log.warning("hermes kanban create timed out")
        return 124

# ── Result logging ────────────────────────────────────────────────────────────

def append_result(source_file: Path, title: str, assignee: str, hermes_exit: int) -> None:
    """Append a JSON status line to the results JSONL file."""
    record = {
        "ts": datetime.now(tz=timezone.utc).isoformat(),
        "source_file": str(source_file),
        "title": title,
        "assignee": assignee,
        "hermes_exit": hermes_exit,
    }
    try:
        RESULTS_FILE.parent.mkdir(parents=True, exist_ok=True)
        with RESULTS_FILE.open("a", encoding="utf-8") as fh:
            fh.write(json.dumps(record) + "\n")
    except OSError as exc:
        log.warning("could not write results: %s", exc)

# ── Per-file processing ───────────────────────────────────────────────────────

def process_file(path: Path) -> None:
    """Run the full voice-note → kanban pipeline for a single file."""
    log.info("processing %s", path.name)

    content = read_voice_file(path)
    if not content.strip():
        log.info("file is empty, skipping: %s", path.name)
        return

    raw = ask_hermes_for_task(content)
    if raw is None:
        log.warning("no response from hermes for %s", path.name)
        # Record the failure so we don't retry forever
        append_result(path, "", "swarm13", -1)
        return

    task = parse_task_json(raw)
    if task is None:
        log.warning("could not parse task JSON for %s", path.name)
        append_result(path, "", "swarm13", -1)
        return

    title    = str(task.get("title", path.stem)).strip() or path.stem
    assignee = str(task.get("assignee", "swarm13")).strip()
    tenant   = str(task.get("tenant", "default")).strip()

    exit_code = create_kanban_task(title, assignee, tenant)
    append_result(path, title, assignee, exit_code)

# ── Signal handling ───────────────────────────────────────────────────────────

_STOP = False


def _on_signal(signum: int, _frame) -> None:
    global _STOP
    log.info("received signal %d, stopping", signum)
    _STOP = True

# ── Main loop ─────────────────────────────────────────────────────────────────

def run() -> int:
    signal.signal(signal.SIGTERM, _on_signal)
    signal.signal(signal.SIGINT,  _on_signal)

    PRIVACY_DIR.mkdir(parents=True, exist_ok=True)
    write_pid_file()

    try:
        # Seed seen: load persisted set + mark any existing vault voice files
        seen = load_seen()
        if VAULT_DIR.is_dir():
            for p in VAULT_DIR.iterdir():
                if p.is_file() and p.suffix.lower() == ".md" and is_voice_file(p):
                    seen.add(str(p))
        save_seen(seen)

        log.info(
            "voice_kanban started — watching %s (poll %ds, seen %d files)",
            VAULT_DIR, POLL_INTERVAL, len(seen),
        )

        while not _STOP:
            new_files = scan_vault(seen)
            for path in new_files:
                if _STOP:
                    break
                process_file(path)
                seen.add(str(path))
                save_seen(seen)

            if not _STOP:
                time.sleep(POLL_INTERVAL)

        return 0
    finally:
        remove_pid_file()
        log.info("voice_kanban stopped")


if __name__ == "__main__":
    sys.exit(run())
