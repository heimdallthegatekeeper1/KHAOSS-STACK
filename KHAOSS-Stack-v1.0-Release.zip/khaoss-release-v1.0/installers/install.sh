#!/usr/bin/env bash
set -euo pipefail

KHAOSS_VERSION="1.0.0"
KHAOSS_REPO="https://github.com/heimdallthegatekeeper1/KHAOSS-STACK"
INSTALL_DIR="$HOME/khaoss"
PRIVACY_DIR="$HOME/beewid-privacy"
VAULT_DIR="$HOME/vault"
OBSIDIAN_DIR="$HOME/obsidian-vault"

DRY_RUN=0
for arg in "$@"; do
  [[ "$arg" == "--dry-run" ]] && DRY_RUN=1
done

# semver_lt A B → true iff A < B (proper version-sort comparison)
semver_lt() {
  [ "$(printf '%s\n' "$1" "$2" | sort -V | head -1)" = "$1" ] && [ "$1" != "$2" ]
}

RED='\033[0;31m'; GREEN='\033[0;32m'; AMBER='\033[0;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

banner() {
  echo ""
  echo -e "${BOLD}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${BOLD}║         KHAOSS STACK INSTALLER v${KHAOSS_VERSION}           ║${NC}"
  echo -e "${BOLD}║   Kanban·Hermes·AionUI·Obsidian·Screenpipe·SA   ║${NC}"
  echo -e "${BOLD}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
}

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${AMBER}⚠${NC}  $1"; }
err()  { echo -e "  ${RED}✗${NC} $1"; }
info() { echo -e "  ${BLUE}►${NC} $1"; }
step() { echo -e "\n${BOLD}── $1 ──${NC}"; }

# Detect OS
detect_os() {
  if [[ "$OSTYPE" == "linux-gnu"* ]]; then
    if command -v apt-get &>/dev/null; then OS="debian"
    elif command -v pacman &>/dev/null; then OS="arch"
    elif command -v dnf &>/dev/null; then OS="fedora"
    else OS="linux"
    fi
  elif [[ "$OSTYPE" == "darwin"* ]]; then
    OS="macos"
  else
    OS="unknown"
  fi
  echo "$OS"
}

# Check prerequisites
check_prereqs() {
  step "Checking prerequisites"
  local MISSING=0

  # Python
  if command -v python3 &>/dev/null; then
    PY_VER=$(python3 -c 'import sys; print(f"{sys.version_info.major}.{sys.version_info.minor}")')
    ok "Python $PY_VER"
  else
    err "Python 3 not found"
    warn "Install from https://python.org/downloads"
    MISSING=$((MISSING+1))
  fi

  # Node
  if command -v node &>/dev/null; then
    NODE_VER=$(node --version)
    ok "Node.js $NODE_VER"
  else
    err "Node.js not found"
    warn "Install from https://nodejs.org (LTS recommended)"
    MISSING=$((MISSING+1))
  fi

  # npm
  if command -v npm &>/dev/null; then
    ok "npm $(npm --version)"
  else
    err "npm not found (should come with Node.js)"
    MISSING=$((MISSING+1))
  fi

  # Git
  if command -v git &>/dev/null; then
    ok "git $(git --version | awk '{print $3}')"
  else
    err "git not found"
    warn "Install from https://git-scm.com"
    MISSING=$((MISSING+1))
  fi

  # curl
  if command -v curl &>/dev/null; then
    ok "curl found"
  else
    err "curl not found"
    MISSING=$((MISSING+1))
  fi

  # Hermes
  if command -v hermes &>/dev/null; then
    HERMES_VER=$(hermes --version 2>/dev/null | grep -oP '\d+\.\d+\.\d+' | head -1 || echo "unknown")
    ok "Hermes $HERMES_VER"
    if [[ "$HERMES_VER" != "unknown" ]] && semver_lt "$HERMES_VER" "0.14.0"; then
      warn "Hermes 0.14.0+ required. Run: hermes update"
    fi
  else
    warn "Hermes not found — installing..."
    if curl -fsSL https://hermes.sh/install | bash; then
      ok "Hermes installed"
    else
      err "Hermes install failed — visit https://hermes.sh"
      MISSING=$((MISSING+1))
    fi
  fi

  # Codex CLI
  if command -v codex &>/dev/null; then
    ok "Codex CLI found"
  else
    warn "Codex CLI not found — installing..."
    if npm install -g @openai/codex &>/dev/null; then
      ok "Codex CLI installed"
    else
      err "Codex CLI install failed"
      warn "Run manually: npm install -g @openai/codex"
    fi
  fi

  # Python packages
  info "Checking Python packages..."
  PKGS="watchdog requests"
  for pkg in $PKGS; do
    if python3 -c "import $pkg" &>/dev/null; then
      ok "  python: $pkg"
    else
      info "Installing python: $pkg"
      python3 -m pip install $pkg --break-system-packages -q || \
        pip3 install $pkg -q || \
        warn "  Could not install $pkg — run: pip3 install $pkg"
    fi
  done

  # Screenpipe
  if command -v screenpipe &>/dev/null || [ -f "$HOME/Downloads/screenpipe-main/target/release/screenpipe" ]; then
    ok "Screenpipe found"
  else
    warn "Screenpipe not found"
    echo ""
    echo -e "  ${AMBER}Download Screenpipe from:${NC}"
    echo -e "  https://screenpipe.com"
    echo -e "  → Extract and place binary at ~/Downloads/screenpipe-main/target/release/screenpipe"
    echo -e "  → Or add to PATH and the launcher will find it"
    echo ""
  fi

  # AionUI
  if [ -d "$HOME/Downloads/AIonUi/AionUi-main" ]; then
    ok "AionUI found at ~/Downloads/AIonUi/AionUi-main"
    # Check source patches
    PATCH_COUNT=$(grep -c "LOCAL PATCH (boq" \
      "$HOME/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts" \
      "$HOME/Downloads/AIonUi/AionUi-main/src/process/team/TeamSessionService.ts" \
      2>/dev/null || echo "0")
    if [[ "$PATCH_COUNT" == "2" ]]; then
      ok "AionUI Hermes patches applied"
    else
      warn "AionUI Hermes patches missing — see docs/AIONUI_HERMES_LEADER_FIX.md"
    fi
  else
    warn "AionUI not found at ~/Downloads/AIonUi/AionUi-main"
    echo -e "  ${AMBER}Download from:${NC} https://github.com/aionui/aionui"
    echo -e "  → Extract to ~/Downloads/AIonUi/AionUi-main"
    echo -e "  → Run: cd ~/Downloads/AIonUi/AionUi-main && npm install"
  fi

  if [ $MISSING -gt 0 ]; then
    echo ""
    err "$MISSING required dependencies missing. Install them and re-run."
    exit 1
  fi
}

# Setup directories
setup_dirs() {
  step "Setting up directories"

  for dir in \
    "$INSTALL_DIR" \
    "$VAULT_DIR/raw" \
    "$VAULT_DIR/private" \
    "$VAULT_DIR/workspace" \
    "$VAULT_DIR/public" \
    "$VAULT_DIR/quarantine" \
    "$OBSIDIAN_DIR" \
    "$PRIVACY_DIR/_session_runs" \
    "$PRIVACY_DIR/_debate_runs" \
    "$PRIVACY_DIR/_learning_runs"; do
    mkdir -p "$dir"
    ok "$dir"
  done

  # Set vault permissions
  chmod 700 "$VAULT_DIR/raw" "$VAULT_DIR/private" "$VAULT_DIR/quarantine"
  chmod 750 "$VAULT_DIR/workspace"
  chmod 755 "$VAULT_DIR/public"
  ok "Vault permissions set"
}

# Deploy KHAOSS scripts
deploy_scripts() {
  step "Deploying KHAOSS scripts"

  # Clone or update repo
  if [ -d "$INSTALL_DIR/.git" ]; then
    info "Updating existing installation..."
    git -C "$INSTALL_DIR" pull --quiet
    ok "Updated to latest"
  else
    info "Cloning KHAOSS repo..."
    git clone "$KHAOSS_REPO" "$INSTALL_DIR" --quiet
    ok "Cloned to $INSTALL_DIR"
  fi

  # Copy beewid-privacy scripts
  info "Deploying privacy scripts..."
  PRIVACY_SCRIPTS="scrubber.py ring_interface.py vault_mcp_readonly.py \
    vault_watcher.py vault_import_sanitizer.py screen_assistant.py \
    session_memory.py proactive_research.py voice_kanban.py \
    learning_loop.py panel_server.py credential_check.sh test_scrubber.py"

  for s in $PRIVACY_SCRIPTS; do
    if [ -f "$INSTALL_DIR/privacy/$s" ]; then
      cp "$INSTALL_DIR/privacy/$s" "$PRIVACY_DIR/$s"
      ok "  $s"
    else
      warn "  $s not found in repo (add to privacy/ directory)"
    fi
  done

  # Copy launch scripts
  cp "$INSTALL_DIR/scripts/launch-stack.sh" "$HOME/launch-stack.sh"
  cp "$INSTALL_DIR/scripts/launch-aionui.sh" "$HOME/launch-aionui.sh"
  chmod +x "$HOME/launch-stack.sh" "$HOME/launch-aionui.sh"
  ok "Launch scripts deployed to ~/"

  # Copy configs if not existing
  for cfg in screen_zones.json blocklist.txt; do
    if [ ! -f "$PRIVACY_DIR/$cfg" ] && [ -f "$INSTALL_DIR/configs/$cfg" ]; then
      cp "$INSTALL_DIR/configs/$cfg" "$PRIVACY_DIR/$cfg"
      ok "  Config: $cfg"
    fi
  done
}

# Setup Hermes swarm profiles
setup_hermes() {
  step "Checking Hermes profiles"

  if hermes profile list 2>/dev/null | grep -q "swarm13"; then
    ok "swarm13 profile exists"
  else
    warn "swarm13 profile not found"
    echo ""
    echo -e "  ${AMBER}Create it with:${NC}"
    echo -e "  hermes auth login --provider openai-codex"
    echo -e "  hermes profile create swarm13 --provider openai-codex --model gpt-5.5"
    echo ""
  fi

  # Check API server
  if hermes config show --profile swarm13 2>/dev/null | grep -q "api_server"; then
    ok "swarm13 API server configured"
  else
    warn "Enable API server for AionUI integration:"
    echo -e "  hermes config set api_server.enabled true --profile swarm13"
    echo -e "  hermes config set api_server.key change-me-local-dev --profile swarm13"
  fi
}

# Run tests
run_tests() {
  step "Running smoke tests"
  bash "$HOME/khaoss/scripts/khaoss_tests.sh" 2>/dev/null || \
    warn "Some tests failed — run khaoss_tests.sh manually for details"
}

# Print completion
finish() {
  echo ""
  echo -e "${BOLD}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${BOLD}║           KHAOSS INSTALLATION COMPLETE          ║${NC}"
  echo -e "${BOLD}╠══════════════════════════════════════════════════╣${NC}"
  echo -e "${BOLD}║  1. bash ~/launch-stack.sh                       ║${NC}"
  echo -e "${BOLD}║  2. Open http://localhost:7842                   ║${NC}"
  echo -e "${BOLD}║  3. Click ⚡ LAUNCH ALL SERVICES                 ║${NC}"
  echo -e "${BOLD}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  Docs:    ~/khaoss/docs/README.md"
  echo -e "  Tests:   bash ~/khaoss/scripts/khaoss_tests.sh"
  echo -e "  Debug:   bash ~/khaoss/scripts/khaoss_debug.sh"
  echo -e "  Panel:   http://localhost:7842"
  echo ""
}

# Main
OS=$(detect_os)
banner
echo -e "  Detected OS: ${BOLD}$OS${NC}"
[[ $DRY_RUN -eq 1 ]] && echo -e "  ${AMBER}[dry-run mode]${NC} — no destructive actions"
check_prereqs
setup_dirs
if [[ $DRY_RUN -eq 0 ]]; then
  deploy_scripts
  setup_hermes
else
  echo "  [dry-run] skipping deploy_scripts and setup_hermes"
fi
if [[ $DRY_RUN -eq 0 ]]; then
  run_tests
else
  echo "  [dry-run] skipping tests"
fi
finish
