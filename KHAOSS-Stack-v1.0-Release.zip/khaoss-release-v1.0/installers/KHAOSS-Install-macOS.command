#!/bin/bash
# KHAOSS Stack Installer for macOS
# If blocked by Gatekeeper: right-click this file → Open → Open

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TIMEOUT=300  # 5 minutes

clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║      KHAOSS STACK INSTALLER v1.0 (macOS)       ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  If this takes more than 2 minutes, check INSTALL_HELP.md"
echo ""
read -p "  Press ENTER to begin (Ctrl+C to cancel)..."
echo ""

# Run with timeout detection
INSTALLER="$SCRIPT_DIR/install_macos.sh"
if [ ! -f "$INSTALLER" ]; then
  echo "  Downloading installer..."
  INSTALLER="/tmp/khaoss_install_macos.sh"
  curl -fsSL --max-time 30 \
    https://raw.githubusercontent.com/heimdallthegatekeeper1/KHAOSS-STACK/main/installers/install_macos.sh \
    -o "$INSTALLER" || {
    echo "  ERROR: Could not download installer."
    echo "  Check your internet connection or see INSTALL_HELP.md"
    read -p "  Press ENTER to close..."
    exit 1
  }
fi

# Run with timeout
chmod +x "$INSTALLER"
timeout $TIMEOUT bash "$INSTALLER"
EXIT_CODE=$?

echo ""
if [ $EXIT_CODE -eq 0 ]; then
  echo "╔══════════════════════════════════════════════════╗"
  echo "║      INSTALLATION COMPLETE!                     ║"
  echo "║  Run: bash ~/launch-stack.sh                    ║"
  echo "║  Open: http://localhost:7842                    ║"
  echo "╚══════════════════════════════════════════════════╝"
elif [ $EXIT_CODE -eq 124 ]; then
  echo "  TIMEOUT: Installation took over ${TIMEOUT}s."
  echo "  Running debug report..."
  bash "$SCRIPT_DIR/../scripts/khaoss_debug.sh" 2>/dev/null
  echo ""
  echo "  Paste /tmp/khaoss_debug_*.md into Claude or ChatGPT for help."
  echo "  See INSTALL_HELP.md for manual steps."
else
  echo "  Installation failed (exit code: $EXIT_CODE)"
  echo "  Running debug report..."
  bash "$SCRIPT_DIR/../scripts/khaoss_debug.sh" 2>/dev/null
  echo ""
  echo "  See INSTALL_HELP.md for help."
fi

read -p "  Press ENTER to close..."
