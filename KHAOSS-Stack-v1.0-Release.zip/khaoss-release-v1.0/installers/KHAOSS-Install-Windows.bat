@echo off
setlocal enabledelayedexpansion
title KHAOSS Stack Installer v1.0
color 0A
cls
echo.
echo  =================================================
echo  ^|      KHAOSS STACK INSTALLER v1.0             ^|
echo  ^|  Kanban x Hermes x AionUI x Obsidian x SP    ^|
echo  =================================================
echo.
echo  Starting installation... (timeout: 5 minutes)
echo  If this window hangs for 2+ minutes, see INSTALL_HELP.md
echo.

set TIMEOUT_DETECT=0
set START_TIME=%TIME%

REM Check WSL2 first (best experience)
wsl --version >nul 2>&1
if %ERRORLEVEL% EQU 0 (
    echo  [OK] WSL2 found - using Linux installer (recommended)
    echo.
    echo  Downloading and running KHAOSS installer in WSL2...
    echo  This may take 3-5 minutes on first run.
    echo.
    wsl -- bash -c "curl -fsSL https://raw.githubusercontent.com/heimdallthegatekeeper1/KHAOSS-STACK/main/installers/install.sh | bash"
    if %ERRORLEVEL% EQU 0 (
        echo.
        echo  =================================================
        echo  ^|        INSTALLATION SUCCESSFUL!              ^|
        echo  ^|  1. Open WSL terminal                        ^|
        echo  ^|  2. Run: bash ~/launch-stack.sh              ^|
        echo  ^|  3. Open: http://localhost:7842              ^|
        echo  =================================================
    ) else (
        echo.
        echo  [ERROR] Installation failed.
        echo  Run khaoss_debug.sh for diagnostics, then paste
        echo  the output into Claude or ChatGPT for help.
        echo  See: INSTALL_HELP.md for manual steps.
    )
    goto END
)

echo  [WARN] WSL2 not detected.
echo.
echo  RECOMMENDED: Install WSL2 for full KHAOSS support.
echo    1. Open PowerShell as Administrator
echo    2. Run: wsl --install
echo    3. Restart and run this installer again
echo.
echo  --- Checking native Windows dependencies ---
echo.
set MISSING=0

python --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [MISSING] Python 3 - https://python.org/downloads
    echo            (check "Add to PATH" during install)
    set /a MISSING+=1
) else (
    for /f "tokens=2" %%v in ('python --version 2^>^&1') do echo  [OK] Python %%v
)

node --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [MISSING] Node.js - https://nodejs.org (get LTS version)
    set /a MISSING+=1
) else (
    for /f %%v in ('node --version') do echo  [OK] Node.js %%v
)

git --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [MISSING] Git - https://git-scm.com
    set /a MISSING+=1
) else (
    echo  [OK] Git found
)

hermes --version >nul 2>&1
if %ERRORLEVEL% NEQ 0 (
    echo  [MISSING] Hermes - https://hermes.sh
    set /a MISSING+=1
) else (
    echo  [OK] Hermes found
)

echo.
if %MISSING% GTR 0 (
    echo  %MISSING% dependencies missing. Install them then re-run.
    echo  See docs\DEPENDENCIES.md for download links.
) else (
    echo  All dependencies found. Running PowerShell installer...
    PowerShell -ExecutionPolicy Bypass -File "%~dp0install.ps1"
)

:END
echo.
echo  STUCK? See INSTALL_HELP.md or run scripts\khaoss_debug.sh
echo.
pause
