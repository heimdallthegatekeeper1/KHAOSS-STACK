#!/usr/bin/env bash
set -euo pipefail

# KHAOSS macOS Installer
# Differences from Linux installer:
#   - Homebrew-based dependency management
#   - macOS-specific Screenpipe path (~/Library/Application Support/screenpipe)
#   - Vault at ~/khaoss-vault (avoids /Users/<n>/vault permission noise)
#   - launchd plist for auto-start instead of cron
#   - Gatekeeper quarantine handling for Electron apps
#   - AionUI may live at ~/Applications/AionUi or ~/Downloads/AIonUi
#   - CoreAudio (no ALSA), native windowing (no DISPLAY needed)

KHAOSS_VERSION="1.0.0"
KHAOSS_REPO="https://github.com/heimdallthegatekeeper1/KHAOSS-STACK"
INSTALL_DIR="$HOME/khaoss"
PRIVACY_DIR="$HOME/beewid-privacy"
VAULT_DIR="$HOME/khaoss-vault"
OBSIDIAN_DIR="$HOME/obsidian-vault"
SCREENPIPE_DIR="$HOME/Library/Application Support/screenpipe"
LAUNCH_AGENTS_DIR="$HOME/Library/LaunchAgents"

RED='\033[0;31m'; GREEN='\033[0;32m'; AMBER='\033[0;33m'
BLUE='\033[0;34m'; BOLD='\033[1m'; NC='\033[0m'

banner() {
  echo ""
  echo -e "${BOLD}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${BOLD}║      KHAOSS STACK INSTALLER v${KHAOSS_VERSION} (macOS)      ║${NC}"
  echo -e "${BOLD}║   Kanban·Hermes·AionUI·Obsidian·Screenpipe·SA   ║${NC}"
  echo -e "${BOLD}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
}

ok()   { echo -e "  ${GREEN}✓${NC} $1"; }
warn() { echo -e "  ${AMBER}⚠${NC}  $1"; }
err()  { echo -e "  ${RED}✗${NC} $1"; }
info() { echo -e "  ${BLUE}►${NC} $1"; }
step() { echo -e "\n${BOLD}── $1 ──${NC}"; }

require_macos() {
  if [[ "$OSTYPE" != "darwin"* ]]; then
    err "This installer only runs on macOS. Use install.sh for Linux."
    exit 1
  fi
  ok "macOS detected: $(sw_vers -productVersion)"
}

# Homebrew
ensure_homebrew() {
  step "Checking Homebrew"
  if command -v brew &>/dev/null; then
    ok "Homebrew $(brew --version | head -1 | awk '{print $2}')"
  else
    warn "Homebrew not found — installing..."
    /bin/bash -c "$(curl -fsSL https://raw.githubusercontent.com/Homebrew/install/HEAD/install.sh)"
    if [[ -f /opt/homebrew/bin/brew ]]; then
      eval "$(/opt/homebrew/bin/brew shellenv)"
    fi
    ok "Homebrew installed"
  fi
}

brew_install_if_missing() {
  local pkg="$1"
  local cmd="${2:-$1}"
  if command -v "$cmd" &>/dev/null; then
    ok "$pkg (already installed)"
  else
    info "Installing $pkg via Homebrew..."
    brew install "$pkg" || warn "Failed to install $pkg — try: brew install $pkg"
  fi
}

# Prerequisites
check_prereqs() {
  step "Checking prerequisites"
  brew_install_if_missing python python3
  brew_install_if_missing node node
  brew_install_if_missing git git
  brew_install_if_missing curl curl

  # Python packages
  info "Installing Python packages..."
  for pkg in watchdog requests; do
    if python3 -c "import $pkg" &>/dev/null; then
      ok "  python: $pkg"
    else
      python3 -m pip install "$pkg" --user -q || \
        pip3 install "$pkg" -q || \
        warn "  Could not install $pkg"
    fi
  done

  # Hermes
  if command -v hermes &>/dev/null; then
    ok "Hermes $(hermes --version 2>/dev/null | grep -oE '[0-9]+\.[0-9]+\.[0-9]+' | head -1 || echo unknown)"
  else
    warn "Hermes not found — installing..."
    curl -fsSL https://hermes.sh/install | bash || warn "Visit https://hermes.sh"
  fi

  # Codex CLI
  if command -v codex &>/dev/null; then
    ok "Codex CLI found"
  else
    info "Installing Codex CLI..."
    npm install -g @openai/codex &>/dev/null || \
      warn "Run manually: npm install -g @openai/codex"
  fi

  # Screenpipe
  if command -v screenpipe &>/dev/null || [ -d "$SCREENPIPE_DIR" ]; then
    ok "Screenpipe found"
  else
    warn "Screenpipe not found"
    echo -e "  ${AMBER}Download macOS DMG:${NC} https://screenpipe.com"
    echo -e "  → Drag to /Applications"
    echo -e "  → If Gatekeeper blocks: xattr -rd com.apple.quarantine /Applications/Screenpipe.app"
  fi

  # AionUI
  local AIONUI_PATH=""
  for candidate in \
    "$HOME/Applications/AionUi/AionUi-main" \
    "$HOME/Downloads/AIonUi/AionUi-main" \
    "$HOME/Downloads/AionUi/AionUi-main"; do
    if [ -d "$candidate" ]; then
      AIONUI_PATH="$candidate"
      break
    fi
  done
  if [ -n "$AIONUI_PATH" ]; then
    ok "AionUI found at $AIONUI_PATH"
    # If electron Gatekeeper-quarantined
    if xattr "$AIONUI_PATH" 2>/dev/null | grep -q "com.apple.quarantine"; then
      warn "AionUI is Gatekeeper-quarantined. Clearing..."
      xattr -rd com.apple.quarantine "$AIONUI_PATH" 2>/dev/null || \
        warn "  Run manually: xattr -rd com.apple.quarantine \"$AIONUI_PATH\""
    fi
  else
    warn "AionUI not found"
    echo -e "  ${AMBER}Download from:${NC} https://github.com/aionui/aionui"
    echo -e "  → Extract to ~/Applications/AionUi/AionUi-main"
    echo -e "  → cd ~/Applications/AionUi/AionUi-main && npm install"
  fi
}

setup_dirs() {
  step "Setting up directories"
  for dir in \
    "$INSTALL_DIR" \
    "$VAULT_DIR/raw" \
    "$VAULT_DIR/private" \
    "$VAULT_DIR/workspace" \
    "$VAULT_DIR/public" \
    "$VAULT_DIR/quarantine" \
    "$OBSIDIAN_DIR" \
    "$PRIVACY_DIR/_session_runs" \
    "$PRIVACY_DIR/_debate_runs" \
    "$PRIVACY_DIR/_learning_runs" \
    "$LAUNCH_AGENTS_DIR"; do
    mkdir -p "$dir"
    ok "$dir"
  done

  chmod 700 "$VAULT_DIR/raw" "$VAULT_DIR/private" "$VAULT_DIR/quarantine"
  chmod 750 "$VAULT_DIR/workspace"
  chmod 755 "$VAULT_DIR/public"
  ok "Vault permissions set"
}

deploy_scripts() {
  step "Deploying KHAOSS scripts"

  if [ -d "$INSTALL_DIR/.git" ]; then
    info "Updating existing installation..."
    git -C "$INSTALL_DIR" pull --quiet
  else
    info "Cloning KHAOSS repo..."
    git clone "$KHAOSS_REPO" "$INSTALL_DIR" --quiet
  fi
  ok "Repo at $INSTALL_DIR"

  PRIVACY_SCRIPTS="scrubber.py ring_interface.py vault_mcp_readonly.py \
    vault_watcher.py vault_import_sanitizer.py screen_assistant.py \
    session_memory.py proactive_research.py voice_kanban.py \
    learning_loop.py panel_server.py credential_check.sh test_scrubber.py"

  for s in $PRIVACY_SCRIPTS; do
    if [ -f "$INSTALL_DIR/privacy/$s" ]; then
      cp "$INSTALL_DIR/privacy/$s" "$PRIVACY_DIR/$s"
      ok "  $s"
    fi
  done

  for ls in launch-stack.sh launch-aionui.sh; do
    if [ -f "$INSTALL_DIR/scripts/$ls" ]; then
      cp "$INSTALL_DIR/scripts/$ls" "$HOME/$ls"
      chmod +x "$HOME/$ls"
    fi
  done
  ok "Launch scripts deployed to ~/"
}

# launchd plist for auto-start on login (replaces cron)
install_launchd() {
  step "Installing launchd plist"

  local plist="$LAUNCH_AGENTS_DIR/com.khaoss.stack.plist"
  cat >"$plist" <<PLIST
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
  <key>Label</key><string>com.khaoss.stack</string>
  <key>ProgramArguments</key>
  <array>
    <string>/bin/bash</string>
    <string>$HOME/launch-stack.sh</string>
  </array>
  <key>RunAtLoad</key><true/>
  <key>KeepAlive</key><false/>
  <key>StandardOutPath</key><string>$HOME/khaoss-stack.log</string>
  <key>StandardErrorPath</key><string>$HOME/khaoss-stack.err</string>
</dict>
</plist>
PLIST
  ok "Wrote $plist"
  info "Enable auto-start on login:"
  echo -e "    launchctl load $plist"
  info "Disable:"
  echo -e "    launchctl unload $plist"
}

setup_hermes() {
  step "Checking Hermes profiles"
  if hermes profile list 2>/dev/null | grep -q "swarm13"; then
    ok "swarm13 profile exists"
  else
    warn "swarm13 profile missing"
    echo -e "  hermes auth login --provider openai-codex"
    echo -e "  hermes profile create swarm13 --provider openai-codex --model gpt-5.5"
  fi
}

finish() {
  echo ""
  echo -e "${BOLD}╔══════════════════════════════════════════════════╗${NC}"
  echo -e "${BOLD}║         KHAOSS macOS INSTALL COMPLETE            ║${NC}"
  echo -e "${BOLD}╠══════════════════════════════════════════════════╣${NC}"
  echo -e "${BOLD}║  1. bash ~/launch-stack.sh                       ║${NC}"
  echo -e "${BOLD}║  2. Open http://localhost:7842                   ║${NC}"
  echo -e "${BOLD}║  3. Auto-start: launchctl load ~/Library/...     ║${NC}"
  echo -e "${BOLD}╚══════════════════════════════════════════════════╝${NC}"
  echo ""
  echo -e "  Vault:    $VAULT_DIR"
  echo -e "  Panel:    http://localhost:7842"
  echo -e "  Logs:     ~/khaoss-stack.log"
  echo ""
}

banner
require_macos
ensure_homebrew
check_prereqs
setup_dirs
deploy_scripts
install_launchd
setup_hermes
finish
