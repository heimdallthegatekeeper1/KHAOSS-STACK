#!/usr/bin/env bash
# KHAOSS Stack Installer for Linux
# chmod +x this file then double-click or run: ./KHAOSS-Install-Linux.sh

SCRIPT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"
TIMEOUT=300

clear
echo ""
echo "╔══════════════════════════════════════════════════╗"
echo "║      KHAOSS STACK INSTALLER v1.0 (Linux)       ║"
echo "╚══════════════════════════════════════════════════╝"
echo ""
echo "  Timeout: ${TIMEOUT}s. If stuck, see INSTALL_HELP.md"
echo ""

if [ "$EUID" -eq 0 ]; then
  echo "  WARNING: Running as root. Recommend running as normal user."
  read -p "  Continue anyway? [y/N] " yn
  [[ "$yn" != "y" && "$yn" != "Y" ]] && exit 1
fi

read -p "  Press ENTER to begin (Ctrl+C to cancel)..."
echo ""

INSTALLER="$SCRIPT_DIR/install.sh"
[ ! -f "$INSTALLER" ] && \
  curl -fsSL --max-time 30 \
    https://raw.githubusercontent.com/heimdallthegatekeeper1/KHAOSS-STACK/main/installers/install.sh \
    -o /tmp/khaoss_install.sh && INSTALLER=/tmp/khaoss_install.sh

chmod +x "$INSTALLER"

# Background the installer, watch for timeout
timeout $TIMEOUT bash "$INSTALLER"
EXIT_CODE=$?

echo ""
if [ $EXIT_CODE -eq 0 ]; then
  echo "  ✓ Installation complete!"
  echo "  Run: bash ~/launch-stack.sh"
  echo "  Open: http://localhost:7842"
elif [ $EXIT_CODE -eq 124 ]; then
  echo "  ✗ TIMEOUT after ${TIMEOUT}s"
  echo ""
  echo "  Generating debug report..."
  bash "$SCRIPT_DIR/../scripts/khaoss_debug.sh" 2>/dev/null
  echo ""
  echo "  NEXT STEPS:"
  echo "  1. Find your debug file: ls /tmp/khaoss_debug_*.md"
  echo "  2. Paste it into: claude (Terminal CC), ChatGPT, or claude.ai"
  echo "  3. Ask: 'Fix my KHAOSS installation errors'"
  echo "  OR: See INSTALL_HELP.md for manual steps"
else
  echo "  ✗ Installation failed (exit $EXIT_CODE)"
  bash "$SCRIPT_DIR/../scripts/khaoss_debug.sh" 2>/dev/null
  echo ""
  echo "  Paste /tmp/khaoss_debug_*.md into an AI for guided fixes."
fi

read -p "  Press ENTER to close..."
