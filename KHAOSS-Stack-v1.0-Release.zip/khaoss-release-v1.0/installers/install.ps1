#Requires -RunAsAdministrator
$ErrorActionPreference = "Stop"
$KHAOSS_VERSION = "1.0.0"
$INSTALL_DIR = "$env:USERPROFILE\khaoss"
$PRIVACY_DIR = "$env:USERPROFILE\beewid-privacy"
$VAULT_DIR = "$env:USERPROFILE\vault"

function Write-Step($msg)  { Write-Host "`n── $msg ──" -ForegroundColor Cyan }
function Write-OK($msg)    { Write-Host "  ✓ $msg" -ForegroundColor Green }
function Write-Warn($msg)  { Write-Host "  ⚠ $msg" -ForegroundColor Yellow }
function Write-Err($msg)   { Write-Host "  ✗ $msg" -ForegroundColor Red }
function Write-Info($msg)  { Write-Host "  ► $msg" -ForegroundColor Blue }

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════╗" -ForegroundColor White
Write-Host "║      KHAOSS STACK INSTALLER v$KHAOSS_VERSION (Windows)   ║" -ForegroundColor White
Write-Host "╚══════════════════════════════════════════════════╝" -ForegroundColor White
Write-Host ""
Write-Warn "Windows support requires WSL2 for full functionality."
Write-Host "  Recommended: Install WSL2 and run the Linux installer."
Write-Host "  Run: wsl --install"
Write-Host "  Then in WSL: curl -fsSL https://raw.githubusercontent.com/heimdallthegatekeeper1/KHAOSS-STACK/main/installers/install.sh | bash"
Write-Host ""

# Check for WSL
Write-Step "Checking WSL2"
try {
    $wslVersion = wsl --version 2>$null
    Write-OK "WSL found"
    $runInWSL = Read-Host "  Run KHAOSS installer inside WSL2 now? (recommended) [Y/n]"
    if ($runInWSL -ne "n" -and $runInWSL -ne "N") {
        Write-Info "Launching in WSL2..."
        wsl -- bash -c "curl -fsSL https://raw.githubusercontent.com/heimdallthegatekeeper1/KHAOSS-STACK/main/installers/install.sh | bash"
        exit 0
    }
} catch {
    Write-Warn "WSL2 not found. Installing WSL2 first is strongly recommended."
    Write-Host "  Run: wsl --install"
    Write-Host "  Then restart and run this installer again."
    Write-Host ""
}

# Native Windows checks
Write-Step "Checking prerequisites (native Windows)"
$MISSING = 0

# Python
try {
    $pyVer = python --version 2>$null
    Write-OK $pyVer
} catch {
    Write-Err "Python not found"
    Write-Warn "Download from https://python.org/downloads (check 'Add to PATH')"
    $MISSING++
}

# Node
try {
    $nodeVer = node --version 2>$null
    Write-OK "Node.js $nodeVer"
} catch {
    Write-Err "Node.js not found"
    Write-Warn "Download from https://nodejs.org"
    $MISSING++
}

# Git
try {
    $gitVer = git --version 2>$null
    Write-OK $gitVer
} catch {
    Write-Err "Git not found"
    Write-Warn "Download from https://git-scm.com"
    $MISSING++
}

# Hermes
$hermesPath = Get-Command hermes -ErrorAction SilentlyContinue
if ($hermesPath) {
    Write-OK "Hermes found"
} else {
    Write-Warn "Hermes not found"
    Write-Host "  Download from https://hermes.sh"
    $MISSING++
}

# Setup directories
Write-Step "Setting up directories"
$dirs = @(
    $INSTALL_DIR,
    "$VAULT_DIR\raw", "$VAULT_DIR\private",
    "$VAULT_DIR\workspace", "$VAULT_DIR\public", "$VAULT_DIR\quarantine",
    "$env:USERPROFILE\obsidian-vault",
    $PRIVACY_DIR
)
foreach ($dir in $dirs) {
    if (-not (Test-Path $dir)) { New-Item -ItemType Directory -Path $dir -Force | Out-Null }
    Write-OK $dir
}

# Screenpipe note
Write-Step "Screenpipe"
Write-Warn "Download Screenpipe from https://screenpipe.com"
Write-Host "  → Windows installer available on the Screenpipe website"

# AionUI note
Write-Step "AionUI"
if (Test-Path "$env:USERPROFILE\Downloads\AIonUi\AionUi-main") {
    Write-OK "AionUI found"
} else {
    Write-Warn "AionUI not found"
    Write-Host "  → Download from https://github.com/aionui/aionui"
    Write-Host "  → Extract to $env:USERPROFILE\Downloads\AIonUi\AionUi-main"
    Write-Host "  → Run: npm install"
}

if ($MISSING -gt 0) {
    Write-Host ""
    Write-Err "$MISSING dependencies missing. Install them and re-run."
    Write-Host ""
    Write-Host "  STRONGLY RECOMMENDED: Use WSL2 for the best experience."
    Write-Host "  Run: wsl --install"
    exit 1
}

Write-Host ""
Write-Host "╔══════════════════════════════════════════════════╗" -ForegroundColor Green
Write-Host "║         KHAOSS SETUP COMPLETE (Windows)          ║" -ForegroundColor Green
Write-Host "║  Start services via WSL2 for best results        ║" -ForegroundColor Green
Write-Host "║  Panel: http://localhost:7842                    ║" -ForegroundColor Green
Write-Host "╚══════════════════════════════════════════════════╝" -ForegroundColor Green
