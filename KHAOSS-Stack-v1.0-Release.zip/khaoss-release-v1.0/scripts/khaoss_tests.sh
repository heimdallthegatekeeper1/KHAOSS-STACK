#!/usr/bin/env bash
# KHAOSS First-Start Test Suite
# Run after install_khaoss.sh
echo "╔══════════════════════════════════════╗"
echo "║      KHAOSS FIRST-START TESTS        ║"
echo "╚══════════════════════════════════════╝"
PASS=0; FAIL=0

check() {
  local name="$1"; local cmd="$2"
  if eval "$cmd" &>/dev/null; then
    echo "  ✓ $name"; PASS=$((PASS+1))
  else
    echo "  ✗ $name FAILED"; FAIL=$((FAIL+1))
  fi
}

echo ""
echo "► Service health checks..."
check "Panel server :7842" "curl -sf http://localhost:7842/ | grep -q KHAOSS"
check "Hermes gateway :8642" "curl -sf http://localhost:8642/v1/models | grep -q swarm"
check "Hermes dashboard :9119" "curl -sf http://127.0.0.1:9119/api/status | grep -q version"
check "Screenpipe :3030" "curl -sf http://localhost:3030/health | grep -q status"
check "Vault workspace exists" "test -d $HOME/vault/workspace"
check "scrubber.py importable" "python3 -c 'import sys; sys.path.insert(0,\"$HOME/beewid-privacy\"); import scrubber'"
check "54+ tests pass" "cd $HOME/beewid-privacy && python3 -m pytest test_scrubber.py -q 2>/dev/null | grep -q passed"

echo ""
echo "► Feature tests..."
check "Screen assistant running" "pgrep -f screen_assistant.py"
check "Vault watcher running" "pgrep -f vault_watcher.py"
check "Sanitizer running" "pgrep -f vault_import_sanitizer.py"
check "Codex authenticated" "test -f $HOME/.codex/auth.json"
check "AionUI electron running" "pgrep -f electron | grep -q AionUi"

echo ""
echo "► Credential check..."
bash ~/beewid-privacy/credential_check.sh | tail -3

echo ""
echo "► Vault write test..."
echo "# KHAOSS test file" > ~/vault/workspace/khaoss_test_$(date +%s).md
sleep 3
COUNT=$(ls ~/vault/workspace/khaoss_test_*.md 2>/dev/null | wc -l)
if [ "$COUNT" -gt 0 ]; then
  echo "  ✓ Vault write successful"
  PASS=$((PASS+1))
else
  echo "  ✗ Vault write failed"
  FAIL=$((FAIL+1))
fi

echo ""
echo "════════════════════════════════════════"
echo "  Results: $PASS passed / $FAIL failed"
echo "════════════════════════════════════════"
if [ $FAIL -gt 0 ]; then
  echo ""
  echo "  Run the debug helper:"
  echo "  bash ~/khaoss-beta-package/scripts/khaoss_debug.sh"
fi
