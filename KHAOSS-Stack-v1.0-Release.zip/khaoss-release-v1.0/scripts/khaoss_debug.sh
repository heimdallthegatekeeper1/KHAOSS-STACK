#!/usr/bin/env bash
# KHAOSS Debug Report Generator
# Detects stuck/failed installations and generates AI-ready reports
TIMEOUT_SECONDS=120
OUT="/tmp/khaoss_debug_$(date +%Y%m%d_%H%M%S).md"
ISSUES=0

check_with_timeout() {
  local name="$1" cmd="$2" timeout="${3:-10}"
  local result
  result=$(timeout "$timeout" bash -c "$cmd" 2>&1)
  local exit_code=$?
  if [ $exit_code -eq 124 ]; then
    echo "- $name: TIMEOUT after ${timeout}s" >> "$OUT"
    ISSUES=$((ISSUES+1))
  elif [ $exit_code -ne 0 ]; then
    echo "- $name: FAILED (exit $exit_code)" >> "$OUT"
    echo "  \`\`\`" >> "$OUT"
    echo "  $result" | head -5 >> "$OUT"
    echo "  \`\`\`" >> "$OUT"
    ISSUES=$((ISSUES+1))
  else
    echo "- $name: OK" >> "$OUT"
  fi
}

cat > "$OUT" << HEADER
# KHAOSS Debug Report
Generated: $(date)
Machine: $(hostname) / $(uname -srm)
User: $(whoami)
Display: ${DISPLAY:-not set}
Shell: $SHELL

HEADER

echo "## Service Status" >> "$OUT"
check_with_timeout "Panel :7842" "curl -sf --max-time 5 http://localhost:7842/" 8
check_with_timeout "Hermes :8642" "curl -sf --max-time 5 http://localhost:8642/v1/models" 8
check_with_timeout "Hermes dashboard :9119" "curl -sf --max-time 5 http://127.0.0.1:9119/api/status" 8
check_with_timeout "Screenpipe :3030" "curl -sf --max-time 5 http://localhost:3030/health" 8

echo "" >> "$OUT"
echo "## Process Check" >> "$OUT"
for proc in panel_server vault_watcher vault_import_sanitizer screen_assistant \
            hermes screenpipe electron; do
  if pgrep -f "$proc" &>/dev/null; then
    echo "- $proc: RUNNING (PID $(pgrep -f "$proc" | head -1))" >> "$OUT"
  else
    echo "- $proc: NOT RUNNING" >> "$OUT"
    ISSUES=$((ISSUES+1))
  fi
done

echo "" >> "$OUT"
echo "## Dependency Check" >> "$OUT"
for cmd in python3 node npm git curl hermes codex; do
  if command -v "$cmd" &>/dev/null; then
    echo "- $cmd: $(command -v $cmd) ($(${cmd} --version 2>/dev/null | head -1))" >> "$OUT"
  else
    echo "- $cmd: NOT FOUND" >> "$OUT"
    ISSUES=$((ISSUES+1))
  fi
done

echo "" >> "$OUT"
echo "## Recent Errors" >> "$OUT"
echo "### Panel server log (last 20 lines)" >> "$OUT"
echo '```' >> "$OUT"
tail -20 /tmp/panel_server.log 2>/dev/null || echo "(no log found)" >> "$OUT"
echo '```' >> "$OUT"

echo "### Screenpipe log (last 10 lines)" >> "$OUT"
echo '```' >> "$OUT"
tail -10 ~/.screenpipe/screenpipe.log 2>/dev/null || echo "(no log found)" >> "$OUT"
echo '```' >> "$OUT"

echo "### Hermes dashboard log (last 10 lines)" >> "$OUT"
echo '```' >> "$OUT"
tail -10 /tmp/hermes-dashboard.log 2>/dev/null || echo "(no log found)" >> "$OUT"
echo '```' >> "$OUT"

echo "" >> "$OUT"
echo "## System Info" >> "$OUT"
echo "- Memory: $(grep MemFree /proc/meminfo 2>/dev/null || vm_stat 2>/dev/null | head -3)" >> "$OUT"
echo "- Disk: $(df -h ~ | tail -1)" >> "$OUT"
echo "- Python packages: $(pip3 list 2>/dev/null | grep -E 'watchdog|requests' || echo 'pip not available')" >> "$OUT"
echo "- AionUI patches: $(grep -c 'LOCAL PATCH' ~/Downloads/AIonUi/AionUi-main/src/common/types/teamTypes.ts 2>/dev/null || echo 'AionUI not found')" >> "$OUT"

echo "" >> "$OUT"
echo "## Issues Found: $ISSUES" >> "$OUT"
echo "" >> "$OUT"
echo "## AI Fix Prompt" >> "$OUT"
echo "Paste this entire file into Claude Code (cc), ChatGPT, or any AI:" >> "$OUT"
echo '```' >> "$OUT"
echo "I am installing the KHAOSS stack and hit errors. Here is my debug report." >> "$OUT"
echo "Please diagnose each issue and provide exact fix commands." >> "$OUT"
echo "Debug report follows:" >> "$OUT"
echo '```' >> "$OUT"

echo "Debug report: $OUT"
echo "Issues found: $ISSUES"
echo ""
if [ $ISSUES -gt 0 ]; then
  echo "Paste $OUT into an AI assistant for guided fixes."
  echo "Or run: cat $OUT | pbcopy (macOS) / xclip -selection clipboard < $OUT (Linux)"
fi
