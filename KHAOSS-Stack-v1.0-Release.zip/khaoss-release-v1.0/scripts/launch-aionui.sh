#!/bin/bash
# Cleanup stale locks before launch
rm -f ~/.config/AionUi-Dev/SingletonLock ~/.config/AionUi-Dev/SingletonCookie ~/.config/AionUi-Dev/SingletonSocket 2>/dev/null
rm -rf ~/.config/AionUi-Dev/GPUCache/ ~/.config/AionUi-Dev/GrShaderCache/ 2>/dev/null

cd ~/Downloads/AIonUi/AionUi-main
ELECTRON_DISABLE_GPU=1 \
ELECTRON_NO_SANDBOX=0 \
GDK_SCALE=1 \
GDK_DPI_SCALE=1 \
LIBGL_ALWAYS_SOFTWARE=1 \
npm run start
