#!/bin/bash
SCREENPIPE_BIN="$HOME/Downloads/screenpipe-main/target/release/screenpipe"
VAULT_WATCHER="$HOME/beewid-privacy/vault_watcher.py"
VAULT_PID_FILE="$HOME/beewid-privacy/vault_watcher.pid"

# ── Flag handling ─────────────────────────────────────────────────────
if [ "$1" = "--status" ]; then
  echo "=== KHAOSS Stack Status $(date +%H:%M:%S) ==="
  _svc(){ local n=$1 pat=$2 port=$3
    if pgrep -f "$pat" > /dev/null 2>&1; then printf "  %-22s \033[32m● running\033[0m" "$n"
    else printf "  %-22s \033[31m○ stopped\033[0m" "$n"; fi
    if [ -n "$port" ]; then
      if curl -s --max-time 1 "http://127.0.0.1:$port/" > /dev/null 2>&1 || \
         curl -s --max-time 1 "http://localhost:$port/"  > /dev/null 2>&1; then
        printf "  (port $port reachable)"
      else printf "  (port $port closed)"; fi
    fi; echo; }
  _svc "screenpipe"       "screenpipe"              "3030"
  _svc "hermes gateway"   "hermes-gateway"          "8642"
  _svc "hermes dashboard" "hermes.*dashboard"       "9119"
  _svc "vault_watcher"    "vault_watcher.py"        ""
  _svc "sanitizer"        "vault_import_sanitizer"  ""
  _svc "screen_assistant" "screen_assistant.py"     ""
  _svc "proactive_research" "proactive_research.py" ""
  _svc "voice_kanban"     "voice_kanban.py"         ""
  _svc "space_agent"      "space-agent"             "3000"
  _svc "aionui"           "electron"                "3002"
  _svc "panel_server"     "panel_server.py"         "7842"
  exit 0
fi

if [ "$1" = "--stop" ]; then
  echo "=== Stopping KHAOSS Stack ==="
  _stop(){ local n=$1 pat=$2
    if pgrep -f "$pat" > /dev/null 2>&1; then
      pkill -f "$pat" 2>/dev/null; echo "  stopped $n"; sleep 0.3
    else echo "  $n not running"; fi; }
  _stop "screen_assistant"   "screen_assistant.py"
  _stop "proactive_research" "proactive_research.py"
  _stop "voice_kanban"       "voice_kanban.py"
  _stop "space_agent"        "space-agent"
  _stop "aionui"             "electron"
  _stop "hermes dashboard"   "hermes.*dashboard"
  _stop "vault sanitizer"    "vault_import_sanitizer"
  _stop "vault watcher"      "vault_watcher.py"
  _stop "screenpipe"         "screenpipe"
  echo "  (panel_server and hermes gateway left running — restart them manually if needed)"
  exit 0
fi

WAIT_MODE=0
[ "$1" = "--wait" ] && WAIT_MODE=1

echo "── Screenpipe ──"
mkdir -p ~/.screenpipe
nohup "$SCREENPIPE_BIN" record --disable-audio --disable-telemetry \
  > ~/.screenpipe/screenpipe.log 2>&1 &
sleep 6
curl -s http://localhost:3030/health && echo " ← OK" || echo " ← FAILED (check ~/.screenpipe/screenpipe.log)"

echo "── Vault Watcher ──"
mkdir -p ~/vault/raw ~/vault/private ~/vault/workspace ~/vault/public
if [ -f "$VAULT_PID_FILE" ]; then
  _vpid=$(cat "$VAULT_PID_FILE" 2>/dev/null)
  if kill -0 "$_vpid" 2>/dev/null; then
    echo "vault_watcher already running (PID $_vpid) ← OK"
  else
    echo "stale PID file found, restarting vault_watcher"
    rm -f "$VAULT_PID_FILE"
    nohup python3 "$VAULT_WATCHER" >> ~/beewid-privacy/watcher.log 2>&1 &
    sleep 1
    echo "vault_watcher started (PID $(cat "$VAULT_PID_FILE" 2>/dev/null)) ← OK"
  fi
else
  nohup python3 "$VAULT_WATCHER" >> ~/beewid-privacy/watcher.log 2>&1 &
  sleep 1
  _vpid=$(cat "$VAULT_PID_FILE" 2>/dev/null)
  if [ -n "$_vpid" ] && kill -0 "$_vpid" 2>/dev/null; then
    echo "vault_watcher started (PID $_vpid) ← OK"
  else
    echo "vault_watcher FAILED to start ← check ~/beewid-privacy/watcher.log"
  fi
fi

echo "── Vault Import Sanitizer ──"
SANITIZER="$HOME/beewid-privacy/vault_import_sanitizer.py"
SANITIZER_PID_FILE="$HOME/beewid-privacy/vault_import_sanitizer.pid"
mkdir -p ~/obsidian-vault ~/vault/quarantine
if [ -f "$SANITIZER_PID_FILE" ]; then
  _spid=$(cat "$SANITIZER_PID_FILE" 2>/dev/null)
  if [ -n "$_spid" ] && kill -0 "$_spid" 2>/dev/null; then
    echo "vault_import_sanitizer already running (PID $_spid) ← OK"
  else
    echo "stale PID file, restarting vault_import_sanitizer"
    rm -f "$SANITIZER_PID_FILE"
    nohup python3 "$SANITIZER" >> ~/beewid-privacy/sanitizer.log 2>&1 &
    sleep 1
    _spid=$(cat "$SANITIZER_PID_FILE" 2>/dev/null)
    [ -n "$_spid" ] && echo "vault_import_sanitizer started (PID $_spid) ← OK" \
                     || echo "vault_import_sanitizer FAILED to start"
  fi
else
  nohup python3 "$SANITIZER" >> ~/beewid-privacy/sanitizer.log 2>&1 &
  sleep 1
  _spid=$(cat "$SANITIZER_PID_FILE" 2>/dev/null)
  [ -n "$_spid" ] && echo "vault_import_sanitizer started (PID $_spid) ← OK" \
                   || echo "vault_import_sanitizer FAILED to start (check ~/beewid-privacy/sanitizer.log)"
fi

echo "── Hermes ──"
hermes dashboard > /tmp/hermes-dashboard.log 2>&1 &
sleep 3
curl -s http://127.0.0.1:9119/api/status | python3 -c "import sys,json; print('Hermes OK:', json.load(sys.stdin)['version'])" 2>/dev/null

# ── HERMES DASHBOARD ─────────────────────────────
echo "── Hermes Dashboard ──"
if curl -s http://127.0.0.1:9119/api/status | grep -q version 2>/dev/null; then
  echo "  Dashboard already running at :9119"
else
  hermes dashboard > /tmp/hermes-dashboard.log 2>&1 &
  sleep 3
  if curl -s http://127.0.0.1:9119/api/status | grep -q version 2>/dev/null; then
    echo "  Dashboard started at :9119"
  else
    echo "  Dashboard failed — check /tmp/hermes-dashboard.log"
  fi
fi

echo "── AionUI ──"
cd ~/Downloads/AIonUi/AionUi-main && nohup npm run start > /tmp/aionui.log 2>&1 &
echo "AionUI launching..."

echo "── Proactive Research ──"
if [ -f "$HOME/beewid-privacy/proactive_research.py" ]; then
  if ! pgrep -f "proactive_research.py" > /dev/null; then
    nohup python3 "$HOME/beewid-privacy/proactive_research.py" \
      >> "$HOME/beewid-privacy/proactive_research.log" 2>&1 &
    echo "proactive_research started (PID $!)"
  else
    echo "proactive_research already running ← OK"
  fi
fi

echo "── Screen Assistant ──"
SA_SCRIPT="$HOME/beewid-privacy/screen_assistant.py"
SA_PID_FILE="$HOME/beewid-privacy/screen_assistant.pid"
if [ -f "$SA_PID_FILE" ]; then
  _sapid=$(cat "$SA_PID_FILE" 2>/dev/null)
  if [ -n "$_sapid" ] && kill -0 "$_sapid" 2>/dev/null; then
    echo "screen_assistant already running (PID $_sapid) ← OK"
  else
    echo "stale PID file, restarting screen_assistant"
    rm -f "$SA_PID_FILE"
    nohup python3 "$SA_SCRIPT" >> ~/beewid-privacy/screen_assistant_runtime.log 2>&1 &
    sleep 1
    _sapid=$(cat "$SA_PID_FILE" 2>/dev/null)
    [ -n "$_sapid" ] && echo "screen_assistant started (PID $_sapid) ← OK" \
                     || echo "screen_assistant FAILED to start (check ~/beewid-privacy/screen_assistant_runtime.log)"
  fi
else
  nohup python3 "$SA_SCRIPT" >> ~/beewid-privacy/screen_assistant_runtime.log 2>&1 &
  sleep 1
  _sapid=$(cat "$SA_PID_FILE" 2>/dev/null)
  [ -n "$_sapid" ] && echo "screen_assistant started (PID $_sapid) ← OK" \
                   || echo "screen_assistant FAILED to start"
fi

echo "── Stack Panel HTTP server ──"
PANEL_SERVER="$HOME/beewid-privacy/panel_server.py"
PANEL_PID_FILE="$HOME/beewid-privacy/panel_server.pid"
if [ -f "$PANEL_PID_FILE" ]; then
  _ppid=$(cat "$PANEL_PID_FILE" 2>/dev/null)
  if [ -n "$_ppid" ] && kill -0 "$_ppid" 2>/dev/null; then
    echo "panel_server already running (PID $_ppid) ← OK"
  else
    echo "stale PID file, restarting panel_server"
    rm -f "$PANEL_PID_FILE"
    nohup python3 "$PANEL_SERVER" >> /tmp/panel_server.log 2>&1 &
    sleep 1
  fi
else
  nohup python3 "$PANEL_SERVER" >> /tmp/panel_server.log 2>&1 &
  sleep 1
fi
curl -s --max-time 2 http://localhost:7842/ | grep -q "AIONUI" && echo "panel OK (http://localhost:7842)" || echo "panel FAILED (check /tmp/panel_server.log)"

# Panel server watchdog (background)
(while true; do
  if ! curl -s -o /dev/null -m 3 http://localhost:7842/; then
    echo "$(date) panel_server down, restarting..." >> /tmp/panel_watchdog.log
    pkill -f panel_server.py 2>/dev/null
    sleep 2
    DISPLAY=:0.0 nohup python3 ~/beewid-privacy/panel_server.py \
      > /tmp/panel_server.log 2>&1 &
  fi
  sleep 60
done) &
